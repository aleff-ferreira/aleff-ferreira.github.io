# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Linha de comando: python -m bmb <comando>."""
import argparse
import sys
import time
from pathlib import Path

from . import __version__, config, db
from .http import Cliente


def _log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def _lista(valor):
    return [x.strip() for x in valor.split(",") if x.strip()] if valor else None


def _servir(a):
    import uvicorn
    from .api import criar_app
    local = a.host in ("127.0.0.1", "localhost", "::1")
    if a.curadoria and not local:
        sys.exit("A curadoria escreve no banco e só roda em endereço local (127.0.0.1). Remova --host ou --curadoria.")
    if not config.DB_PATH.exists():
        sys.exit(f"Banco não encontrado em {config.DB_PATH}. Rode primeiro: python -m bmb construir")
    app = criar_app(curadoria_ativa=a.curadoria)
    base = f"http://{a.host}:{a.porta}"
    print(f"Site:  {base}/", flush=True)
    print(f"API:   {base}/api/docs", flush=True)
    if a.curadoria:
        print("Curadoria (guarde o token; ele vale só nesta execução):", flush=True)
        print(f"       {base}/curadoria/#token={app.state.token}", flush=True)
    uvicorn.run(app, host=a.host, port=a.porta, log_level="warning")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="bmb", description="Núcleo de dados do BioMapaBrasil")
    ap.add_argument("--versao", action="version", version=f"bmb {__version__}")
    sub = ap.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("construir", help="busca nas fontes e monta o banco (etapas retomáveis)")
    c.add_argument("--etapas", help="lista separada por vírgulas; padrão: todas")
    c.add_argument("--so", help="só estes nomes científicos (testes), separados por vírgulas")
    c.add_argument("--semente", help="outro arquivo de semente TOML")
    c.add_argument("--offline", action="store_true", help="usa só o cache em disco")

    ens = sub.add_parser("conformeros", help="preenche estruturas ausentes de pequenas moléculas públicas elegíveis")
    ens.add_argument("--limite", type=int, help="máximo de registros ausentes examinados")
    ens.add_argument("--processos", type=int, default=3)
    ens.add_argument("--id", type=int, action="append", help="restringe aos IDs indicados")
    ens.add_argument("--tempo-fragmento", type=int, default=0, help="limite RDKit em segundos por fragmento, 0 para usar só o limite de iterações")

    sub.add_parser("validar", help="confere os cinco princípios e as invariantes do banco")

    au = sub.add_parser("auditar", help="executa a auditoria científica completa nos nove eixos (WS1–WS9)")
    au.add_argument("--json", action="store_true", help="imprime o resultado estruturado em JSON")
    au.add_argument("--rapido", action="store_true", help="pula o round-trip RDKit das estruturas para verificação rápida")
    au.add_argument("--destino", help="pasta de pacotes exportados a conferir (padrão: plataforma/app/dados)")

    bm = sub.add_parser("benchmark", help="validação por amostragem (uso interno): amostra estratificada, concordância entre "
                                           "curadores e casamento de texto no Europe PMC")
    bm.add_argument("--rodada", default=None, help="nome da rodada (padrão: bmb.benchmark.RODADA_PADRAO)")
    bm.add_argument("--seed", type=int, default=20261115)
    bm.add_argument("--sem-europepmc", action="store_true", help="não consulta a API REST do Europe PMC")
    bm.add_argument("--destino", help="pasta para benchmark_validacao.json (padrão: nucleo/saida/interno; nunca app/dados)")
    bm.add_argument("--md", help="caminho do relatório Markdown (padrão: docs/dev/VALIDACAO_TECNICA.md)")

    m = sub.add_parser("midia", help="baixa miniaturas das imagens licenciadas e desenha as estruturas")
    m.add_argument("--so-estruturas", action="store_true")
    m.add_argument("--so-imagens", action="store_true")
    m.add_argument("--reavaliar", action="store_true", help="reavalia foco e enquadramento das imagens locais sem rede")

    e = sub.add_parser("exportar", help="gera os pacotes públicos (JSON, CSV, GeoJSON e DwC-A) e, em nucleo/saida/interno, o livro de retenções")
    e.add_argument("--destino", help="pasta de saída dos pacotes públicos (padrão: plataforma/app/dados)")
    e.add_argument("--forcar", action="store_true", help="exporta mesmo com erros de validação (só para depurar)")

    bp = sub.add_parser("banco-publico",
                        help="grava a cópia do banco só com os registros publicados (o arquivo SQLite que acompanha a Release)")
    bp.add_argument("--destino", required=True, help="arquivo SQLite a gravar; nunca o próprio banco de trabalho")

    sub.add_parser("relatorio", help="mostra contagens e cobertura do banco (relatório de construção, com as retenções por regra)")

    sub.add_parser("orcamento", help="confere o orçamento de desempenho do site (400 kbps)")

    r = sub.choices["relatorio"]
    r.add_argument("--md", help="grava o relatório completo, em Markdown, neste arquivo")

    s = sub.add_parser("servir", help="serve o site, a API de consulta e, se pedido, a curadoria local")
    s.add_argument("--porta", type=int, default=8765)
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--curadoria", action="store_true",
                   help="liga a curadoria e as rotas internas /api/quarentena e /api/benchmark (escreve no banco; só em endereço local, com token)")

    a = ap.parse_args(argv)
    if a.cmd == "servir":
        return _servir(a)
    if a.cmd == "orcamento":
        from . import orcamento
        _, falhas = orcamento.relatorio()
        return 1 if falhas else 0
    if a.cmd == "banco-publico":
        # A cópia começa apagando o arquivo de destino: o banco de trabalho nunca pode ser esse arquivo.
        if Path(a.destino).resolve() == config.DB_PATH.resolve():
            sys.exit(f"--destino é o próprio banco de trabalho ({config.DB_PATH}); escolha outro arquivo.")
    con = db.conectar()
    cli = Cliente(con, offline=getattr(a, "offline", False))
    try:
        if a.cmd == "construir":
            from .construir import construir
            construir(con, cli, _log, _lista(a.etapas), a.semente, _lista(a.so))
            _log(f"rede: {cli.estatisticas['rede']} · cache: {cli.estatisticas['cache']} · falhas: {cli.estatisticas['falhas']}")
        elif a.cmd == "conformeros":
            from .conformeros import preencher_ausentes
            preencher_ausentes(con, config.SAIDA_DIR, limite=a.limite, processos=a.processos, ids=a.id, tempo_fragmento=a.tempo_fragmento, log=_log)
        elif a.cmd == "validar":
            from .validar import validar, imprimir
            resultado = validar(con)
            imprimir(resultado, _log)
            return 0 if not resultado["erros"] else 1
        elif a.cmd == "auditar":
            import json
            from .auditar import executar_auditoria, formatar_resumo
            res = executar_auditoria(con, pasta_dados=a.destino, rapido=a.rapido)
            if a.json:
                print(json.dumps(res, ensure_ascii=False, indent=2))
            else:
                print(formatar_resumo(res))
            return 0 if res["ok"] else 1
        elif a.cmd == "benchmark":
            from . import benchmark
            benchmark.executar_e_salvar(
                con, cli=cli, pasta_dados=a.destino, caminho_md=a.md,
                rodada=a.rodada or benchmark.RODADA_PADRAO, seed=a.seed, consultar_europepmc=not a.sem_europepmc, log=_log,
            )
        elif a.cmd == "midia":
            from . import midia
            midia.executar(con, cli, _log, imagens=not a.so_estruturas, estruturas=not a.so_imagens, so_reavaliar=a.reavaliar)
        elif a.cmd == "exportar":
            from .exportar import pacotes
            pacotes.exportar_tudo(con, a.destino, _log, forcar=a.forcar)
        elif a.cmd == "banco-publico":
            from .exportar import banco_publico
            banco_publico.gerar(con, a.destino, _log)
        elif a.cmd == "relatorio":
            from .validar import relatorio
            print(relatorio(con))
            if a.md:
                from .relatorio import gravar_markdown
                gravar_markdown(con, a.md)
                _log(f"relatório gravado em {a.md}")
    finally:
        cli.fechar()
        con.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
