# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Conferências reproduzíveis sobre o banco e os pacotes exportados (`python -m bmb auditar`).

Dez eixos, além do validador de princípios:
  WS1.  Taxonomia, checklists nacionais (Flora e Funga do Brasil / CTFB) e sensibilidade do recorte;
  WS2.  Quimioinformática (round-trip RDKit SMILES -> InChIKey de 27 caracteres) e toxinologia;
  WS3.  Farmacologia (alvos ChEMBL, alertas PAINS e separação fase 4: secundário vs. ubíquo);
  WS4.  Literatura (retratações, erratas e cobertura bibliográfica);
  WS5.  Precisão cartográfica (projeção de Mercator e área esférica das células de lacunas);
  WS6.  Mídia (licenças, hashes SHA-256 e país de origem);
  WS7.  Governança (Portaria 344, nenhuma coordenada individual e arquivo Darwin Core);
  WS8.  Estratos, hidrografia, vias e geometrias 3D (hashes por item);
  WS9.  Universo taxonômico, procedência declarada e distribuição da espécie;
  WS10. Invariantes da migração 008 por família, métricas sem dupla contagem e arquivos das fotografias.
"""
import csv
import hashlib
import io
import json
import math
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from . import config, projecao, quimica, validar
from .conectores import chembl, gbif


def intervalo_wilson(sucessos, total, z=1.959963984540054):
    """Intervalo de confiança binomial exato de Wilson (95% por padrão). Devolve `(proporcao, inf, sup)`."""
    if total <= 0:
        return 0.0, 0.0, 0.0
    p = sucessos / total
    z2 = z * z
    denom = 1.0 + z2 / total
    centro = (p + z2 / (2.0 * total)) / denom
    margem = (z / denom) * math.sqrt((p * (1.0 - p) / total) + (z2 / (4.0 * total * total)))
    return round(p, 6), round(max(0.0, centro - margem), 6), round(min(1.0, centro + margem), 6)


def auditar_ws1_taxonomia(con):
    """WS1: invariantes taxonômicas, origem nativa/introduzida e revalidação aritmética do recorte."""
    taxa = [dict(r) for r in con.execute("SELECT * FROM taxon ORDER BY id").fetchall()]
    divergencias_recorte = []
    nao_especie = []
    estabelecimento = {"nativa": 0, "introduzida": 0, "indeterminada": 0, "nao_classificada": 0}
    ufs_por_taxon = {}
    for r in con.execute("SELECT taxon_id, uf_sigla, n FROM ocorrencia_uf"):
        ufs_por_taxon.setdefault(r["taxon_id"], {})[r["uf_sigla"]] = r["n"]

    for t in taxa:
        if t["rank"] != "SPECIES":
            nao_especie.append(t["nome"])
        est = t.get("origem_estabelecimento") or "nao_classificada"
        estabelecimento[est] = estabelecimento.get(est, 0) + 1
        if t["n_br"] is not None:
            por_uf = ufs_por_taxon.get(t["id"], {})
            com_uf = sum(por_uf.values())
            n_al = sum(v for k, v in por_uf.items() if k in config.UF_AMAZONIA_LEGAL)
            dist = {"n_br": t["n_br"], "n_al": n_al, "com_uf": com_uf, "sem_uf": t["n_br"] - com_uf}
            dec = gbif.decidir_recorte(dist, "2026-01-01")
            if dec["no_recorte"] != t["no_recorte"] or dec["predominio_al"] != t["predominio_al"] or n_al != t["n_al"]:
                divergencias_recorte.append({"id": t["id"], "nome": t["nome"]})

    colisoes_sinonimo = [
        {"sinonimo": r[0], "n_taxa": r[1]}
        for r in con.execute(
            "SELECT lower(nome), COUNT(DISTINCT taxon_id) FROM taxon_sinonimo GROUP BY 1 HAVING COUNT(DISTINCT taxon_id) > 1"
        ).fetchall()
    ]
    return {
        "total_taxons": len(taxa),
        "no_recorte": sum(1 for t in taxa if t["no_recorte"] == 1),
        "nao_especie": nao_especie,
        "divergencias_aritmetica_recorte": divergencias_recorte,
        "origem_estabelecimento": estabelecimento,
        "sinonimos_compartilhados_entre_taxa": colisoes_sinonimo,
        "ok": not nao_especie and not divergencias_recorte,
    }


def auditar_ws2_quimica_e_toxinas(con, rapido=False):
    """WS2: identidade estrutural RDKit (27-char InChIKey), massa molecular, SVGs e evidência Tox-Prot."""
    pequenas = [
        dict(r)
        for r in con.execute("SELECT id, nome, inchikey, smiles, massa, desenho FROM molecula WHERE tipo='pequena_molecula'").fetchall()
    ]
    divergencias_ik = []
    smiles_invalidos = []
    if not rapido:
        for m in pequenas:
            if not m["smiles"]:
                continue
            ok, calc = quimica.conferir_inchikey(m["smiles"], m["inchikey"])
            if calc is None:
                smiles_invalidos.append({"id": m["id"], "nome": m["nome"]})
            elif not ok:
                divergencias_ik.append({"id": m["id"], "nome": m["nome"], "esperado": m["inchikey"], "calculado": calc})

    tox = [
        dict(r)
        for r in con.execute(
            "SELECT id, texto, metodo FROM afirmacao WHERE tipo='funcao_toxina' AND estado NOT IN ('quarentena','rejeitado')"
        ).fetchall()
    ]
    exp = sum(1 for a in tox if "ECO:0000269" in (a["metodo"] or ""))
    subesp = sum(1 for a in tox if "subespécie " in (a["texto"] or ""))
    return {
        "pequenas_moleculas": len(pequenas),
        "verificacao_rdkit_executada": not rapido,
        "smiles_invalidos": smiles_invalidos,
        "divergencias_inchikey_27chars": divergencias_ik,
        "toxinas_ativas": len(tox),
        "toxinas_eco_experimental": exp,
        "toxinas_inferencia_nao_experimental": len(tox) - exp,
        "toxinas_com_nota_subespecie": subesp,
        "ok": not smiles_invalidos and not divergencias_ik,
    }


def auditar_ws3_farmacologia(con):
    """WS3: alvos ChEMBL sem atribuição, faixas de potência, PAINS e fármacos retirados vs. insumos ubíquos."""
    marcas = ",".join("?" * len(chembl.ALVOS_SEM_ATRIBUICAO))
    alvos_invalidos = con.execute(
        f"SELECT COUNT(*) FROM afirmacao a JOIN alvo l ON l.id=a.alvo_id "
        f"WHERE a.tipo='atividade_biologica' AND a.estado NOT IN ('quarentena','rejeitado') "
        f"AND lower(trim(l.nome)) IN ({marcas})",
        tuple(chembl.ALVOS_SEM_ATRIBUICAO),
    ).fetchone()[0]
    n_ativ = con.execute(
        "SELECT COUNT(*) FROM afirmacao WHERE tipo='atividade_biologica' AND estado NOT IN ('quarentena','rejeitado')"
    ).fetchone()[0]
    n_pains = con.execute("SELECT COUNT(*) FROM molecula WHERE alerta_pains IS NOT NULL").fetchone()[0]
    clin = [
        dict(r)
        for r in con.execute(
            "SELECT a.id, a.texto, m.nome, m.fase_retirado, m.categoria_clinica FROM afirmacao a "
            "JOIN molecula m ON m.id=a.molecula_id "
            "WHERE a.tipo='efeito_clinico_documentado' AND a.estado NOT IN ('quarentena','rejeitado')"
        ).fetchall()
    ]
    retirados_sem_aviso = [c["nome"] for c in clin if c["fase_retirado"] == 1 and "retirad" not in (c["texto"] or "").lower()]
    unknown_mec = [c["nome"] for c in clin if "mecanismo registrado: unknown" in (c["texto"] or "").lower()]
    return {
        "atividades_ativas": n_ativ,
        "alvos_provisorios_ativos": alvos_invalidos,
        "moleculas_com_alerta_pains": n_pains,
        "afirmacoes_clinicas": len(clin),
        "farmacos_secundarios": sum(1 for c in clin if c["categoria_clinica"] == "farmaco_secundario"),
        "metabolitos_ou_insumos_ubiquos": sum(1 for c in clin if c["categoria_clinica"] == "metabolito_ou_insumo"),
        "retirados_com_aviso": sum(1 for c in clin if c["fase_retirado"] == 1 and "retirad" in (c["texto"] or "").lower()),
        "retirados_sem_aviso": retirados_sem_aviso,
        "mecanismos_unknown_residuais": unknown_mec,
        "ok": alvos_invalidos == 0 and not retirados_sem_aviso and not unknown_mec,
    }


def auditar_ws4_literatura(con):
    """WS4: resolução bibliográfica, retratações e avisos de errata/corrigenda."""
    q = lambda s: con.execute(s).fetchone()[0]
    retratadas_ativas = q(
        "SELECT COUNT(*) FROM afirmacao a WHERE a.estado NOT IN ('quarentena','rejeitado') "
        "AND EXISTS (SELECT 1 FROM afirmacao_referencia x WHERE x.afirmacao_id=a.id) "
        "AND NOT EXISTS (SELECT 1 FROM afirmacao_referencia x JOIN referencia r ON r.id=x.referencia_id "
        "WHERE x.afirmacao_id=a.id AND r.retratada=0)"
    )
    return {
        "referencias_totais": q("SELECT COUNT(*) FROM referencia"),
        "resolvidas": q("SELECT COUNT(*) FROM referencia WHERE resolvida=1"),
        "retratadas": q("SELECT COUNT(*) FROM referencia WHERE retratada=1"),
        "com_aviso_errata_ou_preocupacao": q("SELECT COUNT(*) FROM referencia WHERE aviso IS NOT NULL"),
        "afirmacoes_ativas_sustentadas_so_por_retratada": retratadas_ativas,
        "afirmacoes_em_quarentena": q("SELECT COUNT(*) FROM afirmacao WHERE estado='quarentena'"),
        "ok": retratadas_ativas == 0,
    }


def auditar_ws5_cartografia(pasta_dados=None):
    """WS5: erro numérico da projeção de Mercator e coerência geométrica das células de lacunas."""
    pts = [(-73.99, -7.5), (-60.02, -3.12), (-48.49, -1.45), (-34.80, -7.15), (-53.2, -33.75), (-60.7, 5.27)]
    erro_max = 0.0
    for lon, lat in pts:
        x, y = projecao.proj(lon, lat)
        lon2, lat2 = projecao.inv(x, y)
        erro_max = max(erro_max, abs(lon - lon2), abs(lat - lat2))

    pasta = Path(pasta_dados or (config.APP_DIR / "dados"))
    erro_area_rel_max = 0.0
    n_celulas = 0
    arq_lac = pasta / "geo" / "lacunas.json"
    erro_grs80_rel_max = 0.0
    if arq_lac.exists():
        from .conectores import geometrias_oficiais as go
        lac = json.loads(arq_lac.read_text(encoding="utf-8"))
        cols = lac["colunas"]
        i_lon, i_lat, i_km2 = cols.index("lon"), cols.index("lat"), cols.index("km2")
        r_terra = 6371.0088
        passo_g = lac.get("passo_graus", 0.5)
        dlat = math.radians(passo_g)
        dlon = dlat
        for l in lac["linhas"]:
            n_celulas += 1
            lat_r = math.radians(l[i_lat])
            area_esf = (r_terra ** 2) * dlon * (math.sin(lat_r + dlat / 2) - math.sin(lat_r - dlat / 2))
            if area_esf > 0:
                erro_area_rel_max = max(erro_area_rel_max, abs(l[i_km2] - area_esf) / area_esf)
            area_grs80 = go.area_celula_05deg_km2(l[i_lon], l[i_lat], passo_g)
            if area_grs80 > 0:
                erro_grs80_rel_max = max(erro_grs80_rel_max, abs(l[i_km2] - area_grs80) / area_grs80)

    return {
        "mercator_erro_inversa_graus": erro_max,
        "celulas_lacunas": n_celulas,
        "erro_relativo_max_area_lacunas": round(erro_area_rel_max, 6),
        "erro_relativo_max_grs80": round(erro_grs80_rel_max, 6),
        "ok": erro_max < 1e-10 and erro_area_rel_max < 0.02,
    }


def auditar_ws6_midia(con):
    """WS6: integridade das miniaturas ativas, quarentena rastreável e país de registro."""
    q = lambda s: con.execute(s).fetchone()[0]
    sem_licenca = q("SELECT COUNT(*) FROM midia WHERE licenca NOT IN ('CC0','CC BY')")
    sem_hash = q("SELECT COUNT(*) FROM midia WHERE estado='ativo' AND arquivo IS NOT NULL AND arquivo_sha256 IS NULL")
    quar_invalida = q(
        "SELECT COUNT(*) FROM midia WHERE estado='quarentena' AND (arquivo IS NOT NULL OR motivo_quarentena IS NULL)"
    )
    return {
        "imagens_ativas": q("SELECT COUNT(*) FROM midia WHERE estado='ativo' AND arquivo IS NOT NULL"),
        "imagens_em_quarentena": q("SELECT COUNT(*) FROM midia WHERE estado='quarentena'"),
        "imagens_com_pais_identificado": q("SELECT COUNT(*) FROM midia WHERE estado='ativo' AND arquivo IS NOT NULL AND pais IS NOT NULL"),
        "imagens_fora_do_brasil": q("SELECT COUNT(*) FROM midia WHERE estado='ativo' AND arquivo IS NOT NULL AND pais IS NOT NULL AND pais <> 'BR'"),
        "violacoes_licenca_ou_hash": sem_licenca + sem_hash + quar_invalida,
        "ok": (sem_licenca + sem_hash + quar_invalida) == 0,
    }


def auditar_ws7_governanca_e_dwca(con, pasta_dados=None):
    """WS7: triagem Portaria 344, isolamento de licença CC BY-SA 3.0 e integridade do pacote DwC-A."""
    proscritas = []
    proscritas_quarentena = []
    precursores = []
    ativas_sql = {
        r[0]
        for r in con.execute(
            "SELECT DISTINCT molecula_id FROM afirmacao "
            "WHERE molecula_id IS NOT NULL AND estado NOT IN ('quarentena','rejeitado') AND classe_acesso='publico'"
        )
    }
    for r in con.execute("SELECT id, nome, inchikey, controle_regulatorio FROM molecula WHERE inchikey IS NOT NULL"):
        p = quimica.substancia_proscrita_344(r["inchikey"])
        if p:
            item_p = {"id": r["id"], "nome": r["nome"], "lista": p[0]}
            if r["id"] in ativas_sql:
                proscritas.append(item_p)
            else:
                proscritas_quarentena.append(item_p)
        c = quimica.controle_portaria_344(r["inchikey"])
        if c:
            precursores.append({"id": r["id"], "nome": r["nome"], "controle_registrado": bool(r["controle_regulatorio"])})

    pasta = Path(pasta_dados or (config.APP_DIR / "dados"))
    arq_zip = pasta / "dwca" / "biomapabrasil_dwca.zip"
    dwca_ok = True
    dwca_detalhe = {"presente": arq_zip.exists()}
    if arq_zip.exists():
        with zipfile.ZipFile(arq_zip) as z:
            ET.fromstring(z.read("meta.xml"))
            ET.fromstring(z.read("eml.xml"))
            tax_ids = {
                l[0]
                for l in list(csv.reader(io.StringIO(z.read("taxon.txt").decode("utf-8")), delimiter="\t"))[1:]
                if l
            }
            orfaos = 0
            vazamento_chembl = False
            for ext in ("resourcerelationship.txt", "measurementorfact.txt", "reference.txt"):
                conteudo = z.read(ext).decode("utf-8")
                if "chembl" in conteudo.lower():
                    vazamento_chembl = True
                for l in list(csv.reader(io.StringIO(conteudo), delimiter="\t"))[1:]:
                    if l and l[0] not in tax_ids:
                        orfaos += 1
            dwca_ok = (orfaos == 0) and (not vazamento_chembl)
            dwca_detalhe.update({"taxons": len(tax_ids), "coreid_orfaos": orfaos, "vazamento_chembl_cc_by_sa": vazamento_chembl})

    precursores_sem_nota = [x["nome"] for x in precursores if not x["controle_registrado"]]
    return {
        "substancias_proscritas_344": proscritas,
        "substancias_proscritas_344_retidas_quarentena": proscritas_quarentena,
        "precursores_controlados_344": precursores,
        "precursores_sem_nota_regulatoria": precursores_sem_nota,
        "dwca": dwca_detalhe,
        "ok": not proscritas and not precursores_sem_nota and dwca_ok,
    }


def auditar_ensembles_publicados(con, pasta, rapido=False):
    """Confere cada intervalo citado pelo catálogo, incluindo a identidade de cada SDF no modo completo."""
    import gzip
    import re
    import zlib
    from rdkit import Chem, rdBase
    from .conformeros import mesma_identidade

    contagens = {"ensembles": 0, "conformeros": 0, "sdf_revalidados": 0, "erros": 0}
    banco = {r["id"]: r for r in con.execute("SELECT e.id, e.molecula_id, e.geometria_sha256, m.smiles, m.inchikey "
              "FROM estrutura_3d e JOIN molecula m ON m.id=e.molecula_id WHERE e.arquivo_geometria LIKE 'estruturas3d/ens_%'")}
    ref = re.compile(r"(estruturas3d_ensembles/[0-9a-f]{2}\.zip)#(\d+):(\d+):([0-9a-f]{16})")
    for lote in Path(pasta, "moleculas_lotes").glob("*.json"):
        for mol in json.loads(lote.read_bytes()).values():
            for estrutura in mol.get("estruturas_3d", ()):
                caminho = estrutura.get("arquivo") or ""
                if not caminho.startswith("estruturas3d_ensembles/"):
                    continue
                contagens["ensembles"] += 1
                try:
                    partes = ref.fullmatch(caminho)
                    if not partes:
                        raise ValueError("Referência de lote inválida")
                    arq, inicio, tamanho, prefixo = partes.groups()
                    with (Path(pasta) / arq).open("rb") as f:
                        f.seek(int(inicio))
                        corpo = gzip.decompress(f.read(int(tamanho)))
                    g = json.loads(corpo)
                    r = banco[estrutura["id"]]
                    sha = hashlib.sha256(corpo).hexdigest()
                    if (sha != r["geometria_sha256"] or sha != estrutura["sha256"] or not sha.startswith(prefixo)
                            or g["id"] != r["molecula_id"] or g["ik"] != r["inchikey"] or g["id"] != mol["id"]):
                        raise ValueError("Identidade ou hash divergente")
                    contagens["conformeros"] += len(g["conformeros"])
                    if rapido:
                        continue
                    with rdBase.BlockLogs():
                        smi = Chem.MolToSmiles(Chem.MolFromSmiles(r["smiles"]))
                        for c in g["conformeros"]:
                            if not mesma_identidade(c["sdf"], smi, r["inchikey"]):
                                raise ValueError("SDF divergente")
                            contagens["sdf_revalidados"] += 1
                except (OSError, EOFError, zlib.error, KeyError, TypeError, ValueError, RuntimeError):
                    contagens["erros"] += 1
    return contagens


def auditar_ws8_expansao_e_3d(con, pasta_dados=None, rapido=False):
    """WS8: Estratificação ecológica não inventada, integridade 3D (PDB/AlphaFold/RDKit), Reactome e altimetria métrica."""
    import hashlib
    from PIL import Image
    from .projecao import proj

    estratos_sem_fonte = con.execute(
        "SELECT COUNT(*) FROM taxon WHERE estrato_florestal IS NOT NULL AND estrato_florestal <> 'nao_informado' "
        "AND checklist_consulta_id IS NULL AND checklist_fonte IS NULL"
    ).fetchone()[0]

    est3d_total = con.execute("SELECT COUNT(*) FROM estrutura_3d").fetchone()[0]
    est3d_exp = con.execute("SELECT COUNT(*) FROM estrutura_3d WHERE natureza='experimental'").fetchone()[0]
    mol_com_3d = con.execute("SELECT COUNT(DISTINCT molecula_id) FROM estrutura_3d WHERE molecula_id IS NOT NULL").fetchone()[0]
    est3d_sem_consulta = con.execute("SELECT COUNT(*) FROM estrutura_3d WHERE consulta_id IS NULL").fetchone()[0]
    pasta = Path(pasta_dados or (config.APP_DIR / "dados"))
    ensembles = auditar_ensembles_publicados(con, pasta, rapido)
    erros_hash_3d = 0
    cache_lotes_3d = {}
    for r in con.execute("SELECT arquivo_geometria, geometria_sha256 FROM estrutura_3d ORDER BY CASE natureza WHEN 'experimental' THEN 0 ELSE 1 END, id LIMIT 80"):
        rel = r["arquivo_geometria"] or ""
        if "#" in rel:
            arq_rel, chave = rel.split("#", 1)
            arq = pasta / arq_rel
            if arq.exists():
                if arq_rel not in cache_lotes_3d:
                    cache_lotes_3d[arq_rel] = json.loads(arq.read_text(encoding="utf-8"))
                item_g = cache_lotes_3d[arq_rel].get(chave)
                if item_g is not None:
                    corpo_g = json.dumps(item_g, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
                    if hashlib.sha256(corpo_g).hexdigest() != r["geometria_sha256"]:
                        erros_hash_3d += 1
        elif rel:
            arq = pasta / rel
            if arq.exists():
                if hashlib.sha256(arq.read_bytes()).hexdigest() != r["geometria_sha256"]:
                    erros_hash_3d += 1

    alt_arq = pasta / "geo" / "altimetria_m.webp"
    alt_ok = True
    amostras_alt = {}
    if alt_arq.exists():
        with Image.open(alt_arq) as im:
            rgba = im.convert("RGBA")
            w, h = rgba.size
            px = rgba.load()

            def ler_m(lon, lat):
                mx, my = proj(lon, lat)
                u = (mx - (-118.0)) / 1286.0
                v = (my - (-148.0)) / 1286.0
                ix = min(w - 1, max(0, int(u * w)))
                iy = min(h - 1, max(0, int(v * h)))
                r_, g_, _, _ = px[ix, iy]
                return (r_ * 256 + g_) - 11000

            amostras_alt = {
                "manaus_m": ler_m(-60.02, -3.11),
                "monte_roraima_m": ler_m(-60.76, 5.14),
                "pico_neblina_m": ler_m(-66.00, 0.80),
                "oceano_atlantico_m": ler_m(-36.0, -12.0),
            }
            # Em grade z=6 (~2,4 km/px reamostrada em 512x512), picos estreitos têm média de célula > 1100 m, Manaus 10..120 m, oceano < -1500 m
            alt_ok = (
                5 <= amostras_alt["manaus_m"] <= 130
                and amostras_alt["monte_roraima_m"] >= 1100
                and amostras_alt["pico_neblina_m"] >= 1100
                and amostras_alt["oceano_atlantico_m"] <= -1500
            )

    vias_sem_consulta = con.execute("SELECT COUNT(*) FROM via_biologica WHERE consulta_id IS NULL").fetchone()[0]
    lacunas_sem_consulta = con.execute("SELECT COUNT(*) FROM celula_lacuna WHERE gbif_consulta_id IS NULL").fetchone()[0]

    galaxia_arq = pasta / "viz" / "galaxia.json"
    galaxia_arestas_tmap = None
    galaxia_tmap_ok = True
    if galaxia_arq.exists():
        gx = json.loads(galaxia_arq.read_text(encoding="utf-8"))
        galaxia_arestas_tmap = len(gx.get("arestas", []))
        if len(gx.get("linhas", [])) >= 2 and galaxia_arestas_tmap == 0:
            galaxia_tmap_ok = False

    ok = (
        estratos_sem_fonte == 0
        and est3d_sem_consulta == 0
        and erros_hash_3d == 0 and ensembles["erros"] == 0
        and vias_sem_consulta == 0
        and lacunas_sem_consulta == 0
        and alt_ok
        and galaxia_tmap_ok
    )
    return {
        "estratos_sem_fonte": estratos_sem_fonte,
        "estruturas_3d": est3d_total,
        "estruturas_3d_experimentais": est3d_exp,
        "moleculas_com_3d": mol_com_3d,
        "erros_hash_3d": erros_hash_3d,
        "ensembles_publicados": ensembles,
        "vias_sem_consulta": vias_sem_consulta,
        "lacunas_sem_consulta": lacunas_sem_consulta,
        "altimetria_amostras": amostras_alt,
        "altimetria_calibrada_ok": alt_ok,
        "galaxia_arestas_tmap": galaxia_arestas_tmap,
        "ok": ok,
    }


def auditar_ws9_escala_procedencia_e_benchmark(con, pasta_dados=None):
    """WS9: universo taxonômico DwC-A, procedência declarada, distribuição da espécie, lotes hex e amostra de validação."""
    q = lambda s: con.execute(s).fetchone()[0]
    af_org_sem_proc = q(
        "SELECT COUNT(*) FROM afirmacao WHERE taxon_id IS NOT NULL "
        "AND tipo IN ('composto_em_organismo','funcao_toxina') "
        "AND estado NOT IN ('quarentena','rejeitado') AND procedencia_declarada IS NULL"
    )
    tax_sem_escopo = q("SELECT COUNT(*) FROM taxon WHERE distribuicao_br IS NULL")
    colunas_antigas = q("SELECT (SELECT COUNT(*) FROM afirmacao WHERE nivel_procedencia IS NOT NULL) + "
                        "(SELECT COUNT(*) FROM taxon WHERE escopo_biogeografico IS NOT NULL)")
    proc_mat_inventada = q(
        "SELECT COUNT(*) FROM afirmacao a WHERE a.procedencia_material IS NOT NULL "
        "AND NOT EXISTS (SELECT 1 FROM verificacao v WHERE v.afirmacao_id=a.id AND v.decisao IN ('confirmada','corrigida'))"
    )
    universo_am = 0
    universo_com_q = 0
    if q("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='universo_checklist'"):
        universo_am = q("SELECT COUNT(*) FROM universo_checklist WHERE bioma_amazonia_declarado=1")
        universo_com_q = q("SELECT COUNT(*) FROM universo_checklist WHERE bioma_amazonia_declarado=1 AND tem_quimica_aberta=1")

    bench_n = 0
    bench_sem_ref = 0
    if q("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='amostra_benchmark'"):
        bench_n = q("SELECT COUNT(*) FROM amostra_benchmark")
        bench_sem_ref = q(
            "SELECT COUNT(*) FROM amostra_benchmark ab WHERE NOT EXISTS ("
            "SELECT 1 FROM afirmacao_referencia ar JOIN referencia r ON r.id=ar.referencia_id "
            "WHERE ar.afirmacao_id=ab.afirmacao_id AND (r.doi IS NOT NULL OR r.pmid IS NOT NULL))"
        )

    pasta = Path(pasta_dados or (config.APP_DIR / "dados"))
    indice_mapa_ok = True
    if (pasta / "indice.json").exists():
        indice_mapa_ok = (pasta / "indice_mapa.json").exists() and (pasta / "moleculas_lotes").is_dir()

    ok = (
        af_org_sem_proc == 0
        and tax_sem_escopo == 0
        and colunas_antigas == 0
        and proc_mat_inventada == 0
        and bench_sem_ref == 0
        and indice_mapa_ok
    )
    return {
        "universo_amazonia_aceitas": universo_am,
        "universo_com_quimica_aberta": universo_com_q,
        "afirmacoes_org_sem_procedencia_declarada": af_org_sem_proc,
        "taxons_sem_distribuicao": tax_sem_escopo,
        "colunas_antigas_de_procedencia_preenchidas": colunas_antigas,
        "procedencia_material_inventada": proc_mat_inventada,
        "amostra_benchmark_n": bench_n,
        "benchmark_sem_referencia": bench_sem_ref,
        "pacotes_lotes_e_indice_mapa_ok": indice_mapa_ok,
        "ok": ok,
    }


FAMILIAS_DE_INTEGRIDADE = {
    "T": "identidade_taxonomica", "Q": "regras_de_retencao", "V": "evidencia", "B": "bioatividade", "N": "nao_constituintes",
    "R": "referencias", "L": "linhagens", "M": "identidade_quimica", "U": "universo_taxonomico", "G": "agregados_gbif",
    "F": "fotografias", "C": "localidade_care_sisgen",
}


def auditar_ws10_integridade(con, pasta_dados=None):
    """WS10: invariantes da migração 008 por família, métricas sem dupla contagem e arquivos das fotografias.

    As invariantes são as do validador (`bmb validar`), agrupadas pelo prefixo. As métricas dizem o que cada número
    conta: afirmações, pares distintos táxon–molécula, estruturas com estereoquímica e esqueletos 2D.
    """
    from . import validar
    res = validar.validar(con)
    por_familia = {nome: 0 for nome in FAMILIAS_DE_INTEGRIDADE.values()}
    for item in res["erros"]:
        familia = FAMILIAS_DE_INTEGRIDADE.get(item["id"].split(".")[0])
        if familia:
            por_familia[familia] += item["n"]
    q = lambda sql: con.execute(sql).fetchone()[0]
    publico = "estado IN ('candidato','em_revisao','verificado') AND classe_acesso='publico'"
    metricas = {
        "afirmacoes_publicas_de_composto": q(f"SELECT COUNT(*) FROM afirmacao WHERE tipo='composto_em_organismo' AND {publico}"),
        "pares_taxon_molecula_distintos": q(
            f"SELECT COUNT(*) FROM (SELECT DISTINCT taxon_id, molecula_id FROM afirmacao WHERE tipo='composto_em_organismo' AND {publico})"),
        "pares_em_mais_de_uma_base": q(
            f"SELECT COUNT(*) FROM (SELECT taxon_id, molecula_id FROM afirmacao WHERE tipo='composto_em_organismo' AND {publico} "
            "GROUP BY 1,2 HAVING COUNT(DISTINCT fonte_id) > 1)"),
        "moleculas_inchikey": q("SELECT COUNT(*) FROM molecula WHERE inchikey IS NOT NULL"),
        "conectividades_2d": q("SELECT COUNT(DISTINCT inchikey_conectividade) FROM molecula WHERE inchikey IS NOT NULL"),
        "moleculas_com_estereocentro_indefinido": q("SELECT COUNT(*) FROM molecula WHERE IFNULL(estereocentros_indefinidos,0) > 0"),
    }
    # Fotografias: o arquivo publicado existe e tem o hash registrado
    pasta = Path(pasta_dados or (config.APP_DIR / "dados"))
    conferidas = faltando = divergentes = 0
    if (pasta / "imagens").is_dir():
        for m in con.execute("SELECT arquivo, arquivo_sha256 FROM midia WHERE estado='ativo' AND arquivo IS NOT NULL").fetchall():
            arq = pasta / m["arquivo"]
            if not arq.exists():
                faltando += 1
                continue
            conferidas += 1
            if hashlib.sha256(arq.read_bytes()).hexdigest() != m["arquivo_sha256"]:
                divergentes += 1
    ok = not any(por_familia.values()) and divergentes == 0
    return {"violacoes_por_familia": por_familia, "metricas": metricas,
            "fotografias": {"arquivos_conferidos": conferidas, "arquivos_ausentes_na_pasta": faltando, "hash_divergente": divergentes},
            "ok": ok}


def executar_auditoria(con, pasta_dados=None, rapido=False):
    """Executa os dez eixos (WS1–WS10) mais `validar.validar(con)` e devolve dicionário consolidado."""
    val = validar.validar(con)
    eixos = {
        "validacao_principios": {"erros": len(val["erros"]), "avisos": len(val["avisos"]), "ok": len(val["erros"]) == 0},
        "ws1_taxonomia_recorte": auditar_ws1_taxonomia(con),
        "ws2_quimica_toxinas": auditar_ws2_quimica_e_toxinas(con, rapido=rapido),
        "ws3_farmacologia_clinica": auditar_ws3_farmacologia(con),
        "ws4_literatura": auditar_ws4_literatura(con),
        "ws5_cartografia": auditar_ws5_cartografia(pasta_dados),
        "ws6_midia": auditar_ws6_midia(con),
        "ws7_governanca_dwca": auditar_ws7_governanca_e_dwca(con, pasta_dados),
        "ws8_expansao_e_3d": auditar_ws8_expansao_e_3d(con, pasta_dados, rapido=rapido),
        "ws9_escala_procedencia_e_benchmark": auditar_ws9_escala_procedencia_e_benchmark(con, pasta_dados),
        "ws10_integridade": auditar_ws10_integridade(con, pasta_dados),
    }
    aprovado = all(bloco["ok"] for bloco in eixos.values())
    return {"ok": aprovado, "eixos": eixos, "detalhes_validacao": val}


def formatar_resumo(res):
    """Formata resumo legível para terminal ou Markdown."""
    linhas = [
        f"BioMapaBrasil · conferências do banco e dos pacotes (validador e dez eixos): {'sem falhas' if res['ok'] else 'FALHAS DETECTADAS'}",
    ]
    for chave, bloco in res["eixos"].items():
        sinal = "✓" if bloco["ok"] else "✗"
        resumo_curto = ", ".join(f"{k}={v}" for k, v in bloco.items() if k != "ok" and not isinstance(v, (list, dict)))
        linhas.append(f"  {sinal} {chave}: {resumo_curto}")
    return "\n".join(linhas)
