# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Construção do banco, em etapas retomáveis.

Cada etapa lê o que a anterior gravou e é idempotente: rodar de novo atualiza em vez de duplicar, e as
respostas das fontes saem do cache em disco (com a data da consulta ORIGINAL). Decisões curatoriais
(estado, verificação) nunca são sobrescritas por uma reconstrução.
"""
import json
import re
import tomllib
from collections import Counter
from pathlib import Path

from . import (__version__, bibliografia, bioatividade, config, curadoria, literatura, procedencia, prontidao, quarentena,
               quimica, quimica_espaco, taxonomia, texto)
from .conectores import (
    catalogo_nacional_dwca, checklists_br, chembl, ena, estruturas3d, gbif,
    hidrografia_lacunas, linhagem_vias, lotus, npatlas_coconut, nubbe, pubchem,
    referencias, uniprot,
)
from .http import ErroDeFonte
from .util import agora, chave_nome, json_compacto, milhar

AGENTE = f"software:bmb {__version__}"
MAX_ATIVIDADES_POR_MOLECULA = 5
COMPRIMENTO_MAX_PEPTIDEO = 50       # até 50 aminoácidos: peptídeo; acima: proteína

# Fallback estático (tabela do IBGE) para quando o serviço de localidades não responde.
UFS_IBGE = [
    ("AC", 12, "Acre", "N"), ("AL", 27, "Alagoas", "NE"), ("AP", 16, "Amapá", "N"), ("AM", 13, "Amazonas", "N"),
    ("BA", 29, "Bahia", "NE"), ("CE", 23, "Ceará", "NE"), ("DF", 53, "Distrito Federal", "CO"),
    ("ES", 32, "Espírito Santo", "SE"), ("GO", 52, "Goiás", "CO"), ("MA", 21, "Maranhão", "NE"),
    ("MT", 51, "Mato Grosso", "CO"), ("MS", 50, "Mato Grosso do Sul", "CO"), ("MG", 31, "Minas Gerais", "SE"),
    ("PA", 15, "Pará", "N"), ("PB", 25, "Paraíba", "NE"), ("PR", 41, "Paraná", "S"), ("PE", 26, "Pernambuco", "NE"),
    ("PI", 22, "Piauí", "NE"), ("RJ", 33, "Rio de Janeiro", "SE"), ("RN", 24, "Rio Grande do Norte", "NE"),
    ("RS", 43, "Rio Grande do Sul", "S"), ("RO", 11, "Rondônia", "N"), ("RR", 14, "Roraima", "N"),
    ("SC", 42, "Santa Catarina", "S"), ("SP", 35, "São Paulo", "SE"), ("SE", 28, "Sergipe", "NE"),
    ("TO", 17, "Tocantins", "N"),
]


# ═══════════════════════════ infraestrutura ═══════════════════════════
class Etapa:
    """Registra início, fim e resumo de uma etapa na tabela `etapa`."""

    def __init__(self, con, nome, log):
        self.con, self.nome, self.log, self.resumo = con, nome, log, {}

    def __enter__(self):
        self.log(f"▸ {self.nome}")
        self.con.execute(
            "INSERT INTO etapa (nome, iniciada_em) VALUES (?,?) ON CONFLICT(nome) DO UPDATE SET "
            "iniciada_em=excluded.iniciada_em, concluida_em=NULL, resumo=NULL", (self.nome, agora()))
        self.con.commit()
        return self

    def __exit__(self, tipo, valor, tb):
        if tipo is None:
            self.con.execute("UPDATE etapa SET concluida_em=?, resumo=? WHERE nome=?",
                             (agora(), json_compacto(self.resumo), self.nome))
            self.con.commit()
            self.log(f"  ✓ {self.nome}: {json_compacto(self.resumo)[:300]}")
        else:
            self.con.rollback()
        return False


def carregar_semente(caminho=None):
    with open(caminho or (config.SEMENTE_DIR / "taxa.toml"), "rb") as f:
        return tomllib.load(f)


def evento(con, entidade, entidade_id, atividade, detalhe=None, agente=AGENTE):
    con.execute("INSERT INTO evento_proveniencia (entidade, entidade_id, atividade, agente, em, detalhe) "
                "VALUES (?,?,?,?,?,?)", (entidade, entidade_id, atividade, agente, agora(), detalhe))


# ═══════════════════════════ upserts ═══════════════════════════
def upsert_referencia(con, doi=None, pmid=None, **dados):
    """Cria ou atualiza uma referência, achando-a por DOI ou PMID. Funde duplicatas do mesmo artigo."""
    doi = (doi or "").strip().lower() or None
    pmid = str(pmid).strip() if pmid else None
    if not doi and not pmid:
        return None
    por_doi = con.execute("SELECT id FROM referencia WHERE doi=?", (doi,)).fetchone() if doi else None
    por_pmid = con.execute("SELECT id FROM referencia WHERE pmid=?", (pmid,)).fetchone() if pmid else None
    if por_doi and por_pmid and por_doi["id"] != por_pmid["id"]:
        # DOI e PMID já estão em linhas diferentes. Quem chama diz que são a mesma obra, mas isso só o PubMed confirma:
        # as linhas NÃO são fundidas aqui. `bmb.bibliografia.conferir` compara o DOI que o PubMed dá para o PMID e,
        # sendo a mesma obra, marca a duplicata e migra os vínculos; sendo obras diferentes, nada se mistura.
        pmid, por_pmid = None, None
    existente = por_doi or por_pmid
    campos = {k: v for k, v in dados.items() if v is not None}
    if "autores" in campos and not isinstance(campos["autores"], str):
        campos["autores"] = json_compacto(campos["autores"])
    if existente:
        rid = existente["id"]
        atuais = con.execute("SELECT doi, pmid, titulo, revista, ano, autores, resolvida FROM referencia WHERE id=?",
                             (rid,)).fetchone()
        sets, vals = [], []
        if doi and not atuais["doi"]:
            sets.append("doi=?"); vals.append(doi)
        if pmid and not atuais["pmid"]:
            sets.append("pmid=?"); vals.append(pmid)
        for k in ("titulo", "revista", "ano", "autores"):
            if k in campos and (atuais[k] is None or campos.get("resolvida")):
                sets.append(f"{k}=?"); vals.append(campos[k])
        for k in ("resolvida", "retratada", "aviso", "consulta_id", "pmcid", "tipo_obra", "agencia_doi"):
            if k in campos:
                sets.append(f"{k}=?"); vals.append(campos[k])
        if sets:
            con.execute(f"UPDATE referencia SET {', '.join(sets)} WHERE id=?", (*vals, rid))
        return _referencia_canonica(con, rid)
    colunas = ["doi", "pmid"] + list(campos)
    con.execute(f"INSERT INTO referencia ({', '.join(colunas)}) VALUES ({', '.join('?' * len(colunas))})",
                (doi, pmid, *campos.values()))
    return con.execute("SELECT last_insert_rowid()").fetchone()[0]


def _referencia_canonica(con, rid):
    """Linha que representa a obra: quando `rid` foi marcada como duplicata (mesma obra sob outro DOI, resumo do
    ChemInform, material suplementar), devolve a linha canônica. Assim uma etapa refeita sozinha não volta a ligar
    afirmações à linha duplicata."""
    for _ in range(5):
        linha = con.execute("SELECT duplicata_de FROM referencia WHERE id=?", (rid,)).fetchone()
        if not linha or linha["duplicata_de"] is None:
            break
        rid = linha["duplicata_de"]
    return rid


def upsert_afirmacao(con, *, tipo, molecula_id, origem, fonte_id, consulta_id, texto_, taxon_id=None, alvo_id=None,
                     passagem=None, metodo=None, sistema=None, medida=None, refs=(),
                     uf_coleta_declarada=None, escopo_referencia=None,
                     pais_coleta_declarado=None, localidade_declarada=None,
                     voucher_declarado_base=None, validacao_manual_fonte=None, organismo_na_fonte=None, extras=None):
    """Cria ou atualiza uma afirmação pela sua origem. Nunca altera estado, acesso nem quarentena.

    `localidade_declarada` existe por compatibilidade de assinatura e é ignorada: o banco não guarda localidade mais
    fina que país e UF. `extras`: colunas adicionais da afirmação (agregação de bioatividade, fontes regulatórias)."""
    localidade_declarada = None
    agora_ = agora()
    m = medida or {}
    existente = con.execute(
        "SELECT id FROM afirmacao WHERE tipo=? AND IFNULL(taxon_id,0)=IFNULL(?,0) AND molecula_id=? "
        "AND IFNULL(alvo_id,0)=IFNULL(?,0) AND origem=?", (tipo, taxon_id, molecula_id, alvo_id, origem)).fetchone()
    if existente:
        aid = existente["id"]
        con.execute(
            # a passagem lida por curador, ou localizada no artigo pela etapa de evidências, não é da fonte: fica como está
            "UPDATE afirmacao SET texto=?, passagem=CASE WHEN passagem_origem IN ('curador','resumo','texto_completo_aberto') "
            "THEN passagem ELSE ? END, metodo=?, sistema_experimental=?, medida_tipo=?, medida_relacao=?, "
            "medida_valor=?, medida_unidade=?, uf_coleta_declarada=COALESCE(?, uf_coleta_declarada), "
            "escopo_referencia=COALESCE(?, escopo_referencia), "
            "pais_coleta_declarado=COALESCE(?, pais_coleta_declarado), "
            "localidade_declarada=COALESCE(?, localidade_declarada), "
            "voucher_declarado_base=COALESCE(?, voucher_declarado_base), "
            "validacao_manual_fonte=COALESCE(?, validacao_manual_fonte), "
            "consulta_id=?, atualizado_em=? WHERE id=?",
            (texto_, passagem, metodo, sistema, m.get("tipo"), m.get("relacao"), m.get("valor"), m.get("unidade"),
             uf_coleta_declarada, escopo_referencia, pais_coleta_declarado, localidade_declarada,
             voucher_declarado_base, validacao_manual_fonte, consulta_id, agora_, aid))
    else:
        con.execute(
            "INSERT INTO afirmacao (tipo, taxon_id, molecula_id, alvo_id, texto, passagem, metodo, sistema_experimental, "
            "medida_tipo, medida_relacao, medida_valor, medida_unidade, uf_coleta_declarada, escopo_referencia, "
            "pais_coleta_declarado, localidade_declarada, voucher_declarado_base, validacao_manual_fonte, "
            "origem, fonte_id, consulta_id, criado_em, atualizado_em) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (tipo, taxon_id, molecula_id, alvo_id, texto_, passagem, metodo, sistema, m.get("tipo"), m.get("relacao"),
             m.get("valor"), m.get("unidade"), uf_coleta_declarada, escopo_referencia,
             pais_coleta_declarado, localidade_declarada, voucher_declarado_base, validacao_manual_fonte,
             origem, fonte_id, consulta_id, agora_, agora_))
        aid = con.execute("SELECT last_insert_rowid()").fetchone()[0]
        con.execute("UPDATE afirmacao SET nivel_evidencia='base_curada' WHERE id=?", (aid,))
        evento(con, "afirmacao", aid, "extracao", f"{fonte_id}: {origem}")
    if organismo_na_fonte:
        con.execute("UPDATE afirmacao SET organismo_na_fonte=? WHERE id=?", (organismo_na_fonte, aid))
    if extras:
        cols = sorted(extras)
        con.execute(f"UPDATE afirmacao SET {', '.join(c + '=?' for c in cols)} WHERE id=?", (*[extras[c] for c in cols], aid))
    for rid in refs:
        if rid:
            con.execute("INSERT OR IGNORE INTO afirmacao_referencia (afirmacao_id, referencia_id, papel) VALUES (?,?, 'sustenta')",
                        (aid, rid))
    return aid


def upsert_molecula_pequena(con, c):
    """Molécula pequena (LOTUS, NuBBE ou NPAtlas), achada pelo InChIKey. Preenche só o que falta; não rebaixa dado enriquecido."""
    lotus_id = c.get("lotus_id")
    nubbe_id = c.get("nubbe_id")
    npatlas_id = c.get("npatlas_id")
    smiles_val = c.get("smiles")
    if smiles_val and not quimica.conferir_inchikey(smiles_val, c["inchikey"])[0]:
        smiles_val = None
    nome_ini = quimica.escolher_nome_molecula(c.get("nome"), None, None, c["inchikey"])
    row = con.execute("SELECT id, nome FROM molecula WHERE inchikey=?", (c["inchikey"],)).fetchone()
    if row:
        melhor_nome = nome_ini if (row["nome"] == c["inchikey"] and nome_ini != c["inchikey"]) else row["nome"]
        con.execute("UPDATE molecula SET nome=?, smiles=COALESCE(smiles,?), formula=COALESCE(formula,?), massa=COALESCE(massa,?), "
                    "lotus_id=COALESCE(lotus_id,?), nubbe_id=COALESCE(nubbe_id,?), npatlas_id=COALESCE(npatlas_id,?), "
                    "classe_quimica=COALESCE(classe_quimica,?) WHERE id=?",
                    (melhor_nome, smiles_val, c["formula"], c["massa"], lotus_id, nubbe_id, npatlas_id, c.get("classe"), row["id"]))
        return row["id"]
    con.execute("INSERT INTO molecula (tipo, nome, inchikey, smiles, formula, massa, lotus_id, nubbe_id, npatlas_id, classe_quimica) "
                "VALUES ('pequena_molecula',?,?,?,?,?,?,?,?,?)",
                (nome_ini, c["inchikey"], smiles_val, c["formula"], c["massa"], lotus_id, nubbe_id, npatlas_id, c.get("classe")))
    return con.execute("SELECT last_insert_rowid()").fetchone()[0]


def upsert_molecula_proteica(con, u):
    tipo = "peptideo" if (u["comprimento"] or 10**6) <= COMPRIMENTO_MAX_PEPTIDEO else "proteina"
    pdb = json_compacto(u["pdb"]) if u["pdb"] else None
    row = con.execute("SELECT id FROM molecula WHERE uniprot_acc=?", (u["acc"],)).fetchone()
    if row:
        con.execute("UPDATE molecula SET tipo=?, nome=?, comprimento_aa=?, familia=?, pdb_ids=? WHERE id=?",
                    (tipo, u["nome"], u["comprimento"], u["familia"], pdb, row["id"]))
        return row["id"]
    con.execute("INSERT INTO molecula (tipo, nome, uniprot_acc, comprimento_aa, familia, pdb_ids) VALUES (?,?,?,?,?,?)",
                (tipo, u["nome"], u["acc"], u["comprimento"], u["familia"], pdb))
    return con.execute("SELECT last_insert_rowid()").fetchone()[0]


# ═══════════════════════════ etapa 1: territórios ═══════════════════════════
def etapa_territorios(con, cli, log):
    with Etapa(con, "territorios", log) as e:
        consulta_id, origem = None, "tabela estática do IBGE (serviço de localidades não consultado)"
        ufs = list(UFS_IBGE)
        try:
            r = cli.get("https://servicodados.ibge.gov.br/api/v1/localidades/estados", {"orderBy": "nome"},
                        fonte="ibge", tentativas=1)
            if r.status == 200 and isinstance(r.dados, list) and len(r.dados) == 27:
                ufs = [(x["sigla"], x["id"], x["nome"], x["regiao"]["sigla"]) for x in r.dados]
                consulta_id, origem = r.consulta_id, "API de localidades do IBGE"
        except Exception as exc:  # serviço instável: segue com o fallback declarado
            log(f"  IBGE indisponível ({type(exc).__name__}); usando a tabela estática")
        con.execute("INSERT INTO territorio (id, tipo, codigo, sigla, nome, amazonia_legal, consulta_id) "
                    "VALUES ('BR','pais','76','BR','Brasil',0,NULL) ON CONFLICT(id) DO NOTHING")
        for sigla, cod, nome, regiao in ufs:
            con.execute(
                "INSERT INTO territorio (id, tipo, codigo, sigla, nome, pai_id, amazonia_legal, consulta_id) "
                "VALUES (?, 'uf', ?, ?, ?, 'BR', ?, ?) ON CONFLICT(id) DO UPDATE SET codigo=excluded.codigo, "
                "nome=excluded.nome, amazonia_legal=excluded.amazonia_legal, consulta_id=excluded.consulta_id",
                (f"UF:{sigla}", str(cod), sigla, nome, 1 if sigla in config.UF_AMAZONIA_LEGAL else 0, consulta_id))
        e.resumo = {"ufs": len(ufs), "amazonia_legal": len(config.UF_AMAZONIA_LEGAL), "origem": origem}


# ═══════════════════════════ etapa 1b: universo checklist nacional (JBRJ + CTFB DwC-A) ═══════════════════════════
def _coletar_nomes_semente(sem):
    nomes = set()
    for sec in ("prototipo", "plantas", "fungos", "animais"):
        for n in sem.get(sec, {}).get("nomes", []):
            if n:
                nomes.add(n.strip().lower())
    for a in sem.get("ajustes", []):
        if a.get("nome"):
            nomes.add(a["nome"].strip().lower())
        if a.get("consulta"):
            nomes.add(a["consulta"].strip().lower())
    return nomes


def etapa_universo_checklist(con, cli, log, sem, so=None):
    """Universo taxonômico amazônico (JBRJ + CTFB) e a marca de quais espécies têm química em base aberta.

    A marca `tem_quimica_aberta` segue a mesma regra de identidade da etapa de compostos, sem cortar nomes:
      * o organismo que a fonte nomeia tem, letra por letra, o nome aceito da espécie (ou é um infraespecífico dela,
        segundo a própria fonte), no mesmo reino; ou
      * o organismo tem o nome de um SINÔNIMO da espécie no checklist e o backbone do GBIF confirma: o uso indicado
        pela fonte leva à mesma espécie aceita, ou tem a mesma autoria do sinônimo no checklist.
    Um binômio igual ao de um sinônimo, sem essa confirmação, não marca nada.
    """
    with Etapa(con, "universo_checklist", log) as e:
        orgs_tp, _ = uniprot.organismos_toxprot(cli)
        nomes_tp = {o["cientifico"].strip().lower() for o in orgs_tp if o.get("cientifico")}

        info_uc = catalogo_nacional_dwca.construir_universo_checklist(con, nomes_toxprot=nomes_tp, log=log)
        setattr(cli, "_catalogo_dwca_local", info_uc["catalogo_por_nome"])

        rows_uc = con.execute(
            "SELECT id, nome_aceito, reino, sinonimos_autoria_json, grupo_bmb FROM universo_checklist WHERE bioma_amazonia_declarado=1"
        ).fetchall()
        por_aceito, por_sinonimo, generos = {}, {}, set()
        for r in rows_uc:
            por_aceito.setdefault(r["nome_aceito"].strip().lower(), []).append(r)
            generos.add(r["nome_aceito"].split()[0].lower())
            for sn in json.loads(r["sinonimos_autoria_json"] or "[]"):
                por_sinonimo.setdefault(sn["nome"].strip().lower(), []).append((r, sn))
                generos.add(sn["nome"].split()[0].lower())
        generos |= {n.split()[0] for n in _coletar_nomes_semente(sem)} | {n.split()[0] for n in nomes_tp}

        com_quimica, cont = set(), Counter()

        def marcar_por_nome_aceito(nome, reino_fonte, origem):
            for r in por_aceito.get((nome or "").lower(), ()):
                if not reino_fonte or reino_fonte == r["reino"]:
                    com_quimica.add(r["id"])
                    cont[origem + ":nome_aceito"] += 1

        def marcar_por_sinonimo(nome, uso_gbif, reino_fonte, origem):
            """`uso_gbif`: uso que a fonte indica (por identificador) ou que o casamento estrito devolve."""
            candidatos = por_sinonimo.get((nome or "").lower(), ())
            if not candidatos or uso_gbif is None:
                return
            especie = taxonomia.especie_aceita(cli, uso_gbif)
            for r, sn in candidatos:
                if reino_fonte and reino_fonte != r["reino"]:
                    continue
                mesma_especie = especie is not None and taxonomia.chave(especie.get("nome")) == taxonomia.chave(r["nome_aceito"])
                if mesma_especie or taxonomia.mesma_autoria(uso_gbif.get("autoria"), sn.get("autoria")):
                    com_quimica.add(r["id"])
                    cont[origem + ":sinonimo_confirmado"] += 1
                else:
                    cont[origem + ":sinonimo_nao_confirmado"] += 1

        # LOTUS
        por_org, classes_por_ik, cid_lotus = lotus.indexar_dump_por_organismo(con, generos=generos, log=log)
        a_resolver = sorted({int(g) for (nome, g) in por_org if g and nome.lower() in por_sinonimo and nome.lower() not in por_aceito})
        if a_resolver and hasattr(cli, "get_varios"):
            for ini in range(0, len(a_resolver), 400):
                cli.get_varios([taxonomia.pedido_uso(k) for k in a_resolver[ini:ini + 400]], fonte="gbif", ignorar_erros=True)
        for (nome, gid), org in por_org.items():
            reino_f = _REINO_GBIF.get((org["reino"] or "").lower())
            marcar_por_nome_aceito(nome, reino_f, "lotus")
            if org["especie_lotus"] and nome.lower().startswith(org["especie_lotus"].lower() + " "):
                marcar_por_nome_aceito(org["especie_lotus"], reino_f, "lotus")     # infraespecífico da própria espécie
            if nome.lower() in por_sinonimo and nome.lower() not in por_aceito:
                marcar_por_sinonimo(nome, taxonomia.uso(cli, gid) if gid else taxonomia.casar_nome(cli, nome, reino=reino_f),
                                    reino_f, "lotus")

        # NuBBE-DB e NPAtlas: nome inteiro, sem identificador
        try:
            indice_nubbe, cid_nubbe = nubbe.carregar_indice(cli)
            setattr(cli, "_indice_nubbe_cache", (indice_nubbe, cid_nubbe))
        except Exception as exc:
            indice_nubbe = {}
            log(f"  aviso NuBBE-DB no universo_checklist ({type(exc).__name__}): {exc}")
        try:
            indice_npatlas, _ = npatlas_coconut.carregar_indice(cli)
        except Exception as exc:
            indice_npatlas = {}
            log(f"  aviso NPAtlas no universo_checklist ({type(exc).__name__}): {exc}")
        for origem, indice, reino_f in (("nubbe", indice_nubbe, None), ("npatlas", indice_npatlas, "Fungi")):
            for nome in indice:
                marcar_por_nome_aceito(nome, reino_f, origem)
                if nome.lower() in por_sinonimo and nome.lower() not in por_aceito:
                    marcar_por_sinonimo(nome, taxonomia.casar_nome(cli, nome, reino=reino_f), reino_f, origem)
        # Tox-Prot: só pelo nome aceito, no reino Animalia
        for nome in nomes_tp:
            marcar_por_nome_aceito(nome, "Animalia", "toxprot")

        con.execute("UPDATE universo_checklist SET tem_quimica_aberta = 0 WHERE bioma_amazonia_declarado = 1")
        con.executemany("UPDATE universo_checklist SET tem_quimica_aberta = 1 WHERE id = ?", [(i,) for i in sorted(com_quimica)])
        con.commit()

        n_amz = info_uc["amazonia_aceitos"]
        n_quim = len(com_quimica)
        por_grupo_quim = {
            f"{g}_com_quimica": n
            for g, n in con.execute(
                "SELECT grupo_bmb, COUNT(*) FROM universo_checklist "
                "WHERE bioma_amazonia_declarado=1 AND tem_quimica_aberta=1 GROUP BY grupo_bmb"
            ).fetchall()
        }
        e.resumo = {
            "amazonia_especies_aceitas": n_amz,
            "com_quimica_aberta": n_quim,
            "sem_quimica_aberta": max(0, n_amz - n_quim),
            "fracao_sem_quimica_aberta": round(max(0, n_amz - n_quim) / n_amz, 4) if n_amz else 0.0,
            "por_grupo_amazonia": info_uc["por_grupo_amazonia"],
            **por_grupo_quim,
            "criterio": dict(sorted(cont.items())),
            "lotus_organismos_lidos": len(por_org),
        }


# ═══════════════════════════ etapa 2: táxons ═══════════════════════════
def _candidatos(con, sem, orgs_toxprot, so=None):
    """Lista de candidatos a táxon: semente curada, Tox-Prot e espécies amazônicas nativas com química aberta."""
    cands = []
    for n in sem.get("prototipo", {}).get("nomes", []):
        cands.append({"nome": n, "reino": None, "grupo": None, "origem": "semente: protótipo anterior", "semente": True})
    for n in sem.get("plantas", {}).get("nomes", []):
        cands.append({"nome": n, "reino": "Plantae", "grupo": "planta", "origem": "semente: plantas", "semente": True})
    for n in sem.get("fungos", {}).get("nomes", []):
        cands.append({"nome": n, "reino": "Fungi", "grupo": "fungo", "origem": "semente: fungos", "semente": True})
    for n in sem.get("animais", {}).get("nomes", []):
        cands.append({"nome": n, "reino": "Animalia", "grupo": "animal_peconhento", "origem": "semente: animais",
                      "semente": True})
    for o in orgs_toxprot:
        cands.append({"nome": o["cientifico"], "reino": "Animalia", "grupo": "animal_peconhento",
                      "origem": "Tox-Prot (UniProt)", "semente": False, "uniprot_taxid": o["taxid"],
                      "popular": o["popular"], "sinonimo": o["sinonimo"], "n_toxinas": o["n"]})

    # Promoção em escala de bioma: espécies amazônicas nativas aceitas em JBRJ/CTFB com química aberta verificada
    tem_tabela_uc = con.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='universo_checklist'"
    ).fetchone()
    if tem_tabela_uc:
        rows_uc_cand = con.execute(
            "SELECT nome_aceito, reino, grupo_bmb, fonte FROM universo_checklist "
            "WHERE bioma_amazonia_declarado = 1 AND tem_quimica_aberta = 1 "
            "AND grupo_bmb IN ('planta','fungo','animal_peconhento') "
            "AND IFNULL(status_origem_br, 'nativa') NOT IN ('introduzida','naturalizada','cultivada','exotica','exótica') "
            "ORDER BY nome_aceito"
        ).fetchall()
        for r_uc in rows_uc_cand:
            rot_f = "Flora e Funga do Brasil (JBRJ DwC-A)" if r_uc["fonte"] == "jbrj_flora_funga" else "CTFB Fauna DwC-A"
            cands.append({
                "nome": r_uc["nome_aceito"],
                "reino": r_uc["reino"],
                "grupo": r_uc["grupo_bmb"],
                "origem": f"{rot_f} × Química Aberta",
                "semente": False,
            })

    ajustes = {chave_nome(a["nome"]): a for a in sem.get("ajustes", [])}
    for c in cands:
        a = ajustes.get(chave_nome(c["nome"]))
        if a:
            c["nome_consulta"] = a["consulta"]
    if so:
        alvo = {chave_nome(x) for x in so}
        cands = [c for c in cands if chave_nome(c["nome"]) in alvo]
    return cands


def _vincular_universo_checklist_a_taxon(con):
    """Liga cada espécie do universo ao táxon do banco que é a MESMA espécie.

    Pelo nome aceito, quando os nomes coincidem. Por sinônimo, só quando o nome aceito do checklist é sinônimo de
    categoria espécie do táxon no GBIF e as autorias são as mesmas: um binômio igual, de outro autor, é outra espécie.
    """
    tem_tabela_uc = con.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='universo_checklist'"
    ).fetchone()
    if not tem_tabela_uc:
        return 0
    con.execute("UPDATE universo_checklist SET taxon_id_bmb = NULL")
    con.execute(
        "UPDATE universo_checklist SET taxon_id_bmb = ("
        "  SELECT t.id FROM taxon t WHERE lower(t.nome) = lower(universo_checklist.nome_aceito) LIMIT 1"
        ") WHERE EXISTS (SELECT 1 FROM taxon t WHERE lower(t.nome) = lower(universo_checklist.nome_aceito))"
    )
    por_sinonimo = {}
    for s_ in con.execute("SELECT taxon_id, nome, autoria FROM taxon_sinonimo WHERE origem='gbif' AND upper(IFNULL(categoria,''))='SPECIES' "
                          "AND autoria IS NOT NULL AND IFNULL(status_gbif,'') NOT IN ('PROPARTE_SYNONYM','MISAPPLIED','DOUBTFUL')"):
        por_sinonimo.setdefault(s_["nome"].lower(), []).append(s_)
    for u in con.execute("SELECT id, nome_aceito, autoria FROM universo_checklist WHERE taxon_id_bmb IS NULL").fetchall():
        alvos = {s_["taxon_id"] for s_ in por_sinonimo.get(u["nome_aceito"].lower(), ())
                 if taxonomia.mesma_autoria(s_["autoria"], u["autoria"])}
        if len(alvos) == 1:
            con.execute("UPDATE universo_checklist SET taxon_id_bmb=? WHERE id=?", (alvos.pop(), u["id"]))
    return con.execute("SELECT COUNT(*) FROM universo_checklist WHERE taxon_id_bmb IS NOT NULL").fetchone()[0]


def conferir_midia(con):
    """Integridade das fotografias além da licença: uma mesma imagem (mesmo SHA-256) atribuída a dois táxons não
    pode estar certa nos dois. As duas ficam retidas até um curador dizer de qual espécie é."""
    repetidas = [r["arquivo_sha256"] for r in con.execute(
        "SELECT arquivo_sha256 FROM midia WHERE arquivo_sha256 IS NOT NULL AND estado='ativo' "
        "GROUP BY arquivo_sha256 HAVING COUNT(DISTINCT taxon_id) > 1")]
    n = 0
    for sha in repetidas:
        for m in con.execute("SELECT id, arquivo FROM midia WHERE arquivo_sha256=? AND estado='ativo'", (sha,)).fetchall():
            con.execute("UPDATE midia SET estado='quarentena', motivo_quarentena=?, arquivo=NULL WHERE id=?",
                        ("A mesma imagem (mesmo SHA-256) está atribuída a mais de um táxon; a identificação precisa de curador.", m["id"]))
            evento(con, "midia", m["id"], "quarentena", f"imagem repetida entre táxons (sha256 {sha[:16]}…; arquivo {m['arquivo']})")
            n += 1
    return n


def etapa_taxons(con, cli, log, sem, so=None):
    with Etapa(con, "taxons", log) as e:
        excl = {chave_nome(x["nome"]): x["motivo"] for x in sem.get("excluidos", [])}
        orgs, uniprot_consulta = uniprot.organismos_toxprot(cli)
        cands = _candidatos(con, sem, orgs, so)
        cont = Counter()
        rejeitados = []

        # 1) excluídos eticamente, antes de qualquer busca
        vivos = []
        for c in cands:
            if chave_nome(c["nome"]) in excl:
                cont["excluido_eticamente"] += 1
                rejeitados.append({"nome": c["nome"], "motivo": "exclusão ética: " + excl[chave_nome(c["nome"])],
                                   "origem": c["origem"]})
            else:
                vivos.append(c)

        # 2) resolução de nomes em lote
        log(f"  casando {len(vivos)} nomes no backbone do GBIF…")
        resp = cli.get_varios([gbif.pedido_match(c.get("nome_consulta", c["nome"]), c["reino"]) for c in vivos], fonte="gbif")
        por_chave = {}
        for c, r in zip(vivos, resp):
            m = gbif.interpretar_match(r)
            ok, motivo = gbif.correspondencia_aceitavel(m, c["reino"])
            if not ok:
                cont["nome_rejeitado_" + ("semente" if c["semente"] else "catalogo")] += 1
                cont["rejeicao:" + _tipo_rejeicao(motivo)] += 1
                if c["semente"]:
                    rejeitados.append({"nome": c["nome"], "motivo": motivo, "origem": c["origem"]})
                continue
            entrada = por_chave.setdefault(m["chave_aceita"], {"m": m, "cands": []})
            entrada["cands"].append(c)
        log(f"  {len(por_chave)} táxons distintos após resolver sinônimos")

        # 3) distribuição por UF, em lote
        chaves = list(por_chave)
        resp = cli.get_varios([gbif.pedido_distribuicao(k) for k in chaves], fonte="gbif")
        for k, r in zip(chaves, resp):
            por_chave[k]["dist"] = gbif.interpretar_distribuicao(r)

        # 4) quem fica: sementes ficam sempre (com o resultado do recorte declarado); catálogo/Tox-Prot só dentro do recorte (n_al >= N_AL_MIN)
        ficam = []
        for k, ent in por_chave.items():
            d = ent["dist"]
            tem_semente = any(c["semente"] for c in ent["cands"])
            dentro = bool(d) and d["n_al"] >= config.N_AL_MIN
            if tem_semente or dentro:
                ficam.append(k)
            else:
                cont["fora_do_recorte_n_al"] += 1
        log(f"  {len(ficam)} táxons ficam ({cont['fora_do_recorte_n_al']} abaixo de N_AL_MIN={config.N_AL_MIN} ficam fora)")

        # 5) detalhes taxonômicos, nomes populares, sinônimos e IUCN em lote paralelo
        resp_det = cli.get_varios([gbif.pedido_detalhes(k) for k in ficam], fonte="gbif")
        especies_validas = []
        for k, r in zip(ficam, resp_det):
            ent = por_chave[k]
            det = gbif.interpretar_detalhes(r)
            if not det or det["rank"] != "SPECIES":
                cont["rank_nao_especie"] += 1
                for c in ent["cands"]:
                    if c["semente"]:
                        rejeitados.append({"nome": c["nome"], "motivo": f"resolveu para {det['rank'] if det else '?'}, não espécie",
                                           "origem": c["origem"]})
                continue
            if chave_nome(det["nome"]) in excl:
                cont["excluido_eticamente"] += 1
                rejeitados.append({"nome": det["nome"], "motivo": "exclusão ética (pós-sinonímia): " + excl[chave_nome(det["nome"])],
                                   "origem": "; ".join(sorted({c["origem"] for c in ent["cands"]}))})
                continue
            especies_validas.append((k, ent, det))

        chaves_esp = [k for k, _, _ in especies_validas]
        log(f"  buscando nomes populares, sinônimos e IUCN em lote para {len(chaves_esp)} espécies…")
        resps_pop = cli.get_varios([gbif.pedido_nomes_populares(k) for k in chaves_esp], fonte="gbif", ignorar_erros=True)
        cli.get_varios([(f"{taxonomia.API}/species/{int(k)}/synonyms", {"limit": 300, "offset": 0}) for k in chaves_esp],
                       fonte="gbif", ignorar_erros=True)   # aquece o cache; a gravação é de taxonomia.atualizar_sinonimos_do_taxon
        resps_iucn = cli.get_varios([gbif.pedido_iucn(k) for k in chaves_esp], fonte="gbif", ignorar_erros=True)

        inseridos = 0
        for (k, ent, det), r_pop, r_iu in zip(especies_validas, resps_pop, resps_iucn):
            pop_pre = gbif.interpretar_nomes_populares(r_pop)
            iu_pre = gbif.interpretar_iucn(r_iu)
            _gravar_taxon(con, cli, log, k, ent, det, populares_pre=pop_pre, iucn_pre=iu_pre)
            inseridos += 1
            if inseridos % 150 == 0:
                con.commit()
                log(f"  … {inseridos} táxons gravados")
        n_biocult = _aplicar_contexto_biocultural(con, sem)
        n_vinc_uc = _vincular_universo_checklist_a_taxon(con)
        con.commit()
        e.resumo = {"candidatos": len(cands), "gravados": inseridos, "contexto_biocultural": n_biocult,
                    "vinculados_universo_checklist": n_vinc_uc,
                    **dict(cont), "rejeitados_semente": len(rejeitados),
                    "toxprot_organismos": len(orgs), "toxprot_consulta_id": uniprot_consulta}
        e.resumo["lista_rejeitados"] = rejeitados[:200]
        _guardar_rejeitados(con, rejeitados)


def _aplicar_contexto_biocultural(con, sem):
    """Aplica notas de governança biocultural CARE/SisGen declaradas na semente aos táxons correspondentes."""
    n = 0
    for item in sem.get("contexto_biocultural", []):
        alvo = (item.get("nome") or "").strip()
        nota = (item.get("nota") or "").strip()
        if not alvo or not nota:
            continue
        rows = con.execute(
            "SELECT id FROM taxon WHERE lower(nome)=lower(?) "
            "OR id IN (SELECT taxon_id FROM taxon_sinonimo WHERE lower(nome)=lower(?))",
            (alvo, alvo),
        ).fetchall()
        for r in rows:
            con.execute("UPDATE taxon SET contexto_biocultural=? WHERE id=?", (nota, r["id"]))
            n += 1
    return n


# ═══════════════════════════ etapa 2b: checklists nacionais e estratos ═══════════════════════════
def etapa_checklists(con, cli, log, so=None):
    with Etapa(con, "checklists", log) as e:
        taxa = con.execute(
            "SELECT id, gbif_key, nome, reino, n_al, checklist_consulta_id FROM taxon ORDER BY id"
        ).fetchall()
        if so:
            alvo = {chave_nome(x) for x in so}
            taxa = [t for t in taxa if chave_nome(t["nome"]) in alvo]
        pendentes = [t for t in taxa if t["checklist_consulta_id"] is None]
        log(f"  Checklists nacionais (Flora e Funga / CTFB): {len(pendentes)} táxons pendentes…")
        catalogo_local = getattr(cli, "_catalogo_dwca_local", None)
        if catalogo_local is None and (catalogo_nacional_dwca.pasta_dumps() / "jbrj_flora_funga_dwca.zip").exists():
            info_uc = catalogo_nacional_dwca.construir_universo_checklist(con, log=log)
            catalogo_local = info_uc["catalogo_por_nome"]
            setattr(cli, "_catalogo_dwca_local", catalogo_local)

        cont_est = Counter()
        cont_estrato = Counter()
        n_via_dwca = n_via_api = 0
        for i, t in enumerate(pendentes, 1):
            sins = [dict(r) for r in con.execute(
                "SELECT nome, autoria, categoria FROM taxon_sinonimo WHERE taxon_id=? AND origem='gbif' ORDER BY nome", (t["id"],))]
            res = None
            if catalogo_local:
                res = catalogo_nacional_dwca.reconciliar_via_dwca_local(catalogo_local, t["nome"], t["reino"], sinonimos=sins)
                if res is not None:
                    n_via_dwca += 1
            if res is None:
                res = checklists_br.reconciliar_taxon(cli, t["gbif_key"], t["nome"], t["reino"], sinonimos=sins, n_al=t["n_al"] or 0)
                n_via_api += 1
            con.execute(
                "UPDATE taxon SET origem_estabelecimento=?, endemismo_br=?, biomas_json=?, forma_vida=?, "
                "estrato_florestal=?, categoria_mma=?, checklist_fonte=?, checklist_consulta_id=? WHERE id=?",
                (
                    res["origem_estabelecimento"],
                    res["endemismo_br"],
                    json_compacto(res["biomas"]) if res["biomas"] else None,
                    res["forma_vida"],
                    res["estrato_florestal"],
                    res["categoria_mma"],
                    res["checklist_fonte"],
                    res["checklist_consulta_id"],
                    t["id"],
                ),
            )
            cont_est[res["origem_estabelecimento"] or "nulo"] += 1
            cont_estrato[res["estrato_florestal"] or "nao_informado"] += 1
            if i % 150 == 0:
                con.commit()
                log(f"    checklists {i}/{len(pendentes)} (DwC-A={n_via_dwca}, API={n_via_api})")
        con.commit()
        e.resumo = {"consultados": len(pendentes), "via_dwca_oficial": n_via_dwca, "via_api_gbif": n_via_api,
                    "estabelecimento": dict(cont_est), "estratos": dict(cont_estrato)}


# ═══════════════════════════ etapa 2c: hidrografia, bioma Amazônia e lacunas ═══════════════════════════
def etapa_hidrografia(con, cli, log, so=None):
    with Etapa(con, "hidrografia", log) as e:
        res_bacias = hidrografia_lacunas.atualizar_bioma_e_bacias(con, cli, log)
        res_lacunas = {}
        if not so and (config.SEMENTE_DIR / "geo_base" / "grade_05deg_molde.json").exists():
            res_lacunas = hidrografia_lacunas.atualizar_lacunas_sqlite(con, cli, log)
        e.resumo = {**res_bacias, "lacunas": res_lacunas}


def _tipo_rejeicao(motivo):
    """Rótulo curto do motivo de rejeição de um nome, para a contagem do relatório."""
    for trecho, rotulo in (("nível taxonômico superior", "so_nivel_superior"), ("aproximada", "correspondencia_aproximada"),
                           ("reino", "outro_reino"), ("sem correspondência", "sem_correspondencia")):
        if trecho in (motivo or ""):
            return rotulo
    return "outro"


def _guardar_rejeitados(con, rejeitados):
    """Nomes da semente que não entraram, com o motivo: a decisão fica registrada e auditável."""
    con.execute("DELETE FROM evento_proveniencia WHERE entidade='semente_rejeitada'")
    for r in rejeitados:
        con.execute("INSERT INTO evento_proveniencia (entidade, entidade_id, atividade, agente, em, detalhe) "
                    "VALUES ('semente_rejeitada', 0, 'reconciliacao', ?, ?, ?)",
                    (AGENTE, agora(), json_compacto(r)))


def _gravar_taxon(con, cli, log, chave, ent, det, populares_pre=None, iucn_pre=None):
    d, m, cands = ent["dist"], ent["m"], ent["cands"]
    origens = sorted({c["origem"] for c in cands})
    tem_toxprot = any(c.get("uniprot_taxid") for c in cands)
    tem_animal = any(c["grupo"] == "animal_peconhento" for c in cands)
    reino = det["reino"]
    if reino == "Plantae":
        grupo = "planta"
    elif reino == "Fungi":
        grupo = "fungo"
    elif reino == "Animalia" and (tem_toxprot or tem_animal or any(c["grupo"] is None for c in cands)):
        grupo = "animal_peconhento"
    else:
        grupo = "outro"
    if d:
        rec = gbif.decidir_recorte(d, d["consultado_em"])
    else:
        rec = {"no_recorte": 0, "predominio_al": "indeterminado", "fracao_al_com_uf": None, "fracao_al_total": None,
               "motivo_recorte": "Distribuição não consultada: o GBIF não respondeu. Fora do recorte até haver contagem."}
    taxid = next((c["uniprot_taxid"] for c in cands if c.get("uniprot_taxid")), None)
    populares = list(populares_pre) if populares_pre is not None else gbif.nomes_populares(cli, chave)
    for c in cands:  # nome popular do UniProt, quando o GBIF não tem em português
        if c.get("popular") and not any(p["nome"].lower() == c["popular"].lower() for p in populares):
            populares.append({"nome": c["popular"], "idioma": "en"})
    con.execute(
        "INSERT INTO taxon (gbif_key, nome, autoria, rank, reino, filo, classe, ordem, familia, genero, grupo, nomes_populares, "
        "gbif_correspondencia, gbif_confianca, uniprot_taxid, n_br, n_al, n_br_com_uf, fracao_al_com_uf, fracao_al_total, "
        "predominio_al, ocorr_consulta_id, no_recorte, motivo_recorte, origem_inclusao, criado_em) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
        "ON CONFLICT(gbif_key) DO UPDATE SET nome=excluded.nome, autoria=excluded.autoria, rank=excluded.rank, "
        "reino=excluded.reino, filo=excluded.filo, classe=excluded.classe, ordem=excluded.ordem, familia=excluded.familia, "
        "genero=excluded.genero, grupo=excluded.grupo, nomes_populares=excluded.nomes_populares, "
        "gbif_correspondencia=excluded.gbif_correspondencia, gbif_confianca=excluded.gbif_confianca, "
        "uniprot_taxid=COALESCE(excluded.uniprot_taxid, uniprot_taxid), n_br=excluded.n_br, n_al=excluded.n_al, "
        "n_br_com_uf=excluded.n_br_com_uf, fracao_al_com_uf=excluded.fracao_al_com_uf, fracao_al_total=excluded.fracao_al_total, "
        "predominio_al=excluded.predominio_al, ocorr_consulta_id=excluded.ocorr_consulta_id, no_recorte=excluded.no_recorte, "
        "motivo_recorte=excluded.motivo_recorte, origem_inclusao=excluded.origem_inclusao",
        (chave, det["nome"], det["autoria"], det["rank"], det["reino"], det["filo"], det["classe"], det["ordem"],
         det["familia"], det["genero"], grupo, json_compacto(populares) if populares else None, m["tipo_correspondencia"],
         m["confianca"], taxid, d["n_br"] if d else None, d["n_al"] if d else None, d["com_uf"] if d else None,
         rec["fracao_al_com_uf"], rec["fracao_al_total"], rec["predominio_al"], d["consulta_id"] if d else None,
         rec["no_recorte"], rec["motivo_recorte"], "; ".join(origens), agora()))
    tid = con.execute("SELECT id FROM taxon WHERE gbif_key=?", (chave,)).fetchone()["id"]
    if d:
        con.execute("DELETE FROM ocorrencia_uf WHERE taxon_id=?", (tid,))
        for uf, n in d["por_uf"].items():
            con.execute("INSERT INTO ocorrencia_uf (taxon_id, uf_sigla, n, consulta_id) VALUES (?,?,?,?)",
                        (tid, uf, n, d["consulta_id"]))
    # Nomes pelos quais a espécie foi procurada (semente/UniProt): servem à busca e à exibição. Não ligam registros.
    nomes = {(c["nome"], "semente" if c["semente"] else "uniprot") for c in cands if c["nome"] != det["nome"]}
    for c in cands:
        if c.get("sinonimo") and c["sinonimo"] != det["nome"]:
            nomes.add((c["sinonimo"], "uniprot"))
    # sinônimos são dado derivado: reconstruir substitui (não acumula nomes de versões anteriores do critério)
    con.execute("DELETE FROM taxon_sinonimo WHERE taxon_id=? AND origem IN ('semente','uniprot')", (tid,))
    for n, origem in nomes:
        con.execute("INSERT OR IGNORE INTO taxon_sinonimo (taxon_id, nome, origem) VALUES (?,?,?)", (tid, n, origem))
    # Sinônimos do backbone, inteiros: nome completo, autoria, categoria, status e chave de cada uso.
    if rec["no_recorte"] or any(c["semente"] for c in cands):
        taxonomia.atualizar_sinonimos_do_taxon(con, cli, tid, chave)
    if rec["no_recorte"]:
        iu = iucn_pre if iucn_pre is not None else gbif.iucn(cli, chave)
        if iu and iu.get("consulta_id") is not None:
            con.execute("UPDATE taxon SET iucn=?, iucn_consulta_id=? WHERE id=?", (iu["categoria"], iu["consulta_id"], tid))
    evento(con, "taxon", tid, "reconciliacao", f"GBIF {chave}: {m['tipo_correspondencia']} ({m['confianca']})")
    return tid


# ═══════════════════════════ etapa 3: toxinas (animais, UniProt + EBI ENA) ═══════════════════════════
def _resumir_procedencia_embl(acessos_embl, mapa_ena):
    paises, ufs, vouchers = set(), set(), []
    for acc in acessos_embl or ():
        info = mapa_ena.get(acc)
        if not info:
            continue
        if info.get("pais"):
            paises.add(info["pais"])
        if info.get("uf"):
            ufs.add(info["uf"])
        if info.get("voucher") and info["voucher"] not in vouchers:
            vouchers.append(info["voucher"])
    pais_unico = next(iter(paises)) if len(paises) == 1 else None
    uf_unica = ", ".join(sorted(ufs)) if (pais_unico == "BR" and ufs) else None
    voucher_str = "; ".join(vouchers[:2]) if vouchers else None
    return pais_unico, uf_unica, voucher_str


def etapa_toxinas(con, cli, log):
    with Etapa(con, "toxinas", log) as e:
        taxa = con.execute("SELECT id, nome, uniprot_taxid FROM taxon WHERE uniprot_taxid IS NOT NULL AND no_recorte=1 "
                           "ORDER BY nome").fetchall()
        n_mol = n_af = n_sem_funcao = n_sem_pmid = n_ref_entrada = n_com_ena = 0
        # Animais do recorte sem entrada no Tox-Prot: zero consultado declarado.
        _, consulta_lista = uniprot.organismos_toxprot(cli)
        sem_entrada = con.execute("SELECT id FROM taxon WHERE grupo='animal_peconhento' AND no_recorte=1 AND uniprot_taxid IS NULL").fetchall()
        for s in sem_entrada:
            con.execute("UPDATE taxon SET toxinas_fonte=0, uniprot_consulta_id=? WHERE id=?", (consulta_lista, s["id"]))

        # 1) Coleta entradas do Tox-Prot e reúne acessos EMBL para enriquecimento em lote no EBI ENA
        por_taxon_tox = []
        todos_acessos_embl = []
        for t in taxa:
            toxinas, r = uniprot.toxinas_do_organismo(cli, t["uniprot_taxid"])
            por_taxon_tox.append((t, toxinas, r))
            for u in toxinas:
                embls_u = u.get("embl") or u.get("acessos_embl")
                if u.get("funcao") and embls_u:
                    todos_acessos_embl.extend(embls_u)

        mapa_ena = {}
        if todos_acessos_embl:
            log(f"  EBI ENA Portal: consultando procedência INSDC de {len(set(todos_acessos_embl))} acessos EMBL/GenBank…")
            mapa_ena = ena.buscar_procedencia_embl_em_lote(cli, todos_acessos_embl)

        for t, toxinas, r in por_taxon_tox:
            con.execute("UPDATE taxon SET toxinas_fonte=?, uniprot_consulta_id=? WHERE id=?",
                        (len(toxinas), r.consulta_id, t["id"]))
            for u in toxinas:
                if not u["funcao"]:
                    n_sem_funcao += 1
                    continue
                mid = upsert_molecula_proteica(con, u)
                n_mol += 1
                refs = []
                escopo_ref = "especifica" if u["pmids_funcao"] else None
                for pmid in u["pmids_funcao"]:
                    meta = u["referencias"].get(pmid, {})
                    refs.append(upsert_referencia(con, doi=meta.get("doi"), pmid=pmid, titulo=meta.get("titulo"),
                                                  revista=meta.get("revista"), ano=meta.get("ano"),
                                                  autores=meta.get("autores") or None, consulta_id=r.consulta_id))
                if not u["pmids_funcao"]:
                    chaves_ent = u.get("chaves_ref_entrada") or []
                    for ch_ref in chaves_ent:
                        meta = u["referencias"].get(ch_ref, {})
                        rid = upsert_referencia(
                            con, doi=meta.get("doi"), pmid=meta.get("pmid"), titulo=meta.get("titulo"),
                            revista=meta.get("revista"), ano=meta.get("ano"),
                            autores=meta.get("autores") or None, consulta_id=r.consulta_id,
                        )
                        if rid:
                            refs.append(rid)
                    if refs:
                        escopo_ref = "entrada_geral"
                        n_ref_entrada += 1
                    else:
                        n_sem_pmid += 1
                metodo = texto.METODO_TOXINA_EXPERIMENTAL if u["experimental"] else texto.METODO_TOXINA_NAO_EXPERIMENTAL
                if escopo_ref == "entrada_geral":
                    metodo += " (referência bibliográfica geral da entrada UniProtKB; sem evidência ligada diretamente ao bloco FUNCTION)"
                acessos = u.get("embl") or u.get("acessos_embl") or ()
                pais_ena, uf_ena, voucher_ena = _resumir_procedencia_embl(acessos, mapa_ena)
                if pais_ena or uf_ena or voucher_ena:
                    n_com_ena += 1
                aid_tox = upsert_afirmacao(
                    con, tipo="funcao_toxina", molecula_id=mid, taxon_id=t["id"], origem=f"uniprot:{u['acc']}",
                    fonte_id="uniprot", consulta_id=r.consulta_id,
                    texto_=texto.enunciado_toxina(u["nome"], t["nome"], u.get("organismo")),
                    passagem=u["funcao"], metodo=metodo, refs=refs, escopo_referencia=escopo_ref,
                    pais_coleta_declarado=pais_ena, uf_coleta_declarada=uf_ena, voucher_declarado_base=voucher_ena,
                    organismo_na_fonte=u.get("organismo") or t["nome"],
                )
                if all(a in mapa_ena for a in acessos):
                    # o ENA respondeu por todos os acessos da entrada: o que ele declara substitui o que havia
                    # (inclusive para apagar país atribuído por versão anterior do conector)
                    con.execute("UPDATE afirmacao SET pais_coleta_declarado=?, uf_coleta_declarada=?, voucher_declarado_base=? WHERE id=?",
                                (pais_ena, uf_ena, voucher_ena, aid_tox))
                n_af += 1
            con.commit()
        e.resumo = {"organismos": len(taxa), "organismos_sem_entrada_no_toxprot": len(sem_entrada), "afirmacoes": n_af,
                    "toxinas_com_metadado_ena": n_com_ena,
                    "toxinas_sem_funcao_anotada": n_sem_funcao, "referencias_entrada_geral": n_ref_entrada,
                    "funcao_sem_publicacao_indicada": n_sem_pmid}


# ═══════════════════════════ etapa 4: compostos (LOTUS Zenodo 260413, NuBBE-DB e NPAtlas) ═══════════════════════════
# Regras de retenção que esta etapa declara (ver bmb/quarentena.py).
REGRAS_DE_COMPOSTOS = ("TAX-ESPECIE-DIVERGENTE", "TAX-HOMONIMO", "TAX-NAO-RESOLVIDO", "NAT-SEMISSINTETICO",
                       "FONTE-NAO-SUSTENTA")
_REINO_GBIF = {"archaeplastida": "Plantae", "viridiplantae": "Plantae", "plantae": "Plantae", "fungi": "Fungi",
               "metazoa": "Animalia", "animalia": "Animalia"}
_ROTULO_FONTE = {"lotus": "LOTUS", "nubbe": "NuBBE-DB", "npatlas": "NPAtlas"}


def _binomio(nome):
    """Dois primeiros termos, em minúsculas. Serve SÓ para delimitar quais organismos das fontes vale a pena
    resolver e para explicar vínculos antigos; nunca para ligar um registro a um táxon."""
    partes = (nome or "").split()
    return f"{partes[0]} {partes[1]}".lower() if len(partes) >= 2 else None


def _atualizar_sinonimos_sem_autoria(con, cli, log, taxa):
    """Regrava com autoria, categoria e chave os sinônimos do GBIF de táxons que ainda os têm no formato antigo
    (só o nome canônico). Bancos construídos antes da migração 008 se corrigem aqui."""
    pendentes = [t for t in taxa if con.execute(
        "SELECT 1 FROM taxon_sinonimo WHERE taxon_id=? AND origem='gbif' AND gbif_key IS NULL LIMIT 1", (t["id"],)).fetchone()
        or not con.execute("SELECT 1 FROM taxon_sinonimo WHERE taxon_id=? AND origem='gbif' LIMIT 1", (t["id"],)).fetchone()]
    if not pendentes:
        return 0
    log(f"  sinônimos do GBIF com autoria e categoria: {len(pendentes)} táxons a atualizar…")
    if hasattr(cli, "get_varios"):
        cli.get_varios([(f"{taxonomia.API}/species/{int(t['gbif_key'])}/synonyms", {"limit": 300, "offset": 0})
                        for t in pendentes], fonte="gbif", ignorar_erros=True)
    for i, t in enumerate(pendentes, 1):
        taxonomia.atualizar_sinonimos_do_taxon(con, cli, t["id"], t["gbif_key"])
        if i % 300 == 0:
            con.commit()
    con.commit()
    return len(pendentes)


def _sincronizar_referencias(con, afirmacao_id, refs_validas, motivo):
    """Tira da afirmação os vínculos com referências que a fonte não associa a ESTE organismo. O vínculo some; a
    referência e o evento ficam. Referência usada numa verificação humana não é tocada."""
    validas = {r for r in refs_validas if r}
    n = 0
    for x in con.execute("SELECT ar.referencia_id, r.doi, r.pmid FROM afirmacao_referencia ar JOIN referencia r ON r.id=ar.referencia_id "
                         "WHERE ar.afirmacao_id=?", (afirmacao_id,)).fetchall():
        if x["referencia_id"] in validas:
            continue
        if con.execute("SELECT 1 FROM verificacao WHERE afirmacao_id=? AND referencia_id=?", (afirmacao_id, x["referencia_id"])).fetchone():
            continue
        con.execute("DELETE FROM afirmacao_referencia WHERE afirmacao_id=? AND referencia_id=?", (afirmacao_id, x["referencia_id"]))
        evento(con, "afirmacao", afirmacao_id, "desvinculo_referencia", f"{x['doi'] or ('PMID ' + str(x['pmid']))}: {motivo}")
        n += 1
    return n


def _resumo_nomes(nomes, maximo=3):
    nomes = sorted({n for n in nomes if n})
    return "; ".join(nomes[:maximo]) + (f" e mais {len(nomes) - maximo}" if len(nomes) > maximo else "")


def _explicar_vinculo_antigo(taxon, organismos_e_decisoes, fonte_id):
    """Regra e dados do motivo para uma afirmação que a resolução por organismo não reproduz.

    `organismos_e_decisoes`: [(nome_do_organismo_na_fonte, Decisao)] dos organismos que, pelo casamento antigo por
    nome, levavam o composto a este táxon."""
    # outra espécie: o organismo resolve para espécie fora do banco, para outro táxon do banco, ou é homônimo de
    # OUTRO táxon (aí o identificador da fonte também leva a espécie diferente desta)
    divergentes = [(n, d) for n, d in organismos_e_decisoes
                   if d is not None and (d.decisao == "fora_do_escopo" or (d.taxon_id is not None and d.taxon_id != taxon["id"]))]
    if divergentes:
        return "TAX-ESPECIE-DIVERGENTE", {
            "organismo_fonte": _resumo_nomes(n for n, _ in divergentes),
            "especie_aceita": _resumo_nomes(d.especie_aceita_nome for _, d in divergentes),
            "taxon": taxon["nome"]}
    nao_resolvidos = [n for n, d in organismos_e_decisoes if d is None or d.decisao == "nao_resolvido"]
    if nao_resolvidos:
        return "TAX-NAO-RESOLVIDO", {"organismo_fonte": _resumo_nomes(nao_resolvidos), "taxon": taxon["nome"]}
    return "FONTE-NAO-SUSTENTA", {"fonte": _ROTULO_FONTE[fonte_id], "taxon": taxon["nome"]}


def _dados_homonimo(taxon, c, decisoes, id_fonte=""):
    usos = sorted({(decisoes[(n, id_fonte)].gbif_nome_completo or n) for n in c["organismos_homonimo"] if (n, id_fonte) in decisoes})
    return {"organismo_fonte": _resumo_nomes(c["organismos_homonimo"]), "uso_fonte": _resumo_nomes(usos),
            "taxon": taxon["nome"], "autoria_taxon": taxon["autoria"] or ""}


def etapa_compostos(con, cli, log, so=None):
    """Liga compostos a táxons pelo organismo que a FONTE nomeia, resolvido no backbone do GBIF.

    Nenhum registro entra por coincidência de texto com um sinônimo. O que já estava no banco por esse caminho e não
    se confirma é retido com a regra e o motivo; nada é apagado.
    """
    with Etapa(con, "compostos", log) as e:
        quarentena.registrar_catalogo(con)
        quarentena.adotar_legado(con)
        taxa = con.execute(
            "SELECT id, gbif_key, nome, autoria, grupo FROM taxon WHERE grupo IN ('planta','fungo','animal_peconhento') "
            "AND no_recorte=1 ORDER BY nome").fetchall()
        if so:
            alvo = {chave_nome(x) for x in so}
            taxa = [t for t in taxa if chave_nome(t["nome"]) in alvo]
        n_sin = _atualizar_sinonimos_sem_autoria(con, cli, log, taxa)

        # Nomes pelos quais um organismo de fonte pode interessar (delimitação; a decisão é do Resolvedor).
        binomios_por_taxon = {}
        for t in taxa:
            nomes = {_binomio(t["nome"])}
            nomes.update(_binomio(r["nome"]) for r in con.execute(
                "SELECT nome FROM taxon_sinonimo WHERE taxon_id=? UNION SELECT nome FROM taxon_sinonimo_legado WHERE taxon_id=?",
                (t["id"], t["id"])))
            nomes.discard(None)
            binomios_por_taxon[t["id"]] = nomes
        binomios = set().union(*binomios_por_taxon.values()) if binomios_por_taxon else set()
        generos = {b.split()[0] for b in binomios}
        resolvedor = taxonomia.Resolvedor(con, cli)
        ids_taxa = {t["id"] for t in taxa}

        # ── 1) LOTUS: dump congelado, organismo + identificador GBIF que a própria fonte dá
        por_org, classes_locais, cid_lotus = lotus.indexar_dump_por_organismo(con, generos=generos, log=log)
        por_org = {k: v for k, v in por_org.items()
                   if _binomio(k[0]) in binomios or _binomio(v["especie_lotus"]) in binomios}
        log(f"  LOTUS: {len(por_org)} organismos a resolver no backbone do GBIF…")
        dec_lotus = resolvedor.resolver_varios(
            "lotus", [(nome, gid, v["familia"], _REINO_GBIF.get((v["reino"] or "").lower())) for (nome, gid), v in por_org.items()], log)
        lotus_por_taxon = lotus.compostos_por_taxon(por_org, dec_lotus)
        orgs_lotus_por_binomio = {}
        for k in por_org:
            orgs_lotus_por_binomio.setdefault(_binomio(k[0]), []).append(k)

        # ── 2) NuBBE-DB: nome inteiro, sem identificador; casamento estrito
        indice_nubbe, cid_nubbe, nb_por_taxon, dec_nubbe = {}, None, {}, {}
        try:
            cache_nb = getattr(cli, "_indice_nubbe_cache", None)
            indice_nubbe, cid_nubbe = cache_nb if cache_nb is not None else nubbe.carregar_indice(cli)
        except Exception as exc:
            log(f"  aviso: NuBBE-DB indisponível ({type(exc).__name__}: {exc}); as afirmações existentes ficam como estão")
        if cid_nubbe:
            indice_nubbe = {n: v for n, v in indice_nubbe.items() if _binomio(n) in binomios}
            dec_nubbe = resolvedor.resolver_varios("nubbe", [(n, "", None, None) for n in indice_nubbe], log)
            nb_por_taxon = nubbe.compostos_por_taxon(indice_nubbe, dec_nubbe)
        orgs_nubbe_por_binomio = {}
        for n in indice_nubbe:
            orgs_nubbe_por_binomio.setdefault(_binomio(n), []).append(n)

        # ── 3) NPAtlas: fungos, nome inteiro; casamento estrito no reino Fungi
        indice_np, cid_np, dec_np = {}, None, {}
        tem_fungo = any(t["grupo"] == "fungo" for t in taxa)
        if tem_fungo:
            try:
                indice_np, cid_np = npatlas_coconut.carregar_indice(cli)
            except Exception as exc:
                log(f"  aviso: NPAtlas indisponível ({type(exc).__name__}: {exc}); as afirmações existentes ficam como estão")
        if cid_np:
            indice_np = {n: v for n, v in indice_np.items() if _binomio(n) in binomios}
            dec_np = resolvedor.resolver_varios("npatlas", [(n, "", None, "Fungi") for n in indice_np], log)
        np_nomes_por_taxon = {}
        for n in indice_np:
            d = dec_np.get((n, ""))
            if d is not None and d.taxon_id is not None and d.decisao in ("aceito", "aceito_mesmo_nome_e_autoria", "homonimo_nao_resolvido"):
                np_nomes_por_taxon.setdefault(d.taxon_id, {}).setdefault(d.decisao != "homonimo_nao_resolvido", []).append(n)
        orgs_np_por_binomio = {}
        for n in indice_np:
            orgs_np_por_binomio.setdefault(_binomio(n), []).append(n)
        _ik_np_cache = {}

        def _inchikeys_np(nome_org):
            if nome_org not in _ik_np_cache:
                iks = set()
                for row, _, _ in indice_np.get(nome_org, ()):
                    est = nubbe._padronizar_estrutura((row.get("compound_smiles") or "").strip())
                    if est:
                        iks.add(est["inchikey"])
                _ik_np_cache[nome_org] = iks
            return _ik_np_cache[nome_org]

        cont = Counter()
        disparos, examinadas = {}, set()
        for i, t in enumerate(taxa, 1):
            tid = t["id"]
            existentes = {}
            for a in con.execute(
                    "SELECT a.id, a.origem, a.fonte_id, a.estado, a.molecula_id, a.uf_coleta_declarada, m.inchikey "
                    "FROM afirmacao a JOIN molecula m ON m.id=a.molecula_id "
                    "WHERE a.taxon_id=? AND a.tipo='composto_em_organismo' AND a.fonte_id IN ('lotus','nubbe','npatlas')", (tid,)):
                existentes.setdefault(a["fonte_id"], {})[a["origem"]] = a
            atuais = {"lotus": set(), "nubbe": set(), "npatlas": set()}

            # LOTUS
            for c in lotus_por_taxon.get(tid, ()):
                mid = upsert_molecula_pequena(con, c)
                refs = [upsert_referencia(con, doi=doi) for doi in c["referencias"]]
                bases = sorted({b for v in c["referencias"].values() for b in v})
                origem_lt = f"lotus:{c['inchikey']}"
                aid = upsert_afirmacao(
                    con, tipo="composto_em_organismo", molecula_id=mid, taxon_id=tid, origem=origem_lt, fonte_id="lotus",
                    consulta_id=cid_lotus, texto_=texto.enunciado_composto(c["nome"], t["nome"], len(c["referencias"])),
                    metodo="Relato em publicação, curado pelo LOTUS (bases taxonômicas: " + ", ".join(bases) + ")",
                    refs=refs, validacao_manual_fonte=c.get("validacao_manual"), organismo_na_fonte="; ".join(c["organismos"]))
                atuais["lotus"].add(origem_lt)
                examinadas.add(aid)
                cont["desvinculos_de_outra_especie"] += _sincronizar_referencias(
                    con, aid, refs, "o LOTUS associa esta referência a outro organismo, não a " + t["nome"])
                if not c["firme"]:
                    usos = sorted({(dec_lotus[(n, g)].gbif_nome_completo or n) for (n, g) in por_org
                                   if n in c["organismos_homonimo"] and (n, g) in dec_lotus})
                    disparos.setdefault(aid, {})["TAX-HOMONIMO"] = {
                        "organismo_fonte": _resumo_nomes(c["organismos_homonimo"]), "uso_fonte": _resumo_nomes(usos),
                        "taxon": t["nome"], "autoria_taxon": t["autoria"] or ""}
                cont["lotus"] += 1

            # NuBBE-DB (por InChIKey e UF de coleta declarada)
            if cid_nubbe:
                por_mol_uf = {(a["molecula_id"], a["uf_coleta_declarada"] or ""): o for o, a in existentes.get("nubbe", {}).items()}
                for c in nb_por_taxon.get(tid, ()):
                    mid = upsert_molecula_pequena(con, c)
                    refs_nb = [upsert_referencia(con, doi=doi, titulo=meta.get("titulo"), revista=meta.get("revista"),
                                                 ano=meta.get("ano"), consulta_id=cid_nubbe)
                               for doi, meta in c["referencias"].items()]
                    metodo_nb = "Registro compilado pelo NuBBE-DB (UNESP)"
                    if c.get("isolamento"):
                        metodo_nb += f" · tipo de obtenção: {c['isolamento']}"
                    # a identidade da afirmação é (táxon, molécula, UF): reaproveita a origem já gravada
                    origem_nb = por_mol_uf.get((mid, c["uf_coleta"] or "")) or c["origem"]
                    aid = upsert_afirmacao(
                        con, tipo="composto_em_organismo", molecula_id=mid, taxon_id=tid, origem=origem_nb, fonte_id="nubbe",
                        consulta_id=cid_nubbe,
                        texto_=texto.enunciado_composto_nubbe(c["nome"], t["nome"], len(c["referencias"]), c.get("uf_coleta")),
                        metodo=metodo_nb, refs=refs_nb, uf_coleta_declarada=c.get("uf_coleta"),
                        pais_coleta_declarado="BR" if c.get("uf_coleta") else None, organismo_na_fonte="; ".join(c["organismos"]))
                    atuais["nubbe"].add(origem_nb)
                    examinadas.add(aid)
                    cont["desvinculos_de_outra_especie"] += _sincronizar_referencias(
                        con, aid, refs_nb, "o NuBBE-DB não associa esta referência ao isolamento do composto em " + t["nome"])
                    if c["nao_constituinte"]:
                        disparos.setdefault(aid, {})["NAT-SEMISSINTETICO"] = {
                            "tipo_isolamento": " e ".join(c["tipos_nao_constituinte"]) or "derivado", "taxon": t["nome"]}
                    if not c["firme"]:
                        disparos.setdefault(aid, {})["TAX-HOMONIMO"] = _dados_homonimo(t, c, dec_nubbe)
                    cont["nubbe"] += 1

            # NPAtlas
            if cid_np and t["grupo"] == "fungo":
                nomes_np = np_nomes_por_taxon.get(tid, {})
                firmes, homon = nomes_np.get(True, []), nomes_np.get(False, [])
                por_mol = {a["molecula_id"]: o for o, a in existentes.get("npatlas", {}).items()}
                comps_firmes, _ = npatlas_coconut.compostos_do_fungo(cli, firmes, classes_locais=classes_locais) if firmes else ([], None)
                iks_firmes = {c["inchikey"] for c in comps_firmes}
                comps_homon = []
                if homon:
                    comps_homon = [c for c in npatlas_coconut.compostos_do_fungo(cli, homon, classes_locais=classes_locais)[0]
                                   if c["inchikey"] not in iks_firmes]
                for c, firme in [(c, True) for c in comps_firmes] + [(c, False) for c in comps_homon]:
                    mid = upsert_molecula_pequena(con, c)
                    refs_np = [upsert_referencia(con, doi=meta.get("doi"), pmid=meta.get("pmid"), titulo=meta.get("titulo"),
                                                 revista=meta.get("revista"), ano=meta.get("ano"), autores=meta.get("autores"),
                                                 consulta_id=c["consulta_id"]) for meta in c["referencias"].values()]
                    origem_np = por_mol.get(mid) or f"npatlas:{c['npatlas_id']}"
                    aid = upsert_afirmacao(
                        con, tipo="composto_em_organismo", molecula_id=mid, taxon_id=tid, origem=origem_np, fonte_id="npatlas",
                        consulta_id=c["consulta_id"] or cid_np,
                        texto_=texto.enunciado_composto_npatlas(c["nome"], t["nome"], len(c["referencias"])),
                        metodo="Isolamento fúngico/microbiano curado pelo Natural Products Atlas (NPAtlas)",
                        refs=refs_np, organismo_na_fonte="; ".join(c["organismos"]))
                    atuais["npatlas"].add(origem_np)
                    examinadas.add(aid)
                    cont["desvinculos_de_outra_especie"] += _sincronizar_referencias(
                        con, aid, refs_np, "o NPAtlas associa esta referência a outro organismo, não a " + t["nome"])
                    if not firme:
                        disparos.setdefault(aid, {})["TAX-HOMONIMO"] = _dados_homonimo(
                            t, {"organismos_homonimo": c["organismos"]}, dec_np)
                    cont["npatlas"] += 1

            # Afirmações que já estavam no banco e que a resolução por organismo não reproduz: retidas com o motivo.
            fontes_lidas = {"lotus": True, "nubbe": bool(cid_nubbe), "npatlas": bool(cid_np) and t["grupo"] == "fungo"}
            for fonte_id, por_origem in existentes.items():
                if not fontes_lidas.get(fonte_id):
                    continue
                for origem, a in por_origem.items():
                    if origem in atuais[fonte_id] or a["estado"] == "rejeitado":
                        continue
                    examinadas.add(a["id"])
                    ik, uf = a["inchikey"], a["uf_coleta_declarada"]
                    responsaveis = []
                    for b in sorted(binomios_por_taxon[tid]):
                        if fonte_id == "lotus":
                            responsaveis += [(k[0], dec_lotus.get(k)) for k in orgs_lotus_por_binomio.get(b, ())
                                             if ik in por_org[k]["compostos"]]
                        elif fonte_id == "nubbe":
                            responsaveis += [(n, dec_nubbe.get((n, ""))) for n in orgs_nubbe_por_binomio.get(b, ())
                                             if (ik, uf) in indice_nubbe[n]["compostos"]]
                        else:
                            responsaveis += [(n, dec_np.get((n, ""))) for n in orgs_np_por_binomio.get(b, ())
                                             if ik in _inchikeys_np(n)]
                    codigo, dados = _explicar_vinculo_antigo(t, responsaveis, fonte_id)
                    disparos.setdefault(a["id"], {})[codigo] = dados
                    if responsaveis:
                        con.execute("UPDATE afirmacao SET organismo_na_fonte=? WHERE id=? AND organismo_na_fonte IS NULL",
                                    ("; ".join(sorted({n for n, _ in responsaveis})), a["id"]))
                    cont["antigas_nao_reproduzidas"] += 1
            if i % 100 == 0 or i == len(taxa):
                con.commit()
                log(f"  … {i}/{len(taxa)} táxons; LOTUS={cont['lotus']} · NuBBE={cont['nubbe']} · NPAtlas={cont['npatlas']}")

        _vincular_universo_checklist_a_taxon(con)
        res_decl = quarentena.declarar(con, REGRAS_DE_COMPOSTOS, disparos, entre=examinadas)
        res_mol = aplicar_regras_de_molecula(con)
        res_est = quarentena.aplicar_estados(con, evento)
        _atualizar_contagens_de_compostos(con, ids_taxa, cid_lotus)
        con.commit()
        decisoes = Counter(f"{d.fonte_id}:{d.decisao}" for mapa in (dec_lotus, dec_nubbe, dec_np) for d in mapa.values())
        e.resumo = {"taxons": len(taxa), "sinonimos_atualizados": n_sin, "afirmacoes_lotus": cont["lotus"],
                    "afirmacoes_nubbe": cont["nubbe"], "afirmacoes_npatlas": cont["npatlas"],
                    "organismos_resolvidos": dict(sorted(decisoes.items())),
                    "antigas_nao_reproduzidas": cont["antigas_nao_reproduzidas"],
                    "desvinculos_de_referencia_de_outra_especie": cont["desvinculos_de_outra_especie"],
                    "regras_declaradas": res_decl["declaradas"], "regras_de_molecula": res_mol, "estados": res_est}


def _atualizar_contagens_de_compostos(con, ids_taxa, cid_lotus):
    """Contagens por táxon: `compostos_fonte` = moléculas que as fontes atribuem ao táxon; `compostos_incluidos` e as
    parciais por base = as que estão a público."""
    publico = "a.estado NOT IN ('quarentena','rejeitado') AND a.classe_acesso='publico'"
    for tid in ids_taxa:
        linha = con.execute(
            "SELECT COUNT(DISTINCT a.molecula_id) AS total, "
            f"COUNT(DISTINCT CASE WHEN {publico} THEN a.molecula_id END) AS pub, "
            f"COUNT(DISTINCT CASE WHEN {publico} AND a.fonte_id='lotus' THEN a.molecula_id END) AS lt, "
            f"COUNT(DISTINCT CASE WHEN {publico} AND a.fonte_id='nubbe' THEN a.molecula_id END) AS nb, "
            f"COUNT(DISTINCT CASE WHEN {publico} AND a.fonte_id='npatlas' THEN a.molecula_id END) AS np "
            "FROM afirmacao a WHERE a.taxon_id=? AND a.tipo='composto_em_organismo' AND a.estado!='rejeitado' "
            "AND (a.regra_quarentena IS NULL OR a.regra_quarentena NOT IN "
            "('TAX-ESPECIE-DIVERGENTE','TAX-NAO-RESOLVIDO','FONTE-NAO-SUSTENTA'))", (tid,)).fetchone()
        con.execute("UPDATE taxon SET compostos_fonte=?, compostos_incluidos=?, compostos_lotus=?, compostos_nubbe=?, "
                    "compostos_npatlas=?, lotus_consulta_id=COALESCE(?, lotus_consulta_id) WHERE id=?",
                    (linha["total"], linha["pub"], linha["lt"], linha["nb"], linha["np"], cid_lotus, tid))


# ── substâncias que não podem constar como constituinte (lista curada em semente/nao_constituintes.toml)
REGRAS_DE_MOLECULA = ("NAT-CONTROLE", "NAT-ELEMENTO", "NAT-CONTAMINANTE", "MOL-SEM-ESTRUTURA")
_ROTULO_RESTRICAO = {
    "farmaco_ou_reagente_sintetico": "fármaco ou reagente de origem sintética",
    "controle_de_ensaio": "produto natural de outro grupo de organismos, comum como controle positivo de ensaio",
}


_FORMULA_MONOATOMICA = re.compile(r"^[A-Z][a-z]?(?:[+-]\d*)?$")


def carregar_nao_constituintes(caminho=None):
    arq = Path(caminho) if caminho else (config.SEMENTE_DIR / "nao_constituintes.toml")
    if not arq.exists():
        return []
    with open(arq, "rb") as f:
        return tomllib.load(f).get("substancia", [])


def aplicar_regras_de_molecula(con, lista=None):
    """Marca `molecula.restricao_ocorrencia` pela lista curada e declara as regras que retêm as ocorrências.

    A chave é o primeiro bloco do InChIKey (conectividade), para alcançar sais e estereoisômeros da mesma substância.
    Um produto natural usado como controle de ensaio só é retido fora dos gêneros produtores indicados na lista.
    """
    lista = carregar_nao_constituintes() if lista is None else lista
    por_bloco = {x["conectividade"].strip().upper(): x for x in lista if x.get("conectividade")}
    con.execute("UPDATE molecula SET restricao_ocorrencia=NULL WHERE restricao_ocorrencia IS NOT NULL")
    for bloco, x in por_bloco.items():
        con.execute("UPDATE molecula SET restricao_ocorrencia=? WHERE inchikey_conectividade=?", (x["restricao"], bloco))
    con.execute("UPDATE molecula SET inchikey_conectividade=substr(inchikey,1,14) WHERE inchikey IS NOT NULL AND inchikey_conectividade IS NULL")
    for bloco, x in por_bloco.items():
        con.execute("UPDATE molecula SET restricao_ocorrencia=? WHERE inchikey_conectividade=?", (x["restricao"], bloco))
    # Elemento químico: espécie monoatômica (Ca, Fe, Na+…), reconhecida pela fórmula. Teor mineral não é metabólito.
    for m in con.execute("SELECT id, formula FROM molecula WHERE tipo='pequena_molecula' AND formula IS NOT NULL").fetchall():
        if _FORMULA_MONOATOMICA.match(m["formula"].strip()):
            con.execute("UPDATE molecula SET restricao_ocorrencia='elemento_quimico' WHERE id=?", (m["id"],))
    disparos = {}
    for a in con.execute(
            "SELECT a.id, m.nome AS substancia, m.restricao_ocorrencia AS restricao, m.inchikey_conectividade AS bloco, "
            "m.smiles, m.tipo AS m_tipo, t.nome AS taxon, t.genero FROM afirmacao a JOIN molecula m ON m.id=a.molecula_id "
            "JOIN taxon t ON t.id=a.taxon_id WHERE a.tipo='composto_em_organismo'").fetchall():
        dados = {"substancia": a["substancia"], "taxon": a["taxon"]}
        if a["restricao"] == "elemento_quimico":
            disparos.setdefault(a["id"], {})["NAT-ELEMENTO"] = dados
        elif a["restricao"] == "contaminante_provavel":
            disparos.setdefault(a["id"], {})["NAT-CONTAMINANTE"] = dados
        elif a["restricao"] in _ROTULO_RESTRICAO:
            produtores = {g.lower() for g in por_bloco.get(a["bloco"], {}).get("generos_produtores", [])}
            if (a["genero"] or "").lower() not in produtores:
                disparos.setdefault(a["id"], {})["NAT-CONTROLE"] = {**dados, "classe_restricao": _ROTULO_RESTRICAO[a["restricao"]]}
        if a["m_tipo"] == "pequena_molecula" and not a["smiles"] and a["restricao"] != "elemento_quimico":
            disparos.setdefault(a["id"], {})["MOL-SEM-ESTRUTURA"] = dados
    res = quarentena.declarar(con, REGRAS_DE_MOLECULA, disparos)
    return res["declaradas"]


# ═══════════════════════════ etapa 5: enriquecimento (PubChem, ChEMBL) ═══════════════════════════
def _nome_curto(n):
    return bool(n) and len(n) <= 60


def etapa_enriquecer(con, cli, log):
    with Etapa(con, "enriquecimento", log) as e:
        pend = con.execute("SELECT id, inchikey, nome FROM molecula WHERE inchikey IS NOT NULL AND pubchem_consulta_id IS NULL").fetchall()
        log(f"  PubChem em lote: {len(pend)} moléculas")
        achou_pc = 0
        for i in range(0, len(pend), 1400):
            lote = pend[i:i + 1400]
            mapa_pc = pubchem.propriedades_em_lote(cli, [m["inchikey"] for m in lote], tamanho_lote=35)
            for m in lote:
                par = mapa_pc.get(m["inchikey"])
                if not par:
                    continue
                p, cid_pc = par
                if p:
                    achou_pc += 1
                    nome_orig = quimica.limpar_nome_quimico(m["nome"])
                    novo = quimica.escolher_nome_molecula(nome_orig, p["titulo"], p.get("iupac"), m["inchikey"])
                    diverge = 0
                    nome_fonte = None
                    if chave_nome(novo) != chave_nome(nome_orig) and not quimica.nome_quimico_invalido(nome_orig):
                        nome_fonte = nome_orig
                        diverge = 1 if _nome_curto(nome_orig) else 0
                    smiles_pc = p["smiles"]
                    if smiles_pc and not quimica.conferir_inchikey(smiles_pc, m["inchikey"])[0]:
                        smiles_pc = None
                    con.execute("UPDATE molecula SET nome=?, nome_na_fonte=COALESCE(?, nome_na_fonte), nome_divergente=?, "
                                "pubchem_cid=?, formula=COALESCE(formula,?), massa=COALESCE(massa,?), smiles=COALESCE(smiles,?), "
                                "pubchem_consulta_id=? WHERE id=?",
                                (novo, nome_fonte, diverge, p["cid"], p["formula"], p["massa"], smiles_pc, cid_pc, m["id"]))
                elif cid_pc is not None:
                    con.execute("UPDATE molecula SET pubchem_consulta_id=? WHERE id=?", (cid_pc, m["id"]))
            con.commit()
            log(f"    PubChem {min(i + 1400, len(pend))}/{len(pend)} (encontradas={achou_pc})")

        pend = con.execute("SELECT id, inchikey FROM molecula WHERE inchikey IS NOT NULL AND fase_consulta_id IS NULL").fetchall()
        log(f"  ChEMBL em lote: {len(pend)} moléculas")
        achou_ch = aprovados = 0
        for i in range(0, len(pend), 1600):
            lote = pend[i:i + 1600]
            mapa_ch = chembl.moleculas_em_lote(cli, [m["inchikey"] for m in lote], tamanho_lote=40)
            for m in lote:
                par = mapa_ch.get(m["inchikey"])
                if not par:
                    continue
                c, cid_ch = par
                if c:
                    achou_ch += 1
                    aprovados += 1 if (c["max_fase"] or 0) >= 4 else 0
                    con.execute("UPDATE molecula SET chembl_id=?, max_fase_clinica=?, fase_retirado=?, fase_consulta_id=?, "
                                "nome=CASE WHEN pubchem_cid IS NULL AND ? IS NOT NULL THEN ? ELSE nome END WHERE id=?",
                                (c["chembl_id"], c["max_fase"], 1 if c["retirado"] else 0, cid_ch,
                                 c["nome"], (c["nome"] or "").title(), m["id"]))
                elif cid_ch is not None:
                    con.execute("UPDATE molecula SET fase_consulta_id=? WHERE id=?", (cid_ch, m["id"]))
            con.commit()
            log(f"    ChEMBL {min(i + 1600, len(pend))}/{len(pend)} (encontradas={achou_ch})")
        n_classes = 0
        for m in con.execute("SELECT id, classe_quimica FROM molecula WHERE classe_quimica LIKE '%|%'").fetchall():
            con.execute("UPDATE molecula SET classe_quimica=? WHERE id=?", (lotus.limpar_classe(m["classe_quimica"]), m["id"]))
            n_classes += 1
        for m in con.execute(
            "SELECT id, inchikey, smiles FROM molecula WHERE tipo='pequena_molecula' AND inchikey IS NOT NULL AND smiles IS NOT NULL"
        ).fetchall():
            if not quimica.conferir_inchikey(m["smiles"], m["inchikey"])[0]:
                con.execute("UPDATE molecula SET smiles=NULL, desenho=NULL, umap_x=NULL, umap_y=NULL WHERE id=?", (m["id"],))
                evento(con, "molecula", m["id"], "saneamento_inchikey",
                       f"SMILES na fonte divergiu do InChIKey de 27 caracteres ({m['inchikey']}); SMILES omitido (Princípio 2).")
        for m in con.execute(
            "SELECT id, inchikey, smiles, classe_quimica, max_fase_clinica FROM molecula "
            "WHERE inchikey IS NOT NULL AND (alerta_pains IS NULL OR max_fase_clinica >= 4)"
        ).fetchall():
            pains = "; ".join(quimica.alertas_pains(m["smiles"])) or None
            cat_clin = quimica.classificar_fase4(m["inchikey"], m["classe_quimica"]) if (m["max_fase_clinica"] or 0) >= 4 else None
            ctrl = quimica.controle_portaria_344(m["inchikey"])
            con.execute("UPDATE molecula SET alerta_pains=?, categoria_clinica=?, controle_regulatorio=? WHERE id=?",
                        (pains, cat_clin, ctrl, m["id"]))
        n_q344 = quarentenar_portaria_344(con)
        n_linhagens = linhagem_vias.registrar_linhagens_farmacologicas(con, cli, upsert_referencia, log)
        aplicar_regras_de_molecula(con)
        quimica.normalizar_estruturas(con)
        quarentena.aplicar_estados(con, evento)
        res_espaco = quimica_espaco.atualizar_banco(con, log)
        config.SAIDA_DIR.mkdir(parents=True, exist_ok=True)
        (config.SAIDA_DIR / "tmap_arestas.json").write_text(
            json_compacto(res_espaco.get("arestas", [])), encoding="utf-8"
        )
        con.commit()
        e.resumo = {"pubchem_consultadas": achou_pc, "chembl_encontradas": achou_ch, "aprovadas_fase4": aprovados,
                    "quarentena_portaria_344": n_q344,
                    "linhagens_farmacologicas": n_linhagens,
                    "moleculas_projetadas_umap": res_espaco["moleculas_projetadas"],
                    "arestas_tmap": res_espaco["arestas_tmap"],
                    "enunciados_regerados": regerar_enunciados(con), "classes_normalizadas": n_classes}


def quarentenar_portaria_344(con):
    """Retém (sem apagar) afirmações de substâncias nas listas estritas/proscritas da Portaria SVS/MS nº 344/1998
    (Listas A1, A2, E, F1, F2), pela regra REG-344. Devolve quantas afirmações passaram a disparar a regra."""
    quarentena.registrar_catalogo(con)
    antes = {r["afirmacao_id"] for r in con.execute("SELECT afirmacao_id FROM afirmacao_regra WHERE codigo='REG-344'")}
    disparos = {}
    for r in con.execute("SELECT a.id, m.inchikey FROM afirmacao a JOIN molecula m ON m.id=a.molecula_id "
                         "WHERE m.inchikey IS NOT NULL AND a.estado != 'rejeitado'").fetchall():
        achado = quimica.substancia_proscrita_344(r["inchikey"])
        if achado:
            lista, ref_nome = achado
            disparos[r["id"]] = {"REG-344": {"lista": f"Lista {lista}", "substancia": ref_nome}}
    quarentena.declarar(con, ("REG-344",), disparos)
    quarentena.aplicar_estados(con, evento)
    con.commit()
    return len(set(disparos) - antes)


def regerar_enunciados(con):
    """Enunciados de composto-em-organismo usam o nome exibido da molécula, que muda no enriquecimento."""
    n = 0
    sql = ("SELECT a.id, a.texto, a.fonte_id, a.uf_coleta_declarada, m.nome AS m_nome, t.nome AS t_nome, "
           "(SELECT COUNT(*) FROM afirmacao_referencia x WHERE x.afirmacao_id=a.id) AS n_pub "
           "FROM afirmacao a JOIN molecula m ON m.id=a.molecula_id JOIN taxon t ON t.id=a.taxon_id "
           "WHERE a.tipo='composto_em_organismo'")
    for a in con.execute(sql).fetchall():
        if a["fonte_id"] == "nubbe":
            novo = texto.enunciado_composto_nubbe(a["m_nome"], a["t_nome"], a["n_pub"], a["uf_coleta_declarada"])
        elif a["fonte_id"] == "npatlas":
            novo = texto.enunciado_composto_npatlas(a["m_nome"], a["t_nome"], a["n_pub"])
        else:
            novo = texto.enunciado_composto(a["m_nome"], a["t_nome"], a["n_pub"])
        if novo != a["texto"]:
            con.execute("UPDATE afirmacao SET texto=?, atualizado_em=? WHERE id=?", (novo, agora(), a["id"]))
            n += 1
    con.commit()
    return n


# ═══════════════════════════ etapa 6: atividades e efeito clínico (ChEMBL) ═══════════════════════════
def _declarar_alvos_provisorios(con):
    """Atividade ligada a alvo provisório do ChEMBL não informa ação sobre alvo algum: regra BIO-ALVO-PROVISORIO."""
    marcas = ",".join("?" * len(chembl.ALVOS_SEM_ATRIBUICAO))
    linhas = con.execute(
        f"SELECT a.id, l.nome AS alvo_nome, l.chembl_id FROM afirmacao a JOIN alvo l ON l.id=a.alvo_id "
        f"WHERE a.tipo='atividade_biologica' AND lower(trim(l.nome)) IN ({marcas})", tuple(chembl.ALVOS_SEM_ATRIBUICAO)).fetchall()
    quarentena.declarar(con, ("BIO-ALVO-PROVISORIO",),
                        {r["id"]: {"BIO-ALVO-PROVISORIO": {"alvo": f"{r['alvo_nome']} / {r['chembl_id']}"}} for r in linhas})
    return len(linhas)


def _natureza_dos_alvos(con, cli, ids, cache):
    """Tipo do alvo no ChEMBL (`target_type`) para os ids pedidos; guarda em `cache` e atualiza as linhas de `alvo`."""
    faltam = sorted(i for i in ids if i and i not in cache)
    for ini in range(0, len(faltam), 50):
        lote = faltam[ini:ini + 50]
        try:
            r = cli.get(f"{chembl.API}/target.json", {"target_chembl_id__in": ",".join(lote), "limit": 100,
                                                       "only": "target_chembl_id,target_type,pref_name,organism"},
                        fonte="chembl", tentativas=3)
        except ErroDeFonte:
            continue
        for t in (r.dados.get("targets") or []) if isinstance(r.dados, dict) else []:
            cache[t["target_chembl_id"]] = {"tipo_chembl": t.get("target_type"), "natureza": chembl.natureza_do_alvo(t.get("target_type")),
                                            "nome": t.get("pref_name"), "organismo": t.get("organism"), "consulta_id": r.consulta_id}
    for i in ids:
        info = cache.get(i)
        if info:
            con.execute("UPDATE alvo SET tipo_chembl=?, natureza=? WHERE chembl_id=? AND (tipo_chembl IS NOT ? OR natureza IS NOT ?)",
                        (info["tipo_chembl"], info["natureza"], i, info["tipo_chembl"], info["natureza"]))
    return cache


def _garantir_alvo(con, alvo_chembl_id, info, medida):
    info = info or {}
    nome = info.get("nome") or medida.get("target_pref_name") or alvo_chembl_id
    organismo = info.get("organismo") or medida.get("target_organism")
    linha = con.execute("SELECT id FROM alvo WHERE chembl_id=?", (alvo_chembl_id,)).fetchone()
    if linha:
        con.execute("UPDATE alvo SET tipo_chembl=COALESCE(?, tipo_chembl), natureza=COALESCE(?, natureza) WHERE id=?",
                    (info.get("tipo_chembl"), info.get("natureza"), linha["id"]))
        return linha["id"], nome, organismo
    con.execute("INSERT INTO alvo (nome, chembl_id, organismo, tipo, tipo_chembl, natureza) VALUES (?,?,?,?,?,?)",
                (nome, alvo_chembl_id, organismo, info.get("tipo_chembl"), info.get("tipo_chembl"), info.get("natureza") or "indeterminado"))
    return con.execute("SELECT last_insert_rowid()").fetchone()[0], nome, organismo


def _agregar_molecula(con, m, medidas, cid, naturezas, docs, disparos, examinadas, cont):
    """Grava, para UMA molécula, as afirmações de bioatividade agregadas e o livro de medidas."""
    grupos = bioatividade.agrupar(medidas)
    ags = {par: bioatividade.agregar_par(lst) for par, lst in grupos.items()}

    def nat(par):
        return (naturezas.get(par[0]) or {}).get("natureza") or "indeterminado"

    validos = sorted((par for par, ag in ags.items() if ag["usadas"] and ag["regra"] is None),
                     key=lambda par: bioatividade.ordem_de_selecao(par, ags[par], nat(par)))
    selecionados = validos[:MAX_ATIVIDADES_POR_MOLECULA]
    legadas = {}
    for a in con.execute(
            "SELECT a.id, a.origem, a.medida_tipo, l.chembl_id AS alvo_chembl FROM afirmacao a JOIN alvo l ON l.id=a.alvo_id "
            "WHERE a.molecula_id=? AND a.tipo='atividade_biologica' ORDER BY a.id", (m["id"],)).fetchall():
        legadas.setdefault((a["alvo_chembl"], a["medida_tipo"]), a)
    for par in selecionados + [p for p in legadas if p not in selecionados]:
        ag, legado = ags.get(par), legadas.get(par)
        origem = f"chembl:agregado:{m['chembl_id']}:{par[0]}:{par[1]}"
        if legado is not None and legado["origem"] != origem:
            con.execute("UPDATE afirmacao SET origem=? WHERE id=?", (origem, legado["id"]))
            evento(con, "afirmacao", legado["id"], "agregacao",
                   f"{legado['origem']} → {origem}: a medida isolada dá lugar ao valor central das medidas válidas do par")
        if ag is None or not ag["usadas"]:
            if legado is None:
                continue
            examinadas.add(legado["id"])
            if ag is None:
                disparos.setdefault(legado["id"], {})["FONTE-NAO-SUSTENTA"] = {"fonte": "ChEMBL", "taxon": f"«{m['nome']}»"}
            else:
                disparos.setdefault(legado["id"], {})[ag["regra"]] = ag["dados_regra"]
                _gravar_medidas(con, legado["id"], m["id"], par, ag, cid)
            cont["sem_medida_valida"] += 1
            continue
        primeira = ag["usadas"][0]
        alvo_id, alvo_nome, alvo_org = _garantir_alvo(con, par[0], naturezas.get(par[0]), primeira)
        refs = []
        for d_id in sorted({a.get("document_chembl_id") for a in ag["usadas"] if a.get("document_chembl_id")}):
            d = docs.get(d_id)
            if d and (d["doi"] or d["pmid"]):
                refs.append(upsert_referencia(con, doi=d["doi"], pmid=d["pmid"], titulo=d["titulo"], revista=d["revista"],
                                              ano=d["ano"], consulta_id=d["consulta_id"]))
        tipo_ens = bioatividade.tipo_de_ensaio(ag["usadas"])
        sistema = ((primeira.get("assay_description") or "").strip() or None) if ag["n"] == 1 else (
            f"{ag['n']} medidas em {ag['n_documentos']} {'publicação' if ag['n_documentos'] == 1 else 'publicações'}")
        aid = upsert_afirmacao(
            con, tipo="atividade_biologica", molecula_id=m["id"], alvo_id=alvo_id, origem=origem, fonte_id="chembl",
            consulta_id=cid, texto_=texto.enunciado_atividade_agregada(m["nome"], alvo_nome, alvo_org, par[1], ag, nat(par)),
            metodo=texto.metodo_agregado(ag, tipo_ens), sistema=sistema,
            medida={"tipo": par[1], "relacao": "=", "valor": ag["valor_nm"], "unidade": "nM"}, refs=refs,
            extras={"medida_agregacao": ag["agregacao"], "medida_n": ag["n"], "medida_n_documentos": ag["n_documentos"],
                    "medida_min": ag["min_nm"], "medida_max": ag["max_nm"], "ensaio_tipo": tipo_ens,
                    "contexto_ensaio": json_compacto(bioatividade.contexto(ag["usadas"]))})
        examinadas.add(aid)
        _sincronizar_referencias(con, aid, refs, "a medida desta publicação não entra no valor central do par")
        _gravar_medidas(con, aid, m["id"], par, ag, cid)
        if ag["regra"]:
            disparos.setdefault(aid, {})[ag["regra"]] = ag["dados_regra"]
            cont[ag["regra"]] += 1
        elif par not in selecionados:
            disparos.setdefault(aid, {})["BIO-FORA-DA-SELECAO"] = {"limite": MAX_ATIVIDADES_POR_MOLECULA, "substancia": m["nome"]}
            cont["fora_da_selecao"] += 1
        else:
            cont["pares_publicaveis"] += 1


def _gravar_medidas(con, afirmacao_id, molecula_id, par, ag, cid):
    con.execute("DELETE FROM medida_bioatividade WHERE afirmacao_id=?", (afirmacao_id,))
    linhas = [(a, 1, None) for a in ag["usadas"]] + [(a, 0, motivo) for a, motivo in ag["excluidas"]]
    for a, usada, motivo in linhas:
        con.execute(
            "INSERT INTO medida_bioatividade (activity_id, afirmacao_id, molecula_id, alvo_chembl_id, tipo, relacao, valor_nm, "
            "pchembl, documento_chembl_id, ensaio_chembl_id, ensaio_tipo, usada, motivo_exclusao, consulta_id) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(activity_id) DO UPDATE SET afirmacao_id=excluded.afirmacao_id, "
            "usada=excluded.usada, motivo_exclusao=excluded.motivo_exclusao, valor_nm=excluded.valor_nm, pchembl=excluded.pchembl",
            (a["activity_id"], afirmacao_id, molecula_id, par[0], par[1], a.get("standard_relation"),
             bioatividade._num(a.get("standard_value")) if (a.get("standard_units") or "") == "nM" else None,
             bioatividade._num(a.get("pchembl_value")), a.get("document_chembl_id"), a.get("assay_chembl_id"),
             a.get("assay_type"), usada, motivo, cid))


def _fontes_regulatorias(cl):
    """Rótulos e registros que o ChEMBL cita para as indicações e os mecanismos (DailyMed, FDA, EMA, ATC…)."""
    vistos, saida = set(), []
    for bloco in (cl.get("indicacoes") or []) + (cl.get("mecanismos") or []):
        for x in bloco.get("referencias") or []:
            chave_x = (x.get("tipo"), x.get("id"))
            if x.get("tipo") and x.get("id") and chave_x not in vistos:
                vistos.add(chave_x)
                saida.append({"tipo": x["tipo"], "id": x["id"], "url": x.get("url")})
    return sorted(saida, key=lambda x: (x["tipo"], str(x["id"])))


def etapa_atividades(con, cli, log):
    with Etapa(con, "atividades", log) as e:
        quarentena.registrar_catalogo(con)
        quarentena.adotar_legado(con)
        n_prov = _declarar_alvos_provisorios(con)
        naturezas = {}
        _natureza_dos_alvos(con, cli, [r["chembl_id"] for r in con.execute(
            "SELECT chembl_id FROM alvo WHERE chembl_id IS NOT NULL AND natureza IS NULL")], naturezas)
        con.commit()
        mols = con.execute("SELECT id, nome, inchikey, classe_quimica, chembl_id, max_fase_clinica, fase_retirado "
                           "FROM molecula WHERE chembl_id IS NOT NULL AND medidas_consulta_id IS NULL ORDER BY id").fetchall()
        log(f"  ChEMBL: todas as medidas de potência de {len(mols)} moléculas")
        cont, disparos, examinadas = Counter(), {}, set()
        for ini in range(0, len(mols), 300):
            fatia = mols[ini:ini + 300]
            mapa = chembl.medidas_de_potencia(cli, [m["chembl_id"] for m in fatia], log=log)
            _natureza_dos_alvos(con, cli, {a["target_chembl_id"] for med, _ in mapa.values() for a in med
                                           if a.get("target_chembl_id")}, naturezas)
            ids_doc = {a["document_chembl_id"] for med, _ in mapa.values() for a in med if a.get("document_chembl_id")
                       and bioatividade.motivo_de_exclusao(a) is None}
            docs = chembl.documentos(cli, ids_doc) if ids_doc else {}
            for m in fatia:
                par = mapa.get(m["chembl_id"])
                if par is None:
                    cont["moleculas_pendentes"] += 1
                    continue
                medidas, cid = par
                _agregar_molecula(con, m, medidas, cid, naturezas, docs, disparos, examinadas, cont)
                con.execute("UPDATE molecula SET medidas_consulta_id=?, atividades_consulta_id=COALESCE(atividades_consulta_id, ?) "
                            "WHERE id=?", (cid, cid, m["id"]))
                cont["moleculas"] += 1
            con.commit()
            log(f"    bioatividade {min(ini + 300, len(mols))}/{len(mols)} moléculas (pares publicáveis={cont['pares_publicaveis']})")
        quarentena.declarar(con, bioatividade.REGRAS_DE_BIOATIVIDADE + ("FONTE-NAO-SUSTENTA",), disparos, entre=examinadas)

        # Efeito clínico documentado: indicações aprovadas e mecanismo, com as fontes regulatórias que o ChEMBL cita.
        n_clin = 0
        for m in con.execute("SELECT id, nome, inchikey, classe_quimica, chembl_id, fase_retirado FROM molecula "
                             "WHERE chembl_id IS NOT NULL AND max_fase_clinica >= 4 ORDER BY id").fetchall():
            try:
                cl = chembl.clinico(cli, m["chembl_id"])
            except ErroDeFonte as exc:
                log(f"    ! ChEMBL clínico indisponível para {m['chembl_id']}: {exc}")
                continue
            if cl and cl["indicacoes"]:
                passagem = "; ".join(x["texto"] for x in cl["mecanismos"][:3]) or None
                cat_clin = quimica.classificar_fase4(m["inchikey"], m["classe_quimica"])
                upsert_afirmacao(con, tipo="efeito_clinico_documentado", molecula_id=m["id"],
                                 origem=f"chembl:clinico:{m['chembl_id']}", fonte_id="chembl", consulta_id=cl["consulta_id"],
                                 texto_=texto.enunciado_clinico(
                                     m["nome"], cl["indicacoes"], cl["mecanismos"],
                                     retirado=bool(m["fase_retirado"]), categoria_clinica=cat_clin),
                                 passagem=passagem, metodo="Indicação aprovada (fase 4) e mecanismo, segundo o ChEMBL",
                                 extras={"fontes_regulatorias": json_compacto(_fontes_regulatorias(cl)),
                                         "passagem_origem": "mecanismo_chembl" if passagem else None})
                n_clin += 1
        con.commit()
        n_q344 = quarentenar_portaria_344(con)
        res_est = quarentena.aplicar_estados(con, evento)
        res_vias = linhagem_vias.enriquecer_alvos_e_vias(con, cli, log)
        con.commit()
        e.resumo = {"moleculas": cont["moleculas"], "moleculas_pendentes": cont["moleculas_pendentes"],
                    "pares_publicaveis": cont["pares_publicaveis"], "fora_da_selecao": cont["fora_da_selecao"],
                    "sem_medida_valida": cont["sem_medida_valida"],
                    "retidos_por_regra": {k: v for k, v in cont.items() if k.startswith("BIO-")},
                    "afirmacoes_clinicas": n_clin, "alvos_provisorios": n_prov, "quarentena_portaria_344": n_q344,
                    "estados": res_est, **res_vias}


# ═══════════════════════════ etapa 6b: estruturas 3D (ETKDGv3, RCSB PDB, AlphaFold) ═══════════════════════════
def etapa_estruturas3d(con, cli, log):
    with Etapa(con, "estruturas3d", log) as e:
        e.resumo = estruturas3d.construir_estruturas_3d(con, cli, log)


# ═══════════════════════════ etapa 7: referências ═══════════════════════════
def _desvincular_referencias_mortas_secundarias(con):
    """Se uma afirmação ativa tem >=1 referência resolvida válida e também um DOI secundário morto (404 confirmado),
    remove apenas o vínculo secundário não resolvido e registra evento de proveniência auditável."""
    pares = con.execute("""
        SELECT ar.afirmacao_id, ar.referencia_id, r.doi, r.pmid
        FROM afirmacao_referencia ar
        JOIN referencia r ON r.id = ar.referencia_id
        JOIN afirmacao a ON a.id = ar.afirmacao_id
        WHERE r.resolvida = 0
          AND r.consulta_id IS NOT NULL
          AND a.estado NOT IN ('quarentena','rejeitado')
          AND EXISTS (
              SELECT 1 FROM afirmacao_referencia ar2
              JOIN referencia r2 ON r2.id = ar2.referencia_id
              WHERE ar2.afirmacao_id = ar.afirmacao_id AND r2.resolvida = 1 AND r2.retratada = 0
          )
    """).fetchall()
    for p in pares:
        con.execute(
            "DELETE FROM afirmacao_referencia WHERE afirmacao_id=? AND referencia_id=?",
            (p["afirmacao_id"], p["referencia_id"]),
        )
        evento(
            con, "afirmacao", p["afirmacao_id"], "desvinculo_doi_inexistente",
            f"Referência secundária não localizada ({p['doi'] or p['pmid']}) desvinculada; afirmação sustentada por outra(s) referência(s) resolvida(s).",
        )
    if pares:
        con.commit()
    return len(pares)


def etapa_referencias(con, cli, log):
    with Etapa(con, "referencias", log) as e:
        n_linhagens = linhagem_vias.registrar_linhagens_farmacologicas(con, cli, upsert_referencia, log)
        pend = con.execute("SELECT id, doi, pmid FROM referencia WHERE resolvida=0").fetchall()
        log(f"  referências a resolver: {len(pend)}")
        com_pmid = [r for r in pend if r["pmid"]]
        so_doi = [r for r in pend if not r["pmid"] and r["doi"]]
        n_ok = n_retratadas = n_nao_achadas = 0

        # PMIDs: ESummary em lote
        meta = referencias.pubmed(cli, [r["pmid"] for r in com_pmid])
        for r in com_pmid:
            x = meta.get(r["pmid"])
            if x:
                upsert_referencia(con, doi=x["doi"], pmid=r["pmid"], titulo=x["titulo"], revista=x["revista"], ano=x["ano"],
                                  autores=x["autores"] or None, resolvida=1, retratada=1 if x["retratada"] else 0,
                                  aviso=x.get("aviso"), consulta_id=x["consulta_id"])
                n_ok += 1
                n_retratadas += 1 if x["retratada"] else 0
            elif r["doi"]:
                so_doi.append(r)
            else:
                n_nao_achadas += 1
        con.commit()

        # DOIs sem PMID: Crossref em lote (filter=doi:...) + fallback individual / DataCite / EuropePMC
        for i in range(0, len(so_doi), 1400):
            lote = so_doi[i:i + 1400]
            mapa_cr = referencias.crossref_em_lote(cli, [r["doi"] for r in lote], tamanho_lote=35)
            for r in lote:
                chave_d = (r["doi"] or "").strip().lower()
                par = mapa_cr.get(chave_d)
                if not par:
                    n_nao_achadas += 1
                    continue
                x, cid_cr = par
                if x:
                    upsert_referencia(
                        con, doi=chave_d, pmid=x.get("pmid"), pmcid=x.get("pmcid"),
                        titulo=x["titulo"], revista=x["revista"], ano=x["ano"],
                        autores=x["autores"] or None, resolvida=1, retratada=1 if x["retratada"] else 0,
                        aviso=x["aviso"], consulta_id=cid_cr, tipo_obra=x.get("tipo_obra"), agencia_doi=x.get("agencia_doi"),
                    )
                    n_ok += 1
                    n_retratadas += 1 if x["retratada"] else 0
                else:
                    n_nao_achadas += 1
                    if cid_cr is not None:
                        con.execute("UPDATE referencia SET consulta_id=? WHERE id=?", (cid_cr, r["id"]))
            con.commit()
            log(f"    Crossref lote {min(i + 1400, len(so_doi))}/{len(so_doi)} (resolvidas={n_ok}, não achadas={n_nao_achadas})")

        res_int = bibliografia.conferir(con, cli, log)
        n_desvinc = _desvincular_referencias_mortas_secundarias(con)
        bibliografia.declarar_regras_de_afirmacao(con)
        res_est = quarentena.aplicar_estados(con, evento)
        n_enunc = regerar_enunciados(con)
        e.resumo = {"resolvidas": n_ok, "nao_encontradas": n_nao_achadas, "retratadas": n_retratadas,
                    "integridade": res_int, "linhagens_publicaveis": n_linhagens,
                    "secundarias_mortas_desvinculadas": n_desvinc, "estados": res_est,
                    "enunciados_atualizados": n_enunc}


# ═══════════════════════════ etapa 7b: evidências (conferência na literatura) ═══════════════════════════
def etapa_evidencias(con, cli, log):
    """Lê título, resumo e texto aberto das obras citadas e registra o nível de evidência de cada afirmação."""
    with Etapa(con, "evidencias", log) as e:
        res = literatura.conferir(con, cli, log)
        res_est = quarentena.aplicar_estados(con, evento)
        e.resumo = {**res, "estados": res_est}


# ═══════════════════════════ etapa 8: procedência declarada, distribuição, prontidão e busca ═══════════════════════════
def etapa_prontidao(con, log):
    with Etapa(con, "prontidao", log) as e:
        res_cur = curadoria.aplicar_semente_verificacoes(con, log=log)
        res_proc = procedencia.recalcular_procedencia_banco(con)
        res_mol = aplicar_regras_de_molecula(con)
        res_quim = quimica.normalizar_estruturas(con)
        n_midia = conferir_midia(con)
        n_notas = _aplicar_contexto_biocultural(con, carregar_semente())      # notas editoriais da semente, sempre atuais
        res_est = quarentena.aplicar_estados(con, evento)
        ids_taxa = [r["id"] for r in con.execute("SELECT id FROM taxon WHERE compostos_fonte IS NOT NULL")]
        _atualizar_contagens_de_compostos(con, ids_taxa, None)
        n = prontidao.recalcular_todas(con)
        e.resumo = {"afirmacoes_avaliadas": n, "verificacoes_semente": res_cur, **res_proc, "regras_de_molecula": res_mol,
                    "estruturas": res_quim, "imagens_retidas_por_repeticao": n_midia, "notas_editoriais": n_notas,
                    "estados": res_est, "retencoes": quarentena.resumo(con)}


def etapa_busca(con, log):
    with Etapa(con, "busca", log) as e:
        con.execute("DELETE FROM busca")
        n = 0
        for t in con.execute("SELECT id, nome, familia, nomes_populares FROM taxon").fetchall():
            sin = " ".join(r["nome"] for r in con.execute(
                "SELECT nome FROM taxon_sinonimo WHERE taxon_id=? AND IFNULL(status_gbif,'') NOT IN "
                "('PROPARTE_SYNONYM','MISAPPLIED','DOUBTFUL')", (t["id"],)))
            pop = " ".join(p["nome"] for p in json.loads(t["nomes_populares"] or "[]"))
            con.execute("INSERT INTO busca (tipo, ref_id, texto) VALUES ('taxon', ?, ?)",
                        (t["id"], " ".join(x for x in (t["nome"], pop, sin, t["familia"] or "") if x)))
            n += 1
        for m in con.execute(
            "SELECT id, nome, nome_na_fonte, formula, familia FROM molecula m "
            "WHERE EXISTS (SELECT 1 FROM afirmacao a WHERE a.molecula_id=m.id AND a.estado NOT IN ('quarentena','rejeitado') AND a.classe_acesso='publico') "
            "OR EXISTS (SELECT 1 FROM relacao_molecula rm WHERE (rm.origem_id=m.id OR rm.destino_id=m.id) "
            "AND rm.estado IN ('candidato','em_revisao','verificado'))"
        ).fetchall():
            con.execute("INSERT INTO busca (tipo, ref_id, texto) VALUES ('molecula', ?, ?)",
                        (m["id"], " ".join(x for x in (m["nome"], m["nome_na_fonte"] or "", m["formula"] or "", m["familia"] or "") if x)))
            n += 1
        for u in con.execute("SELECT id, nome, sigla FROM territorio WHERE tipo='uf'").fetchall():
            con.execute("INSERT INTO busca (tipo, ref_id, texto) VALUES ('territorio', ?, ?)", (u["id"], f"{u['nome']} {u['sigla']}"))
            n += 1
        con.commit()
        e.resumo = {"entradas": n}


# ═══════════════════════════ orquestração ═══════════════════════════
ETAPAS = ("territorios", "universo_checklist", "taxons", "checklists", "hidrografia", "toxinas", "compostos",
          "enriquecimento", "atividades", "estruturas3d", "referencias", "evidencias", "prontidao", "busca")


def construir(con, cli, log=print, etapas=None, semente=None, so=None):
    """Executa as etapas pedidas (todas, por padrão) na ordem certa. `so`: lista de nomes, para testes."""
    sem = carregar_semente(semente)
    etapas = list(etapas or ETAPAS)
    desconhecidas = [x for x in etapas if x not in ETAPAS]
    if desconhecidas:
        raise ValueError(f"etapas desconhecidas: {desconhecidas}; válidas: {ETAPAS}")
    for nome in ETAPAS:
        if nome not in etapas:
            continue
        if nome == "territorios":
            etapa_territorios(con, cli, log)
        elif nome == "universo_checklist":
            etapa_universo_checklist(con, cli, log, sem, so)
        elif nome == "taxons":
            etapa_taxons(con, cli, log, sem, so)
        elif nome == "checklists":
            etapa_checklists(con, cli, log, so)
        elif nome == "hidrografia":
            etapa_hidrografia(con, cli, log, so)
        elif nome == "toxinas":
            etapa_toxinas(con, cli, log)
        elif nome == "compostos":
            etapa_compostos(con, cli, log, so)
        elif nome == "enriquecimento":
            etapa_enriquecer(con, cli, log)
        elif nome == "atividades":
            etapa_atividades(con, cli, log)
        elif nome == "estruturas3d":
            etapa_estruturas3d(con, cli, log)
        elif nome == "referencias":
            etapa_referencias(con, cli, log)
        elif nome == "evidencias":
            etapa_evidencias(con, cli, log)
        elif nome == "prontidao":
            etapa_prontidao(con, log)
        elif nome == "busca":
            etapa_busca(con, log)
