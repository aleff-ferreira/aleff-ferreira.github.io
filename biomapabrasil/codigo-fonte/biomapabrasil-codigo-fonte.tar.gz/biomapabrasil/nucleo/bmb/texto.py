# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Enunciados por modelo fixo. Princípio 4: associação documentada nunca vira alegação de eficácia.

Nenhum enunciado usa verbos como "trata", "cura", "combate" ou "é eficaz". Cada um diz de qual fonte
vem a informação, a que ela se refere (organismo, molécula isolada ou fármaco) e o que ela NÃO diz.
"""
from .util import numero_legivel, plural

ENSAIO_TIPOS = {"B": "ligação", "F": "funcional", "A": "ADME", "T": "toxicidade", "P": "físico-química",
                "U": "não classificado"}


def enunciado_composto(molecula, taxon, n_publicacoes, fonte_nome="LOTUS"):
    return (f"«{molecula}» consta como relatado em {taxon}, com {n_publicacoes} "
            f"{plural(n_publicacoes, 'publicação associada', 'publicações associadas')} no {fonte_nome}.")


def enunciado_composto_nubbe(molecula, taxon, n_publicacoes, uf_coleta=None):
    nota_uf = f" (estado de coleta declarado na base: {uf_coleta})" if uf_coleta else ""
    return (f"«{molecula}» consta como relatado em {taxon}, com {n_publicacoes} "
            f"{plural(n_publicacoes, 'publicação associada', 'publicações associadas')} no NuBBE-DB{nota_uf}.")


def enunciado_composto_npatlas(molecula, taxon, n_publicacoes):
    return (f"«{molecula}» consta como isolado em {taxon}, com {n_publicacoes} "
            f"{plural(n_publicacoes, 'publicação de origem', 'publicações de origem')} no NPAtlas.")


def enunciado_toxina(molecula, taxon, organismo_uniprot=None):
    org_u = (organismo_uniprot or "").strip()
    nota_sub = ""
    if org_u and org_u != taxon and len(org_u.split()) >= 3 and org_u.startswith(taxon + " "):
        nota_sub = f" (entrada anotada na subespécie {org_u})"
    return f"O UniProt/Swiss-Prot (Tox-Prot) anota função para {molecula} de {taxon}{nota_sub}."


def enunciado_atividade(molecula, a):
    alvo = a.get("alvo_nome") or a["alvo_chembl_id"]
    org = f" ({a['alvo_organismo']})" if a.get("alvo_organismo") else ""
    medida = f"{a['medida_tipo']} {a['relacao']} {numero_legivel(a['valor'])} {a.get('unidade') or ''}".strip()
    return (f"Medida registrada no ChEMBL para «{molecula}»: {medida}, sobre {alvo}{org}. "
            "Medida da molécula isolada em ensaio; não é medida do organismo nem de extrato.")


ROTULO_NATUREZA_ALVO = {
    "proteina_unica": None,                       # alvo molecular individual: dispensa qualificação
    "complexo_proteico": "complexo proteico", "familia_proteica": "família de proteínas",
    "linhagem_celular": "linhagem celular", "organismo": "organismo inteiro", "tecido": "tecido",
    "fracao_subcelular": "fração subcelular", "acido_nucleico": "ácido nucleico", "admet": "ensaio ADMET",
    "nao_molecular": "sistema sem alvo molecular definido", "indeterminado": "alvo de natureza não classificada",
}


def enunciado_atividade_agregada(molecula, alvo_nome, alvo_organismo, tipo, agregado, natureza=None):
    """Enunciado de um par molécula–alvo resumido por todas as medidas válidas do ChEMBL (ver bmb/bioatividade.py)."""
    qual = [x for x in (ROTULO_NATUREZA_ALVO.get(natureza), alvo_organismo) if x]
    alvo = alvo_nome + (f" ({'; '.join(qual)})" if qual else "")
    if agregado["n"] == 1:
        medida = f"{tipo} = {numero_legivel(agregado['valor_nm'])} nM, em uma medida"
    else:
        n_doc = agregado["n_documentos"]
        medida = (f"{tipo} com mediana de {numero_legivel(agregado['valor_nm'])} nM em {agregado['n']} medidas de "
                  f"{n_doc} {plural(n_doc, 'publicação', 'publicações')} "
                  f"(de {numero_legivel(agregado['min_nm'])} a {numero_legivel(agregado['max_nm'])} nM)")
    return (f"Medidas registradas no ChEMBL para «{molecula}» sobre {alvo}: {medida}. "
            "Medida da molécula isolada em ensaio; não é medida do organismo nem de extrato.")


def metodo_agregado(agregado, tipo_ensaio):
    tipos = [ENSAIO_TIPOS.get(t, t) for t in (tipo_ensaio or "").split("+") if t]
    base = "Ensaio ChEMBL" if agregado["n"] == 1 else f"Mediana de {agregado['n']} medidas do ChEMBL"
    return base + (f", tipo {' e '.join(tipos)}" if tipos else "")


def enunciado_clinico(molecula, indicacoes, mecanismos, retirado=False, categoria_clinica=None):
    ind = "; ".join(i["termo"] for i in indicacoes[:6]) or "sem indicação aprovada listada"
    mecs = [m for m in (mecanismos or []) if (m.get("texto") or "").strip().lower() not in ("", "unknown", "unspecified", "n/a")]
    extra = f" Mecanismo registrado: {mecs[0]['texto']}." if mecs else ""
    if retirado:
        qual = "teve aprovação clínica registrada (fase 4 no ChEMBL, com retirada de mercado em jurisdições)"
    elif categoria_clinica == "metabolito_ou_insumo":
        qual = "é insumo farmacêutico ou metabólito ubíquo com aprovação clínica (fase 4 no ChEMBL)"
    else:
        qual = "é fármaco aprovado (fase 4 no ChEMBL)"
    return (f"«{molecula}» {qual}. Indicações registradas: {ind}.{extra} "
            "Descreve o fármaco isolado, não o organismo de onde a molécula foi isolada.")


def metodo_ensaio(tipo_codigo, formato_ensaio=None):
    base = f"Ensaio ChEMBL, tipo {ENSAIO_TIPOS.get(tipo_codigo, tipo_codigo or 'não informado')}"
    if formato_ensaio and formato_ensaio.strip():
        return f"{base} ({formato_ensaio.strip()})"
    return base


METODO_TOXINA_EXPERIMENTAL = "Evidência experimental publicada (ECO:0000269)"
METODO_TOXINA_NAO_EXPERIMENTAL = ("Anotação sem evidência experimental direta (similaridade de sequência "
                                  "ou outra inferência)")
