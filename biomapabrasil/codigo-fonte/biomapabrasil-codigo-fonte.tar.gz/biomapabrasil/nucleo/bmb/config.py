# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Caminhos, fontes e limiares. Tudo que é critério editorial mora aqui, nomeado e comentado."""
import os
import re
from pathlib import Path

AQUI = Path(__file__).resolve().parent
NUCLEO = AQUI.parent
PLATAFORMA = NUCLEO.parent

# O cache HTTP fica FORA da pasta sincronizada (OneDrive): respostas do LOTUS passam de 9 MB cada.
CACHE_DIR = Path(os.environ.get("BMB_CACHE", Path.home() / ".cache" / "biomapabrasil"))
SAIDA_DIR = Path(os.environ.get("BMB_SAIDA", NUCLEO / "saida"))
DB_PATH = Path(os.environ.get("BMB_DB", SAIDA_DIR / "biomapabrasil.sqlite"))
SEMENTE_DIR = NUCLEO / "semente"
APP_DIR = PLATAFORMA / "app"                  # site estático; os pacotes de dados vão para APP_DIR/dados

USER_AGENT = "BioMapaBrasil/4.2.1 (+https://aleff-ferreira.github.io/biomapabrasil/; pipeline cientifico de dados)"

# ─────────────────────────── recorte amazônico ───────────────────────────
# Estados que compõem a Amazônia Legal (IBGE). O Maranhão entra inteiro, o que superestima a área
# (o polígono oficial inclui só parte dele): limitação declarada, não escondida.
UF_AMAZONIA_LEGAL = ("AC", "AM", "AP", "MA", "MT", "PA", "RO", "RR", "TO")

# Um táxon entra no recorte amazônico quando tem ao menos N_AL_MIN ocorrências GBIF na Amazônia Legal.
N_AL_MIN = 20
# E é "predominantemente amazônico" quando essas ocorrências são metade ou mais das brasileiras.
FRACAO_AL_PREDOMINANTE = 0.5

# ─────────────────────────── licenças admitidas ───────────────────────────
# Princípio 3: imagem só com licença verificável por máquina e que permita redistribuição.
LICENCAS_IMAGEM_OK = {"CC0", "CC BY"}
def normalizar_licenca(texto):
    """Reduz a licença declarada (URL ou código) a CC0, CC BY, CC BY-SA, CC BY-NC, CC BY-ND... ou None."""
    s = (texto or "").lower()
    if not s:
        return None
    if "publicdomain/zero" in s or s.startswith("cc0") or "cc_0" in s or "cc0_1_0" in s:
        return "CC0"
    m = re.search(r"licenses/(by(?:-[a-z]+)*)/", s) or re.search(r"cc[_ -](by(?:[_-][a-z]+)*)", s)
    if m:
        return "CC " + m.group(1).replace("_", "-").upper()
    return None

# ─────────────────────────── etapas da prontidão ───────────────────────────
DIMENSOES = (
    "identidade_biologica", "procedencia", "identidade_quimica",
    "qualidade_experimental", "rastreabilidade", "reutilizacao", "sensibilidade",
)
ESTADOS_DIMENSAO = ("atende", "parcial", "ausente", "nao_avaliado", "nao_se_aplica")

# Limites de cortesia por servidor: segundos mínimos entre requisições.
INTERVALO_HOST = {
    "api.gbif.org": 0.04,
    "rest.uniprot.org": 0.10,
    "lotus.naturalproducts.net": 0.50,
    "pubchem.ncbi.nlm.nih.gov": 0.22,
    "www.ebi.ac.uk": 0.15,
    "eutils.ncbi.nlm.nih.gov": 0.35,
    "api.crossref.org": 0.10,
    "servicodados.ibge.gov.br": 0.40,
    "www.npatlas.org": 0.20,
    "alphafold.ebi.ac.uk": 0.12,
    "data.rcsb.org": 0.10,
    "files.rcsb.org": 0.12,
    "ftp.ebi.ac.uk": 0.08,
    "www.crystallography.net": 0.08,
    "api.esmatlas.com": 0.25,
    "www.wikidata.org": 0.15,
    "reactome.org": 0.12,
    "commons.wikimedia.org": 0.25,
    "raw.githubusercontent.com": 0.10,
    "s3.amazonaws.com": 0.03,
    "terrabrasilis.dpi.inpe.br": 0.25,
    "api.datacite.org": 0.12,
    "zenodo.org": 0.25,
}
INTERVALO_PADRAO = 0.30
