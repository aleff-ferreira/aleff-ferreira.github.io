# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Conferência das afirmações de composto em organismo contra o texto das obras citadas.

Uma base de produtos naturais transcreve pares organismo–composto de artigos. Esta etapa abre o que é possível ler
de cada obra citada — título, resumo e, quando o artigo é de acesso aberto, o texto completo no Europe PMC — e
registra, por afirmação, o que o texto diz:

  nivel_evidencia
    curador                 passagem lida e confirmada por curador (não é atribuído aqui)
    artigo_trecho           uma frase do resumo ou do texto aberto cita o organismo e o composto, com verbo de isolamento
    artigo_cita_organismo   título, resumo ou texto aberto citam o organismo
    base_curada             só a transcrição da base de origem

  conferencia_literatura    o resultado da leitura (vocabulário na migração 008)

Duas situações retêm a afirmação até um curador olhar:
  LIT-OUTRA-ESPECIE   nenhuma obra cita a espécie e os títulos citam outra espécie do mesmo gênero
  LIT-SEM-MENCAO      resumo ou texto foi lido e não cita espécie, gênero nem composto

Obra sem texto legível (sem resumo no Europe PMC, texto fechado) não retém nada: a afirmação fica no nível
`base_curada`, com `conferencia_literatura` dizendo que não houve texto. Quando o serviço não responde (rede, limite de
requisições), a afirmação não é reavaliada: fica exatamente como estava. Falha de rede nunca vira quarentena nem
rebaixa evidência, e o resultado de uma execução com o mesmo cache é sempre o mesmo.

Do texto lido guardam-se o nível, a fonte e o SHA-256. A frase localizada só é guardada quando a obra é de acesso
aberto e a frase não descreve local de coleta; nos demais casos fica o hash. Frases de coleta do texto aberto são
reduzidas a país e unidade da federação.
"""
from __future__ import annotations

import hashlib
import html
import re
import unicodedata
from collections import Counter, defaultdict

from . import procedencia, quarentena
from .conectores import referencias
from .util import agora

REGRAS_DE_LITERATURA = ("LIT-OUTRA-ESPECIE", "LIT-SEM-MENCAO")
_GREGAS = {"α": "alpha", "β": "beta", "γ": "gamma", "δ": "delta", "ε": "epsilon", "ω": "omega", "Δ": "delta", "µ": "mu",
           "μ": "mu", "κ": "kappa", "λ": "lambda"}
_ISOLAMENTO = re.compile(
    r"\b(isolat\w*|obtain\w*|afford\w*|yield\w*|identif\w*|characteri[sz]\w*|constituent\w*|purif\w*|furnish\w*|"
    r"elucidat\w*|reported from|found in|present in|detect\w*|isolad\w*|isolement|isoliert\w*)\b", re.I)
_GENERICOS = {"acid", "ester", "ether", "compound", "unknown", "water", "oxygen"}
_COLETA = re.compile(r"\b(collected|collection of|harvested|gathered|purchased|bought|obtained from|cultivated|grown in|"
                     r"growing in|colet\w+)\b", re.I)
_MATERIAL = re.compile(r"\b(plants?|lea(?:f|ves)|barks?|roots?|rhizome\w*|stems?|seeds?|fruits?|flower\w*|aerial parts|"
                       r"whole plant|wood|heartwood|latex|resin|specimen\w*|fungus|fungal|strain|mycelium|"
                       r"fruiting bod\w+|venom|material)\b", re.I)
# Qualificação do organismo como de origem marinha («the deep-sea-derived fungus Penicillium citrinum»): o material
# estudado não foi coletado na Amazônia. Manguezal fica de fora: há manguezais no litoral amazônico.
_ORIGEM_MARINHA = re.compile(
    r"\b(deep[- ]sea|marine[- ](?:derived|sourced|sediment\w*|sponge\w*|alga\w*|fung\w+|isolate\w*|strain\w*|actinomycete\w*)|"
    r"(?:marine[- ]|edible[- ])?alga[- ]derived|seaweed[- ](?:derived|associated)|"
    r"sea[- ]derived|sponge[- ](?:derived|associated)|coral[- ](?:derived|associated)|(?:sea|ocean)[- ]?(?:water|sediment\w*)|"
    r"hydrothermal vent\w*)\b", re.I)
_CEPA_OU_ISOLAMENTO = re.compile(r"\b(strain|isolate[ds]?|isolated from|derived from|obtained from|collected)\b", re.I)
# Uma frase com qualquer destes termos pode situar a coleta: ela não é guardada, só o hash.
_LOCAL_FINO = re.compile(r"\b(municip\w+|village|district|county|province|river|rio|igarap\w+|reserv\w+|park|parque|"
                         r"communit\w+|comunidad\w+|indigenous|ind[ií]gena\w*|km|latitude|longitude|coordinates|herbari\w+|"
                         r"voucher|campus|road|highway|island|ilha)\b|\d+\s*°", re.I)
_PAISES = {
    "Brazil": "BR", "Brasil": "BR", "Bolivia": "BO", "Colombia": "CO", "Ecuador": "EC", "French Guiana": "GF", "Guyana": "GY",
    "Peru": "PE", "Suriname": "SR", "Venezuela": "VE", "Argentina": "AR", "Paraguay": "PY", "Uruguay": "UY", "Chile": "CL",
    "Mexico": "MX", "Panama": "PA", "Costa Rica": "CR", "Cuba": "CU", "Guatemala": "GT", "Honduras": "HN", "Nicaragua": "NI",
    "Jamaica": "JM", "Puerto Rico": "PR", "Dominican Republic": "DO", "China": "CN", "India": "IN", "Japan": "JP",
    "South Korea": "KR", "Korea": "KR", "Taiwan": "TW", "Thailand": "TH", "Vietnam": "VN", "Viet Nam": "VN",
    "Indonesia": "ID", "Malaysia": "MY", "Philippines": "PH", "Pakistan": "PK", "Bangladesh": "BD", "Sri Lanka": "LK",
    "Nepal": "NP", "Iran": "IR", "Turkey": "TR", "Egypt": "EG", "Nigeria": "NG", "Cameroon": "CM", "Ghana": "GH",
    "Kenya": "KE", "Tanzania": "TZ", "Uganda": "UG", "Ethiopia": "ET", "Madagascar": "MG", "South Africa": "ZA",
    "Ivory Coast": "CI", "Côte d'Ivoire": "CI", "Senegal": "SN", "Benin": "BJ", "Togo": "TG", "Burkina Faso": "BF",
    "Mali": "ML", "Sudan": "SD", "Morocco": "MA", "Tunisia": "TN", "Algeria": "DZ", "Saudi Arabia": "SA", "Yemen": "YE",
    "Oman": "OM", "Australia": "AU", "New Zealand": "NZ", "Papua New Guinea": "PG", "New Caledonia": "NC", "Fiji": "FJ",
    "United States": "US", "USA": "US", "Canada": "CA", "Germany": "DE", "France": "FR", "Italy": "IT", "Spain": "ES",
    "Portugal": "PT", "United Kingdom": "GB", "Poland": "PL", "Russia": "RU", "Hungary": "HU", "Greece": "GR",
    "Serbia": "RS", "Bulgaria": "BG", "Romania": "RO", "Laos": "LA", "Cambodia": "KH", "Myanmar": "MM", "Singapore": "SG",
    "Mauritius": "MU", "Zimbabwe": "ZW", "Zambia": "ZM", "Mozambique": "MZ", "Angola": "AO", "Gabon": "GA",
}
_UF_NOMES = {
    "AC": ["Acre"], "AL": ["Alagoas"], "AM": ["Amazonas", "Manaus"], "AP": ["Amapá", "Amapa", "Macapá"], "BA": ["Bahia"],
    "CE": ["Ceará", "Ceara"], "DF": ["Distrito Federal", "Brasília", "Brasilia"], "ES": ["Espírito Santo", "Espirito Santo"],
    "GO": ["Goiás", "Goias"], "MA": ["Maranhão", "Maranhao"], "MG": ["Minas Gerais"], "MS": ["Mato Grosso do Sul"],
    "MT": ["Mato Grosso"], "PA": ["Pará", "Para State", "State of Para", "Belém", "Belem"], "PB": ["Paraíba", "Paraiba"],
    "PE": ["Pernambuco"], "PI": ["Piauí", "Piaui"], "PR": ["Paraná", "Parana"], "RJ": ["Rio de Janeiro"],
    "RN": ["Rio Grande do Norte"], "RO": ["Rondônia", "Rondonia"], "RR": ["Roraima"], "RS": ["Rio Grande do Sul"],
    "SC": ["Santa Catarina"], "SE": ["Sergipe"], "SP": ["São Paulo", "Sao Paulo"], "TO": ["Tocantins"],
}
_NIVEL = {"nenhum": 0, "titulo": 1, "resumo": 2, "texto_completo_aberto": 3}
_COLETA_TITULO = re.compile(
    r"\b(?:collected in|grown in|cultivated in)\b"
    r"|\bfrom\s+(?:[A-Z][a-z]+\s+){0,3}(?:" + "|".join(re.escape(k) for k in sorted(_PAISES, key=len, reverse=True)) + r")\b"
)


# ───────────────────────── funções puras de texto ─────────────────────────
def limpar(s: str | None) -> str:
    """Texto de registro bibliográfico em forma comparável: sem marcação, sem palavras coladas, letras gregas por extenso.

    Títulos do Crossref trazem itálico no meio do nome («Melampodium </i><i>c</i><i>amphoratum») e palavras coladas
    («genusTabernaemontana»); sem este cuidado o organismo está no título e não é reconhecido."""
    s = html.unescape(re.sub(r"<[^>]+>", "", s or ""))
    s = re.sub(r"(?<=[a-z])(?=[A-Z][a-z]{3,})", " ", s)
    for k, v in _GREGAS.items():
        s = s.replace(k, v)
    s = unicodedata.normalize("NFKC", s)
    for traco in "‐‑–—−":
        s = s.replace(traco, "-")
    return re.sub(r"\s+", " ", s).strip()


def _sem_marca_de_hibrido(nome: str | None) -> list[str]:
    return [p for p in (nome or "").split() if p not in ("×", "x", "X")]


def padrao_do_organismo(nome: str):
    """Expressão que reconhece o binômio no texto: gênero por extenso ou abreviado, epíteto com variação de desinência."""
    partes = _sem_marca_de_hibrido(nome)
    if len(partes) < 2 or len(partes[0]) < 3 or len(partes[1]) < 3:
        return None
    g, ep = partes[0], partes[1].lower()
    radical = re.escape(ep[:-2]) + r"[a-z]{1,4}" if len(ep) >= 7 else re.escape(ep)
    return re.compile(rf"\b(?:{re.escape(g)}|{re.escape(g[0])}\.)\s*(?:{re.escape(ep)}|{radical})\b", re.I)


def variantes_do_composto(nomes) -> list[str]:
    saida = set()
    for n in nomes:
        n = limpar(n).lower()
        if not n:
            continue
        cands = {n, re.sub(r"^\(?[+\-±]{1,3}\)?-", "", n), re.sub(r"^\((?:[0-9a-z,'\s]+)\)-", "", n),
                 re.sub(r"^(?:d|l|dl|cis|trans|rac|\([ezrs]\))-", "", n)}
        for c in cands:
            c = c.strip(" -")
            if len(c) >= 5 and c not in _GENERICOS and not re.fullmatch(r"[a-z]{14}-[a-z]{10}-[a-z]", c) and not c.startswith("cid "):
                saida.add(c)
    return sorted(saida, key=len, reverse=True)


def achar_composto(texto_minusculo: str, variantes) -> tuple[str | None, int]:
    """Primeira variante do nome presente como termo inteiro. «iso-oenothein C» não conta como «oenothein C»."""
    for v in variantes:
        i = texto_minusculo.find(v)
        while i != -1:
            antes = texto_minusculo[i - 1] if i > 0 else " "
            antes2 = texto_minusculo[i - 2] if i > 1 else " "
            depois = texto_minusculo[i + len(v)] if i + len(v) < len(texto_minusculo) else " "
            ok_antes = (not antes.isalnum()) and (antes not in "-'’′" or (antes == "-" and antes2 in ")]"))
            if ok_antes and not depois.isalpha():
                return v, i
            i = texto_minusculo.find(v, i + 1)
    return None, -1


def frases(texto: str):
    return [f for f in re.split(r"(?<=[.;!?])\s+(?=[A-Z(\[])", texto) if f]


_NAO_EPITETO = frozenset((
    "sp", "spp", "species", "and", "from", "genus", "was", "were", "is", "are", "extract", "extracts", "leaves", "plants", "plant",
    "essential", "oil", "oils", "var", "subsp", "cf", "aff", "has", "have", "alkaloids", "seeds", "bark", "roots", "fruits",
    "flowers", "cell", "cells", "floral", "resin", "latex", "wood", "stem", "stems", "with", "that", "which", "in", "of", "by"))


def _distancia(a: str, b: str, limite: int = 2) -> int:
    """Distância de edição entre dois epítetos, interrompida quando passa do limite."""
    if abs(len(a) - len(b)) > limite:
        return limite + 1
    ant = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        atual = [i]
        for j, cb in enumerate(b, 1):
            atual.append(min(ant[j] + 1, atual[j - 1] + 1, ant[j - 1] + (ca != cb)))
        if min(atual) > limite:
            return limite + 1
        ant = atual
    return ant[-1]


def _mesmo_epiteto(ep: str, proprios: set[str]) -> bool:
    """O epíteto lido é o do organismo, com outra desinência ou erro de grafia («guaijava» por «guajava»)."""
    for p in proprios:
        if ep == p or (len(p) >= 5 and ep[:5] == p[:5]) or (len(p) >= 6 and _distancia(ep, p) <= 2):
            return True
    return False


def binomios_do_genero(texto: str, genero: str) -> set[str]:
    """Epítetos que seguem o nome do gênero, por extenso, no texto. Palavras comuns do inglês ficam de fora."""
    return {m.group(1).lower() for m in re.finditer(rf"\b{re.escape(genero)}\s+([a-z][a-z-]{{3,}})\b", texto)} - _NAO_EPITETO


def outros_binomios_do_genero(texto: str, genero: str, epitetos_proprios: set[str]) -> set[str]:
    """Epítetos de OUTRAS espécies do mesmo gênero citadas por extenso no texto («Piper nigrum» num registro de P. aduncum)."""
    return {ep for ep in binomios_do_genero(texto, genero) if not _mesmo_epiteto(ep, epitetos_proprios)}


def origem_marinha(texto: str, padroes, exigir_isolamento: bool = False) -> str | None:
    """Trecho em que o organismo é qualificado como de origem marinha, a até 90 caracteres do nome; None se não há.

    No corpo do artigo (`exigir_isolamento`) a qualificação só conta junto de um termo de cepa ou de isolamento: a
    introdução costuma citar ocorrências marinhas da espécie que nada dizem sobre o material estudado.
    """
    for p in padroes:
        for m in p.finditer(texto):
            janela = texto[max(0, m.start() - 90): m.end() + 90]
            if _ORIGEM_MARINHA.search(janela) and (not exigir_isolamento or _CEPA_OU_ISOLAMENTO.search(janela)):
                return janela.strip()
    return None


def locais_de_coleta(frase: str) -> set[str]:
    """Países e UFs brasileiras citados numa frase de coleta, como códigos ('BR-AM', 'CN'). Nada mais fino."""
    paises = {cod for nome, cod in _PAISES.items() if re.search(rf"\b{re.escape(nome)}\b", frase)}
    ufs = {uf for uf, nomes in _UF_NOMES.items() if any(re.search(rf"\b{re.escape(n)}\b", frase) for n in nomes)}
    if "MT" in ufs and "MS" in ufs and not re.search(r"Mato Grosso(?! do Sul)", frase):
        ufs.discard("MT")
    if paises - {"BR"} and "BR" not in paises:
        ufs = set()                     # «Amazonas, Peru»: departamento de outro país, não a UF brasileira
    locais = {f"BR-{uf}" for uf in ufs}
    if ufs:
        paises.discard("BR")
    return locais | paises


def avaliar_afirmacao(nomes_organismo, genero, variantes, textos, resolver=None, chave_taxon=None) -> dict:
    """Leitura de UMA afirmação. `textos`: [{ref_id, titulo, resumo, corpo, aberto}] das obras citadas.

    `resolver(binomio) -> chave da espécie aceita | None` consulta o backbone: um binômio do mesmo gênero lido no
    título ou no resumo que leva à espécie `chave_taxon` é o próprio organismo sob um sinônimo; se leva a outra
    espécie aceita, é outra espécie; se não é nome de espécie, não conta. Sem `resolver`, só os nomes dados valem.

    Devolve {"conferencia", "nivel", "trecho", "trecho_origem", "trecho_ref", "locais", "local_ref", "local_frase",
             "outra_especie", "nivel_texto"}.
    """
    nomes_organismo = [" ".join(_sem_marca_de_hibrido(n)) for n in nomes_organismo]
    proprios = {n.split()[1].lower() for n in nomes_organismo if len(n.split()) >= 2}
    # sinônimos que o backbone reconhece e que não estavam na lista: lidos no título e no resumo das obras
    outras_por_ref: dict = {}
    for tx in textos:
        for parte in ("titulo", "resumo"):
            for ep in binomios_do_genero(limpar(tx.get(parte) or ""), genero):
                if _mesmo_epiteto(ep, proprios):
                    if ep not in proprios:
                        nomes_organismo.append(f"{genero} {ep}")          # variante de grafia do próprio epíteto
                    continue
                # sem backbone à mão (testes, uso avulso), o binômio é tratado como nome de outra espécie
                chave_lida = resolver(f"{genero} {ep}") if resolver is not None else 0
                if chave_lida is None:
                    continue                                               # não é nome de espécie
                if chave_taxon is not None and chave_lida == chave_taxon:
                    nomes_organismo.append(f"{genero} {ep}")
                elif parte == "titulo":
                    outras_por_ref.setdefault(tx["ref_id"], set()).add(ep)
    nomes_organismo = list(dict.fromkeys(nomes_organismo))
    padroes = [p for p in (padrao_do_organismo(n) for n in nomes_organismo) if p]
    res = {"conferencia": None, "nivel": "base_curada", "trecho": None, "trecho_origem": None, "trecho_ref": None,
           "locais": set(), "local_ref": None, "local_frase": None, "marinha_ref": None, "marinha_frase": None,
           "outra_especie": None, "nivel_texto": "nenhum"}
    cita_org = cita_gen_ou_comp = False
    titulos_outra, n_com_titulo, n_refs = [], 0, len(textos)
    melhor = 0
    for tx in textos:
        partes = [("titulo", tx.get("titulo")), ("resumo", tx.get("resumo")), ("texto_completo_aberto", tx.get("corpo"))]
        nivel_ref = max((_NIVEL[k] for k, v in partes if v), default=0)
        melhor = max(melhor, nivel_ref)
        n_com_titulo += 1 if tx.get("titulo") else 0
        org_nesta = False
        for parte, bruto in partes:
            if not bruto:
                continue
            txt = limpar(bruto)
            if any(p.search(txt) for p in padroes):
                org_nesta = cita_org = True
            if re.search(rf"\b{re.escape(genero)}\b", txt) or achar_composto(txt.lower(), variantes)[0]:
                cita_gen_ou_comp = True
            if res["marinha_ref"] is None:
                marinha = origem_marinha(txt, padroes, exigir_isolamento=(parte == "texto_completo_aberto"))
                if marinha:
                    res["marinha_ref"], res["marinha_frase"] = tx["ref_id"], marinha
            if parte == "titulo":
                if n_refs == 1 and any(p.search(txt) for p in padroes) and _COLETA_TITULO.search(txt):
                    locais = locais_de_coleta(txt)
                    if locais:
                        res["locais"] |= locais
                        if res["local_ref"] is None:
                            res["local_ref"], res["local_frase"] = tx["ref_id"], txt
                continue
            for fr in frases(txt):
                if len(fr) > 900:
                    continue
                tem_org = any(p.search(fr) for p in padroes)
                if not tem_org:
                    continue
                if res["trecho"] is None and variantes and _ISOLAMENTO.search(fr) and achar_composto(fr.lower(), variantes)[0]:
                    res.update(trecho=fr.strip(), trecho_origem=parte, trecho_ref=tx["ref_id"], trecho_aberto=bool(tx.get("aberto")))
                if parte == "texto_completo_aberto" and 40 <= len(fr) and _COLETA.search(fr) and _MATERIAL.search(fr):
                    locais = locais_de_coleta(fr)
                    if locais:
                        res["locais"] |= locais
                        if res["local_ref"] is None:
                            res["local_ref"], res["local_frase"] = tx["ref_id"], fr.strip()
        if not org_nesta and outras_por_ref.get(tx["ref_id"]):
            titulos_outra.append(sorted(outras_por_ref[tx["ref_id"]])[0])
    res["nivel_texto"] = {v: k for k, v in _NIVEL.items()}[melhor]
    if res["trecho"]:
        res["conferencia"], res["nivel"] = "trecho_localizado", "artigo_trecho"
    elif cita_org:
        res["conferencia"], res["nivel"] = "organismo_citado", "artigo_cita_organismo"
    elif n_refs == 0 or melhor == 0:
        res["conferencia"] = "sem_texto"
    elif n_com_titulo == n_refs and len(titulos_outra) == n_refs:
        res["conferencia"], res["outra_especie"] = "outra_especie_citada", f"{genero} {titulos_outra[0]}"
    elif melhor == 1:
        res["conferencia"] = "so_titulo_sem_organismo"
    elif cita_gen_ou_comp:
        res["conferencia"] = "so_composto_ou_genero_citado"
    elif n_com_titulo == n_refs:
        res["conferencia"] = "texto_sem_mencao"
    else:
        res["conferencia"] = "sem_texto"
    return res


def classe_dos_locais(locais: set[str]) -> tuple[str | None, str | None]:
    """Classe única de `procedencia_artigo` para os locais citados; (None, None) quando eles divergem."""
    classes = {}
    for loc in sorted(locais):
        pais, _, uf = loc.partition("-")
        classes.setdefault(procedencia.classe_do_local(pais, uf), loc)
    classes.pop(None, None)
    if len(classes) != 1:
        return None, None
    return next(iter(classes.items()))


# ───────────────────────── etapa ─────────────────────────
def _sha(texto: str) -> str:
    return hashlib.sha256(texto.encode("utf-8")).hexdigest()


def ler_obras(con, cli, refs, log=print) -> dict[int, dict]:
    """Lê título, resumo e texto aberto das referências pedidas e grava nível, fonte e hash em `referencia`."""
    por_doi, por_pmid, falhas = referencias.europepmc_em_lote(
        cli, dois=[r["doi"] for r in refs if r["doi"]], pmids=[r["pmid"] for r in refs if r["pmid"] and not r["doi"]])
    # obra com DOI e PMID que o Europe PMC não achou pelo DOI (registro sem DOI lá): segunda busca, pelo PMID
    so_pelo_pmid = [r["pmid"] for r in refs if r["doi"] and r["pmid"] and r["doi"].lower() not in por_doi and r["doi"].lower() not in falhas]
    if so_pelo_pmid:
        _, por_pmid2, falhas2 = referencias.europepmc_em_lote(cli, pmids=so_pelo_pmid)
        por_pmid.update(por_pmid2)
        falhas |= {r["doi"].lower() for r in refs if r["doi"] and str(r["pmid"] or "") in falhas2}
    textos, n_corpo = {}, 0
    agora_ = agora()
    for r in refs:
        chave_busca = (r["doi"] or "").lower() or str(r["pmid"] or "")
        if chave_busca in falhas:
            # o serviço não respondeu para esta obra: nada se conclui e nada do que já estava gravado muda
            textos[r["id"]] = {"ref_id": r["id"], "nao_conferida": True}
            continue
        ep = por_doi.get((r["doi"] or "").lower()) or por_pmid.get(str(r["pmid"] or ""))
        titulo = r["titulo"] or (ep or {}).get("titulo")
        resumo = (ep or {}).get("resumo")
        corpo, cid_corpo = None, None
        if ep and ep.get("acesso_aberto") and ep.get("pmcid"):
            corpo, cid_corpo = referencias.texto_completo_aberto(cli, ep["pmcid"])
            if corpo is None and cid_corpo is None:
                textos[r["id"]] = {"ref_id": r["id"], "nao_conferida": True}
                continue
            n_corpo += 1 if corpo else 0
        nivel = "texto_completo_aberto" if corpo else "resumo" if resumo else "titulo" if titulo else "nenhum"
        lido = corpo or resumo or titulo
        con.execute("UPDATE referencia SET texto_nivel=?, texto_fonte=?, texto_sha256=?, texto_consulta_id=?, texto_conferido_em=?, "
                    "pmcid=COALESCE(pmcid, ?) WHERE id=?",
                    (nivel, "europepmc" if (corpo or resumo) else ("registro" if titulo else None), _sha(lido) if lido else None,
                     cid_corpo or (ep or {}).get("consulta_id"), agora_, (ep or {}).get("pmcid"), r["id"]))
        textos[r["id"]] = {"ref_id": r["id"], "titulo": titulo, "resumo": resumo, "corpo": corpo,
                           "aberto": bool(ep and ep.get("acesso_aberto"))}
    log(f"  obras lidas: {sum(1 for t in textos.values() if not t.get('nao_conferida'))} de {len(textos)} "
        f"(com resumo: {sum(1 for t in textos.values() if t.get('resumo'))}; texto aberto: {n_corpo})")
    return textos


def conferir(con, cli, log=print) -> dict:
    """Confere todas as afirmações de composto em organismo que não estão retidas por outro motivo."""
    quarentena.registrar_catalogo(con)
    outras_regras = {r["afirmacao_id"] for r in con.execute(
        "SELECT afirmacao_id FROM afirmacao_regra WHERE codigo NOT IN ('LIT-OUTRA-ESPECIE','LIT-SEM-MENCAO','PROV-FORA-DA-AMAZONIA')")}
    afirmacoes = [a for a in con.execute(
        "SELECT a.id, a.taxon_id, a.molecula_id, a.estado, a.organismo_na_fonte, a.passagem, a.passagem_origem, t.nome AS taxon, "
        "t.genero, m.nome AS m_nome, m.nome_na_fonte FROM afirmacao a JOIN taxon t ON t.id=a.taxon_id "
        "JOIN molecula m ON m.id=a.molecula_id WHERE a.tipo='composto_em_organismo' AND a.estado != 'rejeitado' ORDER BY a.id")
        if a["id"] not in outras_regras]
    ids = {a["id"] for a in afirmacoes}
    refs_da_af = defaultdict(list)
    for r in con.execute("SELECT ar.afirmacao_id, ar.referencia_id FROM afirmacao_referencia ar JOIN referencia r ON r.id=ar.referencia_id "
                         "WHERE r.estado='ativa' AND r.duplicata_de IS NULL ORDER BY ar.referencia_id"):
        if r["afirmacao_id"] in ids:
            refs_da_af[r["afirmacao_id"]].append(r["referencia_id"])
    ids_ref = sorted({rid for lst in refs_da_af.values() for rid in lst})
    refs = [dict(r) for ini in range(0, len(ids_ref), 800) for r in con.execute(
        f"SELECT id, doi, pmid, titulo FROM referencia WHERE id IN ({','.join('?' * len(ids_ref[ini:ini + 800]))})", ids_ref[ini:ini + 800])]
    log(f"  conferência na literatura: {len(afirmacoes)} afirmações, {len(refs)} obras citadas")
    textos = ler_obras(con, cli, refs, log)

    # nomes de organismo que as fontes resolveram para OUTRO táxon: não servem para reconhecer este
    conflitantes = {r["nome_fonte"].lower() for r in con.execute(
        "SELECT nome_fonte FROM organismo_fonte WHERE decisao IN ('fora_do_escopo','homonimo_nao_resolvido')")}
    sinonimos = defaultdict(list)
    for s in con.execute("SELECT taxon_id, nome FROM taxon_sinonimo WHERE IFNULL(status_gbif,'') NOT IN "
                         "('PROPARTE_SYNONYM','MISAPPLIED','DOUBTFUL')"):
        if " ".join(s["nome"].split()[:2]).lower() not in conflitantes and s["nome"].lower() not in conflitantes:
            sinonimos[s["taxon_id"]].append(s["nome"])

    from . import taxonomia
    _resolvidos: dict[tuple, int | None] = {}

    def resolver_para(reino):
        def resolver(binomio):
            chave_r = (binomio.lower(), reino)
            if chave_r not in _resolvidos:
                u = taxonomia.casar_nome(cli, binomio, reino=reino)
                sp = taxonomia.especie_aceita(cli, u) if u else None
                _resolvidos[chave_r] = sp["key"] if sp else None
            return _resolvidos[chave_r]
        return resolver

    reino_do_taxon = {r["id"]: (r["reino"], r["gbif_key"]) for r in con.execute("SELECT id, reino, gbif_key FROM taxon")}
    cont, disparos = Counter(), {}
    for a in afirmacoes:
        if any(textos.get(rid, {}).get("nao_conferida") for rid in refs_da_af.get(a["id"], [])):
            ids.discard(a["id"])            # fica exatamente como estava, inclusive as regras de literatura
            cont["nao_conferida_nesta_execucao"] += 1
            continue
        nomes = [a["taxon"], *[n for n in (a["organismo_na_fonte"] or "").split("; ") if n], *sinonimos[a["taxon_id"]]]
        genero = a["genero"] or a["taxon"].split()[0]
        reino, chave_gbif = reino_do_taxon[a["taxon_id"]]
        r = avaliar_afirmacao(list(dict.fromkeys(nomes)), genero, variantes_do_composto([a["m_nome"], a["nome_na_fonte"]]),
                              [textos[rid] for rid in refs_da_af.get(a["id"], []) if rid in textos],
                              resolver=resolver_para(reino), chave_taxon=chave_gbif)
        nivel = "curador" if a["estado"] == "verificado" else r["nivel"]
        classe_local, local = classe_dos_locais(r["locais"])
        local_ref, local_frase = r["local_ref"], r["local_frase"]
        if classe_local is None and r["marinha_ref"] is not None:      # sem país declarado: vale a origem marinha
            classe_local, local, local_ref, local_frase = "ambiente_marinho", None, r["marinha_ref"], r["marinha_frase"]
        sets = {"conferencia_literatura": r["conferencia"], "nivel_evidencia": nivel,
                "procedencia_artigo": classe_local, "procedencia_artigo_local": local,
                "procedencia_artigo_referencia_id": local_ref if classe_local else None,
                "procedencia_artigo_sha256": _sha(local_frase) if (classe_local and local_frase) else None}
        if a["passagem_origem"] in (None, "resumo", "texto_completo_aberto") and a["estado"] != "verificado":
            trecho = r["trecho"]
            guardar = bool(trecho) and r.get("trecho_aberto") and not _LOCAL_FINO.search(trecho) and not _COLETA.search(trecho)
            sets.update({"passagem": trecho[:600] if guardar else None, "passagem_origem": r["trecho_origem"] if trecho else None,
                         "passagem_referencia_id": r["trecho_ref"], "passagem_sha256": _sha(trecho) if trecho else None})
        cols = sorted(sets)
        con.execute(f"UPDATE afirmacao SET {', '.join(c + '=?' for c in cols)} WHERE id=?", (*[sets[c] for c in cols], a["id"]))
        cont[r["conferencia"]] += 1
        if r["conferencia"] == "outra_especie_citada":
            disparos[a["id"]] = {"LIT-OUTRA-ESPECIE": {"especie_no_artigo": r["outra_especie"], "taxon": a["taxon"]}}
        elif r["conferencia"] == "texto_sem_mencao":
            disparos[a["id"]] = {"LIT-SEM-MENCAO": {"nivel_texto": "texto completo" if r["nivel_texto"] == "texto_completo_aberto" else "resumo",
                                                    "taxon": a["taxon"]}}
    quarentena.declarar(con, REGRAS_DE_LITERATURA, disparos, entre=ids)
    # Demais tipos: a fonte é a própria anotação da base; não há conferência de texto a fazer aqui.
    con.execute("UPDATE afirmacao SET conferencia_literatura='nao_se_aplica' WHERE tipo != 'composto_em_organismo'")
    con.execute("UPDATE afirmacao SET nivel_evidencia = CASE WHEN estado='verificado' THEN 'curador' ELSE 'base_curada' END "
                "WHERE tipo != 'composto_em_organismo' OR nivel_evidencia IS NULL")
    con.commit()
    return {"afirmacoes_conferidas": len(afirmacoes), "obras": len(refs), "conferencia": dict(cont),
            "com_local_de_coleta_no_artigo": con.execute(
                "SELECT COUNT(*) FROM afirmacao WHERE procedencia_artigo IS NOT NULL").fetchone()[0]}
