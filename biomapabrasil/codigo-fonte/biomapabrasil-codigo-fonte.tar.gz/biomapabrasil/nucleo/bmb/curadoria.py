# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Curadoria: a única via para uma afirmação chegar a 'verificado'.

O curador lê a publicação, registra o trecho (citação curta), o que o artigo declara sobre a procedência do
material e a sensibilidade do dado, e decide. Máquina nenhuma verifica: o estado 'verificado' só nasce de uma
linha em `verificacao` com nome de curador, trecho e data.

Localidade (CARE / SisGen): o que o curador registra sobre o local de coleta é país e, no Brasil, unidade da
federação. Município, coordenada, nome de comunidade, de terra indígena ou de unidade de conservação não são
gravados em campo nenhum, nem dentro do trecho citado ou do testemunho.
"""
import hashlib
import json
import re
import sqlite3

from . import procedencia, prontidao, quarentena
from .conectores import ena
from .util import agora, sem_acento

DECISOES = ("confirmada", "corrigida", "rejeitada", "duvida")
SENSIBILIDADES = ("sem_restricao", "restrito", "comunitario")
QUALIDADES = ("atende", "parcial", "ausente")
PAPEIS_CURADOR = ("curador_1", "curador_2", "adjudicador")
SUBTIPOS_DECISAO = (
    "isolamento_primario_confirmado",
    "ensaio_primario_confirmado",
    "citacao_secundaria_ou_revisao",
    "erro_taxonomico_ou_sinonimo",
    "erro_quimico_ou_estrutura",
    "material_extra_amazonico",
    "sintetico_ou_derivado_nao_natural",
    "texto_insuficiente",
)
ACESSOS_TEXTO = ("texto_completo_aberto", "texto_completo_assinatura", "apenas_resumo", "indisponivel")
ESCOPOS_GEOGRAFICOS = ("amazonia_br", "pan_amazonia", "brasil_extra_amazonia", "exterior_nao_amazonico", "nao_declarado")
ROTULOS_ESCOPO = {"amazonia_br": "Amazônia brasileira", "pan_amazonia": "Pan-Amazônia (outros países)",
                  "brasil_extra_amazonia": "Brasil fora da Amazônia", "exterior_nao_amazonico": "Exterior fora da Pan-Amazônia",
                  "nao_declarado": "Não declarado no texto"}
LIMITE_TRECHO = 600           # citação curta: o trecho não é uma cópia do artigo
LIMITE_PROCEDENCIA = 40       # «País: UF» cabe com folga; texto maior que isso é descrição de lugar
ESTADO_POR_DECISAO = {"confirmada": "verificado", "corrigida": "verificado", "rejeitada": "rejeitado", "duvida": "em_revisao"}


class ErroCuradoria(ValueError):
    """Entrada inválida do curador; a mensagem é mostrada a ele."""
    status = 422


class ErroDeLocalidade(ErroCuradoria):
    """A entrada traz localidade mais fina que país e UF. Nada é gravado."""
    status = 400


# ═══════════════════════════ localidade: só país e UF ═══════════════════════════
# País em português → ISO 3166-1 alfa-2. Os nomes em inglês vêm do vocabulário do INSDC (bmb.conectores.ena).
_PAISES_PT = {
    "brasil": "BR", "bolivia": "BO", "colombia": "CO", "equador": "EC", "guiana francesa": "GF", "guiana": "GY",
    "peru": "PE", "suriname": "SR", "venezuela": "VE", "argentina": "AR", "paraguai": "PY", "uruguai": "UY",
    "chile": "CL", "mexico": "MX", "panama": "PA", "costa rica": "CR", "cuba": "CU", "guatemala": "GT",
    "honduras": "HN", "nicaragua": "NI", "trinidad e tobago": "TT", "estados unidos": "US", "eua": "US",
    "canada": "CA", "china": "CN", "india": "IN", "japao": "JP", "coreia do sul": "KR", "taiwan": "TW",
    "tailandia": "TH", "vietna": "VN", "indonesia": "ID", "malasia": "MY", "filipinas": "PH", "paquistao": "PK",
    "ira": "IR", "turquia": "TR", "australia": "AU", "nova zelandia": "NZ", "africa do sul": "ZA",
    "madagascar": "MG", "nigeria": "NG", "camaroes": "CM", "gana": "GH", "quenia": "KE", "tanzania": "TZ",
    "egito": "EG", "marrocos": "MA", "angola": "AO", "mocambique": "MZ", "alemanha": "DE", "franca": "FR",
    "italia": "IT", "espanha": "ES", "portugal": "PT", "reino unido": "GB", "paises baixos": "NL", "belgica": "BE",
    "suica": "CH", "russia": "RU",
}
_CODIGOS_ISO = set(ena.MAPA_PAIS_ISO.values()) | set(_PAISES_PT.values())
_FORMATO_PROCEDENCIA = re.compile(r"^(?P<pais>[^:,;/0-9()]+?)(?:\s*:\s*(?P<uf>[A-Za-z]{2}))?$")
MSG_PROCEDENCIA = ("A procedência do material entra só como «País» ou «País: UF», por exemplo «Brasil: AM» ou «Peru». "
                   "Município, coordenada, nome de comunidade, de terra indígena ou de unidade de conservação não são registrados.")

_NOME_PROPRIO = r"[A-ZÀ-Ý][\w'’-]+"
# Coordenada: grau seguido de minuto ou de hemisfério («3°06′», «60.02° W»). «25 °C» e «[α]D +35°» não são coordenada.
_COORDENADA = re.compile(
    r"\d{1,3}(?:[.,]\d+)?\s*[°º]\s*(?:\d{1,2}(?:[.,]\d+)?\s*['′’]|[NSWEOL]\b)"
    r"|\b[NSWEOL]\s*\d{1,3}(?:[.,]\d+)?\s*[°º]"
    r"|\b(?i:latitude|longitude|coordenadas? geogr[aá]ficas?|geographic(?:al)? coordinates?|GPS)\b")
# Tipo de lugar junto de um nome próprio («Reserva Ducke», «village of Xixuaú», «Yunnan Province»), território
# indígena ou unidade de conservação, e distância em quilômetros. «fungal community of endophytes» não é lugar.
_LUGAR = re.compile(
    rf"\b(?i:munic[ií]pios?|municipalit(?:y|ies)|aldeias?|villages?|vilas?|povoados?|comunidades?|communit(?:y|ies)|"
    rf"distritos?|districts?|count(?:y|ies)|prov[ií]ncias?|provinces?|reservas?|reserves?|parques?|parks?|fazendas?|"
    rf"farms?|igarap[eé]s?)\s+(?:(?i:d[aeo]s?|of the|of|del?|la)\s+)?{_NOME_PROPRIO}"
    rf"|{_NOME_PROPRIO}\s+(?:(?:National|State|Forest|Biological|Extractive|Indigenous|Nature)\s+)*"
    rf"(?:Reserve|Park|Village|Community|Municipality|District|County|Province|Farm)\b"
    rf"|\b(?i:terras? ind[ií]genas?|indigenous (?:lands?|territor(?:y|ies)|reserves?)|quilombos?|"
    rf"unidades? de conserva[cç][aã]o|floresta nacional|national forest|esta[cç][aã]o ecol[oó]gica)\b"
    rf"|\b\d+(?:[.,]\d+)?\s*km\b")


# Testemunho digitado por curador: sigla da coleção e número («INPA 22410», «INPA-H 31022», «K000697654»), um ou mais
# separados por «; ». Frase não é código: «coletado em … por …» traz lugar ou pessoa e não é registrada.
_CODIGO_DE_COLECAO = re.compile(r"^[A-Z]{1,10}(?:[-:][A-Z]{1,6}){0,2}[ :#-]?\d[\d.,/-]{0,15}[A-Za-z]?$")


def voucher_de_colecao(texto_):
    """Testemunho como código(s) de coleção, ou None se o texto não é só isso."""
    partes = [" ".join(v.split()) for v in (texto_ or "").split(";")]
    partes = [v for v in partes if v]
    if not partes or any(not _CODIGO_DE_COLECAO.match(v) or ena.voucher_sem_localidade(v) is None for v in partes):
        return None
    return "; ".join(partes)


def _pais_iso(nome):
    chave = " ".join(sem_acento(nome or "").lower().split())
    if len(chave) == 2 and chave.upper() in _CODIGOS_ISO:
        return chave.upper()
    return _PAISES_PT.get(chave) or ena.MAPA_PAIS_ISO.get(chave)


def normalizar_procedencia(texto_):
    """«País» ou «País: UF» → (texto como fica gravado, país ISO-2, UF ou None); vazio → (None, None, None).

    Qualquer outra forma é recusada com `ErroDeLocalidade`: o país tem de ser um país (nome em português, em inglês
    ou código ISO de duas letras) e a UF, uma das 27 siglas brasileiras. Assim nenhum município, coordenada ou nome
    de comunidade chega ao banco por este campo.
    """
    bruto = " ".join((texto_ or "").split())
    if not bruto:
        return None, None, None
    m = _FORMATO_PROCEDENCIA.match(bruto) if len(bruto) <= LIMITE_PROCEDENCIA else None
    pais_iso = _pais_iso(m["pais"]) if m else None
    if not pais_iso:
        raise ErroDeLocalidade(MSG_PROCEDENCIA)
    uf = (m["uf"] or "").upper() or None
    if uf and (pais_iso != "BR" or uf not in ena.SIGLAS_UF):
        raise ErroDeLocalidade(f"«{uf}» não é sigla de unidade da federação brasileira. " + MSG_PROCEDENCIA)
    pais = m["pais"].strip()
    pais = pais.upper() if len(pais) == 2 else pais
    return (f"{pais}: {uf}" if uf else pais), pais_iso, uf


def localidade_fina(texto_):
    """Pedaço de `texto_` que situa algo mais fino que país e UF (coordenada, município, comunidade, reserva…); None se não há.

    Vale para o que o curador digita e, na exportação, para toda frase de artigo já gravada como passagem (de
    curador ou localizada no resumo ou no texto aberto) e para o testemunho que a base de origem declara.
    """
    for padrao in (_COORDENADA, _LUGAR):
        m = padrao.search(texto_ or "")
        if m:
            return m.group(0).strip()
    return None


def _conferir_escopo(escopo, texto_procedencia, pais_iso, uf):
    """O escopo geográfico que o curador marcou não pode contradizer o país e a UF que ele mesmo registrou."""
    if not escopo or not pais_iso:
        return
    contradiz = (
        (escopo == "nao_declarado")
        or (escopo == "amazonia_br" and (pais_iso != "BR" or (uf is not None and uf not in procedencia.UFS_AMAZONIA_LEGAL)))
        or (escopo == "pan_amazonia" and (pais_iso == "BR" or pais_iso not in procedencia.PAISES_PAN_AMAZONICOS))
        or (escopo == "brasil_extra_amazonia" and pais_iso != "BR")
        or (escopo == "exterior_nao_amazonico" and pais_iso == "BR"))
    if contradiz:
        raise ErroCuradoria(f"O escopo geográfico lido («{ROTULOS_ESCOPO[escopo]}») não combina com a procedência "
                            f"registrada («{texto_procedencia}»). Corrija um dos dois.")


def _linha(r):
    return None if r is None else dict(r)


def estatisticas(con):
    por_estado = {r[0]: r[1] for r in con.execute("SELECT estado, COUNT(*) FROM afirmacao GROUP BY 1")}
    por_tipo = {r[0]: r[1] for r in con.execute("SELECT tipo, COUNT(*) FROM afirmacao WHERE estado IN ('candidato','em_revisao') GROUP BY 1")}
    return {"por_estado": por_estado, "pendentes_por_tipo": por_tipo,
            "verificacoes": con.execute("SELECT COUNT(*) FROM verificacao").fetchone()[0],
            "retidas_por_regra": quarentena.resumo(con)["afirmacoes_por_regra"]}


def fila(con, estado="candidato", tipo=None, taxon=None, q=None, limite=50, offset=0, rodada_benchmark=None, papel_curador=None):
    """Afirmações a conferir, das mais úteis para a plataforma às menos. Só as que têm publicação a ler.

    A lista de quarentena é para ver o que está retido e por quê: nela entram todas as retidas, com ou sem publicação.
    """
    limite = max(1, min(int(limite), 200))
    onde, args = [], []
    com_publicacao = "" if estado == "quarentena" else " AND EXISTS (SELECT 1 FROM afirmacao_referencia x WHERE x.afirmacao_id=a.id)"
    cegamento_fila = bool(rodada_benchmark and papel_curador in ("curador_1", "curador_2"))
    adjudicacao_fila = bool(rodada_benchmark and papel_curador == "adjudicador")
    if cegamento_fila and estado in (None, "", "candidato", "todos"):
        # Na revisão independente, curador_1 e curador_2 enxergam todos os itens da rodada que eles próprios ainda não
        # avaliaram, mesmo que o outro já tenha movido a afirmação para em_revisao, verificado ou rejeitado.
        onde.append("a.estado <> 'quarentena'")
    elif adjudicacao_fila and estado == "candidato":
        onde.append("a.estado IN ('em_revisao','candidato')")
    elif estado and estado != "todos":
        onde.append("a.estado = ?"); args.append(estado)
    else:
        onde.append("a.estado <> 'quarentena'")
    if tipo:
        onde.append("a.tipo = ?"); args.append(tipo)
    if taxon:
        onde.append("t.gbif_key = ?"); args.append(int(taxon))
    if q:
        onde.append("(m.nome LIKE ? OR t.nome LIKE ?)"); args += [f"%{q}%", f"%{q}%"]
    join_bench = ""
    ordem_extra = ""
    if rodada_benchmark:
        join_bench = "JOIN amostra_benchmark ab ON ab.afirmacao_id = a.id AND ab.rodada = ? "
        args.insert(0, rodada_benchmark)
        if papel_curador in ("curador_1", "curador_2"):
            onde.append("NOT EXISTS (SELECT 1 FROM verificacao vb WHERE vb.afirmacao_id=a.id AND vb.rodada_benchmark=? AND vb.papel_curador=?)")
            args += [rodada_benchmark, papel_curador]
        elif papel_curador == "adjudicador":
            onde.append("NOT EXISTS (SELECT 1 FROM verificacao vb WHERE vb.afirmacao_id=a.id AND vb.rodada_benchmark=? AND vb.papel_curador='adjudicador')")
            args.append(rodada_benchmark)
            ordem_extra = "(CASE WHEN a.estado = 'em_revisao' THEN 1 ELSE 0 END) DESC, "
    sql = f"""
      SELECT a.id, a.tipo, a.estado, a.nivel_evidencia, a.procedencia_declarada, a.regra_quarentena, a.texto,
             m.nome AS molecula, m.id AS molecula_id, t.nome AS taxon, t.gbif_key AS gbif,
             t.predominio_al AS predominio, t.grupo,
             (SELECT COUNT(*) FROM afirmacao_referencia x WHERE x.afirmacao_id=a.id) AS n_refs,
             (CASE t.predominio_al WHEN 'predominante' THEN 3 WHEN 'indeterminado' THEN 2 WHEN 'nao_predominante' THEN 1 ELSE 0 END
              + CASE WHEN m.max_fase_clinica >= 4 THEN 2 ELSE 0 END
              + CASE WHEN EXISTS (SELECT 1 FROM afirmacao b WHERE b.molecula_id=a.molecula_id AND b.tipo='atividade_biologica') THEN 1 ELSE 0 END
              + CASE WHEN a.tipo = 'funcao_toxina' THEN 1.5 ELSE 0 END
              + MIN((SELECT COUNT(*) FROM afirmacao_referencia x WHERE x.afirmacao_id=a.id), 5) * 0.3) AS prioridade
      FROM afirmacao a
      {join_bench}
      JOIN molecula m ON m.id = a.molecula_id
      LEFT JOIN taxon t ON t.id = a.taxon_id
      WHERE {' AND '.join(onde)}{com_publicacao}
      ORDER BY {ordem_extra}prioridade DESC, a.id
      LIMIT ? OFFSET ?"""
    itens = [dict(r) for r in con.execute(sql, (*args, limite, int(offset)))]
    if cegamento_fila:
        for it in itens:
            it["estado"] = "candidato"
    total = con.execute(f"SELECT COUNT(*) FROM afirmacao a {join_bench} JOIN molecula m ON m.id=a.molecula_id LEFT JOIN taxon t ON t.id=a.taxon_id "
                        f"WHERE {' AND '.join(onde)}{com_publicacao}", args).fetchone()[0]
    return {"total": total, "itens": itens}


def detalhe(con, afirmacao_id, papel_curador=None):
    a = con.execute("SELECT * FROM afirmacao WHERE id=?", (afirmacao_id,)).fetchone()
    if a is None:
        raise ErroCuradoria("Afirmação não encontrada.")
    refs = []
    for r in con.execute("SELECT r.* FROM afirmacao_referencia x JOIN referencia r ON r.id=x.referencia_id WHERE x.afirmacao_id=? ORDER BY r.ano DESC, r.id", (afirmacao_id,)):
        d = dict(r)
        d["autores"] = json.loads(d["autores"]) if d["autores"] else []
        d["url"] = f"https://doi.org/{d['doi']}" if d['doi'] else (f"https://pubmed.ncbi.nlm.nih.gov/{d['pmid']}/" if d["pmid"] else None)
        refs.append(d)
    m = con.execute("SELECT id, nome, tipo, inchikey, smiles, formula, uniprot_acc, chembl_id, pubchem_cid FROM molecula WHERE id=?", (a["molecula_id"],)).fetchone()
    t = con.execute("SELECT id, nome, gbif_key, grupo, motivo_recorte, predominio_al, distribuicao_br FROM taxon WHERE id=?", (a["taxon_id"],)).fetchone() if a["taxon_id"] else None
    alvo = con.execute("SELECT nome, chembl_id, organismo, natureza FROM alvo WHERE id=?", (a["alvo_id"],)).fetchone() if a["alvo_id"] else None
    consulta = con.execute("SELECT url, consultado_em, fonte_id FROM consulta WHERE id=?", (a["consulta_id"],)).fetchone()
    verifs = [dict(v) for v in con.execute("SELECT * FROM verificacao WHERE afirmacao_id=? ORDER BY em DESC", (afirmacao_id,))]
    af_dict = dict(a)
    cegamento_ativo = papel_curador in ("curador_1", "curador_2")
    if cegamento_ativo:
        # Revisão independente: cada curador não vê voto, nota, estado derivado nem procedência registrada pelo outro
        verifs = [v for v in verifs if v.get("papel_curador") == papel_curador]
        if af_dict.get("estado") != "quarentena":
            af_dict["estado"] = "em_revisao" if verifs else "candidato"
        if not verifs:
            af_dict["procedencia_material"] = None
    from .exportar import pacotes                                  # rótulos públicos; importado aqui para não fechar ciclo
    rotulos = {"evidencia": pacotes.ROTULOS_EVIDENCIA.get(af_dict.get("nivel_evidencia")),
               "procedencia": procedencia.ROTULOS_PROCEDENCIA.get(af_dict.get("procedencia_declarada")),
               "procedencia_artigo": procedencia.ROTULOS_PROCEDENCIA_ARTIGO.get(af_dict.get("procedencia_artigo")),
               "distribuicao_br": procedencia.ROTULOS_DISTRIBUICAO.get(t["distribuicao_br"]) if t else None}
    regras = [dict(r) for r in con.execute(
        "SELECT r.codigo, q.titulo, r.detalhe FROM afirmacao_regra r LEFT JOIN regra_quarentena q ON q.codigo=r.codigo "
        "WHERE r.afirmacao_id=? ORDER BY r.codigo", (afirmacao_id,))]
    return {"afirmacao": af_dict, "molecula": _linha(m), "taxon": _linha(t), "alvo": _linha(alvo), "consulta": _linha(consulta), "referencias": refs,
            "prontidao": _linha(con.execute("SELECT * FROM prontidao WHERE afirmacao_id=?", (afirmacao_id,)).fetchone()),
            "verificacoes": verifs, "cegamento_ativo": cegamento_ativo, "rotulos": rotulos, "regras_disparadas": regras}


def _texto(dados, campo, obrigatorio=False, maximo=2000):
    v = dados.get(campo)
    v = v.strip() if isinstance(v, str) else None
    if obrigatorio and not v:
        raise ErroCuradoria(f"O campo «{campo}» é obrigatório.")
    if v and len(v) > maximo:
        raise ErroCuradoria(f"O campo «{campo}» passa de {maximo} caracteres.")
    return v or None


def _classe_binaria(decisao):
    if decisao in ("confirmada", "corrigida"):
        return "positiva"
    if decisao == "rejeitada":
        return "negativa"
    return "duvida"


def verificar(con, dados):
    """Registra a decisão do curador e aplica a transição de estado. Devolve o novo estado e o índice de prontidão."""
    af = con.execute("SELECT * FROM afirmacao WHERE id=?", (dados.get("afirmacao_id"),)).fetchone()
    if af is None:
        raise ErroCuradoria("Afirmação não encontrada.")
    if af["estado"] == "quarentena":
        raise ErroCuradoria("A afirmação está em quarentena; resolva o motivo antes de verificar.")
    curador = _texto(dados, "curador", True, 120)
    if len(curador) < 3:
        raise ErroCuradoria("Identifique-se com o nome (mínimo de 3 caracteres): a verificação é assinada.")
    decisao = dados.get("decisao")
    if decisao not in DECISOES:
        raise ErroCuradoria(f"Decisão inválida; use uma de {', '.join(DECISOES)}.")
    papel = dados.get("papel_curador") or None
    if papel is not None and papel not in PAPEIS_CURADOR:
        raise ErroCuradoria(f"Papel de curador inválido; use um de {', '.join(PAPEIS_CURADOR)}.")
    rodada = _texto(dados, "rodada_benchmark", maximo=80)
    subtipo = dados.get("subtipo_decisao") or None
    if subtipo is not None and subtipo not in SUBTIPOS_DECISAO:
        raise ErroCuradoria("Subtipo de decisão inválido.")
    acesso_txt = dados.get("acesso_texto") or None
    if acesso_txt is not None and acesso_txt not in ACESSOS_TEXTO:
        raise ErroCuradoria("Modo de acesso ao texto inválido.")
    escopo_geo = dados.get("escopo_geografico_lido") or None
    if escopo_geo is not None and escopo_geo not in ESCOPOS_GEOGRAFICOS:
        raise ErroCuradoria("Escopo geográfico lido inválido.")

    passagem = _texto(dados, "passagem_conferida", maximo=LIMITE_TRECHO)
    nota = _texto(dados, "nota")
    if decisao in ("confirmada", "corrigida") and (not passagem or len(passagem) < 20):
        raise ErroCuradoria("Cole o trecho do artigo que você leu (citação curta, de 20 a 600 caracteres).")
    if decisao == "rejeitada" and (not nota or len(nota) < 10):
        raise ErroCuradoria("Explique na nota por que a afirmação foi rejeitada (mínimo de 10 caracteres).")
    sens = dados.get("sensibilidade") or None
    if decisao in ("confirmada", "corrigida") and sens not in SENSIBILIDADES:
        raise ErroCuradoria("Informe a sensibilidade do dado: sem restrição, restrito ou comunitário.")
    qualidade = dados.get("qualidade_experimental") or None
    if qualidade is not None and qualidade not in QUALIDADES:
        raise ErroCuradoria("Qualidade experimental inválida.")
    ref_id = dados.get("referencia_id")
    if ref_id is not None and not con.execute("SELECT 1 FROM afirmacao_referencia WHERE afirmacao_id=? AND referencia_id=?", (af["id"], ref_id)).fetchone():
        raise ErroCuradoria("A referência escolhida não pertence a esta afirmação.")

    # Localidade: país e UF, e mais nada, em qualquer campo que o curador preenche.
    procedencia_mat, pais_iso, uf = normalizar_procedencia(dados.get("procedencia_material") if isinstance(dados.get("procedencia_material"), str) else None)
    _conferir_escopo(escopo_geo, procedencia_mat, pais_iso, uf)
    achado = localidade_fina(passagem)
    if achado:
        raise ErroDeLocalidade(f"O trecho cita um lugar mais fino que país e estado («{achado}»). Cole a frase que sustenta a "
                               "afirmação sem o local de coleta, ou corte esse pedaço; o local entra só como país e UF, no campo de procedência.")
    voucher = _texto(dados, "voucher", maximo=300)
    if voucher:
        voucher = voucher_de_colecao(voucher)
        if voucher is None:
            raise ErroDeLocalidade("O testemunho entra só como código de coleção: sigla e número, por exemplo «INPA 22410». "
                                   "Texto com país, estado, localidade ou nome de coletor não é registrado.")

    # Afirmação sorteada para a validação por amostragem só recebe voto dentro do protocolo (com papel de curador)
    if papel is None and con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='amostra_benchmark'").fetchone():
        row_bm = con.execute("SELECT rodada FROM amostra_benchmark WHERE afirmacao_id=? ORDER BY id DESC LIMIT 1", (af["id"],)).fetchone()
        if row_bm is not None:
            raise ErroCuradoria(
                f"Esta afirmação integra a amostra estratificada de benchmark ({row_bm['rodada']}); "
                "selecione o papel 'curador_1', 'curador_2' ou 'adjudicador'."
            )

    # Consenso entre dois curadores independentes quando papel_curador é curador_1 ou curador_2
    novo_estado = ESTADO_POR_DECISAO[decisao]
    v_outro = None
    if papel in ("curador_1", "curador_2"):
        outro_papel = "curador_2" if papel == "curador_1" else "curador_1"
        sql_outro = "SELECT * FROM verificacao WHERE afirmacao_id=? AND papel_curador=?"
        args_outro = [af["id"], outro_papel]
        if rodada:
            sql_outro += " AND rodada_benchmark=?"
            args_outro.append(rodada)
        sql_outro += " ORDER BY id DESC LIMIT 1"
        v_outro = con.execute(sql_outro, args_outro).fetchone()
        if v_outro is None:
            novo_estado = "em_revisao"
        else:
            mesma_decisao = (decisao == v_outro["decisao"]) and (decisao in ("confirmada", "corrigida", "rejeitada"))
            mesma_sens = (decisao == "rejeitada") or (sens == v_outro["sensibilidade"])
            if mesma_decisao and mesma_sens:
                novo_estado = ESTADO_POR_DECISAO[decisao]
            else:
                novo_estado = "em_revisao"

    ordem_acesso = {"publico": 0, "restrito": 1, "comunitario": 2}
    mapa_sens_acesso = {"sem_restricao": "publico", "restrito": "restrito", "comunitario": "comunitario"}

    try:
        ts = agora()
        con.execute(
            "INSERT INTO verificacao (afirmacao_id, referencia_id, curador, decisao, passagem_conferida, procedencia_material, voucher, "
            "sensibilidade, qualidade_experimental, nota, em, rodada_benchmark, papel_curador, subtipo_decisao, acesso_texto, escopo_geografico_lido) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (af["id"], ref_id, curador, decisao, passagem, procedencia_mat, voucher, sens, qualidade, nota, ts,
             rodada, papel, subtipo, acesso_txt, escopo_geo))
        if novo_estado == "verificado":
            # O trecho conferido passa a ser a passagem pública, com a origem «curador», e o nível de evidência sobe a
            # «curador». A sensibilidade decide o acesso: 'restrito' e 'comunitario' ficam fora de pacotes, CSV, DwC-A e API.
            sens_efetiva = sens or "sem_restricao"
            acesso = mapa_sens_acesso[sens_efetiva]
            if papel != "adjudicador":
                acesso_atual = af["classe_acesso"] or "publico"
                if ordem_acesso.get(acesso_atual, 0) > ordem_acesso.get(acesso, 0):
                    acesso = acesso_atual
            con.execute(
                "UPDATE afirmacao SET estado=?, passagem=?, passagem_origem='curador', passagem_referencia_id=?, passagem_sha256=?, "
                "nivel_evidencia='curador', procedencia_material=?, classe_acesso=?, atualizado_em=? WHERE id=?",
                (novo_estado, passagem, ref_id, hashlib.sha256(passagem.encode("utf-8")).hexdigest(), procedencia_mat, acesso, ts, af["id"]))
        else:
            acesso_cand = mapa_sens_acesso.get(sens, "publico") if sens else (af["classe_acesso"] or "publico")
            acesso_protegido = acesso_cand if ordem_acesso.get(acesso_cand, 0) > ordem_acesso.get(af["classe_acesso"] or "publico", 0) else (af["classe_acesso"] or "publico")
            con.execute("UPDATE afirmacao SET estado=?, classe_acesso=?, atualizado_em=? WHERE id=?", (novo_estado, acesso_protegido, ts, af["id"]))
            if af["estado"] == "verificado":
                # A confirmação anterior deixou de valer: o registro volta ao que a base de origem sustenta, e o trecho
                # do curador sai da afirmação (continua em `verificacao`). A etapa `evidencias` repõe o nível automático.
                con.execute("UPDATE afirmacao SET nivel_evidencia='base_curada', passagem=NULL, passagem_origem=NULL, "
                            "passagem_referencia_id=NULL, passagem_sha256=NULL WHERE id=? AND nivel_evidencia='curador'", (af["id"],))
        con.execute("INSERT INTO evento_proveniencia (entidade, entidade_id, atividade, agente, em, detalhe) VALUES ('afirmacao',?,?,?,?,?)",
                    (af["id"], "verificacao", f"curador:{curador}", ts, f"{decisao}" + (f" [{papel}]" if papel else "") + (f": {nota}" if nota else "")))
        # A leitura do curador muda a procedência declarada e pode mudar o que as regras de retenção decidem.
        procedencia.recalcular_procedencia_banco(con)
        quarentena.aplicar_estados(con)
        novo = con.execute("SELECT * FROM afirmacao WHERE id=?", (af["id"],)).fetchone()
        p = prontidao.avaliar(con, novo)
        prontidao.gravar(con, af["id"], p)
        con.commit()
    except sqlite3.IntegrityError as e:
        con.rollback()
        raise ErroCuradoria(f"O banco recusou o registro: {e}") from e
    return {"estado": novo["estado"], "indice": p["indice"]}


def quarentenar(con, dados):
    af = con.execute("SELECT id, estado FROM afirmacao WHERE id=?", (dados.get("afirmacao_id"),)).fetchone()
    if af is None:
        raise ErroCuradoria("Afirmação não encontrada.")
    curador = _texto(dados, "curador", True, 120)
    motivo = _texto(dados, "motivo", True, 500)
    if len(curador) < 3 or len(motivo) < 10:
        raise ErroCuradoria("Informe o curador (3+ caracteres) e o motivo da quarentena (10+ caracteres).")
    # Quarentena decidida por curador: nenhuma regra automática a desfaz (ver quarentena.aplicar_estados).
    con.execute("UPDATE afirmacao SET estado='quarentena', motivo_quarentena=?, regra_quarentena=NULL, quarentena_origem='curador', "
                "atualizado_em=? WHERE id=?", (motivo, agora(), af["id"]))
    con.execute("INSERT INTO evento_proveniencia (entidade, entidade_id, atividade, agente, em, detalhe) VALUES ('afirmacao',?,?,?,?,?)",
                (af["id"], "quarentena", f"curador:{curador}", agora(), motivo))
    # O estado de uma afirmação decide o de outras: sem a ocorrência, a molécula pode deixar de ter registro publicado
    # em organismo, e então as medidas e o efeito clínico dela também saem do público (regra derivada).
    quarentena.aplicar_estados(con)
    con.commit()
    return {"estado": "quarentena"}


def prebuscar_europepmc(con, cli, referencia_id):
    """Pré-busca título, resumo e status Open Access no Europe PMC para auxiliar a leitura humana na curadoria.

    Nunca promove uma afirmação automaticamente a `verificado`: apenas exibe os metadados abertos ao curador.
    """
    ref = con.execute("SELECT * FROM referencia WHERE id=?", (referencia_id,)).fetchone()
    if ref is None:
        raise ErroCuradoria("Referência não encontrada.")
    partes = []
    if ref["doi"]:
        partes.append(f'DOI:"{ref["doi"]}"')
    if ref["pmid"]:
        partes.append(f'EXT_ID:{ref["pmid"]}')
    if not partes:
        raise ErroCuradoria("Referência sem DOI nem PMID.")
    query = " OR ".join(partes)
    r = cli.get(
        "https://www.ebi.ac.uk/europepmc/webservices/rest/search",
        {"query": query, "resultType": "core", "format": "json", "pageSize": "3"},
        fonte="europepmc",
        tentativas=2,
    )
    lista = ((r.dados.get("resultList") or {}).get("result") or []) if isinstance(r.dados, dict) else []
    if not lista:
        return {"encontrado": False, "consulta_id": r.consulta_id}
    item = lista[0]
    pmcid = item.get("pmcid")
    if pmcid and not ref["pmcid"]:
        con.execute("UPDATE referencia SET pmcid=? WHERE id=?", (pmcid, referencia_id))
        con.commit()
    trecho_oa = None
    if pmcid and item.get("isOpenAccess") == "Y":
        try:
            rx = cli.get(
                f"https://www.ebi.ac.uk/europepmc/webservices/rest/{pmcid}/fullTextXML",
                fonte="europepmc",
                como_json=False,
                accept="application/xml",
                tentativas=2,
            )
            if isinstance(rx.dados, str) and "<body" in rx.dados:
                corpo_xml = rx.dados.split("<body", 1)[1].split("</body>", 1)[0]
                limpo = re.sub(r"<[^>]+>", " ", corpo_xml)
                limpo = re.sub(r"\s+", " ", limpo).strip()
                trecho_oa = limpo[:1200] if limpo else None
        except Exception:
            trecho_oa = None

    url_pdf_oa = None
    urls_ft = ((item.get("fullTextUrlList") or {}).get("fullTextUrl") or []) if isinstance(item, dict) else []
    for u_entry in urls_ft:
        if not isinstance(u_entry, dict):
            continue
        disp = (u_entry.get("availabilityCode") or "").upper()
        estilo = (u_entry.get("documentStyle") or "").lower()
        u_val = (u_entry.get("url") or "").strip()
        if u_val and disp in ("OA", "F") and estilo == "pdf":
            url_pdf_oa = u_val
            break
    if not url_pdf_oa and ref["doi"]:
        try:
            ru = cli.get(
                f"https://api.unpaywall.org/v2/{ref['doi']}",
                {"email": "contato@biomapabrasil.org"},
                fonte="crossref",
                tentativas=1,
            )
            if isinstance(ru.dados, dict) and ru.dados.get("is_oa"):
                best = ru.dados.get("best_oa_location") or {}
                url_pdf_oa = best.get("url_for_pdf") or best.get("url")
        except Exception:
            url_pdf_oa = None

    return {
        "encontrado": True,
        "titulo": item.get("title"),
        "resumo": item.get("abstractText"),
        "trecho_oa": trecho_oa,
        "pmcid": pmcid,
        "acesso_aberto": bool(item.get("isOpenAccess") == "Y" or url_pdf_oa),
        "licenca": item.get("license"),
        "revista": (item.get("journalInfo") or {}).get("journal", {}).get("title"),
        "ano": item.get("pubYear"),
        "url_texto_completo": f"https://europepmc.org/article/PMC/{pmcid}" if pmcid else None,
        "url_pdf_oa": url_pdf_oa,
        "url_unpaywall": f"https://api.unpaywall.org/v2/{ref['doi']}?email=contato@biomapabrasil.org" if ref["doi"] else None,
        "consulta_id": r.consulta_id,
    }


def aplicar_semente_verificacoes(con, caminho=None, log=print, sincronizar_remocoes=None):
    """Sincroniza verificações curatoriais versionadas (`semente/verificacoes_curador.toml`) de forma idempotente."""
    import tomllib
    from . import config

    arq = caminho or (config.SEMENTE_DIR / "verificacoes_curador.toml")
    if not arq.is_file():
        return {"aplicadas": 0, "ja_existentes": 0, "ignoradas": 0}
    entradas = tomllib.loads(arq.read_text(encoding="utf-8")).get("verificacao", [])
    aplicadas = ja_existentes = ignoradas = removidas = 0
    curador_semente = "Curadoria Científica BioMapaBrasil"
    alvos_semente = set()

    for ent in entradas:
        row = con.execute(
            "SELECT a.id AS afirmacao_id, a.estado, r.id AS referencia_id "
            "FROM afirmacao a "
            "JOIN taxon t ON t.id=a.taxon_id "
            "JOIN molecula m ON m.id=a.molecula_id "
            "JOIN afirmacao_referencia ar ON ar.afirmacao_id=a.id "
            "JOIN referencia r ON r.id=ar.referencia_id "
            "WHERE t.gbif_key=? AND m.inchikey=? AND a.fonte_id=? "
            "AND ((? IS NOT NULL AND r.pmid=?) OR (? IS NOT NULL AND lower(r.doi)=lower(?))) "
            "AND (a.estado NOT IN ('quarentena', 'rejeitado') OR a.procedencia_declarada='curador_artigo_fora_da_amazonia') "
            "ORDER BY a.id LIMIT 1",
            (int(ent["taxon_gbif_key"]), ent["molecula_inchikey"], ent["fonte_id"],
             ent.get("pmid"), ent.get("pmid"), ent.get("doi"), ent.get("doi")),
        ).fetchone()
        if row is None:
            ignoradas += 1
            continue
        aid = row["afirmacao_id"]
        curador_nome = ent.get("curador", curador_semente)
        if curador_nome == curador_semente:
            alvos_semente.add(aid)
        decisao = ent.get("decisao", "confirmada")
        proc_norm, _, _ = normalizar_procedencia(ent.get("procedencia_material"))
        voucher_norm = voucher_de_colecao(ent.get("voucher")) if ent.get("voucher") else None
        atual_v = con.execute(
            "SELECT * FROM verificacao WHERE afirmacao_id=? ORDER BY em DESC, id DESC LIMIT 1",
            (aid,),
        ).fetchone()
        if atual_v is not None and (atual_v["curador"] != curador_semente or atual_v["papel_curador"] is not None):
            # Voto humano interativo/benchmark prevalece sobre a semente versionada.
            ja_existentes += 1
            continue
        if (
            atual_v is not None
            and row["estado"] in ("verificado", "quarentena")
            and atual_v["referencia_id"] == row["referencia_id"]
            and atual_v["decisao"] == decisao
            and atual_v["passagem_conferida"] == ent.get("passagem_conferida")
            and (atual_v["procedencia_material"] or None) == proc_norm
            and (atual_v["voucher"] or None) == voucher_norm
            and (atual_v["sensibilidade"] or "sem_restricao") == ent.get("sensibilidade", "sem_restricao")
            and (atual_v["qualidade_experimental"] or "atende") == ent.get("qualidade_experimental", "atende")
            and (atual_v["subtipo_decisao"] or None) == ent.get("subtipo_decisao", "isolamento_primario_confirmado")
            and (atual_v["acesso_texto"] or None) == ent.get("acesso_texto", "apenas_resumo")
            and (atual_v["escopo_geografico_lido"] or None) == ent.get("escopo_geografico_lido", "nao_declarado")
        ):
            ja_existentes += 1
            continue

        if atual_v is not None and atual_v["curador"] == curador_semente and atual_v["papel_curador"] is None:
            con.execute("DELETE FROM verificacao WHERE afirmacao_id=? AND curador=? AND papel_curador IS NULL", (aid, curador_semente))
            con.execute(
                "UPDATE afirmacao SET estado='candidato', nivel_evidencia='base_curada', passagem=NULL, passagem_origem=NULL, "
                "passagem_referencia_id=NULL, passagem_sha256=NULL, procedencia_material=NULL WHERE id=?",
                (aid,),
            )
            procedencia.recalcular_procedencia_banco(con)
            quarentena.aplicar_estados(con)

        verificar(con, {
            "afirmacao_id": aid,
            "referencia_id": row["referencia_id"],
            "curador": curador_nome,
            "decisao": decisao,
            "passagem_conferida": ent["passagem_conferida"],
            "procedencia_material": ent.get("procedencia_material"),
            "voucher": ent.get("voucher"),
            "sensibilidade": ent.get("sensibilidade", "sem_restricao"),
            "qualidade_experimental": ent.get("qualidade_experimental", "atende"),
            "subtipo_decisao": ent.get("subtipo_decisao", "isolamento_primario_confirmado"),
            "acesso_texto": ent.get("acesso_texto", "apenas_resumo"),
            "escopo_geografico_lido": ent.get("escopo_geografico_lido", "nao_declarado"),
            "nota": ent.get("nota"),
        })
        aplicadas += 1

    if sincronizar_remocoes if sincronizar_remocoes is not None else (caminho is None):
        obsoletas = [
            r["afirmacao_id"]
            for r in con.execute(
                "SELECT DISTINCT afirmacao_id FROM verificacao WHERE curador=? AND papel_curador IS NULL",
                (curador_semente,),
            ).fetchall()
            if r["afirmacao_id"] not in alvos_semente
        ]
        for aid_obs in obsoletas:
            con.execute("DELETE FROM verificacao WHERE afirmacao_id=? AND curador=? AND papel_curador IS NULL", (aid_obs, curador_semente))
            con.execute(
                "UPDATE afirmacao SET estado='candidato', nivel_evidencia='base_curada', passagem=NULL, passagem_origem=NULL, "
                "passagem_referencia_id=NULL, passagem_sha256=NULL, procedencia_material=NULL, motivo_quarentena=NULL, "
                "regra_quarentena=NULL WHERE id=? AND (estado='verificado' OR procedencia_declarada='curador_artigo_fora_da_amazonia')",
                (aid_obs,),
            )
            removidas += 1
        if removidas:
            procedencia.recalcular_procedencia_banco(con)
            quarentena.aplicar_estados(con)
            for aid_obs in obsoletas:
                af_r = con.execute("SELECT * FROM afirmacao WHERE id=?", (aid_obs,)).fetchone()
                if af_r:
                    prontidao.gravar(con, aid_obs, prontidao.avaliar(con, af_r))
            con.commit()

    if log and (entradas or removidas):
        log(f"  curadoria (semente): {aplicadas} aplicadas, {ja_existentes} já presentes, {ignoradas} não localizadas, {removidas} removidas")
    res = {"aplicadas": aplicadas, "ja_existentes": ja_existentes, "ignoradas": ignoradas}
    if removidas:
        res["removidas"] = removidas
    return res
