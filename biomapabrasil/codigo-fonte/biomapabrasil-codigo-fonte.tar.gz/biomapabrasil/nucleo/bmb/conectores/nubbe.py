# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""NuBBE-DB (UNESP / ChemNet, licença MIT): produtos naturais da biodiversidade brasileira.

O que se lê de cada linha: organismo (`gender` + `species`, nome inteiro), estrutura, referência (DOI), estado
brasileiro de coleta declarado pela base (`state`) e tipo de obtenção (`isolation_type`). Município e localidade
(`city`, `local`) não são lidos: o projeto não guarda nada mais fino que país e unidade da federação.

Dois cuidados que a base exige:

* o InChIKey nativo usa marcador fora do padrão, então todo SMILES é reconvertido pelo RDKit ao InChIKey padrão
  de 27 caracteres, o que permite a junção com LOTUS, PubChem e ChEMBL;
* nem toda linha é um isolamento. «Semisynthesis» e «Biotransformation product» descrevem derivados preparados a
  partir de um constituinte, e não contam como ocorrência do composto no organismo. O tipo é mantido por
  referência, para que um mesmo composto isolado num artigo e derivatizado em outro fique com a citação certa.
"""
from .. import quimica
from . import lotus

URL_DUMP_NUBBE = "https://raw.githubusercontent.com/chemnet-io/nubbeKG/main/oldJsonData/output.json"

UFS_VALIDAS = {
    "AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MG", "MS", "MT",
    "PA", "PB", "PE", "PI", "PR", "RJ", "RN", "RO", "RR", "RS", "SC", "SE", "SP", "TO",
}

# Tipos de obtenção que NÃO são ocorrência do composto no organismo.
ISOLAMENTO_NAO_CONSTITUINTE = {
    "semisynthesis": "semissíntese",
    "biotransformation product": "produto de biotransformação",
}
_MARCADORES_DE_CATEGORIA = {"var.": "var.", "var": "var.", "subsp.": "subsp.", "subsp": "subsp.", "ssp.": "subsp.",
                            "ssp": "subsp.", "f.": "f.", "fo.": "f.", "forma": "f."}
_NAO_IDENTIFICADO = {"sp", "spp", "cf", "aff", "x", "×"}


def _padronizar_estrutura(smiles):
    if not smiles or not isinstance(smiles, str):
        return None
    from rdkit import Chem, RDLogger
    from rdkit.Chem import Descriptors, rdMolDescriptors
    RDLogger.DisableLog("rdApp.*")
    try:
        mol = Chem.MolFromSmiles(smiles.strip())
        if mol is None or mol.GetNumHeavyAtoms() < 3:
            return None
        ik = Chem.MolToInchiKey(mol)
        if not ik or len(ik) != 27:
            return None
        if quimica.substancia_proscrita_344(ik):
            return None
        smi_can = Chem.MolToSmiles(mol, isomericSmiles=True)
        formula = rdMolDescriptors.CalcMolFormula(mol)
        massa = round(float(Descriptors.ExactMolWt(mol)), 4)
        return {"inchikey": ik, "smiles": smi_can, "formula": formula, "massa": massa}
    finally:
        RDLogger.EnableLog("rdApp.*")


def nome_do_organismo(genero, especie):
    """Nome do organismo como o NuBBE o escreve, sem cortar nada: `(nome, autoria)` ou `(None, None)`.

    O campo `species` às vezes traz a autoria («mandioccana Meissner») e, raramente, um infraespecífico
    («x var. y»). A autoria é devolvida à parte; o infraespecífico fica no nome. Organismo não identificado até
    espécie («sp.», «aff. x», híbrido) é recusado.
    """
    g = (genero or "").strip()
    partes = (especie or "").strip().split()
    if not g or not g.replace("-", "").isalpha() or not partes:
        return None, None
    ep = partes[0].lower().strip(".,;()")
    resto = partes[1:]
    if len(ep) < 2 or not ep.replace("-", "").isalpha() or ep in _NAO_IDENTIFICADO:
        return None, None
    if ep in ("affinis", "confer") and resto:      # «affinis pauciflorus»: afinidade, não epíteto
        return None, None
    nome = f"{g.capitalize()} {ep}"
    if resto:
        marcador = _MARCADORES_DE_CATEGORIA.get(resto[0].lower())
        if marcador and len(resto) >= 2:
            infra = resto[1].lower().strip(".,;()")
            if infra.replace("-", "").isalpha():
                return f"{nome} {marcador} {infra}", (" ".join(resto[2:]) or None)
            return None, None
        if resto[0].lower() in ("x", "×"):
            return None, None
        return nome, " ".join(resto)
    return nome, None


def carregar_indice(cli):
    """Baixa (ou lê do cache com SHA-256) o conjunto do NuBBE-DB e o indexa pelo organismo como a base o nomeia.

    Devolve `(por_organismo, consulta_id)`, com
    `por_organismo[nome] = {"familia", "autoria", "compostos": {(inchikey, uf): composto}}`. Cada composto guarda,
    por DOI, os tipos de obtenção que a base declara naquela referência.
    """
    resp = cli.get(URL_DUMP_NUBBE, fonte="nubbe", tentativas=3)
    linhas = resp.dados if isinstance(resp.dados, list) else []
    cache_smi = {}
    por_organismo = {}

    for row in linhas:
        nome_org, autoria = nome_do_organismo(row.get("gender"), row.get("species"))
        if not nome_org:
            continue
        doi = lotus.normalizar_doi(row.get("doi"))
        if not doi:
            continue
        smi_bruto = (row.get("smiles") or "").strip()
        if not smi_bruto:
            continue
        if smi_bruto not in cache_smi:
            cache_smi[smi_bruto] = _padronizar_estrutura(smi_bruto)
        est = cache_smi[smi_bruto]
        if not est:
            continue

        ik = est["inchikey"]
        org = por_organismo.get(nome_org)
        if org is None:
            org = por_organismo[nome_org] = {"familia": (row.get("family") or "").strip() or None, "autoria": autoria,
                                             "compostos": {}}
        cod = row.get("compound_automatic_code")
        nubbe_id = f"NuBBE_{cod}" if cod is not None else f"NuBBE_id_{row.get('compound_id')}"
        nome = quimica.limpar_nome_quimico(row.get("compound_name") or row.get("name_iupac") or ik)
        if len(nome) > 95 and row.get("name_iupac") and len(row["name_iupac"]) < len(nome):
            nome = quimica.limpar_nome_quimico(row["name_iupac"])
        classe = (row.get("subclass") or row.get("compound_class") or "").strip() or None
        uf = (row.get("state") or "").strip().upper()
        uf = uf if uf in UFS_VALIDAS else None
        iso = (row.get("isolation_type") or "").strip()

        ent = org["compostos"].get((ik, uf))
        if ent is None:
            ent = org["compostos"][(ik, uf)] = {
                "nubbe_id": nubbe_id, "inchikey": ik, "smiles": est["smiles"], "formula": est["formula"],
                "massa": est["massa"], "nome": nome, "classe": classe, "uf_coleta": uf, "referencias": {},
            }
        ref = ent["referencias"].setdefault(doi, {
            "titulo": (row.get("title") or "").strip() or None,
            "revista": (row.get("periodic") or "").strip() or None,
            "ano": int(row["year"]) if str(row.get("year") or "").isdigit() else None,
            "isolamentos": set(),
        })
        ref["isolamentos"].add(iso)

    return por_organismo, resp.consulta_id


def e_ocorrencia(isolamentos) -> bool:
    """Uma referência sustenta a ocorrência quando ao menos um registro dela não é semissíntese nem biotransformação.
    Tipo em branco é tratado como a base trata o registro: produto natural do organismo."""
    return any(i.strip().lower() not in ISOLAMENTO_NAO_CONSTITUINTE for i in isolamentos)


def compostos_por_taxon(por_organismo: dict, decisoes: dict) -> dict[int, list[dict]]:
    """Agrupa por táxon do banco, pela decisão tomada para cada organismo: `{taxon_id: [composto, …]}`.

    Mantém afirmações separadas por (InChIKey, UF de coleta declarada). Em cada composto:
      * `referencias`: só as que sustentam ocorrência, quando há alguma; senão, todas (o registro nasce retido);
      * `nao_constituinte`: verdadeiro quando todo registro é semissíntese ou biotransformação;
      * `tipos_nao_constituinte`: os tipos declarados, em português, para o motivo da retenção;
      * `organismos` / `organismos_homonimo`: nomes usados pela base.
    """
    por_taxon: dict[int, dict] = {}
    for nome_org in sorted(por_organismo):
        d = decisoes.get((nome_org, ""))
        if d is None or d.taxon_id is None or d.decisao not in ("aceito", "aceito_mesmo_nome_e_autoria", "homonimo_nao_resolvido"):
            continue
        firme = d.decisao != "homonimo_nao_resolvido"
        alvo = por_taxon.setdefault(d.taxon_id, {})
        for chave_comp, c in por_organismo[nome_org]["compostos"].items():
            m = alvo.get(chave_comp)
            if m is None:
                m = alvo[chave_comp] = {**c, "referencias": {}, "organismos": set(), "organismos_homonimo": set(), "firme": False}
            (m["organismos"] if firme else m["organismos_homonimo"]).add(nome_org)
            m["firme"] = m["firme"] or firme
            for doi, meta in c["referencias"].items():
                ref = m["referencias"].setdefault(doi, {**meta, "isolamentos": set(), "firme": False})
                ref["isolamentos"].update(meta["isolamentos"])
                ref["firme"] = ref["firme"] or firme
    saida = {}
    for tid, comps in por_taxon.items():
        lista = []
        for c in comps.values():
            refs = {d: v for d, v in c["referencias"].items() if v["firme"] or not c["firme"]}
            de_ocorrencia = {d: v for d, v in refs.items() if e_ocorrencia(v["isolamentos"])}
            nao_constituinte = not de_ocorrencia
            usadas = de_ocorrencia or refs
            tipos = sorted({i for v in usadas.values() for i in v["isolamentos"] if i})
            uf = c["uf_coleta"]
            lista.append({
                "nubbe_id": c["nubbe_id"], "origem": f"nubbe:{c['nubbe_id']}:{uf}" if uf else f"nubbe:{c['nubbe_id']}",
                "inchikey": c["inchikey"], "smiles": c["smiles"], "formula": c["formula"], "massa": c["massa"],
                "nome": c["nome"], "classe": c["classe"], "uf_coleta": uf,
                "isolamento": "; ".join(tipos) or None,
                "nao_constituinte": nao_constituinte,
                "tipos_nao_constituinte": sorted({ISOLAMENTO_NAO_CONSTITUINTE[i.strip().lower()] for v in refs.values()
                                                  for i in v["isolamentos"] if i.strip().lower() in ISOLAMENTO_NAO_CONSTITUINTE}),
                "referencias": {d: {k: v[k] for k in ("titulo", "revista", "ano")} for d, v in usadas.items()},
                "referencias_descartadas": sorted(set(c["referencias"]) - set(usadas)),
                "organismos": sorted(c["organismos"] or c["organismos_homonimo"]),
                "organismos_homonimo": sorted(c["organismos_homonimo"]), "firme": c["firme"],
            })
        lista.sort(key=lambda x: (-len(x["referencias"]), x["nome"].lower(), x["uf_coleta"] or "ZZ"))
        saida[tid] = lista
    return saida
