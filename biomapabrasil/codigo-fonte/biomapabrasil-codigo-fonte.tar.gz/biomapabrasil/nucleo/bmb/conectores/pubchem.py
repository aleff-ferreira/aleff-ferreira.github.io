# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""PubChem: identificador (CID) e nome corrente de um composto, buscado pelo InChIKey.

O InChIKey é a âncora da identidade química da plataforma. O nome varia de fonte para fonte (o mesmo
composto pode se chamar de modos diferentes, e estereoisômeros distintos já foram trocados de nome
entre bases), então o nome nunca serve de chave.
"""
API = "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/inchikey"
PROPRIEDADES = "Title,MolecularFormula,MolecularWeight,IUPACName,SMILES,ConnectivitySMILES"


def _extrair_smiles_isomerico(p):
    """Prefere SMILES isomérico (preserva quiralidade @/@@ e geometria E/Z) ao SMILES plano de conectividade."""
    return (
        p.get("SMILES")
        or p.get("IsomericSMILES")
        or p.get("ConnectivitySMILES")
        or p.get("CanonicalSMILES")
    )


def propriedades(cli, inchikey):
    """Dados do composto no PubChem, ou None se não houver correspondência exata."""
    r = cli.get(f"{API}/{inchikey}/property/{PROPRIEDADES}/JSON", fonte="pubchem")
    if r.status != 200 or not isinstance(r.dados, dict):
        return None
    itens = r.dados.get("PropertyTable", {}).get("Properties", [])
    if not itens:
        return None
    p = itens[0]
    try:
        massa = float(p["MolecularWeight"]) if p.get("MolecularWeight") is not None else None
    except (TypeError, ValueError):
        massa = None
    return {"cid": p.get("CID"), "titulo": (p.get("Title") or "").strip() or None,
            "iupac": p.get("IUPACName"), "formula": p.get("MolecularFormula"), "massa": massa,
            "smiles": _extrair_smiles_isomerico(p), "consulta_id": r.consulta_id}


def pedidos(inchikeys):
    """Lista (url, params) para `Cliente.get_varios`, na mesma ordem dos InChIKeys."""
    return [(f"{API}/{k}/property/{PROPRIEDADES}/JSON", None) for k in inchikeys]


def interpretar(resp):
    """Mesma leitura de `propriedades`, a partir de uma resposta já obtida em lote."""
    if resp.status != 200 or not isinstance(resp.dados, dict):
        return None
    itens = resp.dados.get("PropertyTable", {}).get("Properties", [])
    if not itens:
        return None
    p = itens[0]
    try:
        massa = float(p["MolecularWeight"]) if p.get("MolecularWeight") is not None else None
    except (TypeError, ValueError):
        massa = None
    return {"cid": p.get("CID"), "titulo": (p.get("Title") or "").strip() or None,
            "iupac": p.get("IUPACName"), "formula": p.get("MolecularFormula"), "massa": massa,
            "smiles": _extrair_smiles_isomerico(p), "consulta_id": resp.consulta_id}


PROPRIEDADES_LOTE = f"InChIKey,{PROPRIEDADES}"


def propriedades_em_lote(cli, inchikeys, tamanho_lote=35):
    """Consulta PubChem em lotes separados por vírgula (`~35` InChIKeys por GET), devolvendo `{ik: (dict_ou_None, consulta_id)}`."""
    iks = [k for k in dict.fromkeys(inchikeys) if k]
    if not iks:
        return {}
    fatias = [iks[i:i + tamanho_lote] for i in range(0, len(iks), tamanho_lote)]
    pedidos_lote = [(f"{API}/{','.join(f)}/property/{PROPRIEDADES_LOTE}/JSON", None) for f in fatias]
    resps = cli.get_varios(pedidos_lote, fonte="pubchem", tentativas=2, ignorar_erros=True)
    saida = {}
    faltantes = []
    for fatia, resp in zip(fatias, resps):
        if resp is None:
            faltantes.extend(fatia)
            continue
        if resp.status == 404:
            # Lote inteiro sem correspondência no PubChem
            for ik in fatia:
                saida[ik] = (None, resp.consulta_id)
            continue
        if resp.status != 200 or not isinstance(resp.dados, dict):
            faltantes.extend(fatia)
            continue
        por_ik = {}
        for p in resp.dados.get("PropertyTable", {}).get("Properties", []):
            ik_p = (p.get("InChIKey") or "").strip().upper()
            if not ik_p:
                continue
            try:
                massa = float(p["MolecularWeight"]) if p.get("MolecularWeight") is not None else None
            except (TypeError, ValueError):
                massa = None
            por_ik[ik_p] = {
                "cid": p.get("CID"),
                "titulo": (p.get("Title") or "").strip() or None,
                "iupac": p.get("IUPACName"),
                "formula": p.get("MolecularFormula"),
                "massa": massa,
                "smiles": _extrair_smiles_isomerico(p),
                "consulta_id": resp.consulta_id,
            }
        for ik in fatia:
            saida[ik] = (por_ik.get(ik.upper()), resp.consulta_id)
    if faltantes:
        resps_ind = cli.get_varios(pedidos(faltantes), fonte="pubchem", tentativas=2, ignorar_erros=True)
        for ik, r in zip(faltantes, resps_ind):
            if r is not None:
                saida[ik] = (interpretar(r), r.consulta_id)
    return saida
