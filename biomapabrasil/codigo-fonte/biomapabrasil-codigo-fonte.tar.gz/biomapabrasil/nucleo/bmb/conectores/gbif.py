# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""GBIF: resolução de nomes, distribuição agregada por UF, imagens licenciadas e status IUCN.

Distribuição NUNCA sai daqui como coordenada: só contagem por unidade federativa. A distribuição
conhecida de uma espécie não comprova a procedência do material de um estudo.

Cada operação tem um par `pedido_*` / `interpretar_*`, para que o construtor possa buscar centenas
de nomes em paralelo (`Cliente.get_varios`) e interpretar depois, no fio principal.
"""
import re

from .. import config

API = "https://api.gbif.org/v1"

# GID do GADM nível 1 -> sigla da UF. Extraído de plataforma/web/dados/base.js, que já foi
# conferido contra o serviço de geocodificação do GBIF. Atenção: MS = 11 e MT = 12, não o inverso.
UF_GADM = {
    "BRA.1_1": "AC", "BRA.2_1": "AL", "BRA.3_1": "AP", "BRA.4_1": "AM", "BRA.5_1": "BA", "BRA.6_1": "CE",
    "BRA.7_1": "DF", "BRA.8_1": "ES", "BRA.9_1": "GO", "BRA.10_1": "MA", "BRA.11_1": "MS", "BRA.12_1": "MT",
    "BRA.13_1": "MG", "BRA.14_1": "PA", "BRA.15_1": "PB", "BRA.16_1": "PR", "BRA.17_1": "PE", "BRA.18_1": "PI",
    "BRA.19_1": "RJ", "BRA.20_1": "RN", "BRA.21_1": "RS", "BRA.22_1": "RO", "BRA.23_1": "RR", "BRA.24_1": "SC",
    "BRA.25_1": "SP", "BRA.26_1": "SE", "BRA.27_1": "TO",
}

REINO_POR_GRUPO = {"planta": "Plantae", "fungo": "Fungi", "animal_peconhento": "Animalia"}
RANKS_INFRA = ("SUBSPECIES", "VARIETY", "FORM", "INFRASPECIFIC_NAME", "INFRASUBSPECIFIC_NAME")


# ───────────────────────── resolução de nomes ─────────────────────────
def pedido_match(nome, reino=None):
    return (f"{API}/species/match", {"name": nome, "kingdom": reino, "strict": "false"})


def interpretar_match(resp):
    """Resolve um nome para o uso ACEITO do backbone. Dict, ou None se não houver correspondência."""
    d = resp.dados
    if not isinstance(d, dict) or d.get("matchType") in (None, "NONE"):
        return None
    chave = d.get("acceptedUsageKey") or d.get("usageKey")
    if chave is None:
        return None
    rank = d.get("rank")
    infra = rank in RANKS_INFRA
    # O projeto trabalha no nível de espécie: um nome infraespecífico sobe para a espécie.
    if infra and d.get("speciesKey"):
        chave = d["speciesKey"]
    return {
        "chave_aceita": chave, "chave_consultada": d.get("usageKey"), "rank": rank, "subiu_para_especie": infra,
        "tipo_correspondencia": d.get("matchType"), "confianca": d.get("confidence"),
        "status": d.get("status"), "nome_consultado": d.get("scientificName"), "reino": d.get("kingdom"),
        "foi_sinonimo": bool(d.get("acceptedUsageKey")), "consulta_id": resp.consulta_id}


def correspondencia_aceitavel(m, reino_esperado=None):
    """Critério para aceitar uma correspondência de nome. Devolve (aceita, motivo_da_rejeição)."""
    if m is None:
        return False, "sem correspondência no backbone do GBIF"
    if m["tipo_correspondencia"] == "HIGHERRANK":
        return False, "só casou com um nível taxonômico superior (gênero ou acima)"
    if m["tipo_correspondencia"] == "FUZZY" and (m.get("confianca") or 0) < 95:
        return False, f"correspondência aproximada com confiança {m.get('confianca')}"
    if reino_esperado and m.get("reino") and m["reino"] != reino_esperado:
        return False, f"reino {m['reino']} diferente do esperado ({reino_esperado})"
    return True, None


def casar_nome(cli, nome, reino=None):
    url, params = pedido_match(nome, reino)
    return interpretar_match(cli.get(url, params, fonte="gbif"))


def pedido_detalhes(chave):
    return (f"{API}/species/{chave}", None)


def interpretar_detalhes(resp):
    d = resp.dados
    if not isinstance(d, dict) or "key" not in d:
        return None
    return {
        "gbif_key": d["key"], "nome": d.get("canonicalName") or d.get("scientificName"),
        "autoria": d.get("authorship"), "rank": d.get("rank"), "status": d.get("taxonomicStatus"),
        "reino": d.get("kingdom"), "filo": d.get("phylum"), "classe": d.get("class"), "ordem": d.get("order"),
        "familia": d.get("family"), "genero": d.get("genus"), "consulta_id": resp.consulta_id}


def detalhes(cli, chave):
    url, params = pedido_detalhes(chave)
    return interpretar_detalhes(cli.get(url, params, fonte="gbif"))


def pedido_nomes_populares(chave):
    return (f"{API}/species/{chave}/vernacularNames", {"limit": 200})


def interpretar_nomes_populares(resp, idiomas=("por",)):
    contagem, original = {}, {}
    dados = resp.dados if (resp is not None and isinstance(resp.dados, dict)) else {}
    for v in dados.get("results", []):
        if v.get("language") in idiomas:
            nome = (v.get("vernacularName") or "").strip()
            if nome:
                k = nome.lower()
                contagem[k] = contagem.get(k, 0) + 1
                original.setdefault(k, (nome, v.get("language")))
    ordem = sorted(contagem, key=lambda k: (-contagem[k], len(k), k))
    return [{"nome": original[k][0], "idioma": original[k][1]} for k in ordem]


def nomes_populares(cli, chave, idiomas=("por",)):
    """Nomes populares nos idiomas pedidos, os mais repetidos entre as fontes do GBIF primeiro."""
    url, params = pedido_nomes_populares(chave)
    r = cli.get(url, params, fonte="gbif")
    return interpretar_nomes_populares(r, idiomas=idiomas)


STATUS_SINONIMO_EXCLUIDO = {"PROPARTE_SYNONYM", "DOUBTFUL", "MISAPPLIED"}
PADRAO_ESPECIME_MORTO = re.compile(
    r"\b(dead|mort[oa]s?|atropelad[oa]s?|roadkill|cad[aá]ver|carca[cç]a|carcass|crushed|esmagad[oa])\b",
    re.IGNORECASE,
)


def pedido_sinonimos(chave, maximo=60):
    return (f"{API}/species/{chave}/synonyms", {"limit": maximo})


def interpretar_sinonimos(resp):
    dados = resp.dados if (resp is not None and isinstance(resp.dados, dict)) else {}
    resultados = dados.get("results", [])
    canonicos_excluidos = {
        (s.get("canonicalName") or "").strip().lower()
        for s in resultados
        if (s.get("taxonomicStatus") or "").upper() in STATUS_SINONIMO_EXCLUIDO
    }
    nomes = []
    for s in resultados:
        if (s.get("taxonomicStatus") or "").upper() in STATUS_SINONIMO_EXCLUIDO:
            continue
        n = (s.get("canonicalName") or "").strip()
        if not n or n.lower() in canonicos_excluidos:
            continue
        if n not in nomes and len(n.split()) >= 2:
            nomes.append(n)
    return nomes


def sinonimos(cli, chave, maximo=60):
    """Nomes que o backbone do GBIF trata como sinônimos unívocos do uso aceito.

    Exclui `PROPARTE_SYNONYM`, `DOUBTFUL` e `MISAPPLIED` — inclusive quando o GBIF gera uma entrada-irmã
    `EX_AUTHOR_SYNONYM` com o mesmo `canonicalName` sem o *ex*-autor — pois sinônimos *pro parte* ou
    homônimos posteriores pertencem simultaneamente a outro táxon aceito (p.ex. *Justicia procumbens*
    asiática vs. *Dianthera pectoralis*) e contaminariam o casamento fitoquímico sem autoria no LOTUS.
    """
    url, params = pedido_sinonimos(chave, maximo=maximo)
    r = cli.get(url, params, fonte="gbif")
    return interpretar_sinonimos(r)


# ───────────────────────── distribuição ─────────────────────────
def pedido_distribuicao(chave):
    return (f"{API}/occurrence/search", {
        "taxonKey": chave, "country": "BR", "occurrenceStatus": "PRESENT", "limit": 0,
        "facet": "gadmLevel1Gid", "facetLimit": 40})


def interpretar_distribuicao(resp):
    """Contagens do Brasil por UF. n_br inclui os registros SEM UF (declarados, não escondidos)."""
    d = resp.dados
    if not isinstance(d, dict) or "count" not in d:
        return None
    por_uf = {}
    for f in d.get("facets", []):
        for c in f.get("counts", []):
            sigla = UF_GADM.get(c["name"])
            if sigla:
                por_uf[sigla] = c["count"]
    n_br = d.get("count", 0)
    com_uf = sum(por_uf.values())
    n_al = sum(n for uf, n in por_uf.items() if uf in config.UF_AMAZONIA_LEGAL)
    return {"n_br": n_br, "n_al": n_al, "por_uf": por_uf, "com_uf": com_uf, "sem_uf": n_br - com_uf,
            "consulta_id": resp.consulta_id, "consultado_em": resp.consultado_em}


def distribuicao(cli, chave):
    url, params = pedido_distribuicao(chave)
    return interpretar_distribuicao(cli.get(url, params, fonte="gbif"))


def decidir_recorte(dist, data_consulta):
    """Aplica a regra do recorte amazônico aos números. Devolve dict com as colunas derivadas.

    Duas bases, ambas declaradas: (1) só registros com UF atribuída; (2) todos os registros do Brasil.
    A base (2) é sempre a menor fração. O predomínio só é afirmado quando as DUAS bases concordam.
    """
    n_br, n_al, com_uf = dist["n_br"], dist["n_al"], dist["com_uf"]
    f1 = (n_al / com_uf) if com_uf else None
    f2 = (n_al / n_br) if n_br else None
    dentro = n_al >= config.N_AL_MIN
    if f1 is None:
        predominio = "indeterminado"
    elif f1 < config.FRACAO_AL_PREDOMINANTE:
        predominio = "nao_predominante"
    elif f2 is not None and f2 >= config.FRACAO_AL_PREDOMINANTE:
        predominio = "predominante"
    else:
        predominio = "indeterminado"
    pct = lambda x: "—" if x is None else f"{round(100 * x)}%"
    milhar = lambda n: f"{n:,}".replace(",", ".")
    sem_uf = dist["sem_uf"]
    partes = [
        ("Dentro do recorte" if dentro else "Fora do recorte") +
        f": {milhar(n_al)} registro(s) do GBIF na Amazônia Legal (mínimo exigido: {config.N_AL_MIN}).",
        f"Dos {milhar(com_uf)} registro(s) brasileiros com UF atribuída, {pct(f1)} estão na Amazônia Legal.",
        f"{milhar(sem_uf)} registro(s) do Brasil não têm UF e ficam fora dessa conta; contando-os, a fração cai para {pct(f2)}.",
        {"predominante": "Predomínio amazônico: sim, nas duas bases.",
         "nao_predominante": "Predomínio amazônico: não, nem mesmo só entre os registros com UF.",
         "indeterminado": "Predomínio amazônico: indeterminado, depende da base usada."}[predominio],
        f"Consulta ao GBIF em {data_consulta[:10]}. Distribuição conhecida não comprova a procedência de nenhum estudo."]
    return {"no_recorte": 1 if dentro else 0, "predominio_al": predominio, "fracao_al_com_uf": f1,
            "fracao_al_total": f2, "motivo_recorte": " ".join(partes)}


# ───────────────────────── conservação e imagens ─────────────────────────
def pedido_iucn(chave):
    return (f"{API}/species/{chave}/iucnRedListCategory", None)


def interpretar_iucn(resp):
    if resp is None:
        return {"categoria": None, "consulta_id": None}
    d = resp.dados
    if isinstance(d, dict) and d.get("code"):
        return {"categoria": d["code"], "consulta_id": resp.consulta_id}
    return {"categoria": None, "consulta_id": resp.consulta_id}


def iucn(cli, chave):
    url, params = pedido_iucn(chave)
    r = cli.get(url, params, fonte="gbif")
    return interpretar_iucn(r)


def _pontuar_candidata_midia(c, oc, m):
    """Prioriza registros brasileiros, curados e com URL de boa resolução antes do download."""
    url = (c["url"] or "").lower()
    penalidade_url = 1 if re.search(r"/(square|thumb|small)\.(jpe?g|png)(\?|$)", url) else 0
    grau_pesquisa = 1 if "research-grade" in (c["instituicao"] or "").lower() else 0
    tem_dim_boa = 1 if (m.get("width") or 0) >= 640 and (m.get("height") or 0) >= 420 else 0
    prop_ok = 0
    if m.get("width") and m.get("height"):
        p = m["width"] / max(m["height"], 1)
        prop_ok = 1 if 0.78 <= p <= 1.85 else (-1 if p < 0.58 or p > 2.2 else 0)
    return (not c["brasil"], penalidade_url, -prop_ok, -tem_dim_boa, -grau_pesquisa)


def _extrair_candidatas_midia(resp):
    d = resp.dados if isinstance(resp.dados, dict) else {}
    candidatas = []
    for oc in d.get("results", []):
        if (oc.get("vitality") or "").strip().lower() == "dead":
            continue
        if (oc.get("degreeOfEstablishment") or "").strip().lower() in ("captive", "cultivated"):
            continue
        obs = f"{oc.get('occurrenceRemarks') or ''} {oc.get('dynamicProperties') or ''}"
        if PADRAO_ESPECIME_MORTO.search(obs):
            continue
        for m in oc.get("media", []):
            lic = config.normalizar_licenca(m.get("license"))
            if lic not in config.LICENCAS_IMAGEM_OK:
                continue
            url = m.get("identifier")
            if not url or m.get("type") != "StillImage":
                continue
            autor = (m.get("creator") or m.get("rightsHolder") or "").strip() or None
            if autor is None:
                continue  # Princípio 3: sem autor identificável, a imagem não entra
            pais = (oc.get("countryCode") or "").strip().upper() or None
            item = {
                "url": url, "licenca": lic, "autor": autor,
                "instituicao": oc.get("institutionCode") or oc.get("datasetName"),
                "pagina": f"https://www.gbif.org/occurrence/{oc.get('key')}", "gbif_ocorrencia": str(oc.get("key")),
                "base_registro": oc.get("basisOfRecord"), "brasil": pais == "BR", "pais": pais,
                "consulta_id": resp.consulta_id}
            candidatas.append((_pontuar_candidata_midia(item, oc, m), item))
    return candidatas


def imagens(cli, chave, maximo=3):
    """Fotos com licença CC0 ou CC BY (Princípio 3), buscando primeiro registros no Brasil (`country=BR`)."""
    r_br = cli.get(f"{API}/occurrence/search", {
        "taxonKey": chave, "country": "BR", "mediaType": "StillImage", "occurrenceStatus": "PRESENT", "limit": 80,
        "basisOfRecord": "HUMAN_OBSERVATION"}, fonte="gbif")
    candidatas = _extrair_candidatas_midia(r_br)
    autores_br = {c["autor"] for _, c in candidatas}
    if len(autores_br) < maximo:
        r_gl = cli.get(f"{API}/occurrence/search", {
            "taxonKey": chave, "mediaType": "StillImage", "occurrenceStatus": "PRESENT", "limit": 120,
            "basisOfRecord": "HUMAN_OBSERVATION"}, fonte="gbif")
        urls_ja = {c["url"] for _, c in candidatas}
        for par in _extrair_candidatas_midia(r_gl):
            if par[1]["url"] not in urls_ja:
                candidatas.append(par)
                urls_ja.add(par[1]["url"])
    # Preferência: registros do Brasil, boa proporção/resolução e curadoria; sem repetir autor.
    candidatas.sort(key=lambda par: par[0])
    saida, autores = [], set()
    for _, c in candidatas:
        if c["autor"] in autores:
            continue
        autores.add(c["autor"])
        saida.append(c)
        if len(saida) >= maximo:
            break
    return saida
