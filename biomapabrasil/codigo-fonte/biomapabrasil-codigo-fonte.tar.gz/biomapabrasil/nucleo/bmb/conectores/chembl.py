# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""ChEMBL (CC BY-SA 3.0): atividade medida de uma molécula, e o que se sabe de fármacos aprovados.

Duas leituras que NÃO se misturam:
  * atividade medida  -> descreve a MOLÉCULA PURA em um ensaio (valor, alvo, sistema, publicação);
  * efeito clínico    -> descreve o FÁRMACO aprovado, jamais o organismo de onde a molécula foi isolada.
Nenhuma das duas diz que o organismo, o extrato ou a planta têm esse efeito.
"""
API = "https://www.ebi.ac.uk/chembl/api/data"

# O ChEMBL registra medidas cujo alvo ainda não foi curado com nomes provisórios. Uma medida sem alvo biológico atribuído não
# informa ação sobre alvo algum; ela não vira afirmação (e não aparece na tela como se tivesse alvo).
ALVOS_SEM_ATRIBUICAO = {
    "unchecked", "unknown", "no relevant target", "non-molecular target",
    "non-protein target", "molecular identity unknown", "unspecified",
}

# Tipos de medida que expressam potência de forma comparável (ChEMBL já converte para pChEMBL).
TIPOS_PADRAO = ("IC50", "EC50", "Ki", "Kd", "AC50", "XC50", "ED50", "MIC", "GI50")


def _fase(valor):
    try:
        return float(valor) if valor is not None else None
    except (TypeError, ValueError):
        return None


def pedido_molecula(inchikey):
    return (f"{API}/molecule.json", {"molecule_structures__standard_inchi_key": inchikey})


def interpretar_molecula(resp):
    """Molécula do ChEMBL a partir da resposta de `pedido_molecula`, ou None se não existir."""
    d = resp.dados if isinstance(resp.dados, dict) else {}
    ms = d.get("molecules") or []
    if not ms:
        return None
    m = ms[0]
    return {"chembl_id": m["molecule_chembl_id"], "nome": (m.get("pref_name") or "").strip() or None,
            "max_fase": _fase(m.get("max_phase")), "tipo": m.get("molecule_type"),
            "produto_natural": m.get("natural_product"), "primeira_aprovacao": m.get("first_approval"),
            "retirado": bool(m.get("withdrawn_flag")), "caixa_preta": bool(m.get("black_box_warning")),
            "consulta_id": resp.consulta_id}


def atividades(cli, chembl_id, maximo=6):
    """Até `maximo` medidas de potência, de alvos distintos, em ordem decrescente de pChEMBL.

    Filtros de qualidade: relação exata ("="), sem comentário de validade, sem duplicata potencial.
    Devolve (lista, consulta_id). A medida vem como o ChEMBL a registra; nada é recalculado.
    """
    r = cli.get(f"{API}/activity.json", {
        "molecule_chembl_id": chembl_id, "pchembl_value__isnull": "false", "limit": 60,
        "order_by": "-pchembl_value"}, fonte="chembl")
    dados = r.dados if isinstance(r.dados, dict) else {}
    vistos, saida = set(), []
    for a in dados.get("activities") or []:
        if a.get("standard_relation") != "=" or a.get("data_validity_comment") or a.get("potential_duplicate"):
            continue
        if a.get("standard_type") not in TIPOS_PADRAO or not a.get("target_chembl_id"):
            continue
        if (a.get("target_pref_name") or "").strip().lower() in ALVOS_SEM_ATRIBUICAO:
            continue
        chave = (a["target_chembl_id"], a["standard_type"])
        if chave in vistos:
            continue
        vistos.add(chave)
        try:
            valor = float(a["standard_value"]) if a.get("standard_value") is not None else None
            pchembl = float(a["pchembl_value"]) if a.get("pchembl_value") is not None else None
        except (TypeError, ValueError):
            continue
        saida.append({
            "activity_id": a["activity_id"], "alvo_chembl_id": a["target_chembl_id"],
            "alvo_nome": a.get("target_pref_name"), "alvo_organismo": a.get("target_organism"),
            "tipo_alvo": a.get("target_type") or a.get("bao_label"),
            "formato_ensaio": a.get("bao_label"),
            "medida_tipo": a["standard_type"], "relacao": a["standard_relation"],
            "valor": valor, "unidade": a.get("standard_units"), "pchembl": pchembl,
            "ensaio_tipo": a.get("assay_type"), "ensaio_descricao": a.get("assay_description"),
            "documento": a.get("document_chembl_id"), "revista": a.get("document_journal"),
            "ano": a.get("document_year")})
        if len(saida) >= maximo:
            break
    return saida, r.consulta_id


def documentos(cli, ids):
    """{document_chembl_id: {doi, pmid, titulo, revista, ano}} para um lote de documentos."""
    ids = sorted({i for i in ids if i})
    saida = {}
    for i in range(0, len(ids), 40):
        lote = ids[i:i + 40]
        r = cli.get(f"{API}/document.json", {"document_chembl_id__in": ",".join(lote), "limit": 100}, fonte="chembl")
        for d in (r.dados.get("documents") or []) if isinstance(r.dados, dict) else []:
            saida[d["document_chembl_id"]] = {
                "doi": (d.get("doi") or "").strip().lower() or None, "pmid": str(d["pubmed_id"]) if d.get("pubmed_id") else None,
                "titulo": d.get("title"), "revista": d.get("journal"), "ano": d.get("year"),
                "consulta_id": r.consulta_id}
    return saida


def clinico(cli, chembl_id):
    """Mecanismo e indicações de um fármaco aprovado (fase 4). Devolve dict ou None."""
    rm = cli.get(f"{API}/mechanism.json", {"molecule_chembl_id": chembl_id, "limit": 20}, fonte="chembl")
    ri = cli.get(f"{API}/drug_indication.json", {"molecule_chembl_id": chembl_id, "limit": 100}, fonte="chembl")
    mecanismos, indicacoes = [], []
    for m in (rm.dados.get("mechanisms") or []) if isinstance(rm.dados, dict) else []:
        mec_txt = (m.get("mechanism_of_action") or "").strip()
        if mec_txt and mec_txt.lower() not in ("unknown", "unspecified", "n/a", "none"):
            mecanismos.append({"texto": mec_txt, "acao": m.get("action_type"),
                               "alvo_chembl_id": m.get("target_chembl_id"),
                               "referencias": [{"tipo": x.get("ref_type"), "id": x.get("ref_id"), "url": x.get("ref_url")}
                                               for x in m.get("mechanism_refs") or []]})
    for i in (ri.dados.get("drug_indications") or []) if isinstance(ri.dados, dict) else []:
        termo = i.get("efo_term") or i.get("mesh_heading")
        fase = _fase(i.get("max_phase_for_ind"))
        if termo and fase is not None and fase >= 4:
            indicacoes.append({"termo": termo, "mesh_id": i.get("mesh_id"), "efo_id": i.get("efo_id"),
                               "referencias": [{"tipo": x.get("ref_type"), "id": x.get("ref_id"), "url": x.get("ref_url")}
                                               for x in i.get("indication_refs") or []]})
    if not mecanismos and not indicacoes:
        return None
    # remove termos repetidos preservando a ordem
    vistos, unicas = set(), []
    for i in indicacoes:
        if i["termo"].lower() not in vistos:
            vistos.add(i["termo"].lower())
            unicas.append(i)
    return {"mecanismos": mecanismos, "indicacoes": unicas, "consulta_id": ri.consulta_id,
            "consulta_mecanismo_id": rm.consulta_id}


def moleculas_em_lote(cli, inchikeys, tamanho_lote=40):
    """Consulta ChEMBL `molecule.json` com filtro `__in` (`40` InChIKeys/GET), devolvendo `{ik: (dict_ou_None, consulta_id)}`."""
    iks = [k for k in dict.fromkeys(inchikeys) if k]
    if not iks:
        return {}
    fatias = [iks[i:i + tamanho_lote] for i in range(0, len(iks), tamanho_lote)]
    pedidos_lote = [
        (f"{API}/molecule.json", {"molecule_structures__standard_inchi_key__in": ",".join(f), "limit": 100})
        for f in fatias
    ]
    resps = cli.get_varios(pedidos_lote, fonte="chembl", tentativas=2, ignorar_erros=True)
    saida = {}
    for fatia, resp in zip(fatias, resps):
        if resp is None or not isinstance(resp.dados, dict):
            continue
        por_ik = {}
        for m in resp.dados.get("molecules") or []:
            ik_m = ((m.get("molecule_structures") or {}).get("standard_inchi_key") or "").strip().upper()
            if not ik_m or ik_m in por_ik:
                continue
            por_ik[ik_m] = {
                "chembl_id": m["molecule_chembl_id"],
                "nome": (m.get("pref_name") or "").strip() or None,
                "max_fase": _fase(m.get("max_phase")),
                "tipo": m.get("molecule_type"),
                "produto_natural": m.get("natural_product"),
                "primeira_aprovacao": m.get("first_approval"),
                "retirado": bool(m.get("withdrawn_flag")),
                "caixa_preta": bool(m.get("black_box_warning")),
                "consulta_id": resp.consulta_id,
            }
        for ik in fatia:
            saida[ik] = (por_ik.get(ik.upper()), resp.consulta_id)
    return saida


def _filtrar_lista_atividades(lista_bruta, maximo):
    vistos, saida = set(), []
    # Ordena explicitamente por pChEMBL decrescente
    def _ord(item):
        try:
            return -float(item.get("pchembl_value") or 0.0)
        except (TypeError, ValueError):
            return 0.0

    for a in sorted(lista_bruta, key=_ord):
        if a.get("standard_relation") != "=" or a.get("data_validity_comment") or a.get("potential_duplicate"):
            continue
        if a.get("standard_type") not in TIPOS_PADRAO or not a.get("target_chembl_id"):
            continue
        if (a.get("target_pref_name") or "").strip().lower() in ALVOS_SEM_ATRIBUICAO:
            continue
        chave = (a["target_chembl_id"], a["standard_type"])
        if chave in vistos:
            continue
        vistos.add(chave)
        try:
            valor = float(a["standard_value"]) if a.get("standard_value") is not None else None
            pchembl = float(a["pchembl_value"]) if a.get("pchembl_value") is not None else None
        except (TypeError, ValueError):
            continue
        saida.append({
            "activity_id": a["activity_id"], "alvo_chembl_id": a["target_chembl_id"],
            "alvo_nome": a.get("target_pref_name"), "alvo_organismo": a.get("target_organism"),
            "tipo_alvo": a.get("target_type") or a.get("bao_label"),
            "formato_ensaio": a.get("bao_label"),
            "medida_tipo": a["standard_type"], "relacao": a["standard_relation"],
            "valor": valor, "unidade": a.get("standard_units"), "pchembl": pchembl,
            "ensaio_tipo": a.get("assay_type"), "ensaio_descricao": a.get("assay_description"),
            "documento": a.get("document_chembl_id"), "revista": a.get("document_journal"),
            "ano": a.get("document_year"),
        })
        if len(saida) >= maximo:
            break
    return saida


def atividades_em_lote(cli, chembl_ids, maximo_por_mol=5, tamanho_lote=20):
    """Consulta atividades de potência em lotes (`molecule_chembl_id__in`), com fallback individual quando o lote satura."""
    cids = [c for c in dict.fromkeys(chembl_ids) if c]
    if not cids:
        return {}
    fatias = [cids[i:i + tamanho_lote] for i in range(0, len(cids), tamanho_lote)]
    pedidos_lote = [
        (f"{API}/activity.json", {
            "molecule_chembl_id__in": ",".join(f),
            "pchembl_value__isnull": "false",
            "limit": 1000,
            "order_by": "-pchembl_value",
        })
        for f in fatias
    ]
    resps = cli.get_varios(pedidos_lote, fonte="chembl", tentativas=2, ignorar_erros=True)
    saida = {}
    individuais = []
    for fatia, resp in zip(fatias, resps):
        if resp is None or not isinstance(resp.dados, dict):
            individuais.extend(fatia)
            continue
        acts = resp.dados.get("activities") or []
        page_meta = resp.dados.get("page_meta") or {}
        if len(acts) >= 990 or (page_meta.get("total_count") or 0) > 1000:
            # Lote denso (ex.: fármacos hiper-estudados): consulta individualmente para não truncar nenhuma molécula
            individuais.extend(fatia)
            continue
        agrup = {}
        for a in acts:
            mc = a.get("molecule_chembl_id")
            if mc:
                agrup.setdefault(mc, []).append(a)
        for mc in fatia:
            saida[mc] = (_filtrar_lista_atividades(agrup.get(mc, []), maximo_por_mol), resp.consulta_id)
    for mc in individuais:
        try:
            saida[mc] = atividades(cli, mc, maximo=maximo_por_mol)
        except Exception:
            pass
    return saida


# ───────────────────────── todas as medidas de potência (para agregação) ─────────────────────────
CAMPOS_MEDIDA = (
    "activity_id,molecule_chembl_id,target_chembl_id,target_pref_name,target_organism,standard_type,standard_relation,"
    "standard_value,standard_units,pchembl_value,data_validity_comment,potential_duplicate,activity_comment,"
    "assay_chembl_id,assay_type,assay_description,bao_label,assay_variant_mutation,document_chembl_id,document_year"
)


def _paginas_de_medidas(cli, filtro, por_pagina=1000, max_paginas=400):
    """Percorre `activity.json` em ordem estável de `activity_id` até o fim. Devolve (medidas, consulta_ids, completo)."""
    medidas, consultas, offset = [], [], 0
    for _ in range(max_paginas):
        r = cli.get(f"{API}/activity.json", {**filtro, "pchembl_value__isnull": "false", "only": CAMPOS_MEDIDA,
                                              "order_by": "activity_id", "limit": por_pagina, "offset": offset},
                    fonte="chembl", tentativas=4)
        dados = r.dados if isinstance(r.dados, dict) else {}
        lote = dados.get("activities") or []
        medidas.extend(lote)
        consultas.append(r.consulta_id)
        if not (dados.get("page_meta") or {}).get("next") or not lote:
            return medidas, consultas, True
        offset += por_pagina
    return medidas, consultas, False


def medidas_de_potencia(cli, chembl_ids, tamanho_lote=15, log=None):
    """TODAS as medidas com pChEMBL de cada molécula (não só as mais potentes): `{chembl_id: (medidas, consulta_id)}`.

    Molécula cujo lote falhou ou ficou incompleto não aparece no resultado, e a etapa a deixa pendente em vez de
    agregar sobre dados parciais.
    """
    cids = [c for c in dict.fromkeys(chembl_ids) if c]
    saida = {}
    for n, ini in enumerate(range(0, len(cids), tamanho_lote), 1):
        fatia = cids[ini:ini + tamanho_lote]
        try:
            medidas, consultas, completo = _paginas_de_medidas(cli, {"molecule_chembl_id__in": ",".join(fatia)})
        except Exception:
            continue
        if not completo:
            continue
        por_mol = {c: [] for c in fatia}
        for a in medidas:
            if a.get("molecule_chembl_id") in por_mol:
                por_mol[a["molecule_chembl_id"]].append(a)
        for c in fatia:
            saida[c] = (por_mol[c], consultas[0])
        if log and n % 20 == 0:
            log(f"    ChEMBL medidas: {min(ini + tamanho_lote, len(cids))}/{len(cids)} moléculas")
    return saida


# Natureza do alvo a partir de `target_type` do ChEMBL. Só «proteina_unica» é alvo molecular individual.
NATUREZA_DO_ALVO = {
    "SINGLE PROTEIN": "proteina_unica",
    "PROTEIN COMPLEX": "complexo_proteico", "PROTEIN COMPLEX GROUP": "complexo_proteico",
    "PROTEIN-PROTEIN INTERACTION": "complexo_proteico", "PROTEIN NUCLEIC-ACID COMPLEX": "complexo_proteico",
    "CHIMERIC PROTEIN": "complexo_proteico",
    "PROTEIN FAMILY": "familia_proteica", "SELECTIVITY GROUP": "familia_proteica",
    "CELL-LINE": "linhagem_celular", "3D CELL CULTURE": "linhagem_celular",
    "ORGANISM": "organismo", "TISSUE": "tecido", "SUBCELLULAR": "fracao_subcelular",
    "NUCLEIC-ACID": "acido_nucleico", "ADMET": "admet",
    "NON-MOLECULAR": "nao_molecular", "PHENOTYPE": "nao_molecular", "NO TARGET": "nao_molecular",
}


def natureza_do_alvo(tipo_chembl):
    return NATUREZA_DO_ALVO.get((tipo_chembl or "").strip().upper(), "indeterminado")
