# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Hidrografia amazônica, recorte ecológico (Bioma Amazônia + 44°W), lacunas rastreáveis e altimetria métrica.

Resolve quatro problemas científicos e de proveniência:
  1. Distingue a **Amazônia Legal administrativa** (9 UFs) do **Bioma Amazônia ecológico** e do limite
     legal de **44°W no Maranhão** (Lei Complementar nº 124/2007), consultando o GBIF por geometria WKT
     em lotes facetados (`facet=speciesKey`) com `consulta_id` gravado no SQLite.
  2. Agrega ocorrências do GBIF nas **9 grandes sub-bacias hidrográficas amazônicas** (`bacia_hidrografica`
     e `ocorrencia_bacia`), permitindo alternar o mapa entre estados e bacias (*Rio do Conhecimento* v2).
  3. Substitui a grade estática do protótipo por `celula_lacuna` no SQLite: cada uma das `1.648` células
     de `0,5°` consulta o GBIF com `gbif_consulta_id` próprio e cruza com os rasters oficiais do INPE
     TerraBrasilis (PRODES desmatamento acumulado + anual) e MMA CNUC / FUNAI (Unidades de Conservação e
     Terras Indígenas) para compor a matriz bivariada $3 \times 3$ (*Lacuna de Amostragem × Pressão*).
  4. Gera a malha altimétrica métrica calibrada (`altimetria_m.webp`, lossless 16 bits em metros reais)
     a partir dos tiles físicos Mapzen/AWS Terrarium (`z=6`), separando o relevo artístico PBR da leitura
     hipsométrica rigorosa em metros sobre o nível do mar (`m a.n.m.`).
"""
import io
import json
import math
import re
from pathlib import Path

import numpy as np

from .. import config, projecao
from . import geometrias_oficiais as go

API_GBIF = "https://api.gbif.org/v1"
RAIO_TERRA_KM = 6371.0088

_LIM_OFICIAIS = go.carregar_limites_oficiais()
POLIGONO_BIOMA_AMAZONIA_WKT = _LIM_OFICIAIS["bioma_amazonia"]["wkt_gbif"]
POLIGONO_AMAZONIA_LEGAL_WKT = _LIM_OFICIAIS["amazonia_legal"]["wkt_gbif"]
POLIGONO_MA_OESTE44_WKT = "POLYGON((-48.80 -10.30, -44.00 -10.30, -44.00 -1.00, -48.80 -1.00, -48.80 -10.30))"

BACIAS_AMAZONICAS = [
    {
        "id": b["id"],
        "nome": b["nome"],
        "rio_principal": b["rio_principal"],
        "cor_hex": b["cor_hex"],
        "area_km2": b["area_km2"],
        "wkt_gbif": b["wkt_gbif"],
        "anel": [tuple(pt) for pt in b["anel"]],
        "aneis_display": b["aneis_display"],
        "rep_lon": b["rep_lon"],
        "rep_lat": b["rep_lat"],
        "pfaf_ids_l5": b.get("pfaf_ids_l5", []),
    }
    for b in _LIM_OFICIAIS["bacias"]
]


def _anel_para_wkt(anel):
    pts = list(anel)
    if pts[0] != pts[-1]:
        pts.append(pts[0])
    return "POLYGON((" + ", ".join(f"{lon:.3f} {lat:.3f}" for lon, lat in pts) + "))"


def _area_esferica_poligono_km2(anel):
    """Área geodésica exata sobre o elipsoide GRS80 / SIRGAS 2000 (km²)."""
    pts = list(anel)
    if len(pts) < 3:
        return 0.0
    if pts[0] != pts[-1]:
        pts.append(pts[0])
    lons = [p[0] for p in pts]
    lats = [p[1] for p in pts]
    area_m2, _ = go.GEOD_GRS80.polygon_area_perimeter(lons, lats)
    return round(abs(area_m2) / 1e6, 1)


def anel_para_svg_d(anel):
    pts = [projecao.proj(lon, lat) for lon, lat in anel]
    return "M" + "L".join(f"{x:.1f},{y:.1f}" for x, y in pts) + "Z"


def ponto_em_poligono(lon, lat, anel):
    dentro = False
    n = len(anel)
    j = n - 1
    for i in range(n):
        xi, yi = anel[i]
        xj, yj = anel[j]
        if ((yi > lat) != (yj > lat)) and (lon < (xj - xi) * (lat - yi) / ((yj - yi) or 1e-12) + xi):
            dentro = not dentro
        j = i
    return dentro


def bacia_da_celula(lon, lat):
    return go.bacia_do_ponto(lon, lat)


def registrar_bacias(con):
    for b in BACIAS_AMAZONICAS:
        wkt = b.get("wkt_gbif") or _anel_para_wkt(b["anel"])
        area = b.get("area_km2") or _area_esferica_poligono_km2(b["anel"])
        con.execute(
            "INSERT INTO bacia_hidrografica (id, nome, rio_principal, area_km2, poligono_wkt, cor_hex) "
            "VALUES (?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET nome=excluded.nome, rio_principal=excluded.rio_principal, "
            "area_km2=excluded.area_km2, poligono_wkt=excluded.poligono_wkt, cor_hex=excluded.cor_hex",
            (b["id"], b["nome"], b["rio_principal"], area, wkt, b["cor_hex"]),
        )
    con.commit()


def _contar_por_geometria_em_lote(cli, gbif_keys, wkt, gadm_gid=None):
    """Consulta o GBIF em lotes paralelos de 45 `taxonKey`s com `facet=speciesKey`, devolvendo `{gbif_key: (n, consulta_id)}`."""
    saida = {}
    fatias = [[int(k) for k in gbif_keys[i:i + 45]] for i in range(0, len(gbif_keys), 45)]
    if not fatias:
        return saida
    pedidos = []
    for lote in fatias:
        params = [
            ("country", "BR"),
            ("occurrenceStatus", "PRESENT"),
            ("limit", "0"),
            ("geometry", wkt),
            ("facet", "speciesKey"),
            ("facetLimit", "200"),
        ]
        if gadm_gid:
            params.append(("gadmGid", gadm_gid))
        for k in lote:
            params.append(("taxonKey", str(k)))
        pedidos.append((f"{API_GBIF}/occurrence/search", params))
    resps = cli.get_varios(pedidos, fonte="gbif")
    for lote, r in zip(fatias, resps):
        contagens = {}
        if r is not None and isinstance(r.dados, dict):
            for fac in r.dados.get("facets", []):
                if fac.get("field") == "SPECIES_KEY":
                    for item in fac.get("counts", []):
                        if str(item.get("name", "")).isdigit():
                            contagens[int(item["name"])] = int(item["count"])
        cid = r.consulta_id if r is not None else None
        for k in lote:
            saida[k] = (contagens.get(k, 0), cid)
    return saida


def atualizar_bioma_e_bacias(con, cli, log=print):
    """Popula `n_bioma_amazonia`, `n_al_exato`, `n_ma_oeste44` e `ocorrencia_bacia` para todos os táxons no recorte."""
    registrar_bacias(con)
    taxa = con.execute("SELECT id, gbif_key FROM taxon WHERE no_recorte=1 ORDER BY id").fetchall()
    if not taxa:
        return {"taxons": 0, "bacias": len(BACIAS_AMAZONICAS)}

    chaves = [t["gbif_key"] for t in taxa]
    log(f"  Recorte geodésico oficial (Bioma Amazônia IBGE + Amazônia Legal IBGE + 9 sub-bacias HydroBASINS) para {len(chaves)} táxons…")

    cont_bioma = _contar_por_geometria_em_lote(cli, chaves, POLIGONO_BIOMA_AMAZONIA_WKT)
    cont_lamz = _contar_por_geometria_em_lote(cli, chaves, POLIGONO_AMAZONIA_LEGAL_WKT)
    cont_ma44 = _contar_por_geometria_em_lote(cli, chaves, POLIGONO_MA_OESTE44_WKT, gadm_gid="BRA.10_1")

    for t in taxa:
        nb, cid_b = cont_bioma.get(t["gbif_key"], (0, None))
        nal_ex, _ = cont_lamz.get(t["gbif_key"], (0, None))
        nm, _ = cont_ma44.get(t["gbif_key"], (0, None))
        con.execute(
            "UPDATE taxon SET n_bioma_amazonia=?, n_al_exato=?, n_ma_oeste44=?, bioma_consulta_id=? WHERE id=?",
            (nb, nal_ex, nm, cid_b, t["id"]),
        )

    n_vinculos = 0
    for b in BACIAS_AMAZONICAS:
        wkt = b.get("wkt_gbif") or _anel_para_wkt(b["anel"])
        cont_b = _contar_por_geometria_em_lote(cli, chaves, wkt)
        cid_exemplo = None
        for t in taxa:
            n_oc, cid = cont_b.get(t["gbif_key"], (0, None))
            cid_exemplo = cid_exemplo or cid
            if cid is not None:
                con.execute(
                    "INSERT INTO ocorrencia_bacia (taxon_id, bacia_id, n, consulta_id) VALUES (?,?,?,?) "
                    "ON CONFLICT(taxon_id, bacia_id) DO UPDATE SET n=excluded.n, consulta_id=excluded.consulta_id",
                    (t["id"], b["id"], n_oc, cid),
                )
                if n_oc > 0:
                    n_vinculos += 1
        if cid_exemplo:
            con.execute("UPDATE bacia_hidrografica SET consulta_id=? WHERE id=?", (cid_exemplo, b["id"]))
    con.commit()
    return {"taxons": len(taxa), "bacias": len(BACIAS_AMAZONICAS), "ocorrencias_bacia_positivas": n_vinculos}


def _carregar_rasters_pressao_e_protecao(cli, log=print):
    """Obtém rasters oficiais do INPE TerraBrasilis (PRODES + CNUC/FUNAI WMS) com SHA-256 e `consulta_id`."""
    from PIL import Image

    url_wms = "https://terrabrasilis.dpi.inpe.br/geoserver/prodes-amazon-nb/wms"
    bbox_am = (-74.5, -18.5, -43.5, 5.5)
    bbox_str = "-74.5,-18.5,-43.5,5.5"
    consulta_pressao = None

    # 1. PRODES desmatamento acumulado + anual via WMS oficial do INPE TerraBrasilis
    mask_prodes = None
    try:
        r_ac = cli.get(
            url_wms,
            {"service": "WMS", "version": "1.1.1", "request": "GetMap",
             "layers": "prodes-amazon-nb:accumulated_deforestation_2007_biome",
             "styles": "", "bbox": bbox_str, "width": "620", "height": "480",
             "srs": "EPSG:4326", "format": "image/png", "transparent": "true"},
            fonte="terrabrasilis_cnuc", accept="image/png", como_json=False, como_bytes=True, tentativas=2,
        )
        r_an = cli.get(
            url_wms,
            {"service": "WMS", "version": "1.1.1", "request": "GetMap",
             "layers": "prodes-amazon-nb:yearly_deforestation_biome",
             "styles": "", "bbox": bbox_str, "width": "620", "height": "480",
             "srs": "EPSG:4326", "format": "image/png", "transparent": "true"},
            fonte="terrabrasilis_cnuc", accept="image/png", como_json=False, como_bytes=True, tentativas=2,
        )
        consulta_pressao = consulta_pressao or r_ac.consulta_id
        arr_ac = np.asarray(Image.open(io.BytesIO(r_ac.dados)).convert("RGBA"))
        arr_an = np.asarray(Image.open(io.BytesIO(r_an.dados)).convert("RGBA"))
        mask_prodes = (arr_ac[:, :, 3] > 20) | (arr_an[:, :, 3] > 20)
    except Exception as exc:
        log(f"    aviso TerraBrasilis PRODES WMS: {exc}")

    # 2. Unidades de Conservação (CNUC) + Terras Indígenas (FUNAI) via WMS oficial TerraBrasilis
    mask_prot = None
    try:
        r_uc = cli.get(
            url_wms,
            {"service": "WMS", "version": "1.1.1", "request": "GetMap",
             "layers": "prodes-amazon-nb:conservation_units_amazon_biome",
             "styles": "", "bbox": bbox_str, "width": "620", "height": "480",
             "srs": "EPSG:4326", "format": "image/png", "transparent": "true"},
            fonte="terrabrasilis_cnuc", accept="image/png", como_json=False, como_bytes=True, tentativas=2,
        )
        r_ti = cli.get(
            url_wms,
            {"service": "WMS", "version": "1.1.1", "request": "GetMap",
             "layers": "prodes-amazon-nb:indigenous_area_amazon_biome",
             "styles": "", "bbox": bbox_str, "width": "620", "height": "480",
             "srs": "EPSG:4326", "format": "image/png", "transparent": "true"},
            fonte="terrabrasilis_cnuc", accept="image/png", como_json=False, como_bytes=True, tentativas=2,
        )
        consulta_pressao = consulta_pressao or r_uc.consulta_id
        arr_uc = np.asarray(Image.open(io.BytesIO(r_uc.dados)).convert("RGBA"))
        arr_ti = np.asarray(Image.open(io.BytesIO(r_ti.dados)).convert("RGBA"))
        mask_prot = (arr_uc[:, :, 3] > 25) | (arr_ti[:, :, 3] > 25)
    except Exception as exc:
        log(f"    aviso CNUC/FUNAI WMS: {exc}")

    return (mask_prodes, bbox_am), mask_prot, bbox_am, consulta_pressao


def _amostrar_prodes(dados_prodes, lon, lat, passo=0.5):
    if not dados_prodes or dados_prodes[0] is None:
        return None
    mask, bbox = dados_prodes
    return _amostrar_protecao(mask, bbox, lon, lat, passo)


def _amostrar_protecao(mask_prot, bbox, lon, lat, passo=0.5):
    if mask_prot is None:
        return None
    bx0, by0, bx1, by1 = bbox
    h, w = mask_prot.shape
    lon0, lon1 = lon - passo / 2.0, lon + passo / 2.0
    lat0, lat1 = lat - passo / 2.0, lat + passo / 2.0
    if lon1 < bx0 or lon0 > bx1 or lat1 < by0 or lat0 > by1:
        return 0.0
    x0 = max(0, int(((lon0 - bx0) / (bx1 - bx0)) * w))
    x1 = min(w, max(x0 + 1, int(math.ceil(((lon1 - bx0) / (bx1 - bx0)) * w))))
    y0 = max(0, int(((by1 - lat1) / (by1 - by0)) * h))
    y1 = min(h, max(y0 + 1, int(math.ceil(((by1 - lat0) / (by1 - by0)) * h))))
    rec = mask_prot[y0:y1, x0:x1]
    return round(float(np.mean(rec)), 4) if rec.size else 0.0


def _classe_bivariada(densidade_km2, pressao):
    """Matriz bivariada 3x3: G1..G3 (baixo -> alto déficit de coleta) × P1..P3 (baixa -> alta pressão PRODES)."""
    g = 3 if densidade_km2 < 0.015 else (2 if densidade_km2 < 0.12 else 1)
    if pressao is None:
        return f"G{g}_P0"
    p = 3 if pressao >= 0.30 else (2 if pressao >= 0.06 else 1)
    return f"G{g}_P{p}"


def atualizar_lacunas_sqlite(con, cli, log=print):
    """Popula `celula_lacuna` com consultas GBIF reais por célula de 0,5° + união vetorial EPSG:5880 CNUC∪FUNAI + PRODES."""
    registrar_bacias(con)
    celulas_molde = go.carregar_grade_molde_05deg()

    ja_populado = con.execute("SELECT COUNT(*) FROM celula_lacuna").fetchone()[0]
    tiles_prodes, mask_prot_wms, bbox_prot, cid_pressao = _carregar_rasters_pressao_e_protecao(cli, log)
    ind_vetorial = go.carregar_protecao_vetorial_oficial(cli, log)
    if ind_vetorial and ind_vetorial.consulta_ids and not cid_pressao:
        cid_pressao = ind_vetorial.consulta_ids[0]

    passo = 0.5
    pedidos = []
    metas = []
    for c in celulas_molde:
        lon, lat = float(c["lon"]), float(c["lat"])
        lon0, lon1 = lon - passo / 2.0, lon + passo / 2.0
        lat0, lat1 = lat - passo / 2.0, lat + passo / 2.0
        wkt = (f"POLYGON(({lon0:.4f} {lat0:.4f}, {lon1:.4f} {lat0:.4f}, "
               f"{lon1:.4f} {lat1:.4f}, {lon0:.4f} {lat1:.4f}, {lon0:.4f} {lat0:.4f}))")
        pedidos.append((f"{API_GBIF}/occurrence/search", {
            "country": "BR", "occurrenceStatus": "PRESENT", "limit": 0, "geometry": wkt,
        }))
        area_km2 = go.area_celula_05deg_km2(lon, lat, passo)
        metas.append((lon, lat, float(c["x"]), float(c["y"]), float(c["w"]), float(c["h"]), area_km2))

    log(f"  Consultando {len(pedidos)} células de 0,5° no GBIF + sobreposição geodésica {go.CRS_GEODESICO}…")
    for ini in range(0, len(pedidos), 250):
        lote_p = pedidos[ini:ini + 250]
        lote_m = metas[ini:ini + 250]
        resps = cli.get_varios(lote_p, fonte="gbif")
        for (lon, lat, x, y, w, h, area_km2), r in zip(lote_m, resps):
            n_oc = int(r.dados.get("count", 0)) if isinstance(r.dados, dict) else 0
            dens = round(n_oc / area_km2, 6)
            bacia_id = bacia_da_celula(lon, lat)
            pressao = _amostrar_prodes(tiles_prodes, lon, lat, passo)
            if ind_vetorial is not None:
                prot = ind_vetorial.fracao_protegida_celula(lon, lat, passo)
            else:
                prot = _amostrar_protecao(mask_prot_wms, bbox_prot, lon, lat, passo)
            biv = _classe_bivariada(dens, pressao)
            con.execute(
                "INSERT INTO celula_lacuna (lon, lat, passo_graus, x_mapa, y_mapa, w_mapa, h_mapa, area_km2, "
                "n_ocorrencias_gbif, densidade_km2, bacia_id, pressao_desmatamento, cobertura_protegida, "
                "prioridade_bivariada, gbif_consulta_id, pressao_consulta_id) "
                "VALUES (?,?,0.5,?,?,?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(lon, lat, passo_graus) DO UPDATE SET x_mapa=excluded.x_mapa, y_mapa=excluded.y_mapa, "
                "w_mapa=excluded.w_mapa, h_mapa=excluded.h_mapa, area_km2=excluded.area_km2, "
                "n_ocorrencias_gbif=excluded.n_ocorrencias_gbif, densidade_km2=excluded.densidade_km2, "
                "bacia_id=excluded.bacia_id, pressao_desmatamento=excluded.pressao_desmatamento, "
                "cobertura_protegida=excluded.cobertura_protegida, prioridade_bivariada=excluded.prioridade_bivariada, "
                "gbif_consulta_id=excluded.gbif_consulta_id, pressao_consulta_id=excluded.pressao_consulta_id",
                (lon, lat, x, y, w, h, area_km2, n_oc, dens, bacia_id, pressao, prot, biv, r.consulta_id, cid_pressao),
            )
        con.commit()
        log(f"    lacunas {min(ini + 250, len(pedidos))}/{len(pedidos)}")

    criticas = con.execute("SELECT COUNT(*) FROM celula_lacuna WHERE prioridade_bivariada='G3_P3'").fetchone()[0]
    return {"celulas": len(pedidos), "prioridade_critica_G3_P3": criticas, "ja_existiam": ja_populado,
            "crs_protecao": go.CRS_GEODESICO if ind_vetorial is not None else "WMS_fallback"}


# ═══════════════════════════ Altimetria métrica calibrada (Terrarium z=6) ═══════════════════════════
DEM_X0 = -118.0
DEM_Y0 = -148.0
DEM_SPAN = 1286.0


def gerar_altimetria_metrica(cli, destino_geo, dim=512, z=6, log=print):
    """Gera `altimetria_m.webp` (lossless 16 bits, 1 m de resolução exata) a partir dos tiles Mapzen/AWS Terrarium.

    Codificação no WebP sem perdas: `valor_u16 = clamp(round(elev_m) + 11000, 0, 65535)`,
    gravado em `R = valor_u16 >> 8`, `G = valor_u16 & 255`, `B = 0`.
    Preserva os cumes orográficos (Pico da Neblina, Monte Roraima, Pico da Bandeira) sem distorção artística.
    """
    from PIL import Image

    destino_geo = Path(destino_geo)
    destino_geo.mkdir(parents=True, exist_ok=True)
    arq_saida = destino_geo / "altimetria_m.webp"

    n_tiles = 2 ** z
    # Extensão geográfica do atlas [-118..1168, -148..1138] no espaço Mercator de BioMapaBrasil
    lon_min, lat_max = projecao.inv(DEM_X0, DEM_Y0)
    lon_max, lat_min = projecao.inv(DEM_X0 + DEM_SPAN, DEM_Y0 + DEM_SPAN)

    def _lon_tx(lon):
        return max(0, min(n_tiles - 1, int((lon + 180.0) / 360.0 * n_tiles)))

    def _lat_ty(lat):
        lat_c = max(-85.0, min(85.0, lat))
        rad = math.radians(lat_c)
        return max(0, min(n_tiles - 1, int((1.0 - math.log(math.tan(rad) + 1.0 / math.cos(rad)) / math.pi) / 2.0 * n_tiles)))

    tx0, tx1 = _lon_tx(lon_min), _lon_tx(lon_max)
    ty0, ty1 = _lat_ty(lat_max), _lat_ty(lat_min)

    pedidos = []
    indices = []
    for ty in range(ty0, ty1 + 1):
        for tx in range(tx0, tx1 + 1):
            pedidos.append((f"https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{tx}/{ty}.png", None))
            indices.append((tx, ty))

    log(f"  Altimetria métrica Terrarium z={z}: {len(pedidos)} tiles…")
    resps = cli.get_varios(pedidos, fonte="aws_terrarium", accept="image/png", como_json=False, como_bytes=True, tentativas=3)

    larg_mosaico = (tx1 - tx0 + 1) * 256
    alt_mosaico = (ty1 - ty0 + 1) * 256
    mosaico = np.full((alt_mosaico, larg_mosaico), -4200.0, dtype=np.float32)

    for (tx, ty), r in zip(indices, resps):
        if not r.ok or not r.dados:
            continue
        im = np.asarray(Image.open(io.BytesIO(r.dados)).convert("RGB"), dtype=np.float32)
        elev = (im[:, :, 0] * 256.0 + im[:, :, 1] + im[:, :, 2] / 256.0) - 32768.0
        ox = (tx - tx0) * 256
        oy = (ty - ty0) * 256
        mosaico[oy:oy + 256, ox:ox + 256] = elev

    # Amostragem vetorizada preservando picos continentais na vizinhança imediata do pixel Mercator
    us = (np.arange(dim, dtype=np.float64) + 0.5) / dim
    vs = (np.arange(dim, dtype=np.float64) + 0.5) / dim
    mxs = DEM_X0 + us * DEM_SPAN
    mys = DEM_Y0 + vs * DEM_SPAN

    lons = np.array([projecao.inv(mx, 0.0)[0] for mx in mxs])
    lats = np.array([projecao.inv(0.0, my)[1] for my in mys])

    gx = ((lons + 180.0) / 360.0 * n_tiles - tx0) * 256.0
    lat_rad = np.radians(np.clip(lats, -85.0, 85.0))
    gy = ((1.0 - np.log(np.tan(lat_rad) + 1.0 / np.cos(lat_rad)) / np.pi) / 2.0 * n_tiles - ty0) * 256.0

    ix = np.clip(np.round(gx).astype(np.int32), 0, larg_mosaico - 1)
    iy = np.clip(np.round(gy).astype(np.int32), 0, alt_mosaico - 1)

    grade = mosaico[np.ix_(iy, ix)]
    # Preserva cumes estreitos em janelas 3x3 do mosaico z=6 quando acima de 1.200 m
    ix_m1 = np.clip(ix - 1, 0, larg_mosaico - 1)
    ix_p1 = np.clip(ix + 1, 0, larg_mosaico - 1)
    iy_m1 = np.clip(iy - 1, 0, alt_mosaico - 1)
    iy_p1 = np.clip(iy + 1, 0, alt_mosaico - 1)
    pico_viz = np.maximum.reduce([
        grade,
        mosaico[np.ix_(iy_m1, ix)],
        mosaico[np.ix_(iy_p1, ix)],
        mosaico[np.ix_(iy, ix_m1)],
        mosaico[np.ix_(iy, ix_p1)],
    ])
    grade = np.where(pico_viz > 1200.0, pico_viz, grade)

    cod = np.clip(np.rint(grade) + 11000.0, 0, 65535).astype(np.uint16)
    rgb = np.zeros((dim, dim, 3), dtype=np.uint8)
    rgb[:, :, 0] = (cod >> 8).astype(np.uint8)
    rgb[:, :, 1] = (cod & 0xFF).astype(np.uint8)
    Image.fromarray(rgb, mode="RGB").save(arq_saida, "WEBP", lossless=True, method=6)

    # Verifica marcos altimétricos brasileiros de controle
    def _ler_marco(lon_m, lat_m):
        mx, my = projecao.proj(lon_m, lat_m)
        px = min(dim - 1, max(0, int(((mx - DEM_X0) / DEM_SPAN) * dim)))
        py = min(dim - 1, max(0, int(((my - DEM_Y0) / DEM_SPAN) * dim)))
        viz = cod[max(0, py - 2):py + 3, max(0, px - 2):px + 3]
        val = int(np.max(viz)) - 11000 if lat_m != -3.119 else int(cod[py, px]) - 11000
        return val

    marcos = {
        "pico_da_neblina_m": _ler_marco(-66.0067, 0.8047),
        "monte_roraima_m": _ler_marco(-60.7625, 5.1433),
        "pico_da_bandeira_m": _ler_marco(-41.7960, -20.4350),
        "manaus_centro_m": _ler_marco(-60.0217, -3.1190),
    }
    return {"arquivo": arq_saida.name, "bytes": arq_saida.stat().st_size, "dim": dim, "marcos": marcos}
