# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""UniProt (Swiss-Prot revisado, palavra-chave Toxin KW-0800): toxinas animais com função anotada.

O que a anotação do UniProt É: texto curado por especialistas, com a publicação que o sustenta
indicada por trecho. O que NÃO é: um trecho do artigo. Por isso a afirmação nasce `candidato` e a
rastreabilidade fica `parcial` até alguém conferir a passagem na publicação.
"""
import csv
import io
import re

API = "https://rest.uniprot.org/uniprotkb"
CONSULTA_TOXINAS = "(keyword:KW-0800) AND (reviewed:true)"
CAMPOS = ("accession,protein_name,gene_names,organism_name,organism_id,cc_function,cc_tissue_specificity,"
          "cc_similarity,length,xref_pdb,xref_embl,lit_pubmed_id,lit_doi_id")

# Códigos de evidência (ECO) que o UniProt usa. 269 = experimento descrito em publicação, usado em
# asserção manual; os demais não são experimento sobre aquela proteína.
ECO_EXPERIMENTAL = "ECO:0000269"

# "Nome científico (nome popular) (sinônimo)": o UniProt junta tudo no campo do organismo.
_PADRAO_ORGANISMO = re.compile(r"^(?P<cient>.+?)(?: \((?P<p1>[^()]*)\))?(?: \((?P<p2>[^()]*)\))?$")


def separar_nome(texto):
    """Separa o campo 'Organism' do UniProt em (científico, popular, sinônimo).

    Com um só parêntese, é nome popular; com dois, o primeiro é o popular e o segundo, o sinônimo científico.
    (Não dá para distinguir 'Common lancehead' de um binômio pela forma; a posição é o único critério seguro.)"""
    m = _PADRAO_ORGANISMO.match((texto or "").strip())
    if not m:
        return (texto or "").strip(), None, None
    cient, p1, p2 = m.group("cient").strip(), m.group("p1"), m.group("p2")
    return cient, (p1 or "").strip() or None, (p2 or "").strip() or None


def organismos_toxprot(cli):
    """Todos os organismos com toxina revisada.

    Devolve (lista de dicts {taxid, cientifico, popular, sinonimo, n}, consulta_id), do mais ao menos
    anotado.
    """
    r = cli.get(f"{API}/stream", {
        "query": CONSULTA_TOXINAS, "format": "tsv", "fields": "accession,organism_id,organism_name",
        "compressed": "false"}, fonte="uniprot", como_json=False, accept="text/plain",
        cabecalho_versao="X-UniProt-Release")
    contagem, nomes = {}, {}
    for linha in csv.DictReader(io.StringIO(r.dados, newline=""), delimiter=chr(9)):
        tid = int(linha["Organism (ID)"])
        contagem[tid] = contagem.get(tid, 0) + 1
        nomes[tid] = linha["Organism"]
    saida = []
    for tid, n in contagem.items():
        cient, popular, sinonimo = separar_nome(nomes[tid])
        saida.append({"taxid": tid, "cientifico": cient, "popular": popular, "sinonimo": sinonimo, "n": n})
    saida.sort(key=lambda x: (-x["n"], x["cientifico"]))
    return saida, r.consulta_id


def toxinas_do_organismo(cli, taxid):
    """Entradas revisadas de toxina do organismo, já normalizadas. Devolve (lista, resposta)."""
    r = cli.get(f"{API}/stream", {
        "query": f"(organism_id:{taxid}) AND {CONSULTA_TOXINAS}", "format": "json", "fields": CAMPOS,
        "compressed": "false"}, fonte="uniprot", cabecalho_versao="X-UniProt-Release")
    dados = r.dados if isinstance(r.dados, dict) else {"results": []}
    return [normalizar_entrada(e) for e in dados.get("results", [])], r


def _texto_comentarios(entrada, tipo):
    saida = []
    for c in entrada.get("comments", []):
        if c.get("commentType") == tipo:
            for t in c.get("texts", []):
                saida.append(t)
    return saida


def normalizar_entrada(e):
    """Extrai de uma entrada JSON do UniProt só o que o modelo de dados usa."""
    desc = e.get("proteinDescription", {})
    nome = None
    for chave in ("recommendedName", "submissionNames", "alternativeNames"):
        v = desc.get(chave)
        if isinstance(v, list) and v:
            v = v[0]
        if isinstance(v, dict) and v.get("fullName", {}).get("value"):
            nome = v["fullName"]["value"]
            break
    funcao = _texto_comentarios(e, "FUNCTION")
    texto_funcao = " ".join(t["value"] for t in funcao).strip() or None
    evidencias = [(ev.get("source"), ev.get("id"), ev.get("evidenceCode"))
                  for t in funcao for ev in t.get("evidences", [])]
    pmids = sorted({i for s, i, _ in evidencias if s == "PubMed"})
    experimental = any(cod == ECO_EXPERIMENTAL for _, _, cod in evidencias)
    familia = None
    for t in _texto_comentarios(e, "SIMILARITY"):
        m = re.search(r"[Bb]elongs to the (.+?)[.]?$", t["value"])
        if m:
            familia = m.group(1).strip()
            break
    pdb = sorted({x["id"] for x in e.get("uniProtKBCrossReferences", []) if x.get("database") == "PDB"})
    embl = sorted({x["id"] for x in e.get("uniProtKBCrossReferences", []) if x.get("database") == "EMBL" and x.get("id")})
    refs = {}
    for ref in e.get("references", []):
        c = ref.get("citation", {})
        ids = {x["database"]: x["id"] for x in c.get("citationCrossReferences", [])}
        if "PubMed" in ids or "DOI" in ids:
            refs[ids.get("PubMed") or ids.get("DOI")] = {
                "pmid": ids.get("PubMed"), "doi": (ids.get("DOI") or "").lower() or None, "titulo": c.get("title"),
                "revista": c.get("journal"), "ano": _ano(c.get("publicationDate")),
                "autores": c.get("authors", [])[:12]}
    tecido = " ".join(t["value"] for t in _texto_comentarios(e, "TISSUE SPECIFICITY")) or None
    return {
        "acc": e["primaryAccession"], "nome": nome or e["primaryAccession"],
        "organismo": e.get("organism", {}).get("scientificName"), "taxid": e.get("organism", {}).get("taxonId"),
        "funcao": texto_funcao, "pmids_funcao": pmids, "chaves_ref_entrada": list(refs.keys())[:3],
        "experimental": experimental,
        "evidencias": evidencias, "familia": familia, "comprimento": e.get("sequence", {}).get("length"),
        "pdb": pdb, "embl": embl, "referencias": refs, "tecido": tecido,
    }


def _ano(data):
    m = re.search(r"(19|20)[0-9]{2}", data or "")
    return int(m.group(0)) if m else None
