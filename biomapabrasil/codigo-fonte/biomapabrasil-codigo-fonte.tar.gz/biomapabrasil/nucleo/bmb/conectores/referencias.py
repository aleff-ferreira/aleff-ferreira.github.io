# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Resolução de referências: DOI (Crossref) e PMID (PubMed), com sinalização de retratação.

Uma referência retratada tira a afirmação do ar: ela vai para `quarentena` com o motivo registrado,
em vez de sumir sem rastro.
"""
import re

from ..http import ErroDeFonte

CROSSREF = "https://api.crossref.org/works"
ESUMMARY = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"

# Tipos de atualização editorial do Crossref (inclui dados do Retraction Watch) que tiram a obra do ar.
TIPOS_RETRATACAO = {"retraction", "withdrawal", "removal"}
TIPOS_AVISO = {"expression_of_concern"}
TIPOS_ERRATA = {"correction", "erratum", "corrigendum"}
PADRAO_ERRATA = re.compile(r"^\s*\[?\s*(erratum|corrigendum|correction\s+to)\b", re.IGNORECASE)


def _ano_crossref(m):
    for chave in ("issued", "published", "published-print", "published-online"):
        partes = (m.get(chave) or {}).get("date-parts") or [[None]]
        if partes and partes[0] and partes[0][0]:
            return int(partes[0][0])
    return None


def pedido_crossref(doi):
    return (f"{CROSSREF}/{doi}", None)


def _interpretar_item_crossref(m, consulta_id):
    if not m or not isinstance(m, dict):
        return None
    autores = []
    for a in (m.get("author") or [])[:12]:
        nome = " ".join(x for x in (a.get("family"), a.get("given")) if x) or a.get("name")
        if nome:
            autores.append(nome)
    atualizacoes = m.get("updated-by") or []
    tipos = {(u.get("type") or "").lower() for u in atualizacoes}
    titulo = (m.get("title") or [None])[0]
    retratada = bool(tipos & TIPOS_RETRATACAO) or (titulo or "").upper().startswith("RETRACTED")
    aviso = None
    if tipos & TIPOS_AVISO:
        aviso = "expressao_de_preocupacao"
    elif PADRAO_ERRATA.search(titulo or "") or (tipos & TIPOS_ERRATA):
        aviso = "errata_ou_corrigenda"
    corrige = [(u.get("DOI") or "").lower() for u in (m.get("update-to") or []) if (u.get("type") or "").lower() in TIPOS_ERRATA]
    return {
        "titulo": titulo,
        "revista": (m.get("container-title") or [None])[0],
        "ano": _ano_crossref(m),
        "autores": autores,
        "tipo_obra": m.get("type"),
        "agencia_doi": "Crossref",
        "retratada": retratada,
        "aviso": aviso,
        "volume": (str(m.get("volume")).strip() or None) if m.get("volume") else None,
        "pagina": ((m.get("page") or "").split("-")[0].strip() or None),
        "e_errata_de": corrige[0] if corrige else None,     # a própria obra é a nota de correção de outro DOI
        "resumo": m.get("abstract"),
        "consulta_id": consulta_id,
    }


def interpretar_crossref(resp):
    """Metadados de um DOI, ou None se o Crossref não o conhece."""
    if resp.status != 200 or not isinstance(resp.dados, dict):
        return None
    m = resp.dados.get("message") or {}
    return _interpretar_item_crossref(m, resp.consulta_id)


def _resolver_datacite_ou_epmc(cli, doi):
    """Fallback para DOIs válidos registrados no DataCite ou indexados no Europe PMC quando fora do Crossref."""
    try:
        r_dc = cli.get(f"https://api.datacite.org/dois/{doi}", fonte="datacite", tentativas=2)
        if r_dc and r_dc.status == 200 and isinstance(r_dc.dados, dict):
            atrib = ((r_dc.dados.get("data") or {}).get("attributes")) or {}
            tits = atrib.get("titles") or []
            titulo = tits[0].get("title") if tits and isinstance(tits[0], dict) else None
            autores = [
                (c.get("name") or " ".join(x for x in (c.get("familyName"), c.get("givenName")) if x)).strip()
                for c in (atrib.get("creators") or [])[:12]
            ]
            autores = [a for a in autores if a]
            ano = atrib.get("publicationYear")
            return {
                "titulo": titulo,
                "revista": atrib.get("publisher"),
                "ano": int(ano) if str(ano or "").isdigit() else None,
                "autores": autores,
                "tipo_obra": ((atrib.get("types") or {}).get("resourceTypeGeneral") or "").lower() or None,
                "agencia_doi": "DataCite",
                "retratada": (titulo or "").upper().startswith("RETRACTED"),
                "aviso": None,
                "consulta_id": r_dc.consulta_id,
            }, r_dc.consulta_id
    except ErroDeFonte:
        pass

    try:
        r_ep = cli.get(
            "https://www.ebi.ac.uk/europepmc/webservices/rest/search",
            {"query": f'DOI:"{doi}"', "format": "json", "pageSize": "3"},
            fonte="europepmc",
            tentativas=2,
        )
        if r_ep and r_ep.status == 200 and isinstance(r_ep.dados, dict):
            res_list = ((r_ep.dados.get("resultList") or {}).get("result")) or []
            if res_list:
                it = res_list[0]
                titulo = (it.get("title") or "").strip() or None
                ano_s = str(it.get("pubYear") or "")
                aut_str = it.get("authorString") or ""
                autores = [x.strip() for x in aut_str.split(",") if x.strip()][:12]
                pub_type = str(it.get("pubType") or "")
                return {
                    "titulo": titulo,
                    "revista": it.get("journalTitle"),
                    "ano": int(ano_s) if ano_s.isdigit() else None,
                    "autores": autores,
                    "tipo_obra": pub_type,
                    "retratada": "retract" in pub_type.lower() or (titulo or "").upper().startswith("RETRACTED"),
                    "aviso": None,
                    "pmcid": it.get("pmcid"),
                    "pmid": str(it["pmid"]) if it.get("pmid") else None,
                    "consulta_id": r_ep.consulta_id,
                }, r_ep.consulta_id
            return None, r_ep.consulta_id
    except ErroDeFonte:
        pass
    return None, None


def crossref_em_lote(cli, dois, tamanho_lote=35):
    """Resolve DOIs em lotes via `filter=doi:...` no Crossref, com fallback individual + DataCite/EuropePMC."""
    lista = [d.strip().lower() for d in dict.fromkeys(dois) if d and d.strip()]
    if not lista:
        return {}
    fatias = [lista[i:i + tamanho_lote] for i in range(0, len(lista), tamanho_lote)]
    pedidos_lote = [
        (CROSSREF, {"filter": ",".join(f"doi:{d}" for d in f), "rows": str(len(f) + 10)})
        for f in fatias
    ]
    resps = cli.get_varios(pedidos_lote, fonte="crossref", tentativas=2, ignorar_erros=True)
    saida = {}
    faltantes = []
    for fatia, resp in zip(fatias, resps):
        por_doi = {}
        if resp is not None and resp.status == 200 and isinstance(resp.dados, dict):
            itens = ((resp.dados.get("message") or {}).get("items")) or []
            for m in itens:
                d_item = (m.get("DOI") or "").strip().lower()
                if d_item:
                    parsed = _interpretar_item_crossref(m, resp.consulta_id)
                    if parsed:
                        por_doi[d_item] = (parsed, resp.consulta_id)
        for d in fatia:
            if d in por_doi:
                saida[d] = por_doi[d]
            else:
                faltantes.append(d)

    if faltantes:
        resps_ind = cli.get_varios([pedido_crossref(d) for d in faltantes], fonte="crossref", tentativas=2, ignorar_erros=True)
        ainda_sem = []
        for d, r in zip(faltantes, resps_ind):
            if r is not None:
                parsed = interpretar_crossref(r)
                if parsed:
                    saida[d] = (parsed, r.consulta_id)
                else:
                    saida[d] = (None, r.consulta_id)
                    ainda_sem.append(d)
            else:
                ainda_sem.append(d)
        for d in ainda_sem:
            fb, cid_fb = _resolver_datacite_ou_epmc(cli, d)
            if fb is not None:
                saida[d] = (fb, cid_fb)
            elif d not in saida and cid_fb is not None:
                saida[d] = (None, cid_fb)
    return saida


def pubmed(cli, pmids):
    """{pmid: {titulo, revista, ano, autores, doi, retratada}} para uma lista de PMIDs (lotes de 150)."""
    ids = sorted({str(p) for p in pmids if p})
    saida = {}
    for i in range(0, len(ids), 150):
        lote = ids[i:i + 150]
        try:
            r = cli.get(ESUMMARY, {"db": "pubmed", "id": ",".join(lote), "retmode": "json"}, fonte="pubmed", tentativas=2)
        except ErroDeFonte:
            continue
        res = (r.dados.get("result") or {}) if isinstance(r.dados, dict) else {}
        for u in res.get("uids", []):
            x = res.get(u) or {}
            ano = None
            for pedaco in (x.get("pubdate") or "").split():
                if pedaco.isdigit() and len(pedaco) == 4:
                    ano = int(pedaco)
                    break
            doi = None
            for a in x.get("articleids") or []:
                if a.get("idtype") == "doi":
                    doi = (a.get("value") or "").strip().lower() or None
            titulo = (x.get("title") or "").strip() or None
            pubtypes = x.get("pubtype") or []
            aviso = None
            if "Expression of Concern" in pubtypes:
                aviso = "expressao_de_preocupacao"
            elif "Published Erratum" in pubtypes or PADRAO_ERRATA.search(titulo or ""):
                aviso = "errata_ou_corrigenda"
            saida[u] = {"titulo": titulo, "revista": x.get("source"), "ano": ano,
                        "autores": [a.get("name") for a in (x.get("authors") or [])[:12] if a.get("name")],
                        "doi": doi, "retratada": "Retracted Publication" in pubtypes,
                        "aviso": aviso,
                        "consulta_id": r.consulta_id}
    return saida


# ───────────────────────── existência do DOI e textos abertos ─────────────────────────
HANDLE = "https://doi.org/api/handles"
EPMC = "https://www.ebi.ac.uk/europepmc/webservices/rest"


def doi_registrado(cli, doi):
    """Pergunta ao sistema de handles se o DOI existe: `(True | False | None, consulta_id)`.
    None = não foi possível saber (falha de rede); nesse caso nada é concluído sobre o DOI."""
    try:
        r = cli.get(f"{HANDLE}/{doi}", {"type": "URL"}, fonte="doi_org", tentativas=3)
    except ErroDeFonte:
        return None, None
    d = r.dados if isinstance(r.dados, dict) else {}
    codigo = d.get("responseCode")
    if codigo == 1:
        return True, r.consulta_id
    if codigo == 100 or r.status == 404:
        return False, r.consulta_id
    return None, r.consulta_id


def _limpar_marcacao(texto):
    import html as _html
    return re.sub(r"\s+", " ", _html.unescape(re.sub(r"<[^>]+>", " ", texto or ""))).strip()


def europepmc_em_lote(cli, dois=(), pmids=(), tamanho_lote=12):
    """Título, resumo e situação de acesso aberto no Europe PMC: `({doi: reg}, {pmid: reg})`.

    reg = {pmid, pmcid, doi, titulo, resumo, acesso_aberto, consulta_id}. O terceiro valor devolvido é o conjunto de
    identificadores cujo lote falhou (rede, limite de requisições): essas obras NÃO foram conferidas nesta execução, o
    que é diferente de terem sido conferidas e não constarem no Europe PMC.
    """
    por_doi, por_pmid, falhas = {}, {}, set()
    termos = [("DOI", d) for d in dict.fromkeys(x.strip().lower() for x in dois if x)] + \
             [("EXT_ID", p) for p in dict.fromkeys(str(x) for x in pmids if x)]
    for ini in range(0, len(termos), tamanho_lote):
        lote = termos[ini:ini + tamanho_lote]
        consulta = " OR ".join(f'{campo}:"{valor}"' for campo, valor in lote)
        try:
            r = cli.get(f"{EPMC}/search", {"query": consulta, "resultType": "core", "format": "json", "pageSize": "100"},
                        fonte="europepmc", tentativas=3)
        except ErroDeFonte:
            falhas.update(valor for _, valor in lote)
            continue
        for it in (((r.dados.get("resultList") or {}).get("result")) or []) if isinstance(r.dados, dict) else []:
            reg = {"pmid": str(it["pmid"]) if it.get("pmid") else None, "pmcid": it.get("pmcid"),
                   "doi": (it.get("doi") or "").strip().lower() or None, "titulo": _limpar_marcacao(it.get("title")) or None,
                   "resumo": _limpar_marcacao(it.get("abstractText")) or None,
                   "acesso_aberto": (it.get("isOpenAccess") == "Y"), "consulta_id": r.consulta_id}
            if reg["doi"]:
                por_doi.setdefault(reg["doi"], reg)
            if reg["pmid"]:
                por_pmid.setdefault(reg["pmid"], reg)
    return por_doi, por_pmid, falhas


def texto_completo_aberto(cli, pmcid):
    """Corpo do artigo de acesso aberto no Europe PMC, em texto simples: `(texto | None, consulta_id)`."""
    try:
        r = cli.get(f"{EPMC}/{pmcid}/fullTextXML", fonte="europepmc", como_json=False, accept="application/xml", tentativas=2)
    except ErroDeFonte:
        return None, None
    if r.status != 200 or not isinstance(r.dados, str) or "<body" not in r.dados:
        return None, r.consulta_id
    corpo = r.dados[r.dados.index("<body"):]
    corpo = corpo[:corpo.index("</body>")] if "</body>" in corpo else corpo
    corpo = re.sub(r"<(table-wrap|fig|ref-list|supplementary-material)\b.*?</\1>", " ", corpo, flags=re.S)
    corpo = re.sub(r"</(p|title|sec|li)>", ". ", corpo)
    return _limpar_marcacao(corpo) or None, r.consulta_id


EFETCH = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"


def resumo_pubmed(cli, pmid):
    """Resumo do PubMed em texto simples: `(texto | None, consulta_id)`. None = sem resumo ou serviço indisponível."""
    try:
        r = cli.get(EFETCH, {"db": "pubmed", "id": str(pmid), "retmode": "xml"}, fonte="pubmed", como_json=False,
                    accept="application/xml", tentativas=3)
    except ErroDeFonte:
        return None, None
    if r.status != 200 or not isinstance(r.dados, str):
        return None, r.consulta_id
    partes = re.findall(r"<AbstractText[^>]*>(.*?)</AbstractText>", r.dados, flags=re.S)
    texto = _limpar_marcacao(" ".join(partes))
    return (texto or None), r.consulta_id
