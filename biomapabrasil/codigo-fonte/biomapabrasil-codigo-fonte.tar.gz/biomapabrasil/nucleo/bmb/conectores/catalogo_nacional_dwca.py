# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Arquivos Darwin Core oficiais completos da Flora e Funga do Brasil (JBRJ) e do CTFB (Fauna do Brasil).

Constrói a tabela `universo_checklist` com o universo completo de espécies aceitas na Amazônia brasileira,
permitindo quantificar com rigor de inventário nacional a fração da biodiversidade amazônica que possui
química estrutural aberta documentada versus a "matéria escura química" (*chemical dark matter*, > 88%).
"""
from __future__ import annotations

import csv
import hashlib
import json
import zipfile
from pathlib import Path

import httpx

from .. import config
from ..conectores import checklists_br
from ..http import agora_utc
from ..util import json_compacto

csv.field_size_limit(10_000_000)

URL_JBRJ_DWCA = "https://ipt.jbrj.gov.br/jbrj/archive.do?r=lista_especies_flora_brasil"
URL_CTFB_DWCA = "https://ipt.jbrj.gov.br/jbrj/archive.do?r=catalogo_taxonomico_da_fauna_do_brasil"

UFS_CORE_AMAZONIA = {"AC", "AM", "AP", "PA", "RO", "RR"}
UFS_AMAZONIA_LEGAL = set(config.UF_AMAZONIA_LEGAL)

FAMILIAS_FAUNA_TOXINOLOGICA = {
    # Serpentes, lagartos peçonhentos
    "viperidae", "elapidae", "colubridae", "dipsadidae",
    # Anfíbios anuros com alcaloides/bufadienolídeos/peptídeos cutâneos
    "bufonidae", "dendrobatidae", "aromobatidae", "phyllomedusidae", "hylidae", "leptodactylidae",
    # Escorpiões e aranhas
    "buthidae", "chactidae", "bothriuridae", "theraphosidae", "ctenidae", "sicariidae",
    "araneidae", "dipluridae", "actinopodidae",
    # Himenópteros e lepidópteros urticantes/peçonhentos
    "formicidae", "vespidae", "apidae", "mutillidae", "pompilidae",
    "saturniidae", "megalopygidae", "limacodidae",
    # Peixes peçonhentos / ictiotóxicos / elétricos
    "potamotrygonidae", "batrachoididae", "pimelodidae", "ariidae", "gymnotidae", "electrophoridae",
    # Quilópodes
    "scolopendridae",
}
ORDENS_FAUNA_TOXINOLOGICA = {"scorpiones", "araneae", "scolopendromorpha"}


def pasta_dumps() -> Path:
    d = Path(config.CACHE_DIR) / "dumps"
    d.mkdir(parents=True, exist_ok=True)
    return d


def garantir_arquivo_dump(con, nome_arquivo: str, url: str, fonte_id: str, versao_padrao: str | None = None, log=print) -> tuple[Path, int]:
    """Garante o arquivo em `CACHE_DIR/dumps`, calcula SHA-256 e registra `consulta_id` no SQLite."""
    arq = pasta_dumps() / nome_arquivo
    sha_arq = pasta_dumps() / f"{nome_arquivo}.sha256"
    meta_arq = pasta_dumps() / f"{nome_arquivo}.meta.json"

    if not arq.exists() or arq.stat().st_size < 50_000:
        log(f"  Baixando arquivo oficial {nome_arquivo} ({url})…")
        tmp = arq.with_suffix(arq.suffix + ".part")
        h = hashlib.sha256()
        with httpx.Client(timeout=300.0, follow_redirects=True, headers={"User-Agent": config.USER_AGENT}) as c:
            with c.stream("GET", url) as r:
                r.raise_for_status()
                with open(tmp, "wb") as f:
                    for bloco in r.iter_bytes(1 << 20):
                        f.write(bloco)
                        h.update(bloco)
        tmp.replace(arq)
        digest = h.hexdigest()
        sha_arq.write_text(digest, encoding="utf-8")
        meta = {"consultado_em": agora_utc(), "sha256": digest, "bytes": arq.stat().st_size, "versao": versao_padrao}
        meta_arq.write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
    else:
        if sha_arq.exists():
            digest = sha_arq.read_text(encoding="utf-8").strip()
        else:
            h = hashlib.sha256()
            with open(arq, "rb") as f:
                for bloco in iter(lambda: f.read(1 << 20), b""):
                    h.update(bloco)
            digest = h.hexdigest()
            sha_arq.write_text(digest, encoding="utf-8")
        if meta_arq.exists():
            meta = json.loads(meta_arq.read_text(encoding="utf-8"))
        else:
            meta = {"consultado_em": agora_utc(), "sha256": digest, "bytes": arq.stat().st_size, "versao": versao_padrao}
            meta_arq.write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")

    tam_bytes = arq.stat().st_size
    consultado_em = meta.get("consultado_em") or agora_utc()
    versao = meta.get("versao") or versao_padrao

    existente = con.execute(
        "SELECT id FROM consulta WHERE fonte_id=? AND url=? AND sha256=? ORDER BY id LIMIT 1",
        (fonte_id, url, digest),
    ).fetchone()
    if existente:
        return arq, existente["id"]

    cur = con.execute(
        "INSERT INTO consulta (fonte_id, url, status, bytes, sha256, consultado_em, versao_fonte) "
        "VALUES (?,?,200,?,?,?,?)",
        (fonte_id, url, tam_bytes, digest, consultado_em, versao),
    )
    con.commit()
    return arq, cur.lastrowid


def _limpar_na(v: str | None) -> str | None:
    s = (v or "").strip()
    return None if not s or s.upper() == "NA" else s


_CATEGORIA_INFRA = {
    # Flora e Funga do Brasil
    "VARIEDADE": ("var.", "VARIETY"), "SUB_ESPECIE": ("subsp.", "SUBSPECIES"), "FORMA": ("f.", "FORM"),
    # Catálogo da Fauna (zoologia: trinômio sem marcador)
    "SUBSPECIES": ("", "SUBSPECIES"),
}
_CATEGORIA_ESPECIE = {"ESPECIE", "SPECIES"}


def nome_do_registro(genero: str | None, epiteto: str | None, infra: str | None, categoria: str | None):
    """Nome canônico do registro do checklist, sem autoria e SEM cortar o infraespecífico: `(nome, categoria)`.

    Um sinônimo de categoria variedade, subespécie ou forma mantém o terceiro epíteto. Reduzi-lo ao binômio
    transformaria «Oryza sativa var. grandiglumis» em «Oryza sativa», que é outra espécie.
    """
    if not genero or not epiteto:
        return None, None
    cat = (categoria or "").strip().upper()
    binomio = f"{genero} {epiteto}"
    if cat in _CATEGORIA_ESPECIE:
        return binomio, "SPECIES"
    if cat in _CATEGORIA_INFRA and infra:
        marcador, cat_padrao = _CATEGORIA_INFRA[cat]
        return (f"{binomio} {marcador} {infra}" if marcador else f"{binomio} {infra}"), cat_padrao
    return None, None


def _genero_valido(genero: str | None) -> bool:
    """Gênero de verdade: uma palavra só. «Incertae sedis» é marcador de posição incerta, não nome de gênero."""
    g = (genero or "").strip()
    return bool(g) and " " not in g and g[:1].isupper() and g.lower() != "incertae"


def _deduplicar_aceitos(aceitos_por_id: dict, sins_brutos: list) -> int:
    """O catálogo de origem às vezes traz a mesma espécie aceita em dois registros (mesmo binômio, mesma autoria).
    Fica o de menor identificador, com as UFs e os domínios dos dois; os sinônimos do outro passam para ele.
    Mesmo binômio com autorias diferentes são nomes distintos e ficam os dois."""
    from ..taxonomia import tokens_autoria
    por_nome: dict[tuple, list[str]] = {}
    for tid, ent in aceitos_por_id.items():
        por_nome.setdefault((ent["nome_aceito"].lower(), tokens_autoria(ent["autoria"])), []).append(tid)
    troca = {}
    for ids in por_nome.values():
        if len(ids) < 2:
            continue
        ids = sorted(ids, key=lambda x: (int(x) if str(x).isdigit() else 10**12, str(x)))
        fica = aceitos_por_id[ids[0]]
        for outro in ids[1:]:
            ent = aceitos_por_id.pop(outro)
            fica["ufs_list"] = sorted(set(fica["ufs_list"]) | set(ent["ufs_list"]))
            fica["dominios_list"] = sorted(set(fica["dominios_list"]) | set(ent["dominios_list"]))
            fica["bioma_amazonia_declarado"] = max(fica["bioma_amazonia_declarado"], ent["bioma_amazonia_declarado"])
            troca[outro] = ids[0]
    if troca:
        sins_brutos[:] = [(n, troca.get(aid, aid), aut, cat) for n, aid, aut, cat in sins_brutos]
    return len(troca)


def _aplicar_sinonimos(aceitos_por_id: dict, sins_brutos: list) -> dict[str, str]:
    """Liga a cada espécie aceita os sinônimos unívocos (que apontam para uma só espécie aceita e não coincidem com
    nenhum nome aceito), guardando autoria e categoria de cada um."""
    mapa_sin_ids: dict[str, set[str]] = {}
    dados_sin: dict[tuple[str, str], dict] = {}
    for nome_sin, aid, autoria, categoria in sins_brutos:
        if aid in aceitos_por_id:
            mapa_sin_ids.setdefault(nome_sin.lower(), set()).add(aid)
            dados_sin.setdefault((nome_sin.lower(), aid), {"nome": nome_sin, "autoria": autoria, "categoria": categoria})
    mapa_nome_aceito = {ent["nome_aceito"].lower(): ent["nome_aceito"] for ent in aceitos_por_id.values()}
    for s_low, aids in mapa_sin_ids.items():
        if len(aids) == 1:
            aid = next(iter(aids))
            ent = aceitos_por_id[aid]
            if s_low != ent["nome_aceito"].lower() and s_low not in mapa_nome_aceito:
                ent["sinonimos"].add(s_low)
                ent["sinonimos_autoria"][s_low] = dados_sin[(s_low, aid)]
                mapa_nome_aceito[s_low] = ent["nome_aceito"]
    return mapa_nome_aceito


def _parse_jbrj(arq_zip: Path, cid: int) -> tuple[list[dict], dict[str, str]]:
    """Extrai espécies aceitas e sinônimos unívocos da Flora e Funga do Brasil (JBRJ)."""
    doms_por_id: dict[str, set[str]] = {}
    ufs_por_id: dict[str, set[str]] = {}
    estab_por_id: dict[str, str] = {}
    endem_por_id: dict[str, str] = {}
    forma_por_id: dict[str, str] = {}
    hab_por_id: dict[str, str] = {}

    with zipfile.ZipFile(arq_zip) as z:
        if "eml.xml" in z.namelist():
            pass
        with z.open("distribution.txt") as f:
            for row in csv.DictReader((l.decode("utf-8", errors="replace") for l in f), delimiter="\t"):
                tid = row["id"]
                loc = (row.get("locationID") or "").replace("BR-", "").strip().upper()
                if len(loc) == 2 and loc.isalpha():
                    ufs_por_id.setdefault(tid, set()).add(loc)
                est = _limpar_na(row.get("establishmentMeans"))
                if est and tid not in estab_por_id:
                    estab_por_id[tid] = est
                rem = (row.get("occurrenceRemarks") or "").strip()
                if rem.startswith("{"):
                    try:
                        rj = json.loads(rem)
                        end = _limpar_na(rj.get("endemism"))
                        if end:
                            endem_por_id[tid] = "endemica" if "endemica" in end.lower() and "não" not in end.lower() and "nao" not in end.lower() else "nao_endemica"
                        for dm in rj.get("phytogeographicDomain") or []:
                            if dm:
                                doms_por_id.setdefault(tid, set()).add(str(dm).strip())
                    except Exception:
                        pass

        if "speciesprofile.txt" in z.namelist():
            with z.open("speciesprofile.txt") as f:
                for row in csv.DictReader((l.decode("utf-8", errors="replace") for l in f), delimiter="\t"):
                    tid = row["id"]
                    lf_raw = (row.get("lifeForm") or "").strip()
                    if lf_raw.startswith("{"):
                        try:
                            lj = json.loads(lf_raw)
                            lfs = [str(x).strip() for x in (lj.get("lifeForm") or []) if x]
                            hbs = [str(x).strip() for x in (lj.get("habitat") or []) if x]
                            if lfs:
                                forma_por_id[tid] = "; ".join(lfs[:4])
                            if hbs:
                                hab_por_id[tid] = "; ".join(hbs[:4])
                        except Exception:
                            pass
                    elif lf_raw:
                        forma_por_id[tid] = lf_raw[:120]

        aceitos_por_id: dict[str, dict] = {}
        sins_brutos: list[tuple[str, str, str | None, str]] = []
        with z.open("taxon.txt") as f:
            for row in csv.DictReader((l.decode("utf-8", errors="replace") for l in f), delimiter="\t"):
                tid = row["id"]
                st = (row.get("taxonomicStatus") or "").strip().upper()
                rk = (row.get("taxonRank") or "").strip().upper()
                gen = _limpar_na(row.get("genus"))
                ep = _limpar_na(row.get("specificEpithet"))
                binom = f"{gen} {ep}" if gen and ep else None
                if st == "NOME_ACEITO" and rk == "ESPECIE" and binom and _genero_valido(gen):
                    reino = _limpar_na(row.get("kingdom")) or "Plantae"
                    grupo = "fungo" if reino == "Fungi" else ("planta" if reino == "Plantae" else "outro")
                    doms = sorted(doms_por_id.get(tid, set()))
                    ufs = sorted(ufs_por_id.get(tid, set()))
                    tem_amz = int(any("amaz" in d.lower() for d in doms) or bool(set(ufs) & UFS_CORE_AMAZONIA))
                    est_bruto = (estab_por_id.get(tid) or "").lower()
                    if "nativ" in est_bruto:
                        status_or = "nativa"
                    elif "naturaliz" in est_bruto:
                        status_or = "naturalizada"
                    elif "cultiv" in est_bruto or "exót" in est_bruto or "exot" in est_bruto:
                        status_or = "introduzida"
                    else:
                        status_or = _limpar_na(estab_por_id.get(tid))
                    aceitos_por_id[tid] = {
                        "fonte": "jbrj_flora_funga",
                        "taxon_id_fonte": tid,
                        "nome_aceito": binom,
                        "autoria": _limpar_na(row.get("scientificNameAuthorship")),
                        "reino": reino,
                        "filo": _limpar_na(row.get("phylum")),
                        "classe": _limpar_na(row.get("class")),
                        "ordem": _limpar_na(row.get("order")),
                        "familia": _limpar_na(row.get("family")),
                        "genero": gen,
                        "grupo_bmb": grupo,
                        "status_origem_br": status_or,
                        "endemismo_br": endem_por_id.get(tid),
                        "dominios_list": doms,
                        "ufs_list": ufs,
                        "bioma_amazonia_declarado": tem_amz,
                        "forma_vida": forma_por_id.get(tid),
                        "substrato_habitat": hab_por_id.get(tid),
                        "sinonimos": set(),
                        "sinonimos_autoria": {},
                        "consulta_id": cid,
                    }
                elif st == "SINONIMO" and row.get("acceptedNameUsageID"):
                    nome_sin, cat_sin = nome_do_registro(gen, ep, _limpar_na(row.get("infraspecificEpithet")), rk)
                    if nome_sin:
                        sins_brutos.append((nome_sin, row["acceptedNameUsageID"].strip(),
                                            _limpar_na(row.get("scientificNameAuthorship")), cat_sin))

    _deduplicar_aceitos(aceitos_por_id, sins_brutos)
    return list(aceitos_por_id.values()), _aplicar_sinonimos(aceitos_por_id, sins_brutos)


def _parse_ctfb(arq_zip: Path, cid: int, taxids_toxprot_nomes: set[str]) -> tuple[list[dict], dict[str, str]]:
    """Extrai espécies aceitas e sinônimos unívocos do Catálogo Taxonômico da Fauna do Brasil (CTFB)."""
    ufs_por_id: dict[str, set[str]] = {}
    estab_por_id: dict[str, str] = {}
    forma_por_id: dict[str, str] = {}
    hab_por_id: dict[str, str] = {}

    with zipfile.ZipFile(arq_zip) as z:
        with z.open("distribution.txt") as f:
            for row in csv.DictReader((l.decode("utf-8", errors="replace") for l in f), delimiter="\t"):
                tid = row["id"]
                loc = (row.get("locationID") or "").replace("BR-", "").strip().upper()
                if len(loc) == 2 and loc.isalpha():
                    ufs_por_id.setdefault(tid, set()).add(loc)
                est = _limpar_na(row.get("establishmentMeans"))
                if est and tid not in estab_por_id:
                    estab_por_id[tid] = est

        if "speciesprofile.txt" in z.namelist():
            with z.open("speciesprofile.txt") as f:
                for row in csv.DictReader((l.decode("utf-8", errors="replace") for l in f), delimiter="\t"):
                    tid = row["id"]
                    lf = _limpar_na(row.get("lifeForm"))
                    hb = _limpar_na(row.get("habitat"))
                    if lf:
                        forma_por_id[tid] = lf[:120]
                    if hb:
                        hab_por_id[tid] = hb[:120]

        aceitos_por_id: dict[str, dict] = {}
        sins_brutos: list[tuple[str, str, str | None, str]] = []
        with z.open("taxon.txt") as f:
            for row in csv.DictReader((l.decode("utf-8", errors="replace") for l in f), delimiter="\t"):
                tid = row["id"]
                st = (row.get("taxonomicStatus") or "").strip().lower()
                rk = (row.get("taxonRank") or "").strip().lower()
                gen = _limpar_na(row.get("genus"))
                ep = _limpar_na(row.get("specificEpithet"))
                binom = f"{gen} {ep}" if gen and ep else None
                if st == "accepted" and rk == "species" and binom and _genero_valido(gen):
                    hab = (hab_por_id.get(tid) or "").upper()
                    if hab == "MARINHO":
                        continue
                    ufs = sorted(ufs_por_id.get(tid, set()))
                    fam = _limpar_na(row.get("family"))
                    ord_ = _limpar_na(row.get("order"))
                    eh_tox = (
                        (fam and fam.lower() in FAMILIAS_FAUNA_TOXINOLOGICA)
                        or (ord_ and ord_.lower() in ORDENS_FAUNA_TOXINOLOGICA)
                        or (binom.lower() in taxids_toxprot_nomes)
                    )
                    tem_core_amz = bool(set(ufs) & UFS_CORE_AMAZONIA)
                    tem_legal_amz = bool(set(ufs) & UFS_AMAZONIA_LEGAL)
                    tem_amz = int(tem_core_amz or (eh_tox and tem_legal_amz))
                    est_raw = (estab_por_id.get(tid) or "").lower()
                    endem = "endemica" if "endem" in est_raw else ("nao_endemica" if est_raw else None)
                    if "introd" in est_raw or "exot" in est_raw:
                        status_or = "introduzida"
                    elif "nativ" in est_raw or "endem" in est_raw:
                        status_or = "nativa"
                    else:
                        status_or = _limpar_na(estab_por_id.get(tid))
                    aceitos_por_id[tid] = {
                        "fonte": "ctfb_fauna",
                        "taxon_id_fonte": tid,
                        "nome_aceito": binom,
                        "autoria": _limpar_na(row.get("scientificNameAuthorship")),
                        "reino": "Animalia",
                        "filo": _limpar_na(row.get("phylum")),
                        "classe": _limpar_na(row.get("class")),
                        "ordem": ord_,
                        "familia": fam,
                        "genero": gen,
                        "grupo_bmb": "animal_peconhento" if eh_tox else "animal_outro",
                        "status_origem_br": status_or,
                        "endemismo_br": endem,
                        "dominios_list": ["Amazônia"] if tem_amz else [],
                        "ufs_list": ufs,
                        "bioma_amazonia_declarado": tem_amz,
                        "forma_vida": forma_por_id.get(tid),
                        "substrato_habitat": hab_por_id.get(tid),
                        "sinonimos": set(),
                        "sinonimos_autoria": {},
                        "consulta_id": cid,
                    }
                elif st == "synonym" and row.get("acceptedNameUsageID"):
                    nome_sin, cat_sin = nome_do_registro(gen, ep, _limpar_na(row.get("infraspecificEpithet")), rk)
                    if nome_sin:
                        sins_brutos.append((nome_sin, row["acceptedNameUsageID"].strip(),
                                            _limpar_na(row.get("scientificNameAuthorship")), cat_sin))

    _deduplicar_aceitos(aceitos_por_id, sins_brutos)
    return list(aceitos_por_id.values()), _aplicar_sinonimos(aceitos_por_id, sins_brutos)


def construir_universo_checklist(con, nomes_toxprot: set[str] | None = None, log=print) -> dict:
    """Popula `universo_checklist` com as espécies amazônicas aceitas em JBRJ e CTFB e devolve índices em memória."""
    nomes_toxprot = {n.strip().lower() for n in (nomes_toxprot or set()) if n}
    arq_jbrj, cid_jbrj = garantir_arquivo_dump(con, "jbrj_flora_funga_dwca.zip", URL_JBRJ_DWCA, "jbrj_dwca", "IPT-JBRJ-DwCA", log)
    arq_ctfb, cid_ctfb = garantir_arquivo_dump(con, "ctfb_fauna_dwca.zip", URL_CTFB_DWCA, "ctfb_dwca", "IPT-CTFB-DwCA", log)

    log("  Lendo Flora e Funga do Brasil (JBRJ DwC-A)…")
    lista_jbrj, _ = _parse_jbrj(arq_jbrj, cid_jbrj)
    log("  Lendo Catálogo Taxonômico da Fauna do Brasil (CTFB DwC-A)…")
    lista_ctfb, _ = _parse_ctfb(arq_ctfb, cid_ctfb, nomes_toxprot)

    nomes_em_taxon = {r[0].lower() for r in con.execute("SELECT nome FROM taxon").fetchall()}

    # Indexa todos os registros (amazônicos + os já presentes em `taxon`) para reconciliação instantânea
    catalogo_completo_por_nome: dict[str, dict] = {}
    linhas_gravar = []
    for ent in lista_jbrj + lista_ctfb:
        chave_acc = ent["nome_aceito"].lower()
        catalogo_completo_por_nome[chave_acc] = ent
        for s in ent["sinonimos"]:
            catalogo_completo_por_nome.setdefault(s, ent)
        if ent["bioma_amazonia_declarado"] == 1 or chave_acc in nomes_em_taxon:
            sins_ord = sorted(ent["sinonimos"])
            sins_aut = [ent["sinonimos_autoria"][k] for k in sins_ord if k in ent["sinonimos_autoria"]]
            linhas_gravar.append((
                ent["fonte"],
                ent["taxon_id_fonte"],
                ent["nome_aceito"],
                ent["autoria"],
                ent["reino"],
                ent["filo"],
                ent["classe"],
                ent["ordem"],
                ent["familia"],
                ent["genero"],
                ent["grupo_bmb"],
                ent["status_origem_br"],
                ent["endemismo_br"],
                json_compacto(ent["dominios_list"]) if ent["dominios_list"] else None,
                json_compacto(ent["ufs_list"]) if ent["ufs_list"] else None,
                ent["bioma_amazonia_declarado"],
                ent["forma_vida"],
                ent["substrato_habitat"],
                json_compacto(sins_ord) if sins_ord else None,
                json_compacto(sins_aut) if sins_aut else None,
                ent["consulta_id"],
            ))

    # O universo é dado derivado dos dois arquivos: registro que deixou de sair deles (duplicata no catálogo de
    # origem, gênero «Incertae sedis») sai da tabela.
    atuais = {(l[0], l[1]) for l in linhas_gravar}
    for r in con.execute("SELECT id, fonte, taxon_id_fonte FROM universo_checklist").fetchall():
        if (r["fonte"], r["taxon_id_fonte"]) not in atuais:
            con.execute("DELETE FROM universo_checklist WHERE id=?", (r["id"],))
    con.executemany(
        "INSERT INTO universo_checklist ("
        "fonte, taxon_id_fonte, nome_aceito, autoria, reino, filo, classe, ordem, familia, genero, "
        "grupo_bmb, status_origem_br, endemismo_br, dominios_fitogeograficos, ufs_distribuicao, "
        "bioma_amazonia_declarado, forma_vida, substrato_habitat, sinonimos_json, sinonimos_autoria_json, consulta_id"
        ") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
        "ON CONFLICT(fonte, taxon_id_fonte) DO UPDATE SET "
        "nome_aceito=excluded.nome_aceito, autoria=excluded.autoria, grupo_bmb=excluded.grupo_bmb, "
        "status_origem_br=excluded.status_origem_br, endemismo_br=excluded.endemismo_br, "
        "dominios_fitogeograficos=excluded.dominios_fitogeograficos, ufs_distribuicao=excluded.ufs_distribuicao, "
        "bioma_amazonia_declarado=excluded.bioma_amazonia_declarado, forma_vida=excluded.forma_vida, "
        "substrato_habitat=excluded.substrato_habitat, sinonimos_json=excluded.sinonimos_json, "
        "sinonimos_autoria_json=excluded.sinonimos_autoria_json, "
        "consulta_id=excluded.consulta_id",
        linhas_gravar,
    )
    con.commit()

    n_amz = con.execute("SELECT COUNT(*) FROM universo_checklist WHERE bioma_amazonia_declarado=1").fetchone()[0]
    por_grupo = dict(con.execute(
        "SELECT grupo_bmb, COUNT(*) FROM universo_checklist WHERE bioma_amazonia_declarado=1 GROUP BY grupo_bmb"
    ).fetchall())
    return {
        "gravados_universo": len(linhas_gravar),
        "amazonia_aceitos": n_amz,
        "por_grupo_amazonia": por_grupo,
        "catalogo_por_nome": catalogo_completo_por_nome,
        "cid_jbrj": cid_jbrj,
        "cid_ctfb": cid_ctfb,
    }


def _candidatos_de_reconciliacao(catalogo_por_nome: dict[str, dict], nome: str, sinonimos) -> list[dict]:
    """Entradas do checklist que correspondem ao táxon: primeiro pelo nome aceito; depois por sinônimo do GBIF, mas
    só quando o sinônimo é de categoria espécie e tem a mesma autoria do nome que ele encontra no checklist.
    Um sinônimo sem autoria (texto simples) não serve: o mesmo binômio pode ser de outro autor e de outra espécie."""
    from ..taxonomia import mesma_autoria
    achados = []
    ent = catalogo_por_nome.get((nome or "").strip().lower())
    if ent:
        achados.append(ent)
    for s in sinonimos or ():
        if not isinstance(s, dict) or (s.get("categoria") or "").upper() != "SPECIES" or not s.get("autoria"):
            continue
        chave_s = (s.get("nome") or "").strip().lower()
        ent = catalogo_por_nome.get(chave_s)
        if not ent:
            continue
        if ent["nome_aceito"].lower() == chave_s:
            autoria_no_checklist = ent.get("autoria")
        else:
            autoria_no_checklist = (ent.get("sinonimos_autoria", {}).get(chave_s) or {}).get("autoria")
        if mesma_autoria(s["autoria"], autoria_no_checklist):
            achados.append(ent)
    return achados


def reconciliar_via_dwca_local(catalogo_por_nome: dict[str, dict], nome: str, reino: str, sinonimos=()) -> dict | None:
    """Reconcilia um táxon diretamente contra os arquivos DwC-A oficiais JBRJ/CTFB em memória.

    `sinonimos`: dicionários `{nome, autoria, categoria}` vindos de `taxon_sinonimo` (ver
    `_candidatos_de_reconciliacao`)."""
    for ent in _candidatos_de_reconciliacao(catalogo_por_nome, nome, sinonimos):
        if ent and (not reino or ent["reino"] == reino):
            lfs = [x.strip() for x in (ent["forma_vida"] or "").split(";") if x.strip()]
            hbs = [x.strip() for x in (ent["substrato_habitat"] or "").split(";") if x.strip()]
            estrato = checklists_br._derivar_estrato(
                ent["reino"],
                ent["nome_aceito"],
                lfs,
                hbs,
                [],
            )
            st_raw = (ent["status_origem_br"] or "").strip().lower()
            if st_raw == "nativa":
                origem_est = "nativa"
            elif st_raw in ("introduzida", "naturalizada", "cultivada", "exotica", "exótica"):
                origem_est = "introduzida"
            elif ent["reino"] in ("Plantae", "Fungi") and ent["dominios_list"]:
                origem_est = "nativa"
            else:
                origem_est = "indeterminada"
            endem = ent["endemismo_br"] if ent["endemismo_br"] in ("endemica", "nao_endemica", "indeterminado") else None
            fv_partes = []
            if ent["forma_vida"]:
                fv_partes.append(ent["forma_vida"])
            if ent["substrato_habitat"]:
                fv_partes.append(ent["substrato_habitat"])
            return {
                "origem_estabelecimento": origem_est,
                "endemismo_br": endem,
                "biomas": ent["dominios_list"] or None,
                "forma_vida": " · ".join(fv_partes) if fv_partes else None,
                "estrato_florestal": estrato,
                "categoria_mma": None,
                "checklist_fonte": "Flora e Funga do Brasil (JBRJ DwC-A)" if ent["fonte"] == "jbrj_flora_funga" else "Catálogo Taxonômico da Fauna do Brasil (CTFB DwC-A)",
                "checklist_consulta_id": ent["consulta_id"],
            }
    return None
