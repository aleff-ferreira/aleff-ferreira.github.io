# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""The Natural Products Atlas — NPAtlas (CC BY 4.0): metabólitos secundários de fungos e microrganismos.

Aceita apenas compostos fúngicos cujo organismo de origem (`genus + origin_species`) esteja identificado até
espécie (recusando `sp.`, `spp.`, `cf.`, `aff.`), sustentados por DOI ou PMID primário e com InChIKey padrão de
27 caracteres revalidado via RDKit. O nome do organismo é usado inteiro: quando a base registra variedade ou
forma, ela fica no nome; designações de linhagem (códigos de coleção) não fazem parte dele.
"""
import csv
import io

from .. import quimica
from . import lotus
from .nubbe import _MARCADORES_DE_CATEGORIA, _padronizar_estrutura

API = "https://www.npatlas.org/api/v1"
URL_DUMP_NPATLAS = "https://www.npatlas.org/static/downloads/NPAtlas_download.tsv"

_EPITETOS_INVALIDOS = frozenset({
    "sp", "spp", "cf", "aff", "fungus", "fungi", "endophyte",
    "strain", "isolate", "unidentified", "unknown", "indet",
})


def nome_do_fungo(origin_type, genus, origin_species):
    """Nome do organismo como o NPAtlas o dá, ou None quando não é fungo identificado até espécie."""
    if not (origin_type or "").strip().lower().startswith("fung"):
        return None
    g = (genus or "").strip()
    s_raw = (origin_species or "").strip()
    if not g or not g.isalpha() or not s_raw:
        return None
    baixo = s_raw.lower()
    for marcador in ("sp.", "spp.", "cf.", "aff."):
        if marcador in baixo:
            return None
    toks = s_raw.split()
    ep = toks[0].lower().strip(".,;()")
    if not ep.isalpha() or len(ep) < 3 or ep in _EPITETOS_INVALIDOS:
        return None
    nome = f"{g.capitalize()} {ep}"
    if len(toks) >= 3:
        marcador = _MARCADORES_DE_CATEGORIA.get(toks[1].lower())
        infra = toks[2].lower().strip(".,;()")
        if marcador and infra.isalpha() and len(infra) >= 3:
            return f"{nome} {marcador} {infra}"
    return nome


def carregar_indice(cli):
    """Baixa (ou lê do cache com SHA-256) o TSV oficial do NPAtlas e indexa as linhas fúngicas pelo nome do organismo."""
    cached = getattr(cli, "_indice_npatlas", None)
    if cached is not None:
        return cached
    resp = cli.get(
        URL_DUMP_NPATLAS,
        fonte="npatlas",
        accept="text/tab-separated-values, */*",
        como_json=False,
        tentativas=3,
    )
    texto_tsv = resp.dados if isinstance(resp.dados, str) else ""
    por_organismo = {}
    leitor = csv.DictReader(io.StringIO(texto_tsv), delimiter="\t")
    for row in leitor:
        nome_org = nome_do_fungo(row.get("origin_type"), row.get("genus"), row.get("origin_species"))
        if not nome_org:
            continue
        doi = lotus.normalizar_doi(row.get("original_reference_doi"))
        pmid_raw = (row.get("original_reference_pmid") or "").strip()
        pmid = pmid_raw if pmid_raw.isdigit() else None
        if not doi and not pmid:
            continue
        smi = (row.get("compound_smiles") or "").strip()
        npaid = (row.get("npaid") or "").strip()
        if not smi or not npaid:
            continue
        por_organismo.setdefault(nome_org, []).append((row, doi, pmid))
    resultado = (por_organismo, resp.consulta_id)
    try:
        setattr(cli, "_indice_npatlas", resultado)
    except AttributeError:
        pass
    return resultado


def _classe_npclassifier(dados_np):
    if not isinstance(dados_np, dict):
        return None
    bloco = dados_np.get("data") if isinstance(dados_np.get("data"), dict) else dados_np
    partes = [bloco.get("pathway_results"), bloco.get("superclass_results")]
    flat = []
    for pt in partes:
        if isinstance(pt, list) and pt and pt[0]:
            flat.append(str(pt[0]))
        elif isinstance(pt, str) and pt:
            flat.append(pt)
    return " › ".join(flat) if flat else None


def compostos_do_fungo(cli, nomes_do_organismo, enriquecer_classes=True, classes_locais=None):
    """Compostos fúngicos do NPAtlas para os organismos indicados, pelo nome INTEIRO que a base usa.

    `nomes_do_organismo` são os nomes já decididos por `bmb.taxonomia.Resolvedor` como pertencentes ao táxon; aqui
    não se faz casamento por sinônimo nem se corta nome. Devolve `(lista_compostos, consulta_id)`; cada composto
    leva `organismos`, os nomes da base de onde veio.
    """
    alvos = {" ".join(n.split()).lower() for n in nomes_do_organismo if n and len(n.split()) >= 2}
    if not alvos:
        return [], None

    por_organismo, consulta_id_base = carregar_indice(cli)
    linhas_casadas = []
    vistos_npaid = set()
    for nome_org in sorted(por_organismo):
        if nome_org.lower() not in alvos:
            continue
        for row, doi, pmid in por_organismo[nome_org]:
            npaid = row["npaid"].strip()
            chave = (npaid, doi or "", pmid or "", nome_org)
            if chave not in vistos_npaid:
                vistos_npaid.add(chave)
                linhas_casadas.append((row, doi, pmid, nome_org))

    if not linhas_casadas:
        return [], consulta_id_base

    cache_smi = {}
    por_ik = {}
    npaids_para_classe = []

    for row, doi, pmid, nome_org in linhas_casadas:
        smi = row["compound_smiles"].strip()
        if smi not in cache_smi:
            cache_smi[smi] = _padronizar_estrutura(smi)
        est = cache_smi[smi]
        if not est:
            continue
        ik = est["inchikey"]
        npaid = row["npaid"].strip()
        nome_mol = quimica.limpar_nome_quimico(row.get("compound_name") or ik)
        autores_raw = row.get("original_reference_author_list") or ""
        autores = [a.strip() for a in autores_raw.split(";") if a.strip()][:10]
        ano_raw = (row.get("original_reference_year") or "").strip()
        chave_ref = doi or f"pmid:{pmid}"

        ent = por_ik.get(ik)
        if ent is None:
            cls_ini = (classes_locais or {}).get(ik)
            ent = {
                "npatlas_id": npaid,
                "inchikey": ik,
                "smiles": est["smiles"],
                "formula": est["formula"],
                "massa": est["massa"],
                "nome": nome_mol,
                "classe": cls_ini,
                "consulta_id": consulta_id_base,
                "referencias": {},
                "organismos": set(),
            }
            por_ik[ik] = ent
            if not cls_ini:
                npaids_para_classe.append((ik, npaid))
        ent["organismos"].add(nome_org)
        ent["referencias"][chave_ref] = {
            "doi": doi,
            "pmid": pmid,
            "titulo": (row.get("original_reference_title") or "").strip() or None,
            "revista": (row.get("original_journal_title") or "").strip() or None,
            "ano": int(ano_raw) if ano_raw.isdigit() else None,
            "autores": autores or None,
        }

    if enriquecer_classes and npaids_para_classe:
        pedidos = [(f"{API}/compound/{npaid}/npclassifier", None) for _, npaid in npaids_para_classe]
        respostas = cli.get_varios(pedidos, fonte="npatlas", tentativas=2, ignorar_erros=True)
        for (ik, _), resp in zip(npaids_para_classe, respostas):
            ok_resp = getattr(resp, "ok", 200 <= getattr(resp, "status", 0) < 300)
            if resp is not None and ok_resp and isinstance(resp.dados, dict):
                cls = _classe_npclassifier(resp.dados)
                if cls:
                    por_ik[ik]["classe"] = cls

    for ent in por_ik.values():
        ent["organismos"] = sorted(ent["organismos"])
    saida = sorted(por_ik.values(), key=lambda x: (-len(x["referencias"]), x["nome"].lower()))
    return saida, consulta_id_base
