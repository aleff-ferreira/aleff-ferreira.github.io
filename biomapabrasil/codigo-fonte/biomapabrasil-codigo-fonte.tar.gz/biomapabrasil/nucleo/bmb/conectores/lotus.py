# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""LOTUS: pares estrutura–organismo referenciados por DOI.

Suporta dois modos auditáveis com proveniência SHA-256:
  1. **Dump congelado Zenodo (`10.5281/zenodo.19360665`, `260413_frozen_metadata.csv.gz`)**:
     indexação determinística em escala de bioma (plantas, fungos e animais) com `manual_validation`,
     `PubChem CID`, `SMILES` isomérico validado via RDKit (Standard InChIKey de 27 caracteres) e
     taxonomia química `NPClassifier`.
  2. **API REST simples (`lotus.naturalproducts.net/api/search/simple`)**:
     mantida para consultas incrementais pontuais e compatibilidade com testes unitários offline.
"""
from __future__ import annotations

import csv
import gzip
from pathlib import Path

from .. import quimica
from . import catalogo_nacional_dwca as cat_dwca

API = "https://lotus.naturalproducts.net/api/search/simple"
URL_ZENODO_LOTUS_METADATA = "https://zenodo.org/api/records/19360665/files/260413_frozen_metadata.csv.gz/content"
VERSAO_ZENODO_LOTUS = "10.5281/zenodo.19360665 (260413)"

# O LOTUS troca o ponto do DOI por este marcador na API JSON, porque o ponto não serve de chave no MongoDB deles.
MARCADOR_PONTO = "$x$x$"


def normalizar_doi(doi):
    """DOI em minúsculas, sem prefixo de URL; None se não parecer um DOI."""
    d = (doi or "").strip().replace(MARCADOR_PONTO, ".")
    for prefixo in ("https://doi.org/", "http://doi.org/", "https://dx.doi.org/", "doi:"):
        if d.lower().startswith(prefixo):
            d = d[len(prefixo):]
    d = d.strip().lower()
    return d if d.startswith("10.") and "/" in d else None


def _casa(organismo, nomes):
    """O organismo do registro é o táxon-alvo ou um infraespecífico dele (subsp., var., com autoria)."""
    o = (organismo or "").strip().lower()
    if not o:
        return False
    return any(o == n or o.startswith(n + " ") for n in nomes)


def _nome_exibicao(p):
    """Nome do composto: o nome tradicional se curto, senão o IUPAC; o InChIKey como último recurso."""
    for chave in ("traditional_name", "iupac_name"):
        v = (p.get(chave) or "").strip()
        if v and len(v) <= 90:
            return v
    return (p.get("traditional_name") or p.get("iupac_name") or p.get("inchikey") or "composto sem nome").strip()


def limpar_classe(texto):
    """'Alkaloids|Alkaloids › Purine alkaloids|Purine alkaloids' -> 'Alkaloids › Purine alkaloids'."""
    if not texto:
        return None
    niveis = []
    for nivel in texto.split(" › "):
        primeiro = nivel.split("|")[0].strip()
        if primeiro and primeiro not in niveis:
            niveis.append(primeiro)
    return " › ".join(niveis) or None


def _classe(p):
    partes = [p.get("chemicalTaxonomyNPclassifierPathway"), p.get("chemicalTaxonomyNPclassifierClass")]
    partes = [x.strip() for x in partes if x and x.strip()]
    if not partes:
        partes = [x.strip() for x in (p.get("chemicalTaxonomyClassyfireSuperclass"),
                                      p.get("chemicalTaxonomyClassyfireClass")) if x and x.strip()]
    return limpar_classe(" › ".join(partes))


def nome_de_especie(row) -> str | None:
    """Nome de nível de espécie que o próprio LOTUS dá ao organismo (campo `organism_taxonomy_09species`).

    Serve só para saber de qual espécie um organismo infraespecífico faz parte segundo a fonte. Nunca se obtém
    cortando um nome: «Capsicum annuum var. baccatum» não é «Capsicum annuum» para efeito de sinonímia.
    """
    v = (row.get("organism_taxonomy_09species") or "").strip()
    return v if v and v.upper() != "NA" and len(v.split()) >= 2 else None


def _composto_da_linha(row, ik, classes_por_ik):
    smi = (row.get("structure_smiles") or row.get("structure_smiles_2D") or "").strip() or None
    trad = (row.get("structure_nameTraditional") or "").strip()
    iupac = (row.get("structure_nameIupac") or "").strip()
    trad = "" if trad.upper() == "NA" else trad
    iupac = "" if iupac.upper() == "NA" else iupac
    nome_bruto = trad if (trad and len(trad) <= 90) else (iupac if (iupac and len(iupac) <= 90) else (trad or iupac or ik))
    wd_raw = (row.get("structure_wikidata") or "").strip()
    massa_s = (row.get("structure_exact_mass") or "").strip()
    try:
        massa = round(float(massa_s), 4) if massa_s and massa_s.upper() != "NA" else None
    except ValueError:
        massa = None
    cid_pc_s = (row.get("structure_cid") or "").strip()
    formula = (row.get("structure_molecular_formula") or "").strip()
    return {
        "lotus_id": wd_raw.rsplit("/", 1)[-1] if wd_raw else f"IK_{ik[:14]}",
        "inchikey": ik,
        "smiles": smi,
        "formula": None if (not formula or formula.upper() == "NA") else formula,
        "massa": massa,
        "pubchem_cid": int(float(cid_pc_s)) if cid_pc_s and cid_pc_s.replace(".", "", 1).isdigit() else None,
        "nome": quimica.limpar_nome_quimico(nome_bruto) or ik,
        "classe": classes_por_ik.get(ik),
        "validacao_manual": 0,
        "referencias": {},
    }


def indexar_dump_por_organismo(con, generos: set[str] | None = None, nomes: set[str] | None = None, log=print):
    """Lê (ou baixa, com SHA-256) o dump congelado e indexa os registros pelo organismo COMO O LOTUS O ESCREVE.

    A chave é `(organism_name, organism_taxonomy_gbifid)`: o nome inteiro, com epíteto infraespecífico quando houver,
    e o identificador do GBIF que o LOTUS atribui ao organismo. Nenhum nome é reduzido a binômio. Quem decide a que
    táxon do banco cada organismo pertence é `bmb.taxonomia.Resolvedor`, pelo identificador.

    `generos` / `nomes` (em minúsculas) limitam o que fica em memória: entra o organismo cujo gênero está em `generos`
    ou cujo nome (inteiro ou de espécie segundo o LOTUS) está em `nomes`. Sem filtros, indexa tudo.

    Devolve `(por_organismo, classes_por_ik, consulta_id)`, com
    `por_organismo[(nome, gbifid)] = {"familia", "reino", "especie_lotus", "compostos": {inchikey: composto}}`.
    """
    arq, cid = cat_dwca.garantir_arquivo_dump(
        con, "260413_frozen_metadata.csv.gz", URL_ZENODO_LOTUS_METADATA, "lotus", VERSAO_ZENODO_LOTUS, log=log)
    por_organismo: dict[tuple[str, str], dict] = {}
    classes_por_ik: dict[str, str] = {}
    csv.field_size_limit(1 << 30)
    log("  Indexando dump congelado LOTUS Zenodo 10.5281/zenodo.19360665 por organismo…")
    with gzip.open(arq, "rt", encoding="utf-8", errors="replace") as gz:
        for row in csv.DictReader(gz):
            ik = (row.get("structure_inchikey") or "").strip()
            if len(ik) != 27 or ik[14] != "-" or ik[25] != "-":
                continue
            if ik not in classes_por_ik:
                p_np = (row.get("structure_taxonomy_npclassifier_01pathway") or "").strip()
                c_np = (row.get("structure_taxonomy_npclassifier_03class") or row.get("structure_taxonomy_npclassifier_02superclass") or "").strip()
                partes = [x for x in (p_np, c_np) if x and x.upper() != "NA"]
                if not partes:
                    p_cf = (row.get("structure_taxonomy_classyfire_02superclass") or "").strip()
                    c_cf = (row.get("structure_taxonomy_classyfire_03class") or "").strip()
                    partes = [x for x in (p_cf, c_cf) if x and x.upper() != "NA"]
                if partes:
                    cl = limpar_classe(" › ".join(partes))
                    if cl:
                        classes_por_ik[ik] = cl
            nome = " ".join((row.get("organism_name") or "").split())
            toks = nome.split()
            if len(toks) < 2 or toks[1].strip(".").lower() in ("sp", "spp", "cf", "aff", "x", "×"):
                continue
            especie = nome_de_especie(row)
            if generos is not None or nomes is not None:
                dentro = (generos is not None and toks[0].lower() in generos) or (
                    nomes is not None and (nome.lower() in nomes or (especie or "").lower() in nomes))
                if not dentro:
                    continue
            doi = normalizar_doi(row.get("reference_doi"))
            if not doi:
                continue
            gbifid = (row.get("organism_taxonomy_gbifid") or "").strip()
            gbifid = gbifid if gbifid.isdigit() else ""
            org = por_organismo.get((nome, gbifid))
            if org is None:
                fam = (row.get("organism_taxonomy_06family") or "").strip()
                reino = (row.get("organism_taxonomy_02kingdom") or "").strip()
                org = por_organismo[(nome, gbifid)] = {
                    "familia": None if (not fam or fam.upper() == "NA") else fam,
                    "reino": None if (not reino or reino.upper() == "NA") else reino,
                    "especie_lotus": especie, "compostos": {}}
            ent = org["compostos"].get(ik)
            if ent is None:
                ent = org["compostos"][ik] = _composto_da_linha(row, ik, classes_por_ik)
            if (row.get("manual_validation") or "").strip().upper() in ("TRUE", "1", "T", "YES"):
                ent["validacao_manual"] = 1
            bases = ent["referencias"].setdefault(doi, set())
            if gbifid:
                bases.add("GBIF")
            if (row.get("organism_taxonomy_ncbiid") or "").strip() not in ("", "NA"):
                bases.add("NCBI")
            if not bases:
                bases.add("Wikidata/LOTUS")
    return por_organismo, classes_por_ik, cid


def compostos_por_taxon(por_organismo: dict, decisoes: dict) -> dict[int, list[dict]]:
    """Agrupa os compostos por táxon do banco, usando a decisão tomada para cada organismo da fonte.

    `decisoes[(nome, gbifid)]` é uma `taxonomia.Decisao`. Entram os organismos aceitos e, à parte, os de homônimo não
    resolvido (que nascem retidos). Cada composto leva os nomes de organismo que a fonte usou e, por referência,
    de qual organismo ela veio. Devolve `{taxon_id: [composto, …]}` em ordem estável.
    """
    por_taxon: dict[int, dict[str, dict]] = {}
    for chave_org, org in por_organismo.items():
        d = decisoes.get(chave_org)
        if d is None or d.taxon_id is None or d.decisao not in ("aceito", "aceito_mesmo_nome_e_autoria", "homonimo_nao_resolvido"):
            continue
        firme = d.decisao != "homonimo_nao_resolvido"
        alvo = por_taxon.setdefault(d.taxon_id, {})
        for ik, c in org["compostos"].items():
            m = alvo.get(ik)
            if m is None:
                m = alvo[ik] = {**c, "referencias": {}, "organismos": set(), "organismos_homonimo": set(), "firme": False}
            if c.get("validacao_manual"):
                m["validacao_manual"] = 1
            (m["organismos"] if firme else m["organismos_homonimo"]).add(chave_org[0])
            m["firme"] = m["firme"] or firme
            for doi, bases in c["referencias"].items():
                ref = m["referencias"].setdefault(doi, {"bases": set(), "firme": False})
                ref["bases"].update(bases)
                ref["firme"] = ref["firme"] or firme
    saida = {}
    for tid, comps in por_taxon.items():
        lista = []
        for c in comps.values():
            # com ao menos um organismo aceito, só valem as referências que vieram de organismo aceito
            refs = {d: sorted(v["bases"]) for d, v in c["referencias"].items() if v["firme"] or not c["firme"]}
            lista.append({**c, "referencias": refs, "organismos": sorted(c["organismos"] or c["organismos_homonimo"]),
                          "organismos_homonimo": sorted(c["organismos_homonimo"])})
        lista.sort(key=lambda x: (-len(x["referencias"]), x["nome"].lower(), x["inchikey"]))
        saida[tid] = lista
    return saida


def compostos_do_taxon(cli, nome_busca, nomes_aceitos):
    """Compostos relatados no táxon via API REST do LOTUS (mantido para consultas unitárias/testes)."""
    r = cli.get(API, {"query": nome_busca}, fonte="lotus", tentativas=3)
    dados = r.dados if isinstance(r.dados, dict) else {}
    # Caminho legado por nome, sem identificador taxonômico: só o nome aceito (primeiro da lista) e os seus
    # infraespecíficos valem. Sinônimos exigem o caminho do dump, que resolve o organismo pelo identificador.
    alvo = {n.strip().lower() for n in list(nomes_aceitos)[:1] if n}
    saida = []
    for p in dados.get("naturalProducts") or []:
        refs = {}
        for cod, bases in (p.get("taxonomyReferenceObjects") or {}).items():
            doi = normalizar_doi(cod)
            if not doi:
                continue
            for base, entradas in (bases or {}).items():
                if any(_casa(e.get("organism_value"), alvo) for e in entradas or []):
                    refs.setdefault(doi, set()).add(base)
        if not refs or not p.get("inchikey"):
            continue
        saida.append({
            "lotus_id": p.get("lotus_id") or f"IK_{p['inchikey'][:14]}",
            "inchikey": p["inchikey"],
            "smiles": p.get("smiles"),
            "formula": p.get("molecular_formula"),
            "massa": p.get("molecular_weight"),
            "nome": _nome_exibicao(p),
            "classe": _classe(p),
            "validacao_manual": None,
            "referencias": {d: sorted(b) for d, b in refs.items()},
        })
    saida.sort(key=lambda c: (-len(c["referencias"]), c["nome"].lower()))
    return saida, r
