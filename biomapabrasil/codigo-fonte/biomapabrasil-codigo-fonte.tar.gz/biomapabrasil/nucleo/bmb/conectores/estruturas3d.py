# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Verificação universal e geração de estruturas tridimensionais com rigor epistêmico estrito:

  1. `experimental` (`rcsb_pdb` / `cod`): coordenadas atômicas experimentais originadas de difração de
     raios X, difração de nêutrons, RMN em solução ou criomicroscopia eletrônica (wwPDB CCD `_model.sdf`
     pareado a entrada PDB experimental verificada, entradas macromoleculares RCSB PDB e monocristais
     Crystallography Open Database COD validados por isomorfismo e InChIKey estereoquímico de 27 caracteres);
  2. `predicao_computacional` (`alphafold` / `esm_atlas`): modelos proteicos AlphaFold DB ou ESMFold v1
     com confiança por resíduo (`pLDDT` 0–100);
  3. `conformero_calculado` (`rdkit_local`): ensembles ETKDGv3 de pequenas moléculas elegíveis ainda sem geometria.
     A energia de ponto único MMFF94s ordena os candidatos. O percurso de peptídeos é separado.

Armazena as geometrias em 256 lotes compactados (`saida/estruturas3d_lotes/00.json .. ff.json`, formato
binário `bm32z` com coordenadas exatas `float32` para estruturas experimentais) e reconstrói arquivos
BIOVIA MDL SDF 3D (`V2000` / `V3000`) quimicamente válidos para download offline e via API.
"""
from __future__ import annotations

import base64
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
import csv
import hashlib
import io
import json
import math
import os
import re
import struct
import time
import zlib
from pathlib import Path

from .. import config
from ..util import agora

SEMENTE_3D = 20261111
API_RCSB = "https://data.rcsb.org/rest/v1/core/entry"
GQL_RCSB = "https://data.rcsb.org/graphql"
ARQ_RCSB = "https://files.rcsb.org/download"
URL_CCD_IK = "https://ftp.ebi.ac.uk/pub/databases/msd/pdbechem_v2/ccd/components_inchikeys.csv"
URL_PDBE_STATIC = "https://www.ebi.ac.uk/pdbe/static/files/pdbechem_v2"
URL_COD_SMI = "https://www.crystallography.net/cod/smi/allcod.smi"
URL_COD_CIF = "https://www.crystallography.net/cod"
API_AF = "https://alphafold.ebi.ac.uk/api/prediction"
API_ESMFOLD = "https://api.esmatlas.com/foldSequence/v1/pdb/"
API_UNIPROT = "https://rest.uniprot.org/uniprotkb"

_HDR_BM32 = struct.Struct("<4sBBIIffff")
_MAGIC_BM32 = b"BM32"

_CIP_ENCODE = {"": 0, "R": 1, "S": 2, "r": 3, "s": 4, "?": 5}
_CIP_DECODE = {0: "", 1: "R", 2: "S", 3: "r", 4: "s", 5: "?"}

_ELEMENTOS = (
    "", "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne",
    "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca",
    "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
    "Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr",
    "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn",
    "Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd",
    "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb",
    "Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg",
    "Tl", "Pb", "Bi", "Po", "At", "Rn",
)


def json_canonico_bytes(obj: dict) -> bytes:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")


def bucket_chave(chave: str) -> str:
    return hashlib.sha256(chave.encode("utf-8")).hexdigest()[:2]


def caminho_lote_3d(chave: str) -> str:
    return f"estruturas3d_lotes/{bucket_chave(chave)}.json#{chave}"


def _registrar_consulta_virtual(con, fonte_id: str, url_virtual: str, corpo_bytes: bytes, versao: str | None = None) -> int:
    sha = hashlib.sha256(corpo_bytes).hexdigest()
    existente = con.execute("SELECT id FROM consulta WHERE url=? AND sha256=?", (url_virtual, sha)).fetchone()
    if existente:
        return existente["id"]
    if versao is None and fonte_id == "rdkit_local":
        from rdkit import __version__ as rdkit_ver
        versao = f"RDKit {rdkit_ver}"
    con.execute(
        "INSERT INTO consulta (fonte_id, url, consultado_em, status, bytes, sha256, versao_fonte) VALUES (?,?,?,?,?,?,?)",
        (fonte_id, url_virtual, agora(), 200, len(corpo_bytes), sha, versao),
    )
    return con.execute("SELECT last_insert_rowid()").fetchone()[0]


def _registrar_consulta_rdkit(con, url_virtual: str, corpo_bytes: bytes) -> int:
    return _registrar_consulta_virtual(con, "rdkit_local", url_virtual, corpo_bytes)


def _upsert_estrutura(
    con, *, molecula_id=None, alvo_id=None, natureza: str, fonte_id: str, codigo: str,
    metodo: str | None = None, resolucao: float | None = None, plddt: float | None = None,
    energia: float | None = None, n_elem: int | None = None, n_ss: int = 0,
    arquivo: str | None = None, sha256: str | None = None, consulta_id: int | None = None,
    tem_sdf_3d: int = 0,
) -> int:
    existente = con.execute(
        "SELECT id FROM estrutura_3d WHERE fonte_id=? AND codigo=? AND IFNULL(molecula_id,0)=IFNULL(?,0) "
        "AND IFNULL(alvo_id,0)=IFNULL(?,0)",
        (fonte_id, codigo, molecula_id, alvo_id),
    ).fetchone()
    if existente:
        con.execute(
            "UPDATE estrutura_3d SET natureza=?, metodo=?, resolucao_angstrom=?, plddt_medio=?, energia_kcal_mol=?, "
            "n_atomos_ou_residuos=?, n_pontes_dissulfeto=?, arquivo_geometria=?, geometria_sha256=?, consulta_id=?, tem_sdf_3d=? "
            "WHERE id=?",
            (natureza, metodo, resolucao, plddt, energia, n_elem, n_ss, arquivo, sha256, consulta_id, int(bool(tem_sdf_3d)), existente["id"]),
        )
        return existente["id"]
    con.execute(
        "INSERT INTO estrutura_3d (molecula_id, alvo_id, natureza, fonte_id, codigo, metodo, resolucao_angstrom, "
        "plddt_medio, energia_kcal_mol, n_atomos_ou_residuos, n_pontes_dissulfeto, arquivo_geometria, geometria_sha256, consulta_id, tem_sdf_3d) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (molecula_id, alvo_id, natureza, fonte_id, codigo, metodo, resolucao, plddt, energia, n_elem, n_ss, arquivo, sha256, consulta_id, int(bool(tem_sdf_3d))),
    )
    return con.execute("SELECT last_insert_rowid()").fetchone()[0]


# ═══════════════════════ Codec binário compacto BM32 + SDF 3D ═══════════════════════
def codificar_mol_bm32z(
    mol, *, forc_f32: bool = False, bfactors: list[float] | None = None, preservar_estereo_entrada: bool = False
) -> tuple[str, int, int]:
    """Codifica um `rdkit.Chem.Mol` 3D em buffer binário `BM32` comprimido com DEFLATE bruto (`b64z`).

    Retorna `(b64z, n_atomos, n_ligacoes)`. Para estruturas experimentais (`forc_f32=True`),
    armazena coordenadas IEEE-754 `float32` exatas sem quantização.
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem

    n_at = mol.GetNumAtoms()
    n_bd = mol.GetNumBonds()
    conf = mol.GetConformer()

    # Cargas parciais de Gasteiger–Marsili em cópia isolada (evita falha em metais/hipervalentes)
    gast = [0.0] * n_at
    try:
        mg = Chem.Mol(mol)
        AllChem.ComputeGasteigerCharges(mg, throwOnParamFailure=False)
        for i in range(n_at):
            v = mg.GetAtomWithIdx(i).GetDoubleProp("_GasteigerCharge")
            if math.isfinite(v):
                gast[i] = v
    except Exception:
        pass

    # Quiralidade CIP (R)/(S) e estereoquímica E/Z
    cip_map: dict[int, str] = {}
    has_chiral = False
    try:
        mc = Chem.Mol(mol)
        if preservar_estereo_entrada:
            Chem.AssignStereochemistry(mc, cleanIt=False, force=True)
        else:
            Chem.AssignStereochemistryFrom3D(mc, replaceExistingTags=False)
        for idx, code in Chem.FindMolChiralCenters(mc, includeUnassigned=True):
            cip_map[idx] = code if code in _CIP_ENCODE else "?"
            if code in ("R", "S", "r", "s"):
                has_chiral = True
    except Exception:
        pass

    # Ordens de ligação Kekulé para exportação SDF V2000/V3000 100% válida no RDKit
    kek_orders = [1] * n_bd
    try:
        mk = Chem.Mol(mol)
        Chem.Kekulize(mk, clearAromaticFlags=False)
        for bi in range(n_bd):
            bt = mk.GetBondWithIdx(bi).GetBondType()
            if bt == Chem.BondType.DOUBLE:
                kek_orders[bi] = 2
            elif bt == Chem.BondType.TRIPLE:
                kek_orders[bi] = 3
            else:
                kek_orders[bi] = 1
    except Exception:
        for bi in range(n_bd):
            bo = int(round(mol.GetBondWithIdx(bi).GetBondTypeAsDouble()))
            kek_orders[bi] = bo if bo in (1, 2, 3) else 1

    xs = [conf.GetAtomPosition(i).x for i in range(n_at)]
    ys = [conf.GetAtomPosition(i).y for i in range(n_at)]
    zs = [conf.GetAtomPosition(i).z for i in range(n_at)]
    cx = sum(xs) / n_at if n_at else 0.0
    cy = sum(ys) / n_at if n_at else 0.0
    cz = sum(zs) / n_at if n_at else 0.0
    dxs = [x - cx for x in xs]
    dys = [y - cy for y in ys]
    dzs = [z - cz for z in zs]
    max_abs = max([abs(v) for v in (*dxs, *dys, *dzs)] or [0.0])

    usar_f32 = bool(forc_f32 or max_abs > 16.0 or n_at > 400)
    usar_idx16 = n_at > 255
    flags = (0x01 if usar_f32 else 0) | (0x02 if usar_idx16 else 0) | (0x04 if has_chiral else 0)
    scale = 1.0 if usar_f32 else (max(max_abs, 1e-4) / 32760.0)

    out = bytearray(_HDR_BM32.pack(_MAGIC_BM32, flags, 0, n_at, n_bd, cx, cy, cz, scale))

    pack_meta = struct.Struct("<BbBbB").pack
    pack_f32 = struct.Struct("<fff").pack
    pack_i16 = struct.Struct("<hhh").pack

    for i in range(n_at):
        at = mol.GetAtomWithIdx(i)
        znum = min(255, max(1, at.GetAtomicNum()))
        fchg = max(-127, min(127, at.GetFormalCharge()))
        cip_c = _CIP_ENCODE.get(cip_map.get(i, ""), 0)
        is_aro = 0x08 if at.GetIsAromatic() else 0
        # Doador / receptor de ligação de hidrogênio
        tem_h_viz = any(nb.GetAtomicNum() == 1 for nb in at.GetNeighbors())
        is_hbd = 0x10 if (znum in (7, 8, 16) and (tem_h_viz or at.GetTotalNumHs() > 0)) else 0
        is_hba = 0x20 if (znum in (7, 8, 9) and fchg <= 0) else 0
        cflags = cip_c | is_aro | is_hbd | is_hba
        gq = max(-127, min(127, int(round(gast[i] * 100.0))))
        bf = 0
        if bfactors and i < len(bfactors) and bfactors[i] is not None and math.isfinite(bfactors[i]):
            bf = max(0, min(255, int(round(bfactors[i] * 2.0))))
        out.extend(pack_meta(znum, fchg, cflags, gq, bf))
        if usar_f32:
            out.extend(pack_f32(dxs[i], dys[i], dzs[i]))
        else:
            out.extend(pack_i16(
                max(-32767, min(32767, int(round(dxs[i] / scale)))),
                max(-32767, min(32767, int(round(dys[i] / scale)))),
                max(-32767, min(32767, int(round(dzs[i] / scale)))),
            ))

    pack_b8 = struct.Struct("<BBB").pack
    pack_b16 = struct.Struct("<HHB").pack
    for bi in range(n_bd):
        bd = mol.GetBondWithIdx(bi)
        a1 = bd.GetBeginAtomIdx()
        a2 = bd.GetEndAtomIdx()
        ko = kek_orders[bi] & 0x07
        aro_bit = 0x08 if bd.GetIsAromatic() else 0
        st = bd.GetStereo()
        ez_bits = 0
        if st == Chem.BondStereo.STEREOE:
            ez_bits = 1 << 4
        elif st == Chem.BondStereo.STEREOZ:
            ez_bits = 2 << 4
        ring_bit = 0x40 if bd.IsInRing() else 0
        bbits = ko | aro_bit | ez_bits | ring_bit
        if usar_idx16:
            out.extend(pack_b16(a1, a2, bbits))
        else:
            out.extend(pack_b8(a1, a2, bbits))

    comp = zlib.compress(bytes(out), level=9, wbits=-15)
    return base64.b64encode(comp).decode("ascii"), n_at, n_bd


def decodificar_bm32z(b64z: str) -> dict:
    """Decodifica um payload `b64z` (`BM32`) em dicionário de átomos, ligações e centroide."""
    raw = zlib.decompress(base64.b64decode(b64z), wbits=-15)
    magic, flags, _, n_at, n_bd, cx, cy, cz, scale = _HDR_BM32.unpack_from(raw, 0)
    if magic != _MAGIC_BM32:
        raise ValueError(f"Assinatura BM32 inválida: {magic!r}")
    usar_f32 = bool(flags & 0x01)
    usar_idx16 = bool(flags & 0x02)
    chiral_flag = 1 if (flags & 0x04) else 0

    pos = _HDR_BM32.size
    s_meta = struct.Struct("<BbBbB")
    s_f32 = struct.Struct("<fff")
    s_i16 = struct.Struct("<hhh")

    atomos = []
    for _ in range(n_at):
        znum, fchg, cflags, gq, bf = s_meta.unpack_from(raw, pos)
        pos += 5
        if usar_f32:
            dx, dy, dz = s_f32.unpack_from(raw, pos)
            pos += 12
        else:
            qx, qy, qz = s_i16.unpack_from(raw, pos)
            pos += 6
            dx, dy, dz = qx * scale, qy * scale, qz * scale
        sym = _ELEMENTOS[znum] if 0 < znum < len(_ELEMENTOS) else "C"
        atomos.append({
            "z_num": znum,
            "s": sym,
            "dx": dx, "dy": dy, "dz": dz,
            "ox": cx + dx, "oy": cy + dy, "oz": cz + dz,
            "q": fchg,
            "g": round(gq / 100.0, 3),
            "cip": _CIP_DECODE.get(cflags & 0x07, ""),
            "aro": bool(cflags & 0x08),
            "hbd": bool(cflags & 0x10),
            "hba": bool(cflags & 0x20),
            "bf": round(bf / 2.0, 1),
        })

    s_b8 = struct.Struct("<BBB")
    s_b16 = struct.Struct("<HHB")
    ligacoes = []
    for _ in range(n_bd):
        if usar_idx16:
            a1, a2, bbits = s_b16.unpack_from(raw, pos)
            pos += 5
        else:
            a1, a2, bbits = s_b8.unpack_from(raw, pos)
            pos += 3
        ez_c = (bbits >> 4) & 0x03
        ligacoes.append({
            "a": a1,
            "b": a2,
            "ko": bbits & 0x07,
            "aro": bool(bbits & 0x08),
            "ez": "E" if ez_c == 1 else ("Z" if ez_c == 2 else ""),
            "ring": bool(bbits & 0x40),
        })

    return {
        "chiral_flag": chiral_flag,
        "centroide": (cx, cy, cz),
        "atomos": atomos,
        "ligacoes": ligacoes,
    }


def gerar_sdf_3d(geom: dict, meta: dict | None = None) -> str:
    """Retorna o membro exato do ensemble ou reconstrói o SDF V2000/V3000 de uma tabela arquivada."""
    meta = meta or {}
    if geom.get("fmt") == "ensemble-sdf-v1":
        return geom["conformeros"][0]["sdf"]
    if "b64z" in geom:
        dec = decodificar_bm32z(geom["b64z"])
        atomos = dec["atomos"]
        ligacoes = dec["ligacoes"]
        chiral = dec["chiral_flag"]
    elif "a" in geom and "b" in geom:
        atomos = [
            {"s": a[0], "ox": a[1], "oy": a[2], "oz": a[3], "q": int(a[4] or 0) if len(a) > 4 else 0}
            for a in geom["a"]
        ]
        ligacoes = [{"a": b[0], "b": b[1], "ko": b[2] if b[2] in (1, 2, 3, 4) else 1} for b in geom["b"]]
        chiral = 1 if geom.get("quiral") else 0
    else:
        raise ValueError("Geometria sem tabela atômica para exportação SDF 3D.")

    titulo = str(meta.get("nome") or geom.get("nome") or geom.get("cod") or "BioMapaBrasil_3D").replace("\n", " ").strip()[:80]
    nat = str(meta.get("natureza") or geom.get("nat") or geom.get("natureza") or "conformero_calculado")
    fonte = str(meta.get("fonte") or geom.get("fonte") or "rdkit_local")
    cod = str(meta.get("acesso") or geom.get("cod") or "")
    met = str(meta.get("metodo") or geom.get("met") or geom.get("metodo") or "")
    comentario = f"BioMapaBrasil 3D | {nat} | {fonte} {cod} | {met}"[:80]

    n_at = len(atomos)
    n_bd = len(ligacoes)
    linhas = [titulo, "  BioMapaB11142612003D 1   1.00000     0.00000     0", comentario]

    if n_at <= 999 and n_bd <= 999:
        linhas.append(f"{n_at:3d}{n_bd:3d}  0  0{chiral:3d}  0  0  0  0  0999 V2000")
        cargas = []
        for idx, at in enumerate(atomos, start=1):
            q = int(at.get("q", 0))
            if q != 0:
                cargas.append((idx, q))
            linhas.append(f"{at['ox']:10.4f}{at['oy']:10.4f}{at['oz']:10.4f} {at['s']:<3s} 0  0  0  0  0  0  0  0  0  0  0  0")
        for bd in ligacoes:
            ko = int(bd.get("ko") or 1)
            if ko not in (1, 2, 3, 4):
                ko = 1
            linhas.append(f"{bd['a'] + 1:3d}{bd['b'] + 1:3d}{ko:3d}  0  0  0  0")
        for ini in range(0, len(cargas), 8):
            fatia = cargas[ini:ini + 8]
            partes = "".join(f" {i:3d} {q:3d}" for i, q in fatia)
            linhas.append(f"M  CHG{len(fatia):3d}{partes}")
        radicais = geom.get("rad") or []
        for ini in range(0, len(radicais), 8):
            fatia = radicais[ini:ini + 8]
            partes = "".join(f" {int(i) + 1:3d} {int(r):3d}" for i, r in fatia)
            linhas.append(f"M  RAD{len(fatia):3d}{partes}")
        linhas.append("M  END")
    else:
        linhas.append("  0  0  0  0  0  0            999 V3000")
        linhas.append("M  V30 BEGIN CTAB")
        linhas.append(f"M  V30 COUNTS {n_at} {n_bd} 0 0 {chiral}")
        linhas.append("M  V30 BEGIN ATOM")
        for idx, at in enumerate(atomos, start=1):
            q = int(at.get("q", 0))
            chg_str = f" CHG={q}" if q != 0 else ""
            linhas.append(f"M  V30 {idx} {at['s']} {at['ox']:.4f} {at['oy']:.4f} {at['oz']:.4f} 0{chg_str}")
        linhas.append("M  V30 END ATOM")
        linhas.append("M  V30 BEGIN BOND")
        for bidx, bd in enumerate(ligacoes, start=1):
            ko = int(bd.get("ko") or 1)
            if ko not in (1, 2, 3, 4):
                ko = 1
            linhas.append(f"M  V30 {bidx} {ko} {bd['a'] + 1} {bd['b'] + 1}")
        linhas.append("M  V30 END BOND")
        linhas.append("M  V30 END CTAB")
        linhas.append("M  END")

    lic_padrao = {
        "rcsb_pdb": "CC0 1.0 (wwPDB Public Domain)",
        "cod": "CC0 1.0 (Crystallography Open Database)",
        "alphafold": "CC BY 4.0 (AlphaFold DB)",
        "esm_atlas": "CC BY 4.0 (ESM Metagenomic Atlas)",
        "rdkit_local": "CC0 1.0 (RDKit deterministic conformer)",
    }.get(fonte, "CC BY 4.0")

    props = [
        ("BMB_MOLECULA_ID", meta.get("molecula_id") or geom.get("id")),
        ("NAME", titulo),
        ("INCHIKEY", meta.get("inchikey") or geom.get("ik")),
        ("FORMULA", meta.get("formula") or geom.get("form")),
        ("NATUREZA_EPISTEMICA", nat),
        ("SOURCE_DATABASE", fonte),
        ("SOURCE_ACCESSION", cod),
        ("EXPERIMENTAL_METHOD", met),
        ("RESOLUTION_ANGSTROM", meta.get("resolucao") or geom.get("res_ang")),
        ("ENERGY_KCAL_MOL", meta.get("energia") or geom.get("e_kcal")),
        ("LICENSE", meta.get("licenca") or lic_padrao),
    ]
    for k, v in props:
        if v is not None and str(v).strip() != "":
            linhas.append(f">  <{k}>")
            linhas.append(str(v).strip())
            linhas.append("")
    linhas.append("$$$$")
    return "\n".join(linhas) + "\n"


# ═══════════════════════ Geração universal determinística de confôrmeros 3D ═══════════════════════
def _minimizar_mol_3d(mol, conf_id: int = 0, max_iters: int = 200) -> tuple[str, float | None]:
    from rdkit.Chem import AllChem

    try:
        if AllChem.MMFFHasAllMoleculeParams(mol):
            props = AllChem.MMFFGetMoleculeProperties(mol, mmffVariant="MMFF94s")
            if props is not None:
                ff = AllChem.MMFFGetMoleculeForceField(mol, props, confId=conf_id)
                if ff is not None:
                    ff.Minimize(maxIts=max_iters)
                    e = float(ff.CalcEnergy())
                    if math.isfinite(e):
                        return f"RDKit ETKDGv3 + MMFF94s (seed={SEMENTE_3D})", round(e, 2)
    except Exception:
        pass
    try:
        if AllChem.UFFHasAllMoleculeParams(mol):
            ff = AllChem.UFFGetMoleculeForceField(mol, confId=conf_id)
            if ff is not None:
                ff.Minimize(maxIts=max_iters)
                e = float(ff.CalcEnergy())
                if math.isfinite(e):
                    return f"RDKit ETKDGv3 + UFF (seed={SEMENTE_3D})", round(e, 2)
    except Exception:
        pass
    return f"RDKit ETKDGv3 (seed={SEMENTE_3D})", None


def _normalizar_conformero_zero(mol, conf_id: int | None = None):
    """Garante que `mol` possua exatamente um único confôrmero 3D com `id=0` e coordenadas finitas."""
    from rdkit import Chem

    conf_src = mol.GetConformer() if conf_id is None else mol.GetConformer(conf_id)
    n_at = mol.GetNumAtoms()
    conf0 = Chem.Conformer(n_at)
    conf0.SetId(0)
    conf0.Set3D(True)
    for i in range(n_at):
        p = conf_src.GetAtomPosition(i)
        x = float(p.x) if math.isfinite(p.x) else 0.0
        y = float(p.y) if math.isfinite(p.y) else 0.0
        z = float(p.z) if math.isfinite(p.z) else 0.0
        conf0.SetAtomPosition(i, (x, y, z))
    mol.RemoveAllConformers()
    mol.AddConformer(conf0, assignId=False)
    return mol


def _embutir_fragmento_unico(frag0) -> tuple[object, str, float | None]:
    """Gera coordenadas 3D fisicamente válidas para um único fragmento conectado (de 1 a >500 átomos)."""
    from rdkit import Chem
    from rdkit.Chem import AllChem, rdMolDescriptors

    nha = frag0.GetNumHeavyAtoms()

    # Polipeptídeos e macrociclos gigantes (>120 átomos pesados, ex.: ciclotídeos, heveína, maxadilana):
    # evita suavização triangular O(N^3) com hidrogênios explícitos (~10^9 ops) embutindo primeiro o esqueleto
    # pesado e adicionando os hidrogênios analiticamente em 3D (`addCoords=True`), seguido de relaxação UFF/MMFF94s.
    if nha > 120:
        m_heavy = Chem.Mol(frag0)
        m_heavy.RemoveAllConformers()
        cid_h = -1
        if nha <= 320:
            ps_h = AllChem.ETKDGv3()
            ps_h.randomSeed = SEMENTE_3D
            ps_h.useRandomCoords = True
            ps_h.enforceChirality = True
            ps_h.ignoreSmoothingFailures = True
            ps_h.maxIterations = 90
            ps_h.boxSizeMult = 3.2
            if hasattr(ps_h, "timeout"):
                ps_h.timeout = 4
            try:
                cid_h = AllChem.EmbedMolecule(m_heavy, ps_h)
            except Exception:
                cid_h = -1
        if cid_h < 0:
            AllChem.Compute2DCoords(m_heavy)
            ch = m_heavy.GetConformer()
            for i in range(m_heavy.GetNumAtoms()):
                p = ch.GetAtomPosition(i)
                z_p = 0.36 * math.sin((i + 1) * 1.6180339887) + 0.18 * math.cos((i + 1) * 0.7548776662)
                ch.SetAtomPosition(i, (p.x, p.y, z_p))
            try:
                AllChem.UFFOptimizeMolecule(m_heavy, maxIters=140)
            except Exception:
                pass
            _normalizar_conformero_zero(m_heavy)
            mol_full = Chem.AddHs(m_heavy, addCoords=True)
            met, e = _minimizar_mol_3d(mol_full, conf_id=0, max_iters=60)
            _normalizar_conformero_zero(mol_full)
            return mol_full, met.replace("ETKDGv3", "3D-MacroRelax"), e

        _normalizar_conformero_zero(m_heavy, cid_h)
        mol_full = Chem.AddHs(m_heavy, addCoords=True)
        met, e = _minimizar_mol_3d(mol_full, conf_id=0, max_iters=80)
        _normalizar_conformero_zero(mol_full)
        return mol_full, met, e

    mol = Chem.AddHs(frag0)
    n_at = mol.GetNumAtoms()

    if n_at == 1:
        conf = Chem.Conformer(1)
        conf.SetId(0)
        conf.Set3D(True)
        conf.SetAtomPosition(0, (0.0, 0.0, 0.0))
        mol.RemoveAllConformers()
        mol.AddConformer(conf, assignId=False)
        return mol, "Átomo/íon monoatômico em origem canônica", 0.0

    ri = frag0.GetRingInfo()
    n_rings = ri.NumRings()
    n_rot = rdMolDescriptors.CalcNumRotatableBonds(frag0)

    # Pequenas moléculas flexíveis (<= 30 átomos pesados, <= 3 anéis): pequeno ensemble determinístico -> menor energia
    if 3 <= nha <= 30 and n_rings <= 3 and 1 <= n_rot <= 10:
        ps = AllChem.ETKDGv3()
        ps.randomSeed = SEMENTE_3D
        ps.useSmallRingTorsions = True
        ps.enforceChirality = True
        ps.pruneRmsThresh = 0.5
        ps.maxIterations = 40
        if hasattr(ps, "timeout"):
            ps.timeout = 1
        try:
            cids = [int(c) for c in AllChem.EmbedMultipleConfs(mol, numConfs=3, params=ps) if int(c) >= 0]
        except Exception:
            cids = []
        if cids and mol.GetNumConformers() > 0:
            melhor_cid, melhor_e, melhor_met = cids[0], None, f"RDKit ETKDGv3 (seed={SEMENTE_3D})"
            for cid in cids:
                met, e = _minimizar_mol_3d(mol, conf_id=cid, max_iters=180)
                if e is not None and (melhor_e is None or e < melhor_e):
                    melhor_cid, melhor_e, melhor_met = cid, e, met
            _normalizar_conformero_zero(mol, melhor_cid)
            return mol, melhor_met, melhor_e

    # Cascata ETKDGv3 adaptativa (evita travamento em gaiolas policíclicas em ponte e macrociclos grandes)
    tentativas_cfg = []
    if nha <= 32 and n_rings < 4:
        tentativas_cfg.append((False, True, 40, 1, 2.0, False))
    tentativas_cfg.append((True, True, 70 if nha <= 90 else 95, 1, 2.5, False))
    tentativas_cfg.append((True, True, 90, 1, 3.8, True))
    tentativas_cfg.append((True, True, 260, 4, 4.0, True))

    cid = -1
    for use_rand, enf_chir, max_it, tout, box_m, ign_smooth in tentativas_cfg:
        mol.RemoveAllConformers()
        ps = AllChem.ETKDGv3()
        ps.randomSeed = SEMENTE_3D
        ps.useSmallRingTorsions = True
        ps.useMacrocycleTorsions = True
        ps.useRandomCoords = use_rand
        ps.enforceChirality = enf_chir
        ps.maxIterations = max_it
        ps.boxSizeMult = box_m
        ps.ignoreSmoothingFailures = ign_smooth
        if hasattr(ps, "timeout"):
            ps.timeout = tout
        try:
            cid = AllChem.EmbedMolecule(mol, ps)
        except Exception:
            cid = -1
        if cid >= 0:
            break

    if cid >= 0:
        max_opt = 220 if nha <= 65 else 120
        met, e = _minimizar_mol_3d(mol, conf_id=cid, max_iters=max_opt)
        _normalizar_conformero_zero(mol, cid)
        return mol, met, e

    # Garantia algébrica final (ex.: porfirinas de Mg hipervalentes / gaiolas rígidas):
    # coordenadas 2D levantadas deterministicamente para 3D e relaxadas por UFF/MMFF94s
    mol.RemoveAllConformers()
    AllChem.Compute2DCoords(mol)
    conf = mol.GetConformer()
    for i in range(n_at):
        p = conf.GetAtomPosition(i)
        z_pert = 0.22 * math.sin((i + 1) * 1.6180339887) + (0.08 if mol.GetAtomWithIdx(i).GetAtomicNum() == 1 else 0.0)
        conf.SetAtomPosition(i, (p.x, p.y, z_pert))
    _normalizar_conformero_zero(mol)
    met, e = _minimizar_mol_3d(mol, conf_id=0, max_iters=260)
    _normalizar_conformero_zero(mol)
    return mol, met.replace("ETKDGv3", "3D-Relax"), e


def construir_mol_3d_de_smiles(smiles: str):
    """Constrói um `rdkit.Chem.Mol` 3D completo (com todos os hidrogênios explícitos) a partir de SMILES,
    tratando inclusive sais/misturas desconectadas sem sobreposição espacial na origem.
    """
    from rdkit import Chem, RDLogger

    RDLogger.DisableLog("rdApp.*")
    mol0 = Chem.MolFromSmiles(smiles)
    if mol0 is None or mol0.GetNumAtoms() == 0:
        return None, None, None

    frags = Chem.GetMolFrags(mol0, asMols=True, sanitizeFrags=True)
    if len(frags) == 1:
        return _embutir_fragmento_unico(frags[0])

    # Ordena do maior fragmento orgânico para contra-íons/solventes e posiciona sem colisão VdW
    frags_ord = sorted(frags, key=lambda f: -f.GetNumHeavyAtoms())
    combinado = None
    coords_totais: list[tuple[float, float, float]] = []
    offset_x = 0.0
    energia_soma = 0.0
    tem_e = True
    metodo_principal = f"RDKit ETKDGv3 + MMFF94s (seed={SEMENTE_3D})"

    for idx_f, fg in enumerate(frags_ord):
        m3d, met, e = _embutir_fragmento_unico(fg)
        if idx_f == 0:
            metodo_principal = met
        if e is None:
            tem_e = False
        else:
            energia_soma += e

        conf = m3d.GetConformer(0)
        n_f = m3d.GetNumAtoms()
        xs = [conf.GetAtomPosition(i).x for i in range(n_f)]
        ys = [conf.GetAtomPosition(i).y for i in range(n_f)]
        zs = [conf.GetAtomPosition(i).z for i in range(n_f)]
        cx, cy, cz = sum(xs) / n_f, sum(ys) / n_f, sum(zs) / n_f
        min_x, max_x = min(xs) - cx, max(xs) - cx

        if idx_f == 0:
            shift_x = -cx
            offset_x = max_x + 3.1
        else:
            shift_x = offset_x - min_x - cx
            offset_x += (max_x - min_x) + 3.1

        for i in range(n_f):
            p = conf.GetAtomPosition(i)
            coords_totais.append((p.x + shift_x, p.y - cy, p.z - cz))

        combinado = m3d if combinado is None else Chem.CombineMols(combinado, m3d)

    combinado.RemoveAllConformers()
    conf_final = Chem.Conformer(combinado.GetNumAtoms())
    conf_final.SetId(0)
    conf_final.Set3D(True)
    for idx_a, xyz in enumerate(coords_totais):
        conf_final.SetAtomPosition(idx_a, xyz)
    combinado.AddConformer(conf_final, assignId=False)

    return combinado, metodo_principal, (round(energia_soma, 2) if tem_e else None)


def gerar_conformero_pequena_molecula(smiles, mol_id, nome, inchikey=None, formula=None):
    from ..conformeros import gerar
    geom, _ = gerar((mol_id, nome, smiles, inchikey, formula))
    return geom


# ═══════════════════════ Reparo de SMILES ausentes (verificação 100%) ═══════════════════════
def reparar_smiles_ausentes(con, cli, log=print) -> tuple[int, dict[int, object], set[int]]:
    """Resolve e verifica o SMILES canônico de qualquer pequena molécula sem SMILES no banco.

    Respeita estritamente o Princípio 2 (`quimica.conferir_inchikey` de 27 caracteres):
    apenas grava `molecula.smiles` quando o round-trip `MolFromSmiles -> MolToInchiKey`
    reproduz exatamente o Standard InChIKey de 27 caracteres. Quando a estereoquímica
    exata exige `molfile` (ex.: macrociclo porfirínico `CHEMBL510103`) ou InChI relativo
    (`/SRel` `-NA-N`), preserva `molecula.smiles = NULL` e devolve o grafo molecular
    validado em memória (`mols_diretos`) para geração fiel do confôrmero 3D.
    """
    from rdkit import Chem, RDLogger
    from rdkit.Chem import inchi
    from .. import midia, quimica

    RDLogger.DisableLog("rdApp.*")

    # Saneia qualquer SMILES que não satisfaça concordância estrita de 27 caracteres (Princípio 2)
    saneadas = 0
    ids_recalcular: set[int] = set()
    for row_chk in con.execute(
        "SELECT id, inchikey, smiles FROM molecula "
        "WHERE tipo='pequena_molecula' AND inchikey IS NOT NULL AND smiles IS NOT NULL AND smiles != ''"
    ).fetchall():
        ok_ik, _ = quimica.conferir_inchikey(row_chk["smiles"], row_chk["inchikey"])
        if not ok_ik:
            con.execute(
                "UPDATE molecula SET smiles=NULL, desenho=NULL, umap_x=NULL, umap_y=NULL WHERE id=?",
                (row_chk["id"],),
            )
            ids_recalcular.add(int(row_chk["id"]))
            saneadas += 1
    if saneadas:
        con.commit()

    faltantes = con.execute(
        "SELECT id, nome, inchikey, pubchem_cid, chembl_id, lotus_id FROM molecula "
        "WHERE tipo='pequena_molecula' AND (smiles IS NULL OR smiles = '')"
    ).fetchall()
    if not faltantes:
        return 0, {}, ids_recalcular

    reparadas = 0
    mols_diretos: dict[int, object] = {}

    for r in faltantes:
        mid, ik = r["id"], r["inchikey"]
        candidatos_smi: list[str] = []
        mol_direto = None

        if r["pubchem_cid"]:
            resp = cli.get(
                f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{r['pubchem_cid']}/property/IsomericSMILES,CanonicalSMILES/JSON",
                fonte="pubchem", tentativas=3,
            )
            if resp.ok and isinstance(resp.dados, dict):
                props = resp.dados.get("PropertyTable", {}).get("Properties", [])
                if props:
                    for k_pc in ("IsomericSMILES", "SMILES", "ConnectivitySMILES"):
                        if props[0].get(k_pc):
                            candidatos_smi.append(props[0][k_pc])

        if r["chembl_id"]:
            resp = cli.get(
                f"https://www.ebi.ac.uk/chembl/api/data/molecule/{r['chembl_id']}.json",
                fonte="chembl", tentativas=3,
            )
            if resp.ok and isinstance(resp.dados, dict):
                st = resp.dados.get("molecule_structures") or {}
                if st.get("canonical_smiles"):
                    candidatos_smi.append(st["canonical_smiles"])
                if st.get("molfile") and ik:
                    m_mb = Chem.MolFromMolBlock(st["molfile"], sanitize=True, removeHs=False)
                    if m_mb is not None and Chem.MolToInchiKey(Chem.RemoveHs(m_mb)) == ik:
                        mol_direto = Chem.RemoveHs(m_mb)
                        candidatos_smi.append(Chem.MolToSmiles(mol_direto, isomericSmiles=True))

        if r["lotus_id"] and str(r["lotus_id"]).startswith("Q"):
            qid = str(r["lotus_id"]).strip()
            resp = cli.get(
                f"https://www.wikidata.org/wiki/Special:EntityData/{qid}.json",
                fonte="lotus", tentativas=3,
            )
            if resp.ok and isinstance(resp.dados, dict):
                ent = next(iter((resp.dados.get("entities") or {}).values()), {})
                claims = ent.get("claims") or {}
                # InChI (P234) frequentemente preserva geometria E/Z exata ou estereoquímica relativa (/SRel)
                for x in claims.get("P234", []):
                    inc_val = (x.get("mainsnak", {}).get("datavalue") or {}).get("value")
                    if inc_val:
                        m_in = inchi.MolFromInchi(inc_val)
                        if m_in is not None:
                            candidatos_smi.append(Chem.MolToSmiles(m_in, isomericSmiles=True))
                            if mol_direto is None and ik:
                                ik_std = Chem.MolToInchiKey(m_in)
                                ik_rel = inchi.MolToInchiKey(m_in, options="/SRel") if len(ik) == 27 and ik[23] == "N" else ""
                                if ik_std == ik or ik_rel == ik:
                                    mol_direto = m_in
                for prop in ("P2017", "P233"):
                    for x in claims.get(prop, []):
                        v_s = (x.get("mainsnak", {}).get("datavalue") or {}).get("value")
                        if v_s:
                            candidatos_smi.append(v_s)

        gravou_smi = False
        for smi_cand in candidatos_smi:
            m = Chem.MolFromSmiles(smi_cand)
            if m is None:
                continue
            smi_can = Chem.MolToSmiles(m, isomericSmiles=True)
            ok_27, _ = quimica.conferir_inchikey(smi_can, ik)
            if ok_27:
                con.execute("UPDATE molecula SET smiles=? WHERE id=?", (smi_can, mid))
                ids_recalcular.add(int(mid))
                reparadas += 1
                gravou_smi = True
                break

        if not gravou_smi and mol_direto is not None:
            mols_diretos[int(mid)] = mol_direto
            ids_recalcular.add(int(mid))

    if reparadas or saneadas:
        con.commit()
        midia.desenhar_todas(con, log)
        log(f"  ✓ SMILES resolvidos com concordância estrita de 27 chars: {reparadas} ({len(mols_diretos)} via grafo InChI/MolBlock direto).")
    return reparadas, mols_diretos, ids_recalcular


# ═══════════════════════ Verificação de estruturas 3D experimentais ═══════════════════════
def _buscar_metadados_pdb_lote(cli, pdb_ids: list[str]) -> dict[str, tuple[str, float | None]]:
    """Consulta método experimental e resolução (Å) de códigos PDB em lotes via GraphQL RCSB."""
    saida: dict[str, tuple[str, float | None]] = {}
    unicos = sorted({p.strip().upper() for p in pdb_ids if p and len(p.strip()) == 4})
    for ini in range(0, len(unicos), 120):
        fatia = unicos[ini:ini + 120]
        lista_str = ",".join(f'"{p}"' for p in fatia)
        query = f'{{ entries(entry_ids: [{lista_str}]) {{ rcsb_id exptl {{ method }} rcsb_entry_info {{ resolution_combined }} }} }}'
        try:
            r = cli._http.post(GQL_RCSB, json={"query": query}, timeout=30.0)
            if r.status_code == 200:
                entries = (r.json().get("data") or {}).get("entries") or []
                for e in entries:
                    pid = (e.get("rcsb_id") or "").upper()
                    exptl = e.get("exptl") or [{}]
                    met = (exptl[0].get("method") or "").strip() if exptl else ""
                    res_c = (e.get("rcsb_entry_info") or {}).get("resolution_combined") or []
                    res = round(float(res_c[0]), 2) if res_c and res_c[0] is not None else None
                    if pid and met and "THEORETICAL" not in met.upper():
                        saida[pid] = (met, res)
        except Exception:
            pass
    return saida


def verificar_experimentais_wwpdb_ccd(con, cli, registrar_lote_fn, log=print) -> set[int]:
    """Verifica todas as 15.944 pequenas moléculas contra o wwPDB Chemical Component Dictionary (`rcsb_pdb`).

    Retorna o conjunto de `molecula_id` com estrutura 3D experimental validada.
    """
    from rdkit import Chem, RDLogger

    RDLogger.DisableLog("rdApp.*")
    r_idx = cli.get(URL_CCD_IK, fonte="rcsb_pdb", como_json=False, accept="text/csv", tentativas=3)
    if not r_idx.ok or not isinstance(r_idx.dados, str):
        log("  ! Falha ao consultar índice wwPDB CCD InChIKeys.")
        return set()

    bmb_por_ik: dict[str, list[dict]] = {}
    for r in con.execute("SELECT id, nome, inchikey, smiles, formula FROM molecula WHERE tipo='pequena_molecula' AND inchikey IS NOT NULL"):
        bmb_por_ik.setdefault(r["inchikey"], []).append(dict(r))

    candidatos: dict[str, list[str]] = {}
    for row in csv.reader(io.StringIO(r_idx.dados)):
        if len(row) >= 2:
            ccd, ik = row[0].strip(), row[1].strip()
            if ik in bmb_por_ik:
                candidatos.setdefault(ik, []).append(ccd)

    log(f"  wwPDB CCD: {len(candidatos)} pequenas moléculas com correspondência exata de InChIKey (27 chars). Validando coordenadas experimentais…")

    def _baixar_par_ccd(item):
        ik, ccds = item
        for ccd in ccds:
            r_cif = cli._buscar(f"{URL_PDBE_STATIC}/{ccd}.cif", fonte="rcsb_pdb", como_json=False, accept="text/plain", tentativas=2)
            if not r_cif.ok or not isinstance(r_cif.dados, str):
                continue
            m_miss = re.search(r"_chem_comp\.pdbx_model_coordinates_missing_flag\s+(\S+)", r_cif.dados)
            if not m_miss or m_miss.group(1).strip("'\"") != "N":
                continue
            m_db = re.search(r"_chem_comp\.pdbx_model_coordinates_db_code\s+(\S+)", r_cif.dados)
            pdb_id = m_db.group(1).strip("'\"").upper() if m_db else "?"
            if len(pdb_id) != 4:
                continue
            r_sdf = cli._buscar(f"{URL_PDBE_STATIC}/{ccd}_model.sdf", fonte="rcsb_pdb", como_json=False, accept="chemical/x-mdl-sdfile", tentativas=2)
            if not r_sdf.ok or not isinstance(r_sdf.dados, str):
                continue
            return ik, ccd, pdb_id, r_sdf
        return None

    brutos = []
    with ThreadPoolExecutor(max_workers=10) as pool:
        for res in pool.map(_baixar_par_ccd, list(candidatos.items())):
            if res is not None:
                brutos.append(res)

    mapa_pdb_meta = _buscar_metadados_pdb_lote(cli, [b[2] for b in brutos])

    validados: set[int] = set()
    for ik, ccd, pdb_id, r_sdf in brutos:
        if pdb_id not in mapa_pdb_meta:
            continue
        metodo, resolucao = mapa_pdb_meta[pdb_id]
        mol = Chem.MolFromMolBlock(r_sdf.dados, sanitize=True, removeHs=False)
        if mol is None or not mol.GetNumConformers() or not mol.GetConformer().Is3D():
            continue
        # Exige correspondência exata do InChIKey de 27 caracteres derivado da estrutura 3D experimental
        try:
            Chem.AssignStereochemistryFrom3D(mol, replaceExistingTags=True)
            ik_sdf = Chem.MolToInchiKey(Chem.RemoveHs(mol))
        except Exception:
            continue
        if ik_sdf != ik:
            continue

        conf = mol.GetConformer()
        if mol.GetNumAtoms() > 1:
            xs = [conf.GetAtomPosition(i).x for i in range(mol.GetNumAtoms())]
            ys = [conf.GetAtomPosition(i).y for i in range(mol.GetNumAtoms())]
            if (max(xs) - min(xs) < 0.05) and (max(ys) - min(ys) < 0.05):
                continue

        # Registra consulta real no SQLite
        cid = cli.registrar(r_sdf)
        b64z, n_at, _ = codificar_mol_bm32z(mol, forc_f32=True)
        cod_str = f"{ccd} ({pdb_id})"
        for m_row in bmb_por_ik[ik]:
            mid = m_row["id"]
            chave = f"exp_pdb_{mid}"
            geom = {
                "fmt": "bm32z",
                "id": mid,
                "nome": m_row["nome"],
                "tipo": "atomos",
                "nat": "experimental",
                "fonte": "rcsb_pdb",
                "cod": cod_str,
                "met": metodo,
                "res_ang": resolucao,
                "ik": ik,
                "form": m_row["formula"],
                "b64z": b64z,
            }
            arq_rel, sha = registrar_lote_fn(chave, geom)
            _upsert_estrutura(
                con, molecula_id=mid, natureza="experimental", fonte_id="rcsb_pdb",
                codigo=cod_str, metodo=metodo, resolucao=resolucao,
                n_elem=n_at, n_ss=0, arquivo=arq_rel, sha256=sha, consulta_id=cid, tem_sdf_3d=1,
            )
            validados.add(mid)

    con.commit()
    log(f"  ✓ wwPDB CCD: {len(validados)} estruturas 3D experimentais verificadas (InChIKey 27 chars + entrada PDB experimental).")
    return validados


def _converter_cif_cod_para_mol_3d(cif_text: str, ref_smiles: str, target_ik: str):
    """Converte um CIF cristalográfico da COD em `Chem.Mol` 3D com coordenadas pesadas experimentais intactas
    e verifica correspondência exata do InChIKey estereoquímico 3D de 27 caracteres.
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem, rdDetermineBonds

    def _num(v: str) -> float:
        return float(re.sub(r"\([^)]*\)", "", v.strip()))

    try:
        a = _num(re.search(r"_cell_length_a\s+(\S+)", cif_text).group(1))
        b = _num(re.search(r"_cell_length_b\s+(\S+)", cif_text).group(1))
        c = _num(re.search(r"_cell_length_c\s+(\S+)", cif_text).group(1))
        al, be, ga = [math.radians(_num(re.search(rf"_cell_angle_{k}\s+(\S+)", cif_text).group(1))) for k in ("alpha", "beta", "gamma")]
    except Exception:
        return None, None, None

    ca, cb, cg, sg = math.cos(al), math.cos(be), math.cos(ga), math.sin(ga)
    if sg < 1e-6:
        return None, None, None
    vol_sq = 1.0 - ca * ca - cb * cb - cg * cg + 2.0 * ca * cb * cg
    if vol_sq <= 1e-8:
        return None, None, None
    vol = a * b * c * math.sqrt(vol_sq)

    def _cart(fx: float, fy: float, fz: float) -> tuple[float, float, float]:
        return (
            a * fx + b * cg * fy + c * cb * fz,
            b * sg * fy + c * ((ca - cb * cg) / sg) * fz,
            (vol / (a * b * sg)) * fz,
        )

    m_loop = re.search(r"loop_\s+((?:_atom_site_\S+\s+)+)", cif_text)
    if not m_loop:
        return None, None, None
    cols = m_loop.group(1).split()
    col_idx = {col: i for i, col in enumerate(cols)}
    if "_atom_site_fract_x" not in col_idx or "_atom_site_fract_y" not in col_idx or "_atom_site_fract_z" not in col_idx:
        return None, None, None

    ix, iy, iz = col_idx["_atom_site_fract_x"], col_idx["_atom_site_fract_y"], col_idx["_atom_site_fract_z"]
    isym = col_idx.get("_atom_site_type_symbol")
    ilab = col_idx.get("_atom_site_label")
    idis = col_idx.get("_atom_site_disorder_group")
    iu = col_idx.get("_atom_site_U_iso_or_equiv")
    if isym is None and ilab is None:
        return None, None, None

    heavy = []
    for line in cif_text[m_loop.end():].splitlines():
        s = line.strip()
        if not s or s.startswith(("#", "loop_", "_", "data_")):
            if heavy:
                break
            continue
        toks = re.findall(r"'[^']*'|\"[^\"]*\"|\S+", s)
        if len(toks) < len(cols):
            continue
        if idis is not None and toks[idis] not in (".", "?", "0", "1"):
            continue
        raw = (toks[isym] if isym is not None else toks[ilab]).strip("'\"")
        m_el = re.match(r"([A-Za-z]{1,2})", raw)
        if not m_el:
            continue
        el = m_el.group(1)
        if isym is None and len(el) == 2 and not el[1].islower():
            el = el[0]
        el = el.capitalize()
        if el in ("H", "D"):
            continue
        try:
            xyz = _cart(_num(toks[ix]), _num(toks[iy]), _num(toks[iz]))
        except Exception:
            continue
        b_iso = 0.0
        if iu is not None:
            try:
                u_val = _num(toks[iu])
                if 0.0 < u_val < 2.0:
                    b_iso = round(8.0 * (math.pi ** 2) * u_val, 2)
            except Exception:
                pass
        heavy.append((el, *xyz, b_iso))

    ref0 = Chem.MolFromSmiles(ref_smiles)
    if ref0 is None:
        return None, None, None
    ref = Chem.RemoveHs(ref0)
    if len(heavy) < ref.GetNumAtoms():
        return None, None, None

    pt = Chem.GetPeriodicTable()
    rw = Chem.RWMol()
    conf = Chem.Conformer(len(heavy))
    for k, (el, x, y, z, _) in enumerate(heavy):
        znum = pt.GetAtomicNumber(el)
        if znum <= 0:
            return None, None, None
        rw.AddAtom(Chem.Atom(znum))
        conf.SetAtomPosition(k, (x, y, z))
    m0 = rw.GetMol()
    m0.AddConformer(conf, assignId=True)
    try:
        rdDetermineBonds.DetermineConnectivity(m0)
    except Exception:
        return None, None, None

    frag_indices = Chem.GetMolFrags(m0, asMols=False, sanitizeFrags=False)
    frag_mols = Chem.GetMolFrags(m0, asMols=True, sanitizeFrags=False)
    for idxs_orig, frag in zip(frag_indices, frag_mols):
        if frag.GetNumAtoms() != ref.GetNumAtoms():
            continue
        try:
            for at in frag.GetAtoms():
                at.SetNoImplicit(False)
                at.SetNumExplicitHs(0)
                at.SetNumRadicalElectrons(0)
                at.SetFormalCharge(0)
            tmpl = AllChem.AssignBondOrdersFromTemplate(ref, frag)
            match = tmpl.GetSubstructMatch(ref)
            if len(match) == ref.GetNumAtoms():
                for ref_idx, tmpl_idx in enumerate(match):
                    tmpl.GetAtomWithIdx(tmpl_idx).SetFormalCharge(ref.GetAtomWithIdx(ref_idx).GetFormalCharge())
            for at in tmpl.GetAtoms():
                at.SetNumRadicalElectrons(0)
            Chem.SanitizeMol(tmpl)
            Chem.AssignStereochemistryFrom3D(tmpl)
            if Chem.MolToInchiKey(tmpl) != target_ik:
                continue

            # Verifica distâncias de ligação físicas (evita artefatos de borda de célula unitária)
            c_t = tmpl.GetConformer()
            bad_bond = False
            for bd in tmpl.GetBonds():
                p1 = c_t.GetAtomPosition(bd.GetBeginAtomIdx())
                p2 = c_t.GetAtomPosition(bd.GetEndAtomIdx())
                dist = math.dist((p1.x, p1.y, p1.z), (p2.x, p2.y, p2.z))
                if dist < 0.85 or dist > 2.60:
                    bad_bond = True
                    break
            if bad_bond:
                continue

            # Adiciona hidrogênios e relaxa SOMENTE os hidrogênios (átomos pesados cristalográficos 100% fixos!)
            n_heavy = tmpl.GetNumAtoms()
            mol_h = Chem.AddHs(tmpl, addCoords=True)
            try:
                if AllChem.MMFFHasAllMoleculeParams(mol_h):
                    mp = AllChem.MMFFGetMoleculeProperties(mol_h, mmffVariant="MMFF94s")
                    ff = AllChem.MMFFGetMoleculeForceField(mol_h, mp)
                    if ff is not None:
                        for hi in range(n_heavy):
                            ff.AddFixedPoint(hi)
                        ff.Minimize(maxIts=150)
                elif AllChem.UFFHasAllMoleculeParams(mol_h):
                    ff = AllChem.UFFGetMoleculeForceField(mol_h)
                    if ff is not None:
                        for hi in range(n_heavy):
                            ff.AddFixedPoint(hi)
                        ff.Minimize(maxIts=150)
            except Exception:
                pass

            bfacs = [heavy[oi][4] for oi in idxs_orig] + [0.0] * (mol_h.GetNumAtoms() - n_heavy)
            m_rad = re.search(r"_diffrn_radiation_probe\s+(\S+)", cif_text)
            probe = (m_rad.group(1) if m_rad else cif_text).lower()
            if "neutron" in probe:
                metodo = "NEUTRON DIFFRACTION"
            elif "x-ray" in probe or "xray" in probe:
                metodo = "SINGLE-CRYSTAL X-RAY DIFFRACTION"
            else:
                metodo = "CRYSTALLOGRAPHY (COD)"
            return mol_h, bfacs, metodo
        except Exception:
            continue
    return None, None, None


def _worker_scan_cod_smi(args: tuple[list[str], set[str]]) -> dict[str, list[str]]:
    linhas, alvos_ik = args
    from rdkit import Chem, RDLogger

    RDLogger.DisableLog("rdApp.*")
    achados: dict[str, list[str]] = {}
    ignorar_frags = {"O", "[H]O[H]", "CO", "CCO", "ClC(Cl)Cl", "CC#N", "CC(=O)C", "[Cl-]", "[Br-]", "[I-]"}
    ignorar_metais = ("[Al", "[Ba", "[La", "[Ce", "[Nd", "[Gd", "[Dy", "[Er", "[Yb", "[U", "[Th", "[Zr", "[Hf", "[Ta", "[W", "[Re", "[Os", "[Ir", "[Pt", "[Au", "[Hg", "[Pb", "[Bi", "[Si", "[B", "[Li")

    for l in linhas:
        parts = l.split()
        if len(parts) < 2:
            continue
        smi, cod_id = parts[0], parts[1]
        if "[" in smi and any(x in smi for x in ignorar_metais):
            continue
        for fg in smi.split("."):
            if fg in ignorar_frags or len(fg) < 3:
                continue
            try:
                m = Chem.MolFromSmiles(fg)
                if m is None:
                    continue
                ik = Chem.MolToInchiKey(m)
            except Exception:
                continue
            if ik in alvos_ik:
                achados.setdefault(ik, []).append(cod_id)
                break
    return achados


def verificar_experimentais_cod(con, cli, ja_experimentais: set[int], registrar_lote_fn, log=print) -> set[int]:
    """Verifica monocristais experimentais na Crystallography Open Database (`cod`, CC0 1.0)
    para pequenas moléculas ainda não cobertas pelo wwPDB.
    """
    r_smi = cli.get(URL_COD_SMI, fonte="cod", como_json=False, accept="text/plain", tentativas=3)
    if not r_smi.ok or not isinstance(r_smi.dados, str):
        log("  ! Falha ao consultar índice SMILES da COD.")
        return set()

    restantes_por_ik: dict[str, list[dict]] = {}
    for r in con.execute("SELECT id, nome, inchikey, smiles, formula FROM molecula WHERE tipo='pequena_molecula' AND inchikey IS NOT NULL AND smiles IS NOT NULL"):
        if r["id"] not in ja_experimentais:
            restantes_por_ik.setdefault(r["inchikey"], []).append(dict(r))
    alvos_ik = set(restantes_por_ik.keys())
    todas_linhas = r_smi.dados.splitlines()
    n_workers = min(16, max(2, (os.cpu_count() or 4) - 2))
    passo = max(1, (len(todas_linhas) + n_workers - 1) // n_workers)
    fatias = [(todas_linhas[i:i + passo], alvos_ik) for i in range(0, len(todas_linhas), passo)]

    candidatos_cod: dict[str, list[str]] = {}
    with ProcessPoolExecutor(max_workers=n_workers) as pool:
        for d_parcial in pool.map(_worker_scan_cod_smi, fatias):
            for ik, cids in d_parcial.items():
                candidatos_cod.setdefault(ik, []).extend(cids)

    log(f"  COD (Crystallography Open Database): {len(candidatos_cod)} moléculas candidatas por InChIKey exato. Validando CIFs 3D…")

    def _baixar_cifs_candidato(item):
        ik, cod_ids = item
        cifs = []
        for cod_id in cod_ids[:3]:
            rc = cli._buscar(f"{URL_COD_CIF}/{cod_id}.cif", fonte="cod", como_json=False, accept="chemical/x-cif", tentativas=2)
            if rc.ok and isinstance(rc.dados, str):
                cifs.append((cod_id, rc))
        return ik, cifs

    cifs_baixados = []
    with ThreadPoolExecutor(max_workers=8) as tpool:
        for res in tpool.map(_baixar_cifs_candidato, list(candidatos_cod.items())):
            if res[1]:
                cifs_baixados.append(res)

    novos_cod: set[int] = set()
    for ik, lista_cifs in cifs_baixados:
        m_ref = restantes_por_ik[ik][0]
        for cod_id, resp_cif in lista_cifs:
            mol_h, bfacs, metodo = _converter_cif_cod_para_mol_3d(resp_cif.dados, m_ref["smiles"], ik)
            if mol_h is None:
                continue
            cid = cli.registrar(resp_cif)
            b64z, n_at, _ = codificar_mol_bm32z(mol_h, forc_f32=True, bfactors=bfacs)
            cod_str = f"COD:{cod_id}"
            for m_row in restantes_por_ik[ik]:
                mid = m_row["id"]
                chave = f"exp_cod_{mid}"
                geom = {
                    "fmt": "bm32z",
                    "id": mid,
                    "nome": m_row["nome"],
                    "tipo": "atomos",
                    "nat": "experimental",
                    "fonte": "cod",
                    "cod": cod_str,
                    "met": metodo,
                    "res_ang": None,
                    "ik": ik,
                    "form": m_row["formula"],
                    "b64z": b64z,
                }
                arq_rel, sha = registrar_lote_fn(chave, geom)
                _upsert_estrutura(
                    con, molecula_id=mid, natureza="experimental", fonte_id="cod",
                    codigo=cod_str, metodo=metodo, resolucao=None,
                    n_elem=n_at, n_ss=0, arquivo=arq_rel, sha256=sha, consulta_id=cid, tem_sdf_3d=1,
                )
                novos_cod.add(mid)
            break

    con.commit()
    log(f"  ✓ COD: {len(novos_cod)} estruturas 3D cristalográficas experimentais adicionais verificadas.")
    return novos_cod


# ═══════════════════════ Toxinas Peptídicas / Proteicas & Alvos ═══════════════════════
def _perceber_ss_secundaria(traco: list[list], helices_pdb: set[tuple[str, int]], fitas_pdb: set[tuple[str, int]], cadeia_escolhida: str) -> None:
    """Anota cada resíduo do traço Cα com código de estrutura secundária ('H'=hélice, 'E'=fita β, 'C'=alça)."""
    n = len(traco)
    usou_pdb = False
    for r in traco:
        rn = r[0]
        if (cadeia_escolhida, rn) in helices_pdb:
            r.append("H")
            usou_pdb = True
        elif (cadeia_escolhida, rn) in fitas_pdb:
            r.append("E")
            usou_pdb = True
        else:
            r.append("C")
    if usou_pdb or n < 5:
        return
    # Heurística geométrica Cα(i-1..i+2): d(i,i+3) ~ 5.0–5.8 Å -> hélice α; d(i,i+3) ~ 9.4–11.2 Å -> fita β estendida
    for i in range(n - 3):
        p0 = traco[i][2:5]
        p2 = traco[i + 2][2:5]
        p3 = traco[i + 3][2:5]
        d13 = math.dist(p0, p3)
        d12 = math.dist(p0, p2)
        if 4.7 <= d13 <= 6.0 and 5.0 <= d12 <= 6.2:
            for k in range(i, i + 4):
                traco[k][6] = "H"
        elif 9.2 <= d13 <= 11.4 and d12 >= 6.4:
            for k in range(i, i + 4):
                if traco[k][6] == "C":
                    traco[k][6] = "E"


def _extrair_traco_proteico_pdb(
    pdb_texto: str, codigo: str, natureza: str, metodo: str,
    resolucao: float | None = None, fonte_id: str = "rcsb_pdb", incluir_atomos_sdf: bool = False,
) -> dict | None:
    """Extrai traço Cα + estrutura secundária + pontes dissulfeto; para estruturas experimentais,
    também codifica a tabela atômica completa `b64z` para download de SDF 3D V2000/V3000.
    """
    helices_pdb: set[tuple[str, int]] = set()
    fitas_pdb: set[tuple[str, int]] = set()
    cadeias_ca: dict[str, dict[int, tuple]] = {}
    sg_cys: dict[str, dict[int, tuple[float, float, float]]] = {}
    linhas_modelo1: list[str] = []
    em_modelo_extra = False

    for linha in pdb_texto.splitlines():
        if linha.startswith("MODEL "):
            partes = linha.split()
            if len(partes) >= 2 and partes[1] not in ("1", "0"):
                em_modelo_extra = True
                break
            linhas_modelo1.append(linha)
            continue
        if linha.startswith("ENDMDL"):
            linhas_modelo1.append(linha)
            if not em_modelo_extra:
                break
        if linha.startswith("HELIX ") and len(linha) >= 38:
            ch = (linha[19].strip() or "A")
            try:
                r1, r2 = int(linha[21:25]), int(linha[33:37])
                for rn in range(r1, r2 + 1):
                    helices_pdb.add((ch, rn))
            except ValueError:
                pass
            continue
        if linha.startswith("SHEET ") and len(linha) >= 38:
            ch = (linha[21].strip() or "A")
            try:
                r1, r2 = int(linha[22:26]), int(linha[33:37])
                for rn in range(r1, r2 + 1):
                    fitas_pdb.add((ch, rn))
            except ValueError:
                pass
            continue
        if not linha.startswith("ATOM  "):
            if incluir_atomos_sdf and linha.startswith(("CONECT", "TER", "END")):
                linhas_modelo1.append(linha)
            continue
        alt = linha[16]
        if alt not in (" ", "A", "1"):
            continue
        linhas_modelo1.append(linha)
        atom_name = linha[12:16].strip()
        if atom_name not in ("CA", "SG"):
            continue
        res_name = linha[17:20].strip()
        chain = linha[21].strip() or "A"
        try:
            res_seq = int(linha[22:26])
            x = float(linha[30:38])
            y = float(linha[38:46])
            z = float(linha[46:54])
            bfac = float(linha[60:66]) if len(linha) >= 66 and linha[60:66].strip() else 0.0
        except ValueError:
            continue
        if atom_name == "CA":
            cadeias_ca.setdefault(chain, {}).setdefault(res_seq, (res_seq, res_name, x, y, z, bfac))
        elif atom_name == "SG" and res_name in ("CYS", "CYX"):
            sg_cys.setdefault(chain, {})[res_seq] = (x, y, z)

    if not cadeias_ca:
        return None
    cadeia_escolhida = max(cadeias_ca.keys(), key=lambda c: len(cadeias_ca[c]))
    residuos = [cadeias_ca[cadeia_escolhida][k] for k in sorted(cadeias_ca[cadeia_escolhida])]
    if len(residuos) < 4:
        return None

    # Normaliza escala pLDDT caso ESMFold retorne 0..1 em vez de 0..100
    max_bf = max(r[5] for r in residuos)
    escala_bf = 100.0 if (natureza == "predicao_computacional" and 0.0 < max_bf <= 1.05) else 1.0

    n = len(residuos)
    cx = sum(r[2] for r in residuos) / n
    cy = sum(r[3] for r in residuos) / n
    cz = sum(r[4] for r in residuos) / n

    traco = [
        [r[0], r[1], round(r[2] - cx, 2), round(r[3] - cy, 2), round(r[4] - cz, 2), round(r[5] * escala_bf, 1)]
        for r in residuos
    ]
    _perceber_ss_secundaria(traco, helices_pdb, fitas_pdb, cadeia_escolhida)
    idx_por_res = {r[0]: idx for idx, r in enumerate(residuos)}

    sgs = sg_cys.get(cadeia_escolhida, {})
    chaves_sg = sorted(sgs.keys())
    pontes = []
    for i in range(len(chaves_sg)):
        for j in range(i + 1, len(chaves_sg)):
            r1, r2 = chaves_sg[i], chaves_sg[j]
            p1, p2 = sgs[r1], sgs[r2]
            d = math.dist(p1, p2)
            if d <= 2.45 and r1 in idx_por_res and r2 in idx_por_res:
                pontes.append([idx_por_res[r1], idx_por_res[r2], round(d, 2)])

    b_medio = round(sum(t[5] for t in traco) / n, 1)
    geom = {
        "fmt": "bm32z",
        "cod": codigo,
        "tipo": "cadeia",
        "nat": natureza,
        "fonte": fonte_id,
        "met": metodo,
        "res_ang": round(resolucao, 2) if resolucao else None,
        "plddt": b_medio if natureza == "predicao_computacional" else None,
        "bfac_medio": b_medio if natureza == "experimental" else None,
        "cadeia": cadeia_escolhida,
        "ca": traco,
        "ss_bonds": pontes,
    }

    if incluir_atomos_sdf and linhas_modelo1:
        try:
            from rdkit import Chem, RDLogger
            RDLogger.DisableLog("rdApp.*")
            bloco_cadeia = "\n".join(
                l for l in linhas_modelo1
                if not l.startswith("ATOM  ") or (l[21].strip() or "A") == cadeia_escolhida
            ) + "\nEND\n"
            mol_pdb = Chem.MolFromPDBBlock(bloco_cadeia, sanitize=True, removeHs=False, proximityBonding=False)
            if mol_pdb is None or mol_pdb.GetNumAtoms() < 4:
                mol_pdb = Chem.MolFromPDBBlock(bloco_cadeia, sanitize=False, removeHs=False, proximityBonding=False)
                if mol_pdb is not None:
                    Chem.SanitizeMol(mol_pdb, catchErrors=True)
                    mol_pdb.UpdatePropertyCache(strict=False)
            if mol_pdb is not None and mol_pdb.GetNumAtoms() >= 4:
                bf_atoms = []
                for ai in range(mol_pdb.GetNumAtoms()):
                    ri_info = mol_pdb.GetAtomWithIdx(ai).GetPDBResidueInfo()
                    bf_atoms.append(ri_info.GetTempFactor() if ri_info is not None else b_medio)
                b64z, n_at_pdb, _ = codificar_mol_bm32z(mol_pdb, forc_f32=True, bfactors=bf_atoms)
                geom["b64z"] = b64z
                geom["n_atomos_pdb"] = n_at_pdb
        except Exception:
            pass

    return geom


def _construir_peptideo_ptm_3d(uniprot_json: dict, mid: int, nome: str, acc: str) -> tuple[dict | None, int]:
    """Constrói a estrutura química atômica 3D exata de um peptídeo curto de veneno (< 30 aa)
    a partir da sequência madura e modificações pós-traducionais anotadas no UniProt (`Hyp`, `pGlu`, `-NH2`, `S–S`).
    """
    from rdkit import Chem, RDLogger
    from rdkit.Chem import rdMolDescriptors

    RDLogger.DisableLog("rdApp.*")
    seq_full = (uniprot_json.get("sequence") or {}).get("value") or ""
    if not seq_full:
        return None, 0

    feats = uniprot_json.get("features") or []
    ini_mat, fim_mat = 1, len(seq_full)
    for f in feats:
        if f.get("type") in ("Peptide", "Chain"):
            loc = f.get("location") or {}
            s_v = (loc.get("start") or {}).get("value")
            e_v = (loc.get("end") or {}).get("value")
            if isinstance(s_v, int) and isinstance(e_v, int) and 1 <= s_v <= e_v <= len(seq_full):
                if (e_v - s_v + 1) <= 45:
                    ini_mat, fim_mat = s_v, e_v
                    break

    seq_mat = seq_full[ini_mat - 1:fim_mat]
    if not seq_mat or len(seq_mat) > 60:
        return None, 0

    ptm_hyp: set[int] = set()
    ptm_pglu = False
    ptm_amida = False
    pontes_ss: list[tuple[int, int]] = []

    for f in feats:
        ft = f.get("type")
        desc = (f.get("description") or "").lower()
        loc = f.get("location") or {}
        s_v = (loc.get("start") or {}).get("value")
        e_v = (loc.get("end") or {}).get("value")
        if ft == "Modified residue" and isinstance(s_v, int) and ini_mat <= s_v <= fim_mat:
            pos_rel = s_v - ini_mat  # 0-based
            if "hydroxyproline" in desc:
                ptm_hyp.add(pos_rel)
            elif "pyrrolidone carboxylic acid" in desc and pos_rel == 0:
                ptm_pglu = True
            elif "amidation" in desc or "amide" in desc:
                if pos_rel == len(seq_mat) - 1:
                    ptm_amida = True
        elif ft == "Disulfide bond" and isinstance(s_v, int) and isinstance(e_v, int):
            if ini_mat <= s_v < e_v <= fim_mat:
                pontes_ss.append((s_v - ini_mat, e_v - ini_mat))

    # Monta SMILES peptídico explícito resíduo a resíduo (preservando L-estereoquímica + Hyp + pGlu + C-amida)
    AA_BLOCOS = {
        "A": "N[C@@H](C)C(=O)",
        "R": "N[C@@H](CCCNC(=N)N)C(=O)",
        "N": "N[C@@H](CC(=O)N)C(=O)",
        "D": "N[C@@H](CC(=O)O)C(=O)",
        "C": "N[C@@H](CS)C(=O)",
        "E": "N[C@@H](CCC(=O)O)C(=O)",
        "Q": "N[C@@H](CCC(=O)N)C(=O)",
        "G": "NCC(=O)",
        "H": "N[C@@H](Cc1c[nH]cn1)C(=O)",
        "I": "N[C@@H]([C@@H](C)CC)C(=O)",
        "L": "N[C@@H](CC(C)C)C(=O)",
        "K": "N[C@@H](CCCCN)C(=O)",
        "M": "N[C@@H](CCSC)C(=O)",
        "F": "N[C@@H](Cc1ccccc1)C(=O)",
        "P": "N1CCC[C@H]1C(=O)",
        "S": "N[C@@H](CO)C(=O)",
        "T": "N[C@@H]([C@H](O)C)C(=O)",
        "W": "N[C@@H](Cc1c[nH]c2ccccc12)C(=O)",
        "Y": "N[C@@H](Cc1ccc(O)cc1)C(=O)",
        "V": "N[C@@H](C(C)C)C(=O)",
    }
    # Numeração de fechamento de anel para pontes dissulfeto (até 6 pontes: %10..%15)
    ss_tag_por_pos: dict[int, str] = {}
    n_ss_validas = 0
    for idx_ss, (p1, p2) in enumerate(pontes_ss[:6], start=10):
        if seq_mat[p1] == "C" and seq_mat[p2] == "C" and p1 not in ss_tag_por_pos and p2 not in ss_tag_por_pos:
            ss_tag_por_pos[p1] = f"%{idx_ss}"
            ss_tag_por_pos[p2] = f"%{idx_ss}"
            n_ss_validas += 1

    partes_smi = []
    for idx_aa, aa in enumerate(seq_mat):
        if idx_aa == 0 and ptm_pglu and aa in ("Q", "E"):
            partes_smi.append("O=C1CC[C@H](N1)C(=O)")
        elif idx_aa in ptm_hyp and aa == "P":
            partes_smi.append("N1C[C@H](O)C[C@H]1C(=O)")
        elif idx_aa in ss_tag_por_pos and aa == "C":
            partes_smi.append(f"N[C@@H](CS{ss_tag_por_pos[idx_aa]})C(=O)")
        elif aa in AA_BLOCOS:
            partes_smi.append(AA_BLOCOS[aa])
        else:
            partes_smi.append("N[C@@H](C)C(=O)")

    smi_pep = "".join(partes_smi) + ("N" if ptm_amida else "O")
    mol_pep = Chem.MolFromSmiles(smi_pep)
    if mol_pep is None:
        mol_pep = Chem.MolFromSequence(seq_mat)
        n_ss_validas = 0
    if mol_pep is None:
        return None, 0

    mol_3d, metodo, energia = _embutir_fragmento_unico(mol_pep)
    formula = rdMolDescriptors.CalcMolFormula(mol_pep)
    ik = Chem.MolToInchiKey(mol_pep)
    b64z, n_at, _ = codificar_mol_bm32z(mol_3d, forc_f32=False)

    notas_ptm = []
    if ptm_pglu:
        notas_ptm.append("pGlu")
    if ptm_hyp:
        notas_ptm.append(f"{len(ptm_hyp)}×Hyp")
    if ptm_amida:
        notas_ptm.append("C-NH2")
    if n_ss_validas:
        notas_ptm.append(f"{n_ss_validas}×S-S")
    suf_ptm = f" [{', '.join(notas_ptm)}]" if notas_ptm else ""

    geom = {
        "fmt": "bm32z",
        "id": mid,
        "nome": nome,
        "tipo": "atomos",
        "nat": "conformero_calculado",
        "fonte": "rdkit_local",
        "cod": f"PEP3D-{acc}",
        "met": f"{metodo} · sequência madura UniProt ({len(seq_mat)} aa{suf_ptm})",
        "e_kcal": energia,
        "ik": ik,
        "form": formula,
        "seq_aa": seq_mat,
        "b64z": b64z,
    }
    return geom, n_ss_validas


def _baixar_pdb_experimental(cli, pdb_id: str):
    pdb_up = pdb_id.strip().upper()
    try:
        r_meta = cli.get(f"{API_RCSB}/{pdb_up}", fonte="rcsb_pdb", tentativas=2)
        if not r_meta.ok or not isinstance(r_meta.dados, dict):
            return None, None
        exptl = r_meta.dados.get("exptl") or [{}]
        metodo = exptl[0].get("method") or "Experimental (wwPDB)"
        if "THEORETICAL" in metodo.upper():
            return None, None
        info = r_meta.dados.get("rcsb_entry_info") or {}
        res_comb = info.get("resolution_combined") or []
        resolucao = float(res_comb[0]) if res_comb and res_comb[0] is not None else None

        r_pdb = cli.get(f"{ARQ_RCSB}/{pdb_up}.pdb", fonte="rcsb_pdb", como_json=False, accept="chemical/x-pdb", tentativas=2)
        if not r_pdb.ok or not isinstance(r_pdb.dados, str):
            return None, None
        geom = _extrair_traco_proteico_pdb(
            r_pdb.dados, pdb_up, "experimental", metodo,
            resolucao=resolucao, fonte_id="rcsb_pdb", incluir_atomos_sdf=True,
        )
        return geom, r_pdb.consulta_id
    except Exception:
        return None, None


def _baixar_alphafold(cli, uniprot_acc: str):
    acc = uniprot_acc.strip().upper()
    try:
        r_meta = cli.get(f"{API_AF}/{acc}", fonte="alphafold", tentativas=2)
        if not r_meta.ok or not isinstance(r_meta.dados, list) or not r_meta.dados:
            return None, None
        item = r_meta.dados[0]
        pdb_url = item.get("pdbUrl")
        entry_id = item.get("entryId") or f"AF-{acc}-F1"
        if not pdb_url:
            return None, None
        r_pdb = cli.get(pdb_url, fonte="alphafold", como_json=False, accept="chemical/x-pdb", tentativas=2)
        if not r_pdb.ok or not isinstance(r_pdb.dados, str):
            return None, None
        geom = _extrair_traco_proteico_pdb(
            r_pdb.dados, entry_id, "predicao_computacional", "AlphaFold Monomer", fonte_id="alphafold",
        )
        if geom and item.get("globalMetricValue") is not None:
            geom["plddt"] = round(float(item["globalMetricValue"]), 1)
        return geom, r_pdb.consulta_id
    except Exception:
        return None, None


def _dobrar_esmfold(con, cli, uniprot_acc: str, seq_aa: str):
    """Prediz estrutura proteica via ESMFold v1 (`esm_atlas`, CC BY 4.0) quando ausente do AlphaFold DB."""
    acc = uniprot_acc.strip().upper()
    seq_limpa = re.sub(r"[^ACDEFGHIKLMNPQRSTVWY]", "A", seq_aa.strip().upper())[:1000]
    if len(seq_limpa) < 12:
        return None, None
    url_chave = f"{API_ESMFOLD}?uniprot={acc}"
    hit = cli._ler_cache(f"POST:{url_chave}", "chemical/x-pdb")
    if hit:
        meta, corpo = hit
        pdb_txt = corpo.decode("utf-8", errors="replace")
        quando = meta["consultado_em"]
    else:
        corpo = None
        pdb_txt = ""
        quando = agora()
        for tent in range(3):
            if tent > 0:
                time.sleep(1.2 * tent)
            else:
                time.sleep(0.35)
            try:
                r = cli._http.post(API_ESMFOLD, content=seq_limpa, timeout=60.0)
                if r.status_code == 200 and "ATOM  " in r.text:
                    corpo = r.content
                    pdb_txt = r.text
                    quando = agora()
                    cli._gravar_cache(f"POST:{url_chave}", "chemical/x-pdb", {"status": 200, "consultado_em": quando}, corpo)
                    break
            except Exception:
                continue
        if corpo is None:
            return None, None

    sha = hashlib.sha256(corpo).hexdigest()
    con.execute(
        "INSERT OR IGNORE INTO consulta (fonte_id, url, consultado_em, status, bytes, sha256, versao_fonte) VALUES (?,?,?,?,?,?,?)",
        ("esm_atlas", url_chave, quando, 200, len(corpo), sha, "ESMFold v1"),
    )
    cid = con.execute("SELECT id FROM consulta WHERE url=? AND sha256=?", (url_chave, sha)).fetchone()[0]
    met_esm = "ESMFold v1 Monomer (resíduos X modelados como Ala)" if "X" in seq_aa.upper() else "ESMFold v1 Monomer"
    geom = _extrair_traco_proteico_pdb(
        pdb_txt, f"ESMFold-{acc}", "predicao_computacional", met_esm, fonte_id="esm_atlas",
    )
    return geom, cid


def _worker_bm32z_pequena_predita(tarefa) -> tuple[int, dict | None, int, str | None]:
    """Gera e valida estrutura 3D `bm32z` para pequena molécula fora do domínio de ensemble multiconformacional."""
    from rdkit import Chem, RDLogger

    RDLogger.DisableLog("rdApp.*")
    mid, nome, smiles, ik, formula = tarefa
    if not smiles or not ik:
        return mid, None, 0, "identidade_ausente"
    try:
        grafo = Chem.MolFromSmiles(smiles)
        if grafo is None or Chem.MolToInchiKey(grafo) != ik:
            return mid, None, 0, "identidade_divergente"
        tem_indef = bool(grafo.GetStereoGroups()) or any(
            s.specified != Chem.StereoSpecified.Specified for s in Chem.FindPotentialStereo(grafo)
        )
        mol_3d, met, energia = construir_mol_3d_de_smiles(smiles)
        if mol_3d is None or not mol_3d.GetNumConformers():
            return mid, None, 0, "falha_3d"
        rad = [
            [i, (2 if mol_3d.GetAtomWithIdx(i).GetNumRadicalElectrons() == 1 else 3)]
            for i in range(mol_3d.GetNumAtoms())
            if mol_3d.GetAtomWithIdx(i).GetNumRadicalElectrons() > 0
        ]
        b64z, n_at, _ = codificar_mol_bm32z(mol_3d, forc_f32=False, preservar_estereo_entrada=tem_indef)
        sdf_rt = gerar_sdf_3d({"fmt": "bm32z", "b64z": b64z, **({"rad": rad} if rad else {})})
        mol_rt = Chem.MolFromMolBlock(sdf_rt, sanitize=True, removeHs=False)
        if mol_rt is None or not mol_rt.GetNumConformers() or not mol_rt.GetConformer().Is3D():
            return mid, None, 0, "falha_sdf_rt"
        Chem.AssignStereochemistryFrom3D(mol_rt, replaceExistingTags=True)
        pesado_rt = Chem.RemoveHs(mol_rt)
        m_topo_rt = Chem.Mol(mol_rt)
        Chem.RemoveStereochemistry(m_topo_rt)
        m_topo_ref = Chem.Mol(grafo)
        Chem.RemoveStereochemistry(m_topo_ref)
        if (
            Chem.MolToInchiKey(pesado_rt)[:14] != ik[:14]
            or Chem.MolToSmiles(Chem.RemoveHs(m_topo_rt), isomericSmiles=False)
            != Chem.MolToSmiles(Chem.RemoveHs(m_topo_ref), isomericSmiles=False)
        ):
            return mid, None, 0, "conectividade_divergente"
        ik_exato = Chem.MolToInchiKey(pesado_rt) == ik
        repr_est = bool(tem_indef or not ik_exato)
        if repr_est and not tem_indef:
            b64z, n_at, _ = codificar_mol_bm32z(mol_3d, forc_f32=False, preservar_estereo_entrada=True)
        met_final = f"{met} · estereoisômero representativo" if tem_indef else met
        canonico = Chem.MolToSmiles(grafo)
        geom = {
            "fmt": "bm32z",
            "id": mid,
            "nome": nome,
            "tipo": "atomos",
            "nat": "conformero_calculado",
            "fonte": "rdkit_local",
            "cod": f"ETKDGv3-{mid}",
            "met": met_final,
            "e_kcal": energia,
            "ik": ik,
            "form": formula,
            "smiles": canonico,
            "smiles_sha256": hashlib.sha256(smiles.encode("utf-8")).hexdigest(),
            "b64z": b64z,
        }
        if rad:
            geom["rad"] = rad
        if repr_est:
            geom["repr_estereo"] = True
        return mid, geom, n_at, None
    except Exception:
        return mid, None, 0, "excecao_rdkit"


def preencher_pequenas_preditas_restantes(con, pasta_saida=None, *, limite=None, processos=16, log=print) -> dict:
    """Garante cobertura 3D universal para pequenas moléculas públicas que permanecem sem pose após ensembles."""
    from collections import Counter
    from ..conformeros import validar_arquivo
    from ..exportar.pacotes import SQL_MOLECULAS_PUBLICAS

    pasta_saida = Path(pasta_saida or config.SAIDA_DIR)
    pastas = (pasta_saida, config.APP_DIR / "dados")
    pasta_lotes = pasta_saida / "estruturas3d_lotes"
    pasta_lotes.mkdir(parents=True, exist_ok=True)

    existentes_ok: set[int] = set()
    for row in con.execute(
        f"""SELECT e.*, m.tipo, m.smiles, m.inchikey FROM estrutura_3d e
            JOIN molecula m ON e.molecula_id=m.id
            WHERE m.tipo='pequena_molecula' AND m.id IN ({SQL_MOLECULAS_PUBLICAS})"""
    ):
        if validar_arquivo(row, row, pastas) is not False:
            existentes_ok.add(int(row["molecula_id"]))

    tarefas = [
        tuple(r)
        for r in con.execute(
            f"""SELECT m.id, m.nome, m.smiles, m.inchikey, m.formula FROM molecula m
                WHERE m.tipo='pequena_molecula' AND m.id IN ({SQL_MOLECULAS_PUBLICAS})
                ORDER BY m.id"""
        )
        if int(r["id"]) not in existentes_ok
    ]
    if limite is not None:
        tarefas = tarefas[:limite]
    if not tarefas:
        return {}

    lotes: dict[str, dict[str, dict]] = {}
    lotes_sujos: set[str] = set()
    totais = Counter()

    def _carregar_bucket(bk: str) -> dict[str, dict]:
        if bk not in lotes:
            arq_bk = pasta_lotes / f"{bk}.json"
            if arq_bk.is_file():
                try:
                    lotes[bk] = json.loads(arq_bk.read_text(encoding="utf-8"))
                except Exception:
                    lotes[bk] = {}
            else:
                lotes[bk] = {}
        return lotes[bk]

    n_workers = max(1, min(processos, len(tarefas)))
    log(f"  Modelos 3D preditos complementares ({len(tarefas)} pequenas moléculas restantes, {n_workers} processos)…")
    resultados = []
    with ProcessPoolExecutor(max_workers=n_workers) as pool:
        futuros = [pool.submit(_worker_bm32z_pequena_predita, t) for t in tarefas]
        for idx_f, fut in enumerate(as_completed(futuros), 1):
            mid, geom, n_at, motivo = fut.result()
            if motivo or geom is None:
                totais[motivo or "falha"] += 1
            else:
                resultados.append((mid, geom, n_at))
                totais["gerados"] += 1
                if geom.get("repr_estereo"):
                    totais["estereoisomero_representativo"] += 1
            if idx_f % 500 == 0:
                log(f"    {idx_f}/{len(tarefas)} · {dict(totais)}")

    # Grava lotes canônicos em disco antes de registrar no SQLite
    metadados_gravados: list[tuple[int, dict, int, str, str, bytes]] = []
    for mid, geom, n_at in sorted(resultados, key=lambda x: x[0]):
        chave = f"mol_{mid}"
        bk = bucket_chave(chave)
        corpo = json_canonico_bytes(geom)
        sha = hashlib.sha256(corpo).hexdigest()
        _carregar_bucket(bk)[chave] = geom
        lotes_sujos.add(bk)
        metadados_gravados.append((mid, geom, n_at, f"estruturas3d_lotes/{bk}.json#{chave}", sha, corpo))

    for bk in sorted(lotes_sujos):
        (pasta_lotes / f"{bk}.json").write_bytes(json_canonico_bytes(lotes[bk]))

    with con:
        for mid, geom, n_at, arq_rel, sha, corpo in metadados_gravados:
            cid = _registrar_consulta_rdkit(con, f"rdkit://bm32z/{mid}/{sha}", corpo)
            _upsert_estrutura(
                con, molecula_id=mid, natureza="conformero_calculado", fonte_id="rdkit_local",
                codigo=geom["cod"], metodo=geom["met"], energia=geom.get("e_kcal"),
                n_elem=n_at, n_ss=0, arquivo=arq_rel, sha256=sha, consulta_id=cid, tem_sdf_3d=1,
            )

    log(f"  ✓ Modelos 3D complementares registrados: {dict(totais)}")
    return dict(totais)


# ═══════════════════════ Orquestrador Universal 3D ═══════════════════════
def construir_estruturas_3d(
    con, cli, log=print,
    max_pequenas: int | None = None,
    max_toxinas_af: int | None = None,
    max_alvos_af: int = 45,
) -> dict:
    """Obtém estruturas de fonte externa e preenche pequenas moléculas elegíveis ainda sem geometria."""
    pasta_lotes = config.SAIDA_DIR / "estruturas3d_lotes"
    pasta_lotes.mkdir(parents=True, exist_ok=True)

    # Carrega lotes existentes para atualização idempotente
    lotes: dict[str, dict[str, dict]] = {f"{b:02x}": {} for b in range(256)}
    for arq_existente in pasta_lotes.glob("*.json"):
        bk = arq_existente.stem.lower()
        if bk in lotes:
            try:
                lotes[bk] = json.loads(arq_existente.read_text(encoding="utf-8"))
            except Exception:
                lotes[bk] = {}

    lotes_sujos: set[str] = set()

    def _registrar_no_lote(chave: str, geom: dict) -> tuple[str, str]:
        bk = bucket_chave(chave)
        corpo = json_canonico_bytes(geom)
        sha = hashlib.sha256(corpo).hexdigest()
        lotes[bk][chave] = geom
        lotes_sujos.add(bk)
        return f"estruturas3d_lotes/{bk}.json#{chave}", sha

    def _despejar_lotes_sujos():
        for bk in sorted(lotes_sujos):
            if lotes[bk]:
                (pasta_lotes / f"{bk}.json").write_bytes(json_canonico_bytes(lotes[bk]))
        lotes_sujos.clear()

    # Etapa 0: Garante cobertura estrita de SMILES 27-char e resolve grafos InChI/MolBlock diretos
    n_smiles_reparados, _, _ = reparar_smiles_ausentes(con, cli, log=log)

    # Etapa 1: Estruturas 3D experimentais para pequenas moléculas (wwPDB CCD + COD X-Ray)
    exp_wwpdb = verificar_experimentais_wwpdb_ccd(con, cli, _registrar_no_lote, log=log)
    _despejar_lotes_sujos()
    exp_cod = verificar_experimentais_cod(con, cli, exp_wwpdb, _registrar_no_lote, log=log)
    _despejar_lotes_sujos()

    # Etapa 2: Todas as 225 moléculas peptídicas/proteicas UniProt (PDB experimental + AlphaFold + ESMFold + peptídeos PTM)
    toxinas = con.execute("""
        SELECT m.id, m.nome, m.tipo, m.uniprot_acc, m.pdb_ids, m.comprimento_aa
        FROM molecula m
        WHERE m.uniprot_acc IS NOT NULL
        ORDER BY (m.pdb_ids IS NOT NULL) DESC, m.id ASC
    """).fetchall()

    n_pdb_tox = n_af_tox = n_esm_tox = n_pep_rdkit = 0
    log(f"  Toxinas e proteínas UniProt ({len(toxinas)} entradas): verificando PDB experimental, AlphaFold, ESMFold e peptídeos PTM…")

    for tx in toxinas:
        tid = tx["id"]
        acc = tx["uniprot_acc"].strip().upper()
        pdbs = json.loads(tx["pdb_ids"]) if tx["pdb_ids"] else []

        # Consulta JSON do UniProt quando necessário (para conferir novos PDBs ou sequência/PTMs)
        uniprot_doc = None
        r_up = cli.get(f"{API_UNIPROT}/{acc}.json", fonte="uniprot", tentativas=2)
        if r_up.ok and isinstance(r_up.dados, dict):
            uniprot_doc = r_up.dados
            novos_pdbs = sorted({
                x["id"].upper()
                for x in (uniprot_doc.get("uniProtKBCrossReferences") or [])
                if x.get("database") == "PDB" and x.get("id")
            })
            if novos_pdbs and set(novos_pdbs) != {p.upper() for p in pdbs}:
                pdbs = novos_pdbs
                con.execute("UPDATE molecula SET pdb_ids=? WHERE id=?", (json.dumps(pdbs), tid))

        tem_est_tox = False
        # 2a. Experimental PDB (com b64z atômico incluso para download SDF 3D V2000/V3000!)
        for pdb_cand in pdbs[:3]:
            pdb_id = pdb_cand.strip().upper()
            geom_p, cid_p = _baixar_pdb_experimental(cli, pdb_id)
            if geom_p and cid_p:
                geom_p["id"] = tid
                geom_p["nome"] = tx["nome"]
                chave_p = f"pdb_{pdb_id.lower()}_{tid}"
                arq_rel, sha = _registrar_no_lote(chave_p, geom_p)
                tem_sdf = 1 if "b64z" in geom_p else 0
                _upsert_estrutura(
                    con, molecula_id=tid, natureza="experimental", fonte_id="rcsb_pdb",
                    codigo=pdb_id, metodo=geom_p["met"], resolucao=geom_p["res_ang"],
                    n_elem=len(geom_p["ca"]), n_ss=len(geom_p["ss_bonds"]),
                    arquivo=arq_rel, sha256=sha, consulta_id=cid_p, tem_sdf_3d=tem_sdf,
                )
                n_pdb_tox += 1
                tem_est_tox = True
                break

        # 2b. AlphaFold DB (inclusive para algumas com PDB, ou para todas sem PDB >= 16 aa)
        comp = tx["comprimento_aa"] or (len((uniprot_doc or {}).get("sequence", {}).get("value", "")))
        tentar_af = (comp >= 16) and (not tem_est_tox or n_af_tox < 20)
        if max_toxinas_af is not None and n_af_tox >= max_toxinas_af and tem_est_tox:
            tentar_af = False
        if tentar_af:
            geom_af, cid_af = _baixar_alphafold(cli, acc)
            if geom_af and cid_af:
                geom_af["id"] = tid
                geom_af["nome"] = tx["nome"]
                chave_af = f"af_{acc.lower()}_{tid}"
                arq_rel, sha = _registrar_no_lote(chave_af, geom_af)
                _upsert_estrutura(
                    con, molecula_id=tid, natureza="predicao_computacional", fonte_id="alphafold",
                    codigo=geom_af["cod"], metodo=geom_af["met"], plddt=geom_af["plddt"],
                    n_elem=len(geom_af["ca"]), n_ss=len(geom_af["ss_bonds"]),
                    arquivo=arq_rel, sha256=sha, consulta_id=cid_af, tem_sdf_3d=0,
                )
                n_af_tox += 1
                tem_est_tox = True

        # 2c. Se ainda sem 3D: peptídeo curto (<= 30 aa) -> modelo químico all-atom com PTMs; proteína (>= 16 aa) -> ESMFold v1
        if not tem_est_tox and uniprot_doc:
            seq_val = (uniprot_doc.get("sequence") or {}).get("value") or ""
            if comp <= 30:
                geom_pep, n_ss_pep = _construir_peptideo_ptm_3d(uniprot_doc, tid, tx["nome"], acc)
                if geom_pep:
                    chave_pep = f"mol_{tid}"
                    arq_rel, sha = _registrar_no_lote(chave_pep, geom_pep)
                    _upsert_estrutura(
                        con, molecula_id=tid, natureza="conformero_calculado", fonte_id="rdkit_local",
                        codigo=geom_pep["cod"], metodo=geom_pep["met"], energia=geom_pep["e_kcal"],
                        n_elem=len(seq_val), n_ss=n_ss_pep,
                        arquivo=arq_rel, sha256=sha, consulta_id=r_up.consulta_id, tem_sdf_3d=1,
                    )
                    n_pep_rdkit += 1
                    tem_est_tox = True
            if not tem_est_tox and len(seq_val) >= 12:
                geom_esm, cid_esm = _dobrar_esmfold(con, cli, acc, seq_val)
                if geom_esm and cid_esm:
                    geom_esm["id"] = tid
                    geom_esm["nome"] = tx["nome"]
                    chave_esm = f"esm_{acc.lower()}_{tid}"
                    arq_rel, sha = _registrar_no_lote(chave_esm, geom_esm)
                    _upsert_estrutura(
                        con, molecula_id=tid, natureza="predicao_computacional", fonte_id="esm_atlas",
                        codigo=geom_esm["cod"], metodo=geom_esm["met"], plddt=geom_esm["plddt"],
                        n_elem=len(geom_esm["ca"]), n_ss=len(geom_esm["ss_bonds"]),
                        arquivo=arq_rel, sha256=sha, consulta_id=cid_esm, tem_sdf_3d=0,
                    )
                    n_esm_tox += 1
                    tem_est_tox = True
            if not tem_est_tox and comp <= 60:
                geom_pep, n_ss_pep = _construir_peptideo_ptm_3d(uniprot_doc, tid, tx["nome"], acc)
                if geom_pep:
                    chave_pep = f"mol_{tid}"
                    arq_rel, sha = _registrar_no_lote(chave_pep, geom_pep)
                    _upsert_estrutura(
                        con, molecula_id=tid, natureza="conformero_calculado", fonte_id="rdkit_local",
                        codigo=geom_pep["cod"], metodo=geom_pep["met"], energia=geom_pep["e_kcal"],
                        n_elem=len(seq_val), n_ss=n_ss_pep,
                        arquivo=arq_rel, sha256=sha, consulta_id=r_up.consulta_id, tem_sdf_3d=1,
                    )
                    n_pep_rdkit += 1
                    tem_est_tox = True

    con.commit()
    _despejar_lotes_sujos()

    # Etapa 3: Alvos biológicos humanos (AlphaFold DB)
    alvos = con.execute("""
        SELECT l.id, l.nome, l.uniprot_acc, COUNT(a.id) AS n_afirm
        FROM alvo l
        JOIN afirmacao a ON a.alvo_id = l.id AND a.estado != 'quarentena'
        WHERE l.uniprot_acc IS NOT NULL
        GROUP BY l.id
        ORDER BY n_afirm DESC, l.id ASC
        LIMIT ?
    """, (max_alvos_af,)).fetchall()

    n_alvos_3d = 0
    for al in alvos:
        acc = al["uniprot_acc"].strip().upper()
        geom_al, cid_al = _baixar_alphafold(cli, acc)
        if geom_al and cid_al:
            geom_al["nome"] = al["nome"]
            chave_al = f"alvo_{al['id']}"
            arq_rel, sha = _registrar_no_lote(chave_al, geom_al)
            _upsert_estrutura(
                con, alvo_id=al["id"], natureza="predicao_computacional", fonte_id="alphafold",
                codigo=geom_al["cod"], metodo=geom_al["met"], plddt=geom_al["plddt"],
                n_elem=len(geom_al["ca"]), n_ss=len(geom_al["ss_bonds"]),
                arquivo=arq_rel, sha256=sha, consulta_id=cid_al, tem_sdf_3d=0,
            )
            n_alvos_3d += 1
    con.commit()
    _despejar_lotes_sujos()

    # Uma estrutura de origem existente tem precedência em toda retomada.
    from ..conformeros import preencher_ausentes
    contagens = preencher_ausentes(con, config.SAIDA_DIR, limite=max_pequenas, log=log)
    complementares = preencher_pequenas_preditas_restantes(con, config.SAIDA_DIR, limite=max_pequenas, log=log)

    resumo = {
        "smiles_reparados": n_smiles_reparados,
        "experimentais_wwpdb_ccd": len(exp_wwpdb),
        "experimentais_cod_xray": len(exp_cod),
        "pdb_experimentais": len(exp_wwpdb) + n_pdb_tox,
        "pdb_toxinas_experimentais": n_pdb_tox,
        "alphafold_toxinas": n_af_tox,
        "esmfold_toxinas": n_esm_tox,
        "peptideos_ptm_rdkit": n_pep_rdkit,
        "alphafold_alvos": n_alvos_3d,
        "conformeros_rdkit": contagens.get("gerados", 0) + complementares.get("gerados", 0),
        "pequenas_ausentes": contagens,
        "pequenas_complementares": complementares,
        "total_moleculas_com_3d": con.execute("SELECT COUNT(DISTINCT molecula_id) FROM estrutura_3d WHERE molecula_id IS NOT NULL").fetchone()[0],
    }
    log(f"  ✓ Estruturas 3D universais concluídas: {resumo}")
    return resumo
