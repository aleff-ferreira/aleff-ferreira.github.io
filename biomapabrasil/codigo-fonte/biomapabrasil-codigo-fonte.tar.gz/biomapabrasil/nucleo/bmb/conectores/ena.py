# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""EBI ENA Portal API (CC0 / INSDC): procedência geográfica e voucher de sequências ligadas ao UniProt.

Importante (Princípio 2 e governança CARE / SisGen):
  * Qualquer localidade sub-estadual no campo `country` do INSDC (p.ex. `"Brazil: Amazonas, Presidente Figueiredo"`)
    é reduzida ESTRITAMENTE ao código ISO-2 do país (`BR`) e à sigla oficial da UF (`AM`).
  * Nenhuma coordenada geográfica ou topônimo comunitário fino é armazenado ou exportado.
"""
from __future__ import annotations

import re

API_ENA = "https://www.ebi.ac.uk/ena/portal/api/search"

# Vocabulário de países do INSDC (qualificador /country, hoje /geo_loc_name) → ISO 3166-1 alfa-2.
# Nome que não está aqui fica SEM país: não se deduz código a partir das letras do nome.
MAPA_PAIS_ISO = {
    "afghanistan": "AF", "albania": "AL", "algeria": "DZ", "american samoa": "AS", "andorra": "AD", "angola": "AO",
    "anguilla": "AI", "antarctica": "AQ", "antigua and barbuda": "AG", "argentina": "AR", "armenia": "AM",
    "aruba": "AW", "australia": "AU", "austria": "AT", "azerbaijan": "AZ", "bahamas": "BS", "bahrain": "BH",
    "bangladesh": "BD", "barbados": "BB", "belarus": "BY", "belgium": "BE", "belize": "BZ", "benin": "BJ",
    "bermuda": "BM", "bhutan": "BT", "bolivia": "BO", "bosnia and herzegovina": "BA", "botswana": "BW",
    "brazil": "BR", "brasil": "BR", "british virgin islands": "VG", "brunei": "BN", "bulgaria": "BG",
    "burkina faso": "BF", "burundi": "BI", "cabo verde": "CV", "cape verde": "CV", "cambodia": "KH",
    "cameroon": "CM", "canada": "CA", "cayman islands": "KY", "central african republic": "CF", "chad": "TD",
    "chile": "CL", "china": "CN", "christmas island": "CX", "colombia": "CO", "comoros": "KM", "cook islands": "CK",
    "costa rica": "CR", "cote d'ivoire": "CI", "croatia": "HR", "cuba": "CU", "curacao": "CW", "cyprus": "CY",
    "czechia": "CZ", "czech republic": "CZ", "democratic republic of the congo": "CD", "denmark": "DK",
    "djibouti": "DJ", "dominica": "DM", "dominican republic": "DO", "ecuador": "EC", "egypt": "EG",
    "el salvador": "SV", "equatorial guinea": "GQ", "eritrea": "ER", "estonia": "EE", "eswatini": "SZ",
    "swaziland": "SZ", "ethiopia": "ET", "falkland islands (islas malvinas)": "FK", "faroe islands": "FO",
    "fiji": "FJ", "finland": "FI", "france": "FR", "french guiana": "GF", "french polynesia": "PF", "gabon": "GA",
    "gambia": "GM", "georgia": "GE", "germany": "DE", "ghana": "GH", "gibraltar": "GI", "greece": "GR",
    "greenland": "GL", "grenada": "GD", "guadeloupe": "GP", "guam": "GU", "guatemala": "GT", "guinea": "GN",
    "guinea-bissau": "GW", "guyana": "GY", "haiti": "HT", "honduras": "HN", "hong kong": "HK", "hungary": "HU",
    "iceland": "IS", "india": "IN", "indonesia": "ID", "iran": "IR", "iraq": "IQ", "ireland": "IE", "israel": "IL",
    "italy": "IT", "jamaica": "JM", "japan": "JP", "jordan": "JO", "kazakhstan": "KZ", "kenya": "KE",
    "kiribati": "KI", "kosovo": "XK", "kuwait": "KW", "kyrgyzstan": "KG", "laos": "LA", "latvia": "LV",
    "lebanon": "LB", "lesotho": "LS", "liberia": "LR", "libya": "LY", "liechtenstein": "LI", "lithuania": "LT",
    "luxembourg": "LU", "macau": "MO", "madagascar": "MG", "malawi": "MW", "malaysia": "MY", "maldives": "MV",
    "mali": "ML", "malta": "MT", "marshall islands": "MH", "martinique": "MQ", "mauritania": "MR",
    "mauritius": "MU", "mayotte": "YT", "mexico": "MX", "micronesia": "FM", "moldova": "MD", "monaco": "MC",
    "mongolia": "MN", "montenegro": "ME", "montserrat": "MS", "morocco": "MA", "mozambique": "MZ", "myanmar": "MM",
    "burma": "MM", "namibia": "NA", "nauru": "NR", "nepal": "NP", "netherlands": "NL", "new caledonia": "NC",
    "new zealand": "NZ", "nicaragua": "NI", "niger": "NE", "nigeria": "NG", "niue": "NU", "norfolk island": "NF",
    "north korea": "KP", "north macedonia": "MK", "macedonia": "MK", "northern mariana islands": "MP",
    "norway": "NO", "oman": "OM", "pakistan": "PK", "palau": "PW", "panama": "PA", "papua new guinea": "PG",
    "paraguay": "PY", "peru": "PE", "philippines": "PH", "poland": "PL", "portugal": "PT", "puerto rico": "PR",
    "qatar": "QA", "republic of the congo": "CG", "reunion": "RE", "romania": "RO", "russia": "RU", "rwanda": "RW",
    "saint kitts and nevis": "KN", "saint lucia": "LC", "saint vincent and the grenadines": "VC", "samoa": "WS",
    "san marino": "SM", "sao tome and principe": "ST", "saudi arabia": "SA", "senegal": "SN", "serbia": "RS",
    "seychelles": "SC", "sierra leone": "SL", "singapore": "SG", "sint maarten": "SX", "slovakia": "SK",
    "slovenia": "SI", "solomon islands": "SB", "somalia": "SO", "south africa": "ZA", "south korea": "KR",
    "south sudan": "SS", "spain": "ES", "sri lanka": "LK", "sudan": "SD", "suriname": "SR", "sweden": "SE",
    "switzerland": "CH", "syria": "SY", "taiwan": "TW", "tajikistan": "TJ", "tanzania": "TZ", "thailand": "TH",
    "timor-leste": "TL", "east timor": "TL", "togo": "TG", "tonga": "TO", "trinidad and tobago": "TT",
    "tunisia": "TN", "turkey": "TR", "turkiye": "TR", "turkmenistan": "TM", "turks and caicos islands": "TC",
    "tuvalu": "TV", "uganda": "UG", "ukraine": "UA", "united arab emirates": "AE", "united kingdom": "GB",
    "united states": "US", "usa": "US", "uruguay": "UY", "uzbekistan": "UZ", "vanuatu": "VU", "venezuela": "VE",
    "viet nam": "VN", "vietnam": "VN", "virgin islands": "VI", "yemen": "YE", "zambia": "ZM", "zimbabwe": "ZW",
}

MAPA_UF_NOME = {
    "acre": "AC", "alagoas": "AL", "amapa": "AP", "amapá": "AP", "amazonas": "AM",
    "bahia": "BA", "ceara": "CE", "ceará": "CE", "distrito federal": "DF",
    "espirito santo": "ES", "espírito santo": "ES", "goias": "GO", "goiás": "GO",
    "maranhao": "MA", "maranhão": "MA", "mato grosso do sul": "MS", "mato grosso": "MT",
    "minas gerais": "MG", "para": "PA", "pará": "PA", "paraiba": "PB", "paraíba": "PB",
    "parana": "PR", "paraná": "PR", "pernambuco": "PE", "piaui": "PI", "piauí": "PI",
    "rio de janeiro": "RJ", "rio grande do norte": "RN", "rio grande do sul": "RS",
    "rondonia": "RO", "rondônia": "RO", "roraima": "RR", "santa catarina": "SC",
    "sao paulo": "SP", "são paulo": "SP", "sergipe": "SE", "tocantins": "TO",
}
SIGLAS_UF = set(MAPA_UF_NOME.values())
_CODIGOS_ISO = set(MAPA_PAIS_ISO.values())
_PADRAO_VOUCHER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 .:/_#()<>-]{1,79}$")
# Pedaço de um código de coleção: sigla em maiúsculas («INPA», «INPA-H», «J.») ou identificador com dígito
# («22410», «MCZ:Herp:A-12345»). Palavra comum (lugar, nome de coletor) não é nem uma coisa nem outra.
_PEDACO_DE_CODIGO = re.compile(r"^(?:[A-Z]{1,12}(?:[-:/][A-Z]{1,8}){0,3}\.?|[A-Za-z0-9.:/_#<>()-]*\d[A-Za-z0-9.:/_#<>()-]*)$")


def voucher_sem_localidade(texto: str | None) -> str | None:
    """Devolve o testemunho só quando ele é um código de coleção (sigla e número). Texto livre com país, estado ou
    localidade é descartado: o projeto não guarda localidade mais fina que país e UF, nem por via indireta."""
    v = " ".join((texto or "").split())
    if not v or not _PADRAO_VOUCHER.match(v) or not any(c.isdigit() for c in v):
        return None
    if not all(_PEDACO_DE_CODIGO.match(pedaco) for pedaco in v.split(" ")):
        return None                             # «Manaus AM 2019», «coletado em … por J. Silva 123»: texto, não código
    if set(re.findall(r"[a-zà-ÿ]{4,}", v.lower())) & (set(MAPA_PAIS_ISO) | set(MAPA_UF_NOME)):
        return None
    return v[:80]


def interpretar_pais_uf_ena(country_str: str | None) -> tuple[str | None, str | None]:
    """Converte string INSDC `country` (ex. `'Brazil: Para, Santarem'`) em `(pais_iso2, uf_sigla)`."""
    if not country_str or not country_str.strip():
        return None, None
    partes = country_str.split(":", 1)
    pais_txt = " ".join(partes[0].strip().lower().split())
    pais_cod = MAPA_PAIS_ISO.get(pais_txt)
    if not pais_cod and len(pais_txt) == 2 and pais_txt.isalpha() and pais_txt.upper() in _CODIGOS_ISO:
        pais_cod = pais_txt.upper()          # a base já trouxe o código

    uf_sigla = None
    if pais_cod == "BR" and len(partes) > 1:
        sub = partes[1].strip()
        sub_low = sub.lower()
        # Testa primeiro nomes longos ("mato grosso do sul" antes de "mato grosso", "paraiba" antes de "para")
        for nome_est in sorted(MAPA_UF_NOME, key=len, reverse=True):
            if re.search(rf"\b{re.escape(nome_est)}\b", sub_low):
                uf_sigla = MAPA_UF_NOME[nome_est]
                break
        if not uf_sigla:
            m = re.search(r"\b([A-Z]{2})\b", sub)
            if m and m.group(1) in SIGLAS_UF:
                uf_sigla = m.group(1)
    return pais_cod, uf_sigla


def buscar_procedencia_embl_em_lote(cli, acessos_embl: list[str], tamanho_lote: int = 35) -> dict[str, dict]:
    """Consulta o EBI ENA Portal API em lotes de acessos EMBL/GenBank.

    Retorna `{embl_acc: {'pais': iso2_ou_None, 'uf': sigla_ou_None, 'voucher': str_ou_None, 'consulta_id': int}}`.
    Todo acesso de um lote que o ENA respondeu tem entrada, mesmo sem país nem testemunho: «o ENA não declara» é
    resposta. Acesso de lote que falhou (rede) fica SEM entrada: aí nada se sabe, e o que já estava gravado não muda.
    """
    unicos = sorted({a.strip() for a in acessos_embl if a and a.strip() and re.fullmatch(r"[A-Za-z0-9_]+", a.strip())})
    saida = {}
    for i in range(0, len(unicos), tamanho_lote):
        lote = unicos[i:i + tamanho_lote]
        query = " OR ".join(f'accession="{acc}"' for acc in lote)
        try:
            r = cli.get(
                API_ENA,
                {
                    "result": "sequence",
                    "query": query,
                    "fields": "accession,country,specimen_voucher",
                    "format": "json",
                },
                fonte="ena",
                tentativas=2,
            )
        except Exception:
            continue
        if not isinstance(r.dados, list):
            if getattr(r, "status", 200) not in (200, 204):
                continue
            r_dados = []
        else:
            r_dados = r.dados
        for acc in lote:
            saida[acc] = {"pais": None, "uf": None, "voucher": None, "consulta_id": r.consulta_id}
        for item in r_dados:
            acc = (item.get("accession") or "").strip()
            if not acc:
                continue
            pais, uf = interpretar_pais_uf_ena(item.get("country"))
            voucher = voucher_sem_localidade(item.get("specimen_voucher"))
            saida[acc] = {"pais": pais, "uf": uf, "voucher": voucher, "consulta_id": r.consulta_id}
    return saida
