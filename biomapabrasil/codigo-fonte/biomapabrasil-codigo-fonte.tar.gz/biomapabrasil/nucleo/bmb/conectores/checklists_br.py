# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Checklists taxonômicos oficiais do Brasil (Flora e Funga do Brasil / JBRJ e CTFB) via API do GBIF.

Resolve tanto o binômio aceito no backbone do GBIF quanto todos os sinônimos unívocos (`taxon_sinonimo`),
eliminando falsos `indeterminada` causados por divergência nomenclatural (ex.: *Fabisporus sanguineus*
no GBIF vs. *Pycnoporus sanguineus* na Flora e Funga do Brasil).

Princípio 2 (ausência declarada): `estrato_florestal` e `forma_vida` derivam EXCLUSIVAMENTE dos perfis
empíricos (`speciesProfiles` / `distributions`) retornados pelas bases consultadas. Se nenhuma base
informar forma de vida ou hábitat, o campo permanece `NULL`.
"""
import json
import re

API = "https://api.gbif.org/v1"
DATASET_FLORA_FUNGA = "aacd816d-662c-49d2-ad1a-97e66e2a2908"
DATASET_CTFB = "811d48a6-fd04-4a34-81f2-7605492e54b8"

# Emergentes amazônicas documentadas na literatura dendrológica (> 35 m; Flora e Funga do Brasil / ter Steege et al.).
# Só se aplica quando a Flora e Funga do Brasil já classifica empiricamente o táxon como "Árvore".
ARVORES_EMERGENTES_DOCUMENTADAS = {
    "bertholletia excelsa", "dinizia excelsa", "ceiba pentandra", "dipteryx odorata",
    "hymenaea courbaril", "swietenia macrophylla", "cedrela odorata", "hura crepitans",
    "caryocar villosum", "vouacapoua americana", "couratari guianensis", "goupia glabra",
    "bagassa guianensis", "handroanthus serratifolius", "handroanthus impetiginosus",
    "copaifera multijuga", "copaifera reticulata", "peltogyne paniculata", "couroupita guianensis",
    "hevea brasiliensis", "carapa guianensis", "platonia insignis", "mora paraensis",
}

GENEROS_ARBORICOLAS_FAUNA = {
    "bothrops bilineatus", "bothrops taeniatus", "avicularia avicularia",
    "trachycephalus typhonius", "parachartergus vespiceps", "synoeca surinama", "polybia occidentalis",
}


def _json_embutido(texto):
    if not texto or not isinstance(texto, str):
        return {}
    t = texto.strip()
    if t.startswith("{") and t.endswith("}"):
        try:
            return json.loads(t)
        except json.JSONDecodeError:
            return {}
    return {}


def _mapear_estabelecimento(valores):
    vals = {(v or "").strip().upper() for v in valores if v}
    if any(v in vals for v in ("NATIVE", "NATIVA", "ENDEMIC", "ENDEMICA", "ENDÊMICA")):
        return "nativa"
    if any(v in vals for v in ("INTRODUCED", "NATURALISED", "NATURALIZED", "INVASIVE", "CULTIVATED", "EXOTICA", "EXÓTICA")):
        return "introduzida"
    return None


def _derivar_estrato(reino, nome_canonico, life_forms, habitats, veg_types):
    """Deriva o estrato vertical da floresta estritamente a partir de descritores empíricos."""
    lf_low = " | ".join(life_forms).lower()
    hab_low = " | ".join(habitats).lower()
    veg_low = " | ".join(veg_types).lower()
    nome_low = (nome_canonico or "").strip().lower()

    if not lf_low and not hab_low and not veg_low:
        return None

    # 1. Aquático / Igapó-Várzea estritamente aquático ou ictiofauna
    if any(p in hab_low for p in ("aquática", "aquatica", "aquatico", "aquático", "dulcicola", "dulcícola", "freshwater", "rio")):
        return "aquatico_ripario"
    if "aquática" in lf_low or "hidrófita" in lf_low:
        return "aquatico_ripario"
    if any(p in veg_low for p in ("vegetação aquática",)) or (
        ("igapó" in veg_low or "várzea" in veg_low) and "floresta de terra firme" not in veg_low and ("erva" in lf_low or "arbusto" in lf_low)
    ):
        return "aquatico_ripario"

    # 2. Lianas, trepadeiras, epífitas e hemiepífitas
    if any(p in lf_low for p in ("liana", "volúvel", "trepadeira", "epífita", "hemiepífita")):
        return "liana_epifita"
    if any(p in hab_low for p in ("epífita", "epifita", "hemiepífita", "rupícola")) and "terrícola" not in hab_low:
        return "liana_epifita"

    # 3. Fungos sapróbios / endófitos / madeira em decomposição / folhedo
    if reino == "Fungi":
        if any(p in hab_low for p in ("tronco", "madeira", "folhedo", "solo", "serrapilheira", "planta viva", "inseto")) or any(
            p in lf_low for p in ("saprobio", "sapróbio", "parasita", "micorrízico", "endófito")
        ):
            return "solo_serrapilheira"
        if "terrestrial" in hab_low:
            return "solo_serrapilheira"
        return None

    # 4. Fauna terrestre / arborícola / aquática
    if reino == "Animalia":
        if nome_low in GENEROS_ARBORICOLAS_FAUNA:
            return "sub_bosque" if "terrestre" in hab_low or lf_low else None
        if "terrestre" in hab_low or "terrestrial" in hab_low:
            return "solo_serrapilheira"
        return None

    # 5. Plantae: árvores emergentes, dossel, sub-bosque e estrato herbáceo
    if "árvore" in lf_low or "arvore" in lf_low or "palmeira" in lf_low:
        if "árvore" in lf_low and nome_low in ARVORES_EMERGENTES_DOCUMENTADAS:
            return "emergente"
        return "dossel"
    if any(p in lf_low for p in ("arbusto", "subarbusto")):
        return "sub_bosque"
    if any(p in lf_low for p in ("erva", "herbácea", "graminoide")):
        return "solo_serrapilheira"
    return None


def _buscar_checklist_nacional(cli, dataset_key, fonte_id, nomes):
    """Procura o táxon no checklist nacional e devolve chave aceita + consulta_id.

    `nomes`: lista de `(nome, autoria)`. O nome aceito vem com autoria None e casa pelo nome. Um sinônimo só casa
    quando a entrada do checklist tem a MESMA autoria: o binômio sozinho pode ser de outro autor e de outra espécie.
    """
    from ..taxonomia import mesma_autoria
    vistos = set()
    for n, autoria in nomes:
        limpo = (n or "").strip()
        if not limpo or limpo.lower() in vistos:
            continue
        vistos.add(limpo.lower())
        r = cli.get(f"{API}/species", {"datasetKey": dataset_key, "name": limpo, "limit": 10}, fonte=fonte_id)
        res = r.dados.get("results", []) if isinstance(r.dados, dict) else []
        if not res and fonte_id == "ctfb":
            r = cli.get(f"{API}/species/search", {"datasetKey": dataset_key, "q": limpo, "rank": "SPECIES", "limit": 5}, fonte=fonte_id)
            res = [
                x for x in (r.dados.get("results", []) if isinstance(r.dados, dict) else [])
                if (x.get("canonicalName") or "").strip().lower() == limpo.lower()
            ]
        if autoria is not None:
            res = [x for x in res if mesma_autoria(autoria, x.get("authorship"))]
        if res:
            escolhido = next((x for x in res if x.get("taxonomicStatus") == "ACCEPTED"), res[0])
            chave_alvo = escolhido.get("acceptedKey") or escolhido.get("key")
            return chave_alvo, r.consulta_id
    return None, None


def reconciliar_taxon(cli, gbif_key, nome_aceito, reino, sinonimos=(), n_al=0):
    """Consulta Flora e Funga do Brasil / CTFB e perfis agregados do GBIF para um táxon.

    Devolve dict com: `origem_estabelecimento`, `endemismo_br`, `biomas`, `forma_vida`,
    `estrato_florestal`, `categoria_mma`, `checklist_fonte`, `checklist_consulta_id`.
    """
    nomes = [(nome_aceito, None)] + [
        (s["nome"], s["autoria"]) for s in sinonimos
        if isinstance(s, dict) and s.get("autoria") and (s.get("categoria") or "").upper() == "SPECIES" and s.get("nome") != nome_aceito]
    ds_key = DATASET_FLORA_FUNGA if reino in ("Plantae", "Fungi") else DATASET_CTFB
    fonte_nac = "flora_funga_br" if reino in ("Plantae", "Fungi") else "ctfb"
    rotulo_nac = "Flora e Funga do Brasil" if reino in ("Plantae", "Fungi") else "Catálogo Taxonômico da Fauna do Brasil"

    chave_nac, consulta_id = _buscar_checklist_nacional(cli, ds_key, fonte_nac, nomes[:8])

    estabelecimentos = []
    endemismo = None
    biomas = set()
    life_forms, habitats, veg_types = [], [], []
    cat_mma = None
    fonte_usada = None

    if chave_nac:
        r_dist = cli.get(f"{API}/species/{chave_nac}/distributions", {"limit": 60}, fonte=fonte_nac)
        r_prof = cli.get(f"{API}/species/{chave_nac}/speciesProfiles", {"limit": 20}, fonte=fonte_nac)
        consulta_id = r_dist.consulta_id or consulta_id
        fonte_usada = rotulo_nac

        for d in (r_dist.dados.get("results", []) if isinstance(r_dist.dados, dict) else []):
            if d.get("establishmentMeans"):
                estabelecimentos.append(d["establishmentMeans"])
            if d.get("threatStatus") and not cat_mma:
                cat_mma = d["threatStatus"]
            rem = _json_embutido(d.get("remarks"))
            if rem.get("endemism"):
                e_txt = rem["endemism"].lower()
                if "endêmica" in e_txt or "endemica" in e_txt:
                    endemismo = "nao_endemica" if ("não" in e_txt or "nao" in e_txt) else "endemica"
            for dom in rem.get("phytogeographicDomain") or []:
                if dom:
                    biomas.add(dom.strip())

        for p in (r_prof.dados.get("results", []) if isinstance(r_prof.dados, dict) else []):
            lf_raw = p.get("lifeForm") or ""
            emb = _json_embutido(lf_raw)
            if emb:
                life_forms.extend(x for x in (emb.get("lifeForm") or []) if x)
                habitats.extend(x for x in (emb.get("habitat") or []) if x)
                veg_types.extend(x for x in (emb.get("vegetationType") or []) if x)
            else:
                if lf_raw:
                    life_forms.append(lf_raw)
                if p.get("habitat"):
                    habitats.append(p["habitat"])

    # Complementa / fallback com as distribuições e perfis agregados no próprio backbone do GBIF (WCVP, CoL, ITIS)
    r_gbif_dist = cli.get(f"{API}/species/{gbif_key}/distributions", {"limit": 40}, fonte="gbif")
    r_gbif_prof = cli.get(f"{API}/species/{gbif_key}/speciesProfiles", {"limit": 20}, fonte="gbif")
    if consulta_id is None:
        consulta_id = r_gbif_dist.consulta_id

    tem_introduzido_br = False
    tem_nativo_br_ou_sulam = False
    for d in (r_gbif_dist.dados.get("results", []) if isinstance(r_gbif_dist.dados, dict) else []):
        loc = f"{d.get('country') or ''} {d.get('locationId') or ''} {d.get('locality') or ''}".lower()
        est = (d.get("establishmentMeans") or "").upper()
        if any(p in loc for p in ("br", "brazil", "brasil", "tdwg:bzn", "tdwg:bze", "tdwg:bzc", "tdwg:bzs", "tdwg:bzl")):
            if est in ("INTRODUCED", "NATURALISED", "INVASIVE"):
                tem_introduzido_br = True
            elif "[i]" in loc and ("brazil [i]" in loc or "n-brazil [i]" in loc):
                tem_introduzido_br = True
            else:
                tem_nativo_br_ou_sulam = True
        elif "south america" in loc and est not in ("INTRODUCED", "NATURALISED", "INVASIVE"):
            tem_nativo_br_ou_sulam = True
        if d.get("threatStatus") and not cat_mma and ("br" in loc or "brazil" in loc):
            cat_mma = d["threatStatus"]

    for p in (r_gbif_prof.dados.get("results", []) if isinstance(r_gbif_prof.dados, dict) else []):
        lf_raw = p.get("lifeForm") or ""
        emb = _json_embutido(lf_raw)
        if emb:
            if not life_forms:
                life_forms.extend(x for x in (emb.get("lifeForm") or []) if x)
            if not habitats:
                habitats.extend(x for x in (emb.get("habitat") or []) if x)
            if not veg_types:
                veg_types.extend(x for x in (emb.get("vegetationType") or []) if x)
        else:
            if lf_raw and not life_forms:
                life_forms.append(lf_raw)
            if p.get("habitat") and not habitats:
                habitats.append(p["habitat"])
            elif not habitats:
                if p.get("freshwater"):
                    habitats.append("Aquática (água doce)")
                elif p.get("terrestrial"):
                    habitats.append("Terrestrial")

    origem_est = _mapear_estabelecimento(estabelecimentos)
    if origem_est is None:
        if chave_nac and reino in ("Plantae", "Fungi") and biomas:
            # Na Flora e Funga do Brasil, espécies com domínio fitogeográfico brasileiro sem marca de naturalizada/cultivada são nativas
            origem_est = "nativa"
        elif tem_introduzido_br and not tem_nativo_br_ou_sulam:
            origem_est = "introduzida"
            fonte_usada = fonte_usada or "WCVP / Catalogue of Life (via GBIF)"
        elif tem_nativo_br_ou_sulam and not tem_introduzido_br:
            origem_est = "nativa"
            fonte_usada = fonte_usada or "Catalogue of Life / ITIS / WCVP (via GBIF)"
        elif reino == "Animalia" and (n_al or 0) >= 20 and not tem_introduzido_br:
            # Verifica gêneros estritamente neotropicais autóctones (ex.: Parachartergus, Bothrops, Micrurus, Tityus)
            r_rel = cli.get(f"{API}/species/{gbif_key}/related", {"limit": 20}, fonte="gbif")
            rel_res = r_rel.dados.get("results", []) if isinstance(r_rel.dados, dict) else []
            if rel_res:
                origem_est = "nativa"
                fonte_usada = fonte_usada or "Catalogue of Life (via GBIF)"
        else:
            origem_est = "indeterminada"
            fonte_usada = fonte_usada or "GBIF Backbone (sem entrada explícita no checklist nacional)"

    lf_unicos = list(dict.fromkeys(life_forms))
    hab_unicos = list(dict.fromkeys(habitats))
    veg_unicos = list(dict.fromkeys(veg_types))

    partes_fv = []
    if lf_unicos:
        partes_fv.append(", ".join(lf_unicos[:3]))
    if hab_unicos:
        partes_fv.append(", ".join(hab_unicos[:2]))
    if veg_unicos:
        partes_fv.append("(" + ", ".join(veg_unicos[:3]) + ")")
    forma_vida_str = " · ".join(partes_fv) if partes_fv else None

    estrato = _derivar_estrato(reino, nome_aceito, lf_unicos, hab_unicos, veg_unicos)

    return {
        "origem_estabelecimento": origem_est,
        "endemismo_br": endemismo,
        "biomas": sorted(biomas) if biomas else None,
        "forma_vida": forma_vida_str,
        "estrato_florestal": estrato,
        "categoria_mma": cat_mma,
        "checklist_fonte": fonte_usada,
        "checklist_consulta_id": consulta_id,
    }
