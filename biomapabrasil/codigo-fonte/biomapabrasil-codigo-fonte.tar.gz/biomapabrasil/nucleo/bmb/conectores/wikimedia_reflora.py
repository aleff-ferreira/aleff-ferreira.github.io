# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Wikimedia Commons (suplemento fotográfico para espécies sem mídia suficiente no GBIF).

Cumpre estritamente o Princípio 3:
  * Só aceita imagens cuja URL de licença em `extmetadata.LicenseUrl` normalize para `'CC0'` ou `'CC BY'`
    via `config.normalizar_licenca` (rejeitando `CC BY-SA`, `CC BY-NC`, `CC BY-ND` e licenças sem URL).
  * Exige autor identificável (`extmetadata.Artist`, sem HTML) e página de origem verificável.
"""
import html
import re

from .. import config

API_COMMONS = "https://commons.wikimedia.org/w/api.php"
_TAG_HTML = re.compile(r"<[^>]+>")
_EXCLUIR_TITULO = re.compile(
    r"\b(map|mapa|range|distribution|distribuicao|herbarium|stamp|selo|coat_of_arms|logo|icon|svg|diagram|dead|roadkill)\b",
    re.IGNORECASE,
)


def _limpar_artista(bruto):
    if not bruto or not isinstance(bruto, str):
        return None
    limpo = html.unescape(_TAG_HTML.sub(" ", bruto))
    limpo = re.sub(r"\s+", " ", limpo).strip(" -–·,;:")
    if not limpo or limpo.lower() in ("unknown", "unknown author", "anonymous", "n/a"):
        return None
    return limpo[:140]


def imagens_commons(cli, nomes_busca, maximo=3):
    """Busca fotografias `CC0` ou `CC BY` no Wikimedia Commons para o binômio aceito (ou sinônimo)."""
    saida = []
    autores_vistos = set()
    urls_vistas = set()

    for nome in list(dict.fromkeys(nomes_busca))[:2]:
        limpo = (nome or "").strip()
        if not limpo:
            continue
        try:
            r = cli.get(
                API_COMMONS,
                {
                    "action": "query",
                    "generator": "search",
                    "gsrnamespace": "6",
                    "gsrsearch": f'"{limpo}" filetype:bitmap',
                    "gsrlimit": "15",
                    "prop": "imageinfo",
                    "iiprop": "url|extmetadata|dimensions",
                    "iiurlwidth": "1024",
                    "format": "json",
                },
                fonte="wikimedia_commons",
                tentativas=2,
            )
        except Exception:
            continue

        paginas = (r.dados.get("query", {}).get("pages", {}) if isinstance(r.dados, dict) else {})
        for pg in paginas.values():
            titulo = pg.get("title") or ""
            if _EXCLUIR_TITULO.search(titulo):
                continue
            infos = pg.get("imageinfo") or []
            if not infos:
                continue
            ii = infos[0]
            w = ii.get("width") or 0
            h = ii.get("height") or 0
            if w < 480 or h < 360:
                continue
            ext = ii.get("extmetadata") or {}
            lic_url = (ext.get("LicenseUrl") or {}).get("value")
            lic = config.normalizar_licenca(lic_url)
            if lic not in config.LICENCAS_IMAGEM_OK:
                continue
            autor = _limpar_artista((ext.get("Artist") or {}).get("value"))
            if not autor or autor in autores_vistos:
                continue
            url_dl = ii.get("thumburl") or ii.get("url")
            pagina = ii.get("descriptionurl")
            if not url_dl or not pagina or url_dl in urls_vistas:
                continue
            desc_txt = html.unescape(_TAG_HTML.sub(" ", (ext.get("ImageDescription") or {}).get("value") or ""))
            brasil = bool(re.search(r"\b(bra[sz]il|amaz[oô]n|manaus|bel[eé]m|acre|rond[oô]nia|roraima|amap[aá]|mato grosso)\b", desc_txt, re.I))

            autores_vistos.add(autor)
            urls_vistas.add(url_dl)
            saida.append({
                "url": url_dl,
                "licenca": lic,
                "autor": autor,
                "instituicao": "Wikimedia Commons",
                "pagina": pagina,
                "gbif_ocorrencia": None,
                "base_registro": "WIKIMEDIA_COMMONS",
                "brasil": brasil,
                "pais": "BR" if brasil else None,
                "consulta_id": r.consulta_id,
            })
            if len(saida) >= maximo:
                return saida
    return saida
