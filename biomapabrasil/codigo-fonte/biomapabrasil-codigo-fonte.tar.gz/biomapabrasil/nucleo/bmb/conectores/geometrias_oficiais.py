# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Geodésia oficial SIRGAS 2000 / Brazil Polyconic (EPSG:5880) e elipsoide GRS80.

Integra e audita com soma criptográfica SHA-256 as malhas vetoriais oficiais:
  1. Amazônia Legal brasileira (IBGE / INPE TerraBrasilis WFS `prodes-legal-amz:brazilian_legal_amazon`, ~5.017.854 km²).
  2. Bioma Amazônia oficial 1:250.000 (IBGE / INPE TerraBrasilis WFS `prodes-amazon-nb:amazon_biome_border`, ~4.215.443 km²).
  3. Sub-bacias hidrográficas amazônicas Pfafstetter Nível 4/5 (ANA / HydroBASINS South America v1c recortadas pela Amazônia Legal).
  4. Unidades de Conservação (CNUC/MMA) e Terras Indígenas (FUNAI) via WFS oficial TerraBrasilis, com união topológica
     exata em EPSG:5880 (`(UC ∪ TI) ∩ célula`, zero dupla contagem quando TI e UC se sobrepõem).
"""
from __future__ import annotations

import functools
import json
from pathlib import Path

from pyproj import Geod, Transformer
import numpy as np
from shapely import STRtree, transform as shp_transform_coords
from shapely.geometry import MultiPolygon, Point, Polygon, box, shape
from shapely.ops import unary_union

from .. import config, projecao

CRS_GEODESICO = "EPSG:5880"  # SIRGAS 2000 / Brazil Polyconic (IBGE)
GEOD_GRS80 = Geod(ellps="GRS80")
_TRANS_4326_5880 = Transformer.from_crs("EPSG:4326", CRS_GEODESICO, always_xy=True)

URL_WFS_LEGAL_AMZ = (
    "https://terrabrasilis.dpi.inpe.br/geoserver/prodes-legal-amz/ows"
    "?service=WFS&version=1.0.0&request=GetFeature"
    "&typeName=prodes-legal-amz:brazilian_legal_amazon&outputFormat=application/json"
)
URL_WFS_BIOMA_AMZ = (
    "https://terrabrasilis.dpi.inpe.br/geoserver/prodes-amazon-nb/ows"
    "?service=WFS&version=1.0.0&request=GetFeature"
    "&typeName=prodes-amazon-nb:amazon_biome_border&outputFormat=application/json"
)
URL_WFS_CNUC = (
    "https://terrabrasilis.dpi.inpe.br/geoserver/prodes-legal-amz/ows"
    "?service=WFS&version=1.0.0&request=GetFeature"
    "&typeName=prodes-legal-amz:conservation_units_legal_amazon&outputFormat=application/json"
)
URL_WFS_FUNAI = (
    "https://terrabrasilis.dpi.inpe.br/geoserver/prodes-legal-amz/ows"
    "?service=WFS&version=1.0.0&request=GetFeature"
    "&typeName=prodes-legal-amz:indigenous_area_legal_amazon&outputFormat=application/json"
)
URL_HYDROBASINS_L5 = "https://data.hydrosheds.org/file/hydrobasins/standard/hybas_sa_lev05_v1c.zip"


def caminho_geo_base() -> Path:
    return config.SEMENTE_DIR / "geo_base"


@functools.lru_cache(maxsize=1)
def carregar_limites_oficiais() -> dict:
    arq = caminho_geo_base() / "limites_oficiais.json"
    return json.loads(arq.read_text(encoding="utf-8"))


@functools.lru_cache(maxsize=1)
def carregar_grade_molde_05deg() -> list[dict]:
    arq = caminho_geo_base() / "grade_05deg_molde.json"
    return json.loads(arq.read_text(encoding="utf-8"))


def projetar_epsg5880(geom):
    """Projeta geometria Shapely de WGS84/SIRGAS2000 geográfico (lon, lat) para EPSG:5880 (metros)."""
    def _proj_xy(coords: np.ndarray) -> np.ndarray:
        x, y = _TRANS_4326_5880.transform(coords[:, 0], coords[:, 1])
        return np.column_stack([x, y])

    return shp_transform_coords(geom, _proj_xy)


def area_geodesica_km2(geom) -> float:
    """Área geodésica exata sobre o elipsoide GRS80 / SIRGAS 2000 em km²."""
    if geom is None or geom.is_empty:
        return 0.0
    area_m2, _ = GEOD_GRS80.geometry_area_perimeter(geom)
    return round(abs(area_m2) / 1e6, 2)


def area_celula_05deg_km2(lon: float, lat: float, passo: float = 0.5) -> float:
    """Área geodésica exata (GRS80) de uma célula regular lon/lat em km²."""
    m = passo / 2.0
    lons = [lon - m, lon + m, lon + m, lon - m, lon - m]
    lats = [lat - m, lat - m, lat + m, lat + m, lat - m]
    area_m2, _ = GEOD_GRS80.polygon_area_perimeter(lons, lats)
    return round(abs(area_m2) / 1e6, 2)


def aneis_para_svg_d(aneis: list[list[list[float]]]) -> str:
    """Converte uma lista de anéis exteriores `[[lon, lat], ...]` em um caminho SVG projetado."""
    partes = []
    for anel in aneis:
        if len(anel) < 3:
            continue
        pts = [projecao.proj(float(lon), float(lat)) for lon, lat in anel]
        partes.append("M" + "L".join(f"{x:.1f},{y:.1f}" for x, y in pts) + "Z")
    return "".join(partes)


@functools.lru_cache(maxsize=1)
def _indice_bacias():
    lim = carregar_limites_oficiais()
    geoms = []
    ids = []
    for b in lim["bacias"]:
        polys = [Polygon(anel).buffer(0) for anel in b["aneis_display"] if len(anel) >= 4]
        if polys:
            geoms.append(unary_union(polys))
            ids.append(b["id"])
    return STRtree(geoms), geoms, ids


def bacia_do_ponto(lon: float, lat: float) -> str | None:
    """Determina a sub-bacia hidrográfica amazônica oficial (HydroBASINS L4/L5) de um ponto."""
    tree, geoms, ids = _indice_bacias()
    pt = Point(lon, lat)
    for idx in tree.query(pt):
        if geoms[int(idx)].covers(pt):
            return ids[int(idx)]
    # Caso caia exatamente sobre uma borda simplificada costeira/limítrofe, usa a bacia mais próxima até 0.35°
    melhor_id, d_min = None, 0.35
    for idx in range(len(geoms)):
        d = geoms[idx].distance(pt)
        if d < d_min:
            d_min = d
            melhor_id = ids[idx]
    return melhor_id


class IndiceProtecaoVetorial:
    """Índice espacial geodésico (EPSG:5880) da união topológica CNUC ∪ FUNAI sem dupla contagem."""

    def __init__(self, poligonos_5880: list, consulta_ids: list[int]):
        self.poligonos = poligonos_5880
        self.tree = STRtree(poligonos_5880) if poligonos_5880 else None
        self.consulta_ids = [c for c in consulta_ids if c is not None]

    def fracao_protegida_celula(self, lon: float, lat: float, passo: float = 0.5) -> float:
        if not self.tree:
            return 0.0
        m = passo / 2.0
        cel_5880 = projetar_epsg5880(box(lon - m, lat - m, lon + m, lat + m))
        area_cel = cel_5880.area
        if area_cel <= 0:
            return 0.0
        idxs = self.tree.query(cel_5880)
        if len(idxs) == 0:
            return 0.0
        recortes = []
        for idx in idxs:
            g = self.poligonos[int(idx)]
            if g.intersects(cel_5880):
                inter = g.intersection(cel_5880)
                if not inter.is_empty and inter.area > 0:
                    recortes.append(inter)
        if not recortes:
            return 0.0
        # Pela distributividade (⋃ P_i) ∩ C = ⋃ (P_i ∩ C): zero dupla contagem entre UC e TI sobrepostas!
        uniao_local = unary_union(recortes)
        return round(min(1.0, max(0.0, float(uniao_local.area / area_cel))), 4)


def carregar_protecao_vetorial_oficial(cli, log=print) -> IndiceProtecaoVetorial | None:
    """Baixa (ou lê do cache SHA-256) os polígonos WFS oficiais CNUC + FUNAI e indexa em EPSG:5880."""
    pols_5880 = []
    cids = []
    # Registra também as malhas oficiais IBGE Amazônia Legal e Bioma Amazônia e HydroBASINS no log de consultas
    for fonte, url in (
        ("ibge", URL_WFS_LEGAL_AMZ),
        ("ibge", URL_WFS_BIOMA_AMZ),
        ("ana_hydrosheds", URL_HYDROBASINS_L5),
    ):
        try:
            r = cli.get(url, fonte=fonte, como_json=False, como_bytes=True, tentativas=2)
            if r.consulta_id:
                cids.append(r.consulta_id)
        except Exception as exc:
            log(f"    aviso registro vetorial ({fonte}): {exc}")

    for rotulo, url in (("CNUC Unidades de Conservação", URL_WFS_CNUC), ("FUNAI Terras Indígenas", URL_WFS_FUNAI)):
        try:
            r = cli.get(url, fonte="terrabrasilis_cnuc", como_json=False, como_bytes=True, tentativas=2)
            if r.consulta_id:
                cids.append(r.consulta_id)
            fc = json.loads(r.dados.decode("utf-8"))
            feats = fc.get("features") or []
            n_ok = 0
            for f in feats:
                geom_raw = f.get("geometry")
                if not geom_raw:
                    continue
                g = shape(geom_raw)
                if not g.is_valid:
                    g = g.buffer(0)
                if g.is_empty:
                    continue
                g_5880 = projetar_epsg5880(g)
                if not g_5880.is_valid:
                    g_5880 = g_5880.buffer(0)
                if not g_5880.is_empty and g_5880.area > 0:
                    pols_5880.append(g_5880)
                    n_ok += 1
            log(f"    vetor oficial {rotulo}: {n_ok} polígonos projetados em {CRS_GEODESICO}")
        except Exception as exc:
            log(f"    aviso WFS {rotulo}: {exc}")

    if not pols_5880:
        return None
    return IndiceProtecaoVetorial(pols_5880, cids)
