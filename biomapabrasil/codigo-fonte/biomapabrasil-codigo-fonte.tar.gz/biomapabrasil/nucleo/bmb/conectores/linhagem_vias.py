# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Linhagens farmacológicas bioinspiradas (`relacao_molecula`) e vias biológicas humanas (Reactome).

Cumpre rigorosamente os Princípios 1 e 4:
  * Toda relação `origem_id -> destino_id` exige referência primária (`referencia_id` com DOI/PMID) e `consulta_id`.
  * Todo fármaco sintético/semissintético de destino é obtido ao vivo na API do ChEMBL (`max_phase = 4`),
    com InChIKey padrão e `fase_consulta_id`, mantendo separação estrita entre o organismo amazônico,
    a molécula natural isolada e o fármaco aprovado derivado/inspirado.
  * Alvos moleculares do ChEMBL são cruzados com o UniProt e mapeados às vias humanas curadas do Reactome (`R-HSA-*`).
"""
import re

from .. import quimica
from ..http import ErroDeFonte
from . import chembl, referencias

API_CHEMBL = "https://www.ebi.ac.uk/chembl/api/data"
API_REACTOME = "https://reactome.org/ContentService/data"

def carregar_linhagens(caminho=None):
    """Entradas de `semente/linhagens.toml` (ver o cabeçalho do arquivo para a regra de entrada)."""
    import tomllib
    from .. import config
    with open(caminho or (config.SEMENTE_DIR / "linhagens.toml"), "rb") as f:
        return tomllib.load(f).get("linhagem", [])


def _so_letras(texto):
    """Forma de comparação de trechos: só letras e dígitos, minúsculos. Tolera hifenização e espaços do texto de origem."""
    return re.sub(r"[^a-z0-9]", "", (texto or "").lower())


def conferir_citacao(cli, spec):
    """Relê a obra citada e confere a entrada: `(ok, motivo, dados)`.

    ok=True só quando o PMID e o DOI são a mesma obra, o trecho está no texto lido agora e nomeia origem e destino.
    `dados`: {"fonte", "sha256", "consulta_id"}. Sem rede ou sem texto, ok=False com o motivo; a relação não é publicada.
    """
    pmid, doi = spec.get("pmid"), (spec.get("doi") or "").strip().lower() or None
    trecho = spec.get("trecho") or ""
    if not pmid or not trecho:
        return False, "entrada sem PMID ou sem trecho", {}
    meta = referencias.pubmed(cli, [pmid]).get(str(pmid))
    if not meta:
        return False, f"o PubMed não devolveu o PMID {pmid}", {}
    doi_pm = (meta.get("doi") or "").strip().lower() or None
    if doi and doi_pm and doi != doi_pm:
        return False, f"o PMID {pmid} tem DOI {doi_pm}, diferente do DOI citado {doi}", {}
    if spec.get("trecho_fonte") == "texto_completo_europepmc":
        texto, cid = referencias.texto_completo_aberto(cli, spec.get("pmcid") or "")
        fonte = "texto_completo_europepmc"
    else:
        texto, cid = referencias.resumo_pubmed(cli, pmid)
        fonte = "resumo_pubmed"
    if not texto:
        return False, "o texto da obra não pôde ser lido nesta construção", {}
    if _so_letras(trecho) not in _so_letras(texto):
        return False, "o trecho registrado não está no texto lido", {}
    contexto = trecho + " " + (spec.get("contexto_do_trecho") or "")
    for lista, papel in ((spec.get("termos_origem") or [], "a molécula de origem"), (spec.get("termos_destino") or [], "o fármaco")):
        if not any(t.lower() in contexto.lower() for t in lista):
            return False, f"o trecho não nomeia {papel}", {}
    if spec.get("contexto_do_trecho") and _so_letras(spec["contexto_do_trecho"]) not in _so_letras(texto):
        return False, "o contexto do trecho não está no texto lido", {}
    import hashlib
    return True, None, {"fonte": fonte, "sha256": hashlib.sha256(trecho.encode("utf-8")).hexdigest(), "consulta_id": cid,
                        "titulo": meta.get("titulo"), "revista": meta.get("revista"), "ano": meta.get("ano"),
                        "autores": meta.get("autores"), "doi_pubmed": doi_pm, "consulta_pubmed": meta.get("consulta_id")}


def _localizar_molecula_origem(con, spec):
    """Molécula de origem pelo identificador declarado na semente (InChIKey ou UniProt). Nunca por nome."""
    if spec.get("origem_uniprot"):
        r = con.execute("SELECT id FROM molecula WHERE uniprot_acc=?", (spec["origem_uniprot"],)).fetchone()
    elif spec.get("origem_inchikey"):
        r = con.execute("SELECT id FROM molecula WHERE inchikey=?", (spec["origem_inchikey"],)).fetchone()
    else:
        r = None
    return r["id"] if r else None


def _garantir_molecula_destino_chembl(con, cli, pref_name, lote=None):
    """Busca o fármaco aprovado no ChEMBL por `pref_name` e garante sua linha completa em `molecula`."""
    nome_inn = pref_name.strip().title()
    chave_up = pref_name.strip().upper()
    existente = con.execute(
        "SELECT id, chembl_id, fase_consulta_id FROM molecula "
        "WHERE (upper(nome)=? OR upper(nome_na_fonte)=?) AND max_fase_clinica >= 4 LIMIT 1",
        (chave_up, chave_up),
    ).fetchone()
    if existente and existente["fase_consulta_id"] is not None:
        con.execute("UPDATE molecula SET nome=? WHERE id=? AND length(nome) > 35", (nome_inn, existente["id"]))
        return existente["id"], existente["fase_consulta_id"]

    if lote and chave_up in lote:
        r_cid, mols = lote[chave_up]
    else:
        try:
            r = cli.get(f"{API_CHEMBL}/molecule.json", {"pref_name": chave_up, "limit": 5}, fonte="chembl", tentativas=2)
            if not (isinstance(r.dados, dict) and r.dados.get("molecules")):
                r = cli.get(f"{API_CHEMBL}/molecule.json", {"pref_name__iexact": pref_name, "limit": 5}, fonte="chembl", tentativas=2)
        except ErroDeFonte:
            return None, None
        r_cid = r.consulta_id
        mols = r.dados.get("molecules", []) if isinstance(r.dados, dict) else []
    escolhida = None
    for m in mols:
        st = m.get("molecule_structures") or {}
        if st.get("standard_inchi_key") and st.get("canonical_smiles") and float(m.get("max_phase") or 0) >= 4:
            escolhida = m
            break
    if not escolhida:
        return None, None

    st = escolhida["molecule_structures"]
    props = escolhida.get("molecule_properties") or {}
    ik = st["standard_inchi_key"].strip()
    smi = st["canonical_smiles"].strip()
    formula = props.get("full_molformula")
    massa = float(props["full_mwt"]) if props.get("full_mwt") is not None else None
    chembl_id = escolhida["molecule_chembl_id"]
    nome_exib = (escolhida.get("pref_name") or nome_inn).strip().title()
    retirado = 1 if escolhida.get("withdrawn_flag") else 0
    pains = "; ".join(quimica.alertas_pains(smi)) or None
    cat_clin = quimica.classificar_fase4(ik, "Fármaco sintético/semissintético bioinspirado")
    ctrl = quimica.controle_portaria_344(ik)

    por_ik = con.execute("SELECT id, nome FROM molecula WHERE inchikey=?", (ik,)).fetchone()
    if por_ik:
        # Preserva a denominação comum internacional (INN) se o nome atual for um IUPAC longo
        novo_nome = nome_exib if len(por_ik["nome"] or "") > 32 else por_ik["nome"]
        nome_fonte = por_ik["nome"] if novo_nome != por_ik["nome"] else None
        con.execute(
            "UPDATE molecula SET nome=?, nome_na_fonte=COALESCE(nome_na_fonte, ?), chembl_id=COALESCE(chembl_id,?), "
            "max_fase_clinica=4.0, fase_retirado=?, fase_consulta_id=COALESCE(fase_consulta_id,?), "
            "alerta_pains=?, categoria_clinica=?, controle_regulatorio=? WHERE id=?",
            (novo_nome, nome_fonte, chembl_id, retirado, r_cid, pains, cat_clin, ctrl, por_ik["id"]),
        )
        return por_ik["id"], r_cid

    con.execute(
        "INSERT INTO molecula (tipo, nome, inchikey, smiles, formula, massa, chembl_id, classe_quimica, "
        "max_fase_clinica, fase_consulta_id, fase_retirado, alerta_pains, categoria_clinica, controle_regulatorio) "
        "VALUES ('pequena_molecula', ?, ?, ?, ?, ?, ?, 'Fármaco sintético/semissintético bioinspirado', "
        "4.0, ?, ?, ?, ?, ?)",
        (nome_exib, ik, smi, formula, massa, chembl_id, r_cid, retirado, pains, cat_clin, ctrl),
    )
    mid = con.execute("SELECT last_insert_rowid()").fetchone()[0]
    return mid, r_cid


def _prebuscar_destinos_chembl(con, cli, specs):
    """Pré-consulta em lote os fármacos de destino ausentes no banco usando índice B-tree de `pref_name__in`."""
    ausentes = []
    for sp in specs:
        up = (sp.get("destino_chembl_nome") or "").strip().upper()
        if not up or up in ausentes:
            continue
        ok = con.execute(
            "SELECT 1 FROM molecula WHERE (upper(nome)=? OR upper(nome_na_fonte)=?) AND max_fase_clinica >= 4 AND fase_consulta_id IS NOT NULL LIMIT 1",
            (up, up),
        ).fetchone()
        if not ok:
            ausentes.append(up)
    if len(ausentes) < 2:
        return {}
    lote = {}
    try:
        r = cli.get(f"{API_CHEMBL}/molecule.json", {"pref_name__in": ",".join(ausentes), "limit": max(50, len(ausentes) * 2)},
                    fonte="chembl", tentativas=2)
    except ErroDeFonte:
        return {}
    for m in (r.dados.get("molecules", []) if isinstance(r.dados, dict) else []):
        pn = (m.get("pref_name") or "").strip().upper()
        if pn:
            lote.setdefault(pn, (r.consulta_id, []))[1].append(m)
    return lote


def registrar_linhagens_farmacologicas(con, cli, upsert_referencia_fn, log=print, caminho=None):
    """Sincroniza `relacao_molecula` com a semente, relendo cada citação. Devolve o número de relações publicáveis.

    * `confirmada` com citação conferida agora  → relação ativa, com trecho, fonte do trecho e hash;
    * `confirmada` cuja conferência falhou      → retida (LIN-NAO-CONFIRMADA ou LIN-CITACAO-INVALIDA);
    * `contradita`                              → rejeitada (LIN-CONTRADITA), com a história correta no motivo;
    * relação do banco que não está na semente  → retida (LIN-NAO-CONFIRMADA).
    Nenhuma linha é apagada, e relação já verificada por curador não é rebaixada.
    """
    from .. import quarentena
    from ..util import agora
    quarentena.registrar_catalogo(con)
    especs = carregar_linhagens(caminho)
    lote = _prebuscar_destinos_chembl(con, cli, especs)
    vistos, n_pub = set(), 0
    for spec in especs:
        origem_id = _localizar_molecula_origem(con, spec)
        if not origem_id:
            continue
        destino_id, cid = _garantir_molecula_destino_chembl(con, cli, spec["destino_chembl_nome"], lote=lote)
        if not destino_id or destino_id == origem_id:
            continue
        nomes = {r["id"]: r["nome"] for r in con.execute("SELECT id, nome FROM molecula WHERE id IN (?,?)", (origem_id, destino_id))}
        dados_motivo = {"origem": nomes[origem_id], "destino": nomes[destino_id]}
        atual = con.execute("SELECT id, estado, referencia_id FROM relacao_molecula WHERE origem_id=? AND destino_id=? AND tipo=?",
                            (origem_id, destino_id, spec["tipo"])).fetchone()
        if spec["decisao"] == "contradita":
            motivo = quarentena.motivo("LIN-CONTRADITA", detalhe=spec["historia_corrigida"], **dados_motivo)
            obras = "; ".join(f"PMID {e['pmid']}" for e in spec.get("evidencia", []))
            texto_rel = f"Relação não sustentada: {spec['historia_corrigida']}." + (f" Obras: {obras}." if obras else "")
            if atual is None:
                ev = (spec.get("evidencia") or [{}])[0]
                rid = upsert_referencia_fn(con, doi=ev.get("doi"), pmid=ev.get("pmid"))
                if not rid:
                    continue
                con.execute("INSERT INTO relacao_molecula (origem_id, destino_id, tipo, texto, referencia_id, consulta_id, estado, "
                            "chave, regra_quarentena, motivo_quarentena) VALUES (?,?,?,?,?,?, 'rejeitado', ?, 'LIN-CONTRADITA', ?)",
                            (origem_id, destino_id, spec["tipo"], texto_rel, rid, cid, spec["chave"], motivo))
                rel_id = con.execute("SELECT last_insert_rowid()").fetchone()[0]
            else:
                rel_id = atual["id"]
                anterior = con.execute("SELECT texto, estado FROM relacao_molecula WHERE id=?", (rel_id,)).fetchone()
                if anterior["texto"] != texto_rel:
                    # o enunciado antigo afirmava a história errada: sai da linha e fica no evento de proveniência
                    quarentena._evento_padrao(con, "relacao_molecula", rel_id, "rejeicao",
                                              f"LIN-CONTRADITA. Enunciado anterior: {anterior['texto']}")
                con.execute("UPDATE relacao_molecula SET estado='rejeitado', chave=?, regra_quarentena='LIN-CONTRADITA', "
                            "motivo_quarentena=?, texto=?, trecho=NULL, trecho_fonte=NULL, trecho_sha256=NULL WHERE id=?",
                            (spec["chave"], motivo, texto_rel, rel_id))
            vistos.add(rel_id)
            continue

        ok, falha, d = conferir_citacao(cli, spec)
        if ok:
            rid = upsert_referencia_fn(con, doi=spec.get("doi") or d.get("doi_pubmed"), pmid=spec["pmid"], titulo=d.get("titulo"),
                                       revista=d.get("revista"), ano=d.get("ano"), autores=d.get("autores") or None,
                                       resolvida=1, consulta_id=d.get("consulta_pubmed"))
        else:
            rid = (atual["referencia_id"] if atual else None) or upsert_referencia_fn(con, doi=spec.get("doi"), pmid=spec.get("pmid"))
        if not rid:
            continue
        if atual is None:
            con.execute("INSERT INTO relacao_molecula (origem_id, destino_id, tipo, texto, referencia_id, consulta_id, chave) "
                        "VALUES (?,?,?,?,?,?,?)", (origem_id, destino_id, spec["tipo"], spec["texto"], rid, cid, spec["chave"]))
            rel_id, estado_atual = con.execute("SELECT last_insert_rowid()").fetchone()[0], "candidato"
        else:
            rel_id, estado_atual = atual["id"], atual["estado"]
        vistos.add(rel_id)
        if ok:
            estado = estado_atual if estado_atual in ("em_revisao", "verificado") else "candidato"
            con.execute("UPDATE relacao_molecula SET texto=?, referencia_id=?, consulta_id=?, chave=?, estado=?, regra_quarentena=NULL, "
                        "motivo_quarentena=NULL, trecho=?, trecho_fonte=?, trecho_sha256=?, trecho_conferido_em=? WHERE id=?",
                        (spec["texto"], rid, d.get("consulta_id") or cid, spec["chave"], estado, spec["trecho"], d["fonte"],
                         d["sha256"], agora(), rel_id))
            n_pub += 1
        elif estado_atual != "verificado":
            codigo = "LIN-CITACAO-INVALIDA" if "DOI" in (falha or "") else "LIN-NAO-CONFIRMADA"
            con.execute("UPDATE relacao_molecula SET chave=?, estado='quarentena', regra_quarentena=?, motivo_quarentena=? WHERE id=?",
                        (spec["chave"], codigo, quarentena.motivo(codigo, detalhe=falha, **dados_motivo), rel_id))
            log(f"  linhagem {spec['chave']} retida: {falha}")
    for r in con.execute("SELECT rm.id, rm.estado, mo.nome AS origem, md.nome AS destino FROM relacao_molecula rm "
                         "JOIN molecula mo ON mo.id=rm.origem_id JOIN molecula md ON md.id=rm.destino_id").fetchall():
        if r["id"] not in vistos and r["estado"] in ("candidato", "em_revisao"):
            con.execute("UPDATE relacao_molecula SET estado='quarentena', regra_quarentena='LIN-NAO-CONFIRMADA', motivo_quarentena=? WHERE id=?",
                        (quarentena.motivo("LIN-NAO-CONFIRMADA", origem=r["origem"], destino=r["destino"]), r["id"]))
    con.commit()
    log(f"  Linhagens farmacológicas publicáveis: {n_pub}")
    return n_pub


def enriquecer_alvos_e_vias(con, cli, log=print):
    """Mapeia `alvo.chembl_id` -> `uniprot_acc` e associa às vias biológicas humanas do Reactome (`R-HSA-*`)."""
    pend_alvos = con.execute(
        "SELECT id, chembl_id, organismo FROM alvo WHERE chembl_id IS NOT NULL AND alvo_consulta_id IS NULL"
    ).fetchall()

    n_uniprot = 0
    n_vias_xref = 0
    if pend_alvos:
        log(f"  ChEMBL Target -> UniProt/Reactome: {len(pend_alvos)} alvos…")
        for ini in range(0, len(pend_alvos), 120):
            lote = pend_alvos[ini:ini + 120]
            pedidos = [(f"{API_CHEMBL}/target/{a['chembl_id']}.json", None) for a in lote]
            resps = cli.get_varios(pedidos, fonte="chembl", tentativas=2, ignorar_erros=True)
            for al, r in zip(lote, resps):
                if r is None:
                    continue
                acc = None
                vias_ch = []
                if r.ok and isinstance(r.dados, dict):
                    for comp in r.dados.get("target_components") or []:
                        if not acc and comp.get("accession"):
                            acc = comp["accession"].strip()
                        for xr in comp.get("target_component_xrefs") or []:
                            if xr.get("xref_src_db") == "Reactome" and str(xr.get("xref_id", "")).startswith("R-HSA-"):
                                vias_ch.append((xr["xref_id"].strip(), (xr.get("xref_name") or xr["xref_id"]).strip()))
                if acc:
                    n_uniprot += 1
                con.execute(
                    "UPDATE alvo SET uniprot_acc=COALESCE(uniprot_acc, ?), alvo_consulta_id=? WHERE id=?",
                    (acc, r.consulta_id, al["id"]),
                )
                for st_id, nome_via in (vias_ch if (al['organismo'] or '') == 'Homo sapiens' else []):
                    con.execute(
                        "INSERT INTO via_biologica (reactome_id, nome, especie, consulta_id) VALUES (?,?,'Homo sapiens',?) "
                        "ON CONFLICT(reactome_id) DO UPDATE SET nome=excluded.nome",
                        (st_id, nome_via, r.consulta_id),
                    )
                    vid = con.execute("SELECT id FROM via_biologica WHERE reactome_id=?", (st_id,)).fetchone()["id"]
                    con.execute(
                        "INSERT OR IGNORE INTO alvo_via (alvo_id, via_id, consulta_id) VALUES (?,?,?)",
                        (al["id"], vid, r.consulta_id),
                    )
                    n_vias_xref += 1
            con.commit()

    # Vias humanas pelo Reactome ContentService, por acesso UniProt. O vínculo alvo–via é dado derivado: é refeito
    # inteiro a cada execução, só para alvos humanos, sem teto de vias por alvo e sem identificadores aposentados.
    con.execute("DELETE FROM alvo_via")
    con.execute("DELETE FROM via_biologica")
    alvos_humanos = con.execute("""
        SELECT l.id, l.uniprot_acc
        FROM alvo l
        WHERE l.uniprot_acc IS NOT NULL
          AND l.organismo = 'Homo sapiens'
          AND IFNULL(l.natureza, 'proteina_unica') = 'proteina_unica'
    """).fetchall()

    n_reactome_api = 0
    if alvos_humanos:
        log(f"  Reactome ContentService (Homo sapiens): {len(alvos_humanos)} alvos com UniProt…")
        accs_unicos = sorted({a["uniprot_acc"] for a in alvos_humanos})
        mapa_resp = {}
        for ini in range(0, len(accs_unicos), 80):
            fatia = accs_unicos[ini:ini + 80]
            pedidos = [(f"{API_REACTOME}/mapping/UniProt/{acc}/pathways", {"species": "9606"}) for acc in fatia]
            resps = cli.get_varios(pedidos, fonte="reactome", tentativas=2, ignorar_erros=True)
            for acc, r in zip(fatia, resps):
                mapa_resp[acc] = r

        for al in alvos_humanos:
            r = mapa_resp.get(al["uniprot_acc"])
            if not r or not r.ok or not isinstance(r.dados, list):
                continue
            for item in r.dados:
                st_id = (item.get("stId") or "").strip()
                nome_via = (item.get("displayName") or "").strip()
                if not st_id.startswith("R-HSA-") or not nome_via:
                    continue
                con.execute(
                    "INSERT INTO via_biologica (reactome_id, nome, especie, consulta_id) VALUES (?,?,'Homo sapiens',?) "
                    "ON CONFLICT(reactome_id) DO UPDATE SET nome=excluded.nome, consulta_id=excluded.consulta_id",
                    (st_id, nome_via, r.consulta_id),
                )
                vid = con.execute("SELECT id FROM via_biologica WHERE reactome_id=?", (st_id,)).fetchone()["id"]
                con.execute(
                    "INSERT OR IGNORE INTO alvo_via (alvo_id, via_id, consulta_id) VALUES (?,?,?)",
                    (al["id"], vid, r.consulta_id),
                )
                n_reactome_api += 1
        con.commit()

    total_vias = con.execute("SELECT COUNT(*) FROM via_biologica").fetchone()[0]
    total_vinculos = con.execute("SELECT COUNT(*) FROM alvo_via").fetchone()[0]
    return {
        "alvos_com_uniprot": n_uniprot,
        "vias_totais": total_vias,
        "vinculos_alvo_via": total_vinculos,
        "novos_reactome_api": n_reactome_api,
    }
