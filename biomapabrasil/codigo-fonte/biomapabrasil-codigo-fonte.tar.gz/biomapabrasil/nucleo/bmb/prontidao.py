# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Perfil de prontidão da evidência: sete dimensões independentes.

O índice resume a COMPLETUDE para reutilização do registro. Não é nota de eficácia biológica e
nunca deve ser lido como tal: uma afirmação com índice 1,0 continua sendo só uma afirmação
documentada. Dimensões que não se aplicam ao tipo de afirmação saem da conta (denominador menor).
"""
from . import config
from .texto import METODO_TOXINA_EXPERIMENTAL
from .util import agora

PONTOS = {"atende": 1.0, "parcial": 0.5, "ausente": 0.0, "nao_avaliado": 0.0}


def classe_licenca(texto):
    s = (texto or "").lower()
    if "cc0" in s or "domínio público" in s or "metadados públicos" in s or "metadados)" in s:
        return "livre"
    if "by-sa" in s:
        return "compartilha_igual"
    if ("cc by" in s and "-nc" not in s) or "mit" in s or "atribuição aberta" in s:
        return "atribuicao"
    return "desconhecida"


def indice(dims):
    aplicaveis = [dims[d] for d in config.DIMENSOES if dims[d] != "nao_se_aplica"]
    if not aplicaveis:
        return 0.0
    return round(sum(PONTOS[e] for e in aplicaveis) / len(aplicaveis), 4)


def avaliar(con, a):
    """Calcula as dimensões de uma afirmação (linha de `afirmacao`). Devolve dict com dims, indice e notas."""
    tipo = a["tipo"]
    d = {k: "nao_avaliado" for k in config.DIMENSOES}
    tem_org = tipo in ("composto_em_organismo", "funcao_toxina")
    verificada = a["estado"] == "verificado"

    if tem_org:
        t = con.execute("SELECT gbif_correspondencia FROM taxon WHERE id=?", (a["taxon_id"],)).fetchone()
        # Nome resolvido no backbone, mas sem testemunho (voucher) conferido no estudo: parcial.
        d["identidade_biologica"] = "atende" if verificada else ("parcial" if t and t["gbif_correspondencia"] else "nao_avaliado")
        # Depois da leitura humana, a procedência é a que o artigo declara; se não declara, a ausência é registrada como tal.
        declarada = a["procedencia_declarada"] if "procedencia_declarada" in a.keys() else None
        if verificada:
            d["procedencia"] = "atende" if (declarada or "").startswith("curador_artigo") else "ausente"
        elif (declarada or "").startswith("base_declara"):
            d["procedencia"] = "parcial"                      # a base declara país ou UF; ninguém conferiu no artigo
        else:
            d["procedencia"] = "nao_avaliado"
    else:
        d["identidade_biologica"] = "nao_se_aplica"
        d["procedencia"] = "nao_se_aplica"

    m = con.execute("SELECT inchikey, uniprot_acc, pubchem_cid, chembl_id FROM molecula WHERE id=?",
                    (a["molecula_id"],)).fetchone()
    if m["uniprot_acc"]:
        d["identidade_quimica"] = "atende"                    # entrada revisada, com sequência
    elif m["inchikey"] and (m["pubchem_cid"] or m["chembl_id"]):
        d["identidade_quimica"] = "atende"                    # mesma estrutura confirmada em outra base
    elif m["inchikey"]:
        d["identidade_quimica"] = "parcial"                   # estrutura só na base de origem
    else:
        d["identidade_quimica"] = "ausente"

    if tipo == "funcao_toxina":
        d["qualidade_experimental"] = "parcial" if METODO_TOXINA_EXPERIMENTAL in (a["metodo"] or "") else "ausente"
    elif tipo == "atividade_biologica":
        d["qualidade_experimental"] = "parcial"               # medida padronizada, sem réplicas nem controles na fonte
    # composto_em_organismo e clínico: fica nao_avaliado

    q = con.execute("SELECT qualidade_experimental FROM verificacao WHERE afirmacao_id=? AND decisao IN ('confirmada','corrigida') "
                    "AND qualidade_experimental IS NOT NULL ORDER BY em DESC LIMIT 1", (a["id"],)).fetchone()
    if q:                                                     # o curador leu o método do estudo
        d["qualidade_experimental"] = q["qualidade_experimental"]
    n_refs = con.execute("SELECT COUNT(*) FROM afirmacao_referencia WHERE afirmacao_id=?", (a["id"],)).fetchone()[0]
    d["rastreabilidade"] = "atende" if verificada else ("parcial" if (n_refs or a["origem"]) else "ausente")

    f = con.execute("SELECT licenca FROM fonte WHERE id=?", (a["fonte_id"],)).fetchone()
    classe = classe_licenca(f["licenca"] if f else None)
    d["reutilizacao"] = {"livre": "atende", "atribuicao": "atende", "compartilha_igual": "parcial"}.get(classe, "ausente")

    v = con.execute("SELECT sensibilidade FROM verificacao WHERE afirmacao_id=? AND decisao IN ('confirmada','corrigida') "
                    "AND sensibilidade IS NOT NULL ORDER BY em DESC LIMIT 1", (a["id"],)).fetchone()
    d["sensibilidade"] = "atende" if v and v["sensibilidade"] == "sem_restricao" else (
        "parcial" if v else "nao_avaliado")

    pendencias = []
    if d["procedencia"] == "nao_avaliado":
        pendencias.append("procedência do material não verificada na publicação")
    if d["sensibilidade"] == "nao_avaliado":
        pendencias.append("sensibilidade (conhecimento tradicional, localidade) não avaliada")
    if d["procedencia"] == "ausente":
        pendencias.append("o artigo conferido não declara a procedência do material")
    if not verificada:
        pendencias.append("passagem da publicação não conferida por curador")
    d["indice"] = indice(d)
    d["notas"] = "; ".join(pendencias) or None
    return d


def gravar(con, afirmacao_id, d):
    con.execute(
        "INSERT INTO prontidao (afirmacao_id, identidade_biologica, procedencia, identidade_quimica, "
        "qualidade_experimental, rastreabilidade, reutilizacao, sensibilidade, indice, notas) VALUES (?,?,?,?,?,?,?,?,?,?) "
        "ON CONFLICT(afirmacao_id) DO UPDATE SET identidade_biologica=excluded.identidade_biologica, "
        "procedencia=excluded.procedencia, identidade_quimica=excluded.identidade_quimica, "
        "qualidade_experimental=excluded.qualidade_experimental, rastreabilidade=excluded.rastreabilidade, "
        "reutilizacao=excluded.reutilizacao, sensibilidade=excluded.sensibilidade, indice=excluded.indice, "
        "notas=excluded.notas",
        (afirmacao_id, *(d[k] for k in config.DIMENSOES), d["indice"], d["notas"]))


def recalcular_todas(con):
    """Recalcula a procedência declarada, os estados que dela decorrem e a prontidão de todas as afirmações."""
    from . import procedencia, quarentena
    procedencia.recalcular_procedencia_banco(con)
    quarentena.aplicar_estados(con)
    n = 0
    for a in con.execute("SELECT * FROM afirmacao").fetchall():
        gravar(con, a["id"], avaliar(con, a))
        n += 1
    con.commit()
    return n
