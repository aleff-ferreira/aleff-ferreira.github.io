# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Integridade das referências: cada linha de `referencia` é UMA obra que existe e é a obra citada.

O que se confere, com o que cada conferência produz:

  DOI e PMID da mesma linha são a mesma obra?   →  `doi_pmid_coerente`; se não, a referência é retida
                                                    (REF-DOI-PMID-DIVERGENTES) — não se escolhe um dos dois por palpite
  O DOI está registrado?                        →  o sistema de handles diz que não: REF-DOI-INEXISTENTE
  A mesma obra está em duas linhas?             →  a linha sem DOI aponta a outra em `duplicata_de`; os vínculos migram
  O DOI é de material suplementar (.s001)?      →  os vínculos passam para o artigo; a linha fica como componente
  A obra foi retratada?                         →  REF-RETRATACAO
  Que tipo de obra é, e quem registra o DOI?    →  `tipo_obra`, `agencia_doi` (artigo, capítulo, conjunto de dados…)

Depois, três regras de afirmação saem do estado das referências: todas retratadas (REF-RETRATADA), nenhuma
localizada (REF-INEXISTENTE), todas retidas (REF-EM-QUARENTENA). Nenhuma linha é apagada.

Serviço fora do ar não retém nada: uma conferência que não pôde ser feita deixa o campo NULL e a referência ativa.
"""
from __future__ import annotations

import re
from collections import Counter

from . import quarentena
from .conectores import referencias
from .util import agora

REGRAS_DE_REFERENCIA = ("REF-RETRATADA", "REF-INEXISTENTE", "REF-EM-QUARENTENA")
_SUPLEMENTO = re.compile(r"^(10\.\d{4,9}/.+?)\.s\d{3}$", re.I)
_PUBLICO = "a.estado NOT IN ('rejeitado')"


def _doi(v):
    return (v or "").strip().lower() or None


def _escolher_texto_limpo(atual, novo):
    """Prefere metadado sem caractere substituto Unicode (U+FFFD) quando o registro legado veio corrompido."""
    if not atual:
        return novo
    if "\ufffd" in str(atual) and novo and "\ufffd" not in str(novo):
        return novo
    return atual


def _evento(con, entidade, entidade_id, atividade, detalhe):
    con.execute("INSERT INTO evento_proveniencia (entidade, entidade_id, atividade, agente, em, detalhe) VALUES (?,?,?,?,?,?)",
                (entidade, entidade_id, atividade, "software:bmb", agora(), detalhe))


def _mover_vinculos(con, de_id, para_id, motivo):
    """Passa os vínculos de afirmações (e verificações) de uma linha de referência para outra. Nada é apagado da
    tabela `referencia`; cada mudança de vínculo deixa evento."""
    n = 0
    for x in con.execute("SELECT afirmacao_id, papel FROM afirmacao_referencia WHERE referencia_id=?", (de_id,)).fetchall():
        con.execute("INSERT OR IGNORE INTO afirmacao_referencia (afirmacao_id, referencia_id, papel) VALUES (?,?,?)",
                    (x["afirmacao_id"], para_id, x["papel"]))
        con.execute("DELETE FROM afirmacao_referencia WHERE afirmacao_id=? AND referencia_id=?", (x["afirmacao_id"], de_id))
        _evento(con, "afirmacao", x["afirmacao_id"], "revinculo_referencia", f"referência {de_id} → {para_id}: {motivo}")
        n += 1
    for tabela, coluna in (("verificacao", "referencia_id"), ("relacao_molecula", "referencia_id"),
                           ("afirmacao", "passagem_referencia_id"), ("afirmacao", "procedencia_artigo_referencia_id")):
        con.execute(f"UPDATE {tabela} SET {coluna}=? WHERE {coluna}=?", (para_id, de_id))
    return n


def conferir(con, cli, log=print) -> dict:
    quarentena.registrar_catalogo(con)
    cont = Counter()
    refs = [dict(r) for r in con.execute("SELECT * FROM referencia ORDER BY id")]
    por_doi = {r["doi"]: r for r in refs if r["doi"]}

    # ── 1. O que o PubMed diz de cada PMID: DOI da obra, título, retratação
    meta_pm = referencias.pubmed(cli, [r["pmid"] for r in refs if r["pmid"]])
    divergentes = []
    for r in refs:
        x = meta_pm.get(str(r["pmid"])) if r["pmid"] else None
        if not x:
            continue
        doi_pm = _doi(x.get("doi"))
        if r["doi"] and doi_pm:
            coerente = 1 if _doi(r["doi"]) == doi_pm else 0
            con.execute("UPDATE referencia SET doi_pmid_coerente=? WHERE id=?", (coerente, r["id"]))
            if not coerente:
                divergentes.append((r, x))
        elif not r["doi"] and doi_pm and doi_pm in por_doi and por_doi[doi_pm]["id"] != r["id"]:
            # a mesma obra já tem linha própria pelo DOI: esta é duplicata
            alvo = por_doi[doi_pm]
            if r["duplicata_de"] != alvo["id"]:
                con.execute("UPDATE referencia SET duplicata_de=? WHERE id=?", (alvo["id"], r["id"]))
                con.execute("UPDATE referencia SET pmid=COALESCE(pmid, ?) WHERE id=? AND NOT EXISTS "
                            "(SELECT 1 FROM referencia x WHERE x.pmid=? AND x.id != ?)", (r["pmid"], alvo["id"], r["pmid"], alvo["id"]))
                cont["vinculos_migrados_de_duplicata"] += _mover_vinculos(
                    con, r["id"], alvo["id"], f"mesma obra (PMID {r['pmid']} tem DOI {doi_pm})")
                _evento(con, "referencia", r["id"], "duplicata", f"mesma obra que a referência {alvo['id']} (DOI {doi_pm})")
            cont["duplicatas"] += 1

    # ── 2. DOI e PMID de obras diferentes: a referência é retida, com o que cada identificador é
    if divergentes:
        obras = referencias.crossref_em_lote(cli, [r["doi"] for r, _ in divergentes])
        for r, x in divergentes:
            achado = (obras.get(_doi(r["doi"])) or (None, None))[0]
            if achado is None:
                existe, _ = referencias.doi_registrado(cli, r["doi"])
                obra = "um DOI não registrado" if existe is False else "uma obra não identificada"
            else:
                obra = f"«{(achado.get('titulo') or 'sem título')[:140]}»"
            quarentena.reter_referencia(con, r["id"], "REF-DOI-PMID-DIVERGENTES", _evento_ref, doi=r["doi"], pmid=r["pmid"],
                                        titulo_pmid=(x.get("titulo") or "")[:140], doi_do_pmid=x.get("doi") or "sem DOI",
                                        obra_do_doi=obra)
            cont["doi_pmid_divergentes"] += 1
    divergentes_ids = {r["id"] for r, _ in divergentes}

    # ── 3. Tipo de obra, agência do DOI, avisos editoriais (Crossref; DataCite para o que não é do Crossref)
    com_doi = [r for r in refs if r["doi"] and r["id"] not in divergentes_ids]
    registro = {}                                   # referencia_id -> metadados do Crossref lidos nesta execução
    for ini in range(0, len(com_doi), 1400):
        lote = com_doi[ini:ini + 1400]
        mapa = referencias.crossref_em_lote(cli, [r["doi"] for r in lote])
        for r in lote:
            achado, cid = mapa.get(_doi(r["doi"])) or (None, None)
            if achado:
                registro[r["id"]] = achado
                aut_json = None
                if achado.get("autores"):
                    import json as _json
                    aut_json = _json.dumps(achado["autores"], ensure_ascii=False)
                con.execute(
                    "UPDATE referencia SET tipo_obra=COALESCE(?, tipo_obra), agencia_doi=COALESCE(?, agencia_doi), "
                    "titulo=?, revista=?, autores=?, ano=COALESCE(ano, ?), resolvida=1, "
                    "retratada=MAX(retratada, ?), aviso=COALESCE(?, aviso), consulta_id=COALESCE(consulta_id, ?) WHERE id=?",
                    (achado.get("tipo_obra"), achado.get("agencia_doi"),
                     _escolher_texto_limpo(r["titulo"], achado.get("titulo")),
                     _escolher_texto_limpo(r["revista"], achado.get("revista")),
                     _escolher_texto_limpo(r["autores"], aut_json),
                     achado.get("ano"), 1 if achado.get("retratada") else 0,
                     "nota_de_correcao" if achado.get("e_errata_de") else achado.get("aviso"), cid, r["id"]))
                cont["com_tipo_de_obra"] += 1
            elif cid is not None and not r["resolvida"]:
                # nem Crossref, nem DataCite, nem Europe PMC conhecem o DOI: pergunta-se ao sistema de handles
                existe, cid_h = referencias.doi_registrado(cli, r["doi"])
                if existe is False:
                    quarentena.reter_referencia(con, r["id"], "REF-DOI-INEXISTENTE", _evento_ref, doi=r["doi"],
                                                resposta_handle="handle não encontrado")
                    cont["doi_inexistente"] += 1
                elif existe is None:
                    cont["doi_nao_conferido"] += 1
        con.commit()
        log(f"    integridade das referências: {min(ini + 1400, len(com_doi))}/{len(com_doi)} DOIs")

    # ── 3b. A mesma obra registrada sob dois DOIs
    cont.update(_fundir_obras_com_dois_dois(con, com_doi, registro))

    # ── 4. DOI de material suplementar: a obra citável é o artigo
    for r in refs:
        m = _SUPLEMENTO.match(r["doi"] or "")
        if not m or r["id"] in divergentes_ids:
            continue
        pai_doi = m.group(1).lower()
        pai = con.execute("SELECT id FROM referencia WHERE doi=?", (pai_doi,)).fetchone()
        if pai is None:
            achado, cid = (referencias.crossref_em_lote(cli, [pai_doi]).get(pai_doi) or (None, None))
            if not achado:
                continue
            con.execute("INSERT INTO referencia (doi, titulo, revista, ano, resolvida, tipo_obra, agencia_doi, consulta_id) "
                        "VALUES (?,?,?,?,1,?,?,?)", (pai_doi, achado.get("titulo"), achado.get("revista"), achado.get("ano"),
                                                    achado.get("tipo_obra"), achado.get("agencia_doi"), cid))
            pai = con.execute("SELECT id FROM referencia WHERE doi=?", (pai_doi,)).fetchone()
        con.execute("UPDATE referencia SET duplicata_de=?, tipo_obra='component' WHERE id=?", (pai["id"], r["id"]))
        cont["vinculos_migrados_de_suplemento"] += _mover_vinculos(con, r["id"], pai["id"], f"{r['doi']} é material suplementar de {pai_doi}")
        cont["suplementos"] += 1

    # ── 5. Retratação e liberação do que deixou de valer
    for r in con.execute("SELECT id, retratada, estado, regra_quarentena FROM referencia").fetchall():
        if r["retratada"] and r["estado"] != "quarentena":
            quarentena.reter_referencia(con, r["id"], "REF-RETRATACAO", _evento_ref, origem_do_aviso="Crossref/PubMed")
            cont["retratadas"] += 1
    con.execute("UPDATE referencia SET doi_pmid_coerente=NULL WHERE doi IS NULL OR pmid IS NULL")
    con.commit()
    res_af = declarar_regras_de_afirmacao(con)
    return {**dict(cont), "regras_de_afirmacao": res_af,
            "referencias_ativas": con.execute("SELECT COUNT(*) FROM referencia WHERE estado='ativa' AND duplicata_de IS NULL").fetchone()[0]}


def _titulo_normalizado(titulo):
    t = re.sub(r"<[^>]+>", "", titulo or "").lower()
    t = re.sub(r"^cheminform abstract:\s*", "", t)
    return re.sub(r"[^a-z0-9]", "", t)


def _fundir_obras_com_dois_dois(con, refs_com_doi, registro) -> Counter:
    """Marca como duplicata a segunda linha de uma obra que tem dois DOIs. Só em dois casos, ambos verificáveis no
    registro do Crossref, e nunca só por título parecido:

    * resumo do ChemInform (`10.1002/chin.…`) de um artigo que está no banco com o mesmo título e ano;
    * mesmo título, ano, volume, página inicial e primeiro autor (o artigo foi registrado por dois publicadores).

    Mesmo título e ano com volume ou página diferentes (partes de uma série, resumo de congresso e artigo completo)
    ficam como estão.
    """
    cont = Counter()
    grupos = {}
    for r in refs_com_doi:
        m = registro.get(r["id"])
        if not m or not m.get("titulo") or not m.get("ano") or r.get("duplicata_de"):
            continue
        chave = (_titulo_normalizado(m["titulo"]), m["ano"])
        if len(chave[0]) >= 25:
            grupos.setdefault(chave, []).append((r, m))
    for membros in grupos.values():
        if len(membros) < 2:
            continue
        resumos = [x for x in membros if x[0]["doi"].startswith("10.1002/chin.") or (x[1].get("revista") or "").lower() == "cheminform"]
        artigos = [x for x in membros if x not in resumos]
        if resumos and len(artigos) == 1:
            canonico, duplicatas, motivo = artigos[0], resumos, "resumo do ChemInform do mesmo artigo"
        elif not resumos and len({(x[1].get("volume"), x[1].get("pagina"), ((x[1].get("autores") or [""])[0].split(" ")[0]).lower())
                                  for x in membros}) == 1 and membros[0][1].get("volume") and membros[0][1].get("pagina"):
            n_vinc = {x[0]["id"]: con.execute("SELECT COUNT(*) FROM afirmacao_referencia WHERE referencia_id=?", (x[0]["id"],)).fetchone()[0]
                      for x in membros}
            canonico = sorted(membros, key=lambda x: (-n_vinc[x[0]["id"]], x[0]["id"]))[0]
            duplicatas, motivo = [x for x in membros if x is not canonico], "mesmo artigo registrado sob dois DOIs (mesmo volume e página)"
        else:
            cont["mesmo_titulo_e_ano_mantidas_separadas"] += 1
            continue
        for r, _ in duplicatas:
            con.execute("UPDATE referencia SET duplicata_de=? WHERE id=?", (canonico[0]["id"], r["id"]))
            cont["vinculos_migrados_de_duplicata"] += _mover_vinculos(con, r["id"], canonico[0]["id"], f"{r['doi']}: {motivo} ({canonico[0]['doi']})")
            _evento(con, "referencia", r["id"], "duplicata", f"{motivo}: referência {canonico[0]['id']} ({canonico[0]['doi']})")
            cont["duplicatas"] += 1
    return cont


def _evento_ref(con, entidade, entidade_id, atividade, detalhe):
    _evento(con, entidade, entidade_id, atividade, detalhe)


def declarar_regras_de_afirmacao(con) -> dict:
    """Regras de afirmação que decorrem só do estado das referências (não consulta rede)."""
    disparos = {}

    def rotulos(aid):
        return ", ".join((r["doi"] or ("PMID " + str(r["pmid"]))) for r in con.execute(
            "SELECT r.doi, r.pmid FROM afirmacao_referencia x JOIN referencia r ON r.id=x.referencia_id WHERE x.afirmacao_id=? ORDER BY r.id",
            (aid,)))

    tem_ref = "EXISTS (SELECT 1 FROM afirmacao_referencia x WHERE x.afirmacao_id=a.id)"
    for a in con.execute(f"""SELECT a.id FROM afirmacao a WHERE {_PUBLICO} AND {tem_ref} AND NOT EXISTS (
            SELECT 1 FROM afirmacao_referencia x JOIN referencia r ON r.id=x.referencia_id
            WHERE x.afirmacao_id=a.id AND r.retratada=0)""").fetchall():
        disparos.setdefault(a["id"], {})["REF-RETRATADA"] = {"referencias": rotulos(a["id"])}
    for a in con.execute(f"""SELECT a.id FROM afirmacao a WHERE {_PUBLICO} AND {tem_ref} AND NOT EXISTS (
            SELECT 1 FROM afirmacao_referencia x JOIN referencia r ON r.id=x.referencia_id
            WHERE x.afirmacao_id=a.id AND (r.resolvida=1 OR r.consulta_id IS NULL))""").fetchall():
        disparos.setdefault(a["id"], {})["REF-INEXISTENTE"] = {"referencias": rotulos(a["id"])}
    for a in con.execute(f"""SELECT a.id FROM afirmacao a WHERE {_PUBLICO} AND {tem_ref} AND NOT EXISTS (
            SELECT 1 FROM afirmacao_referencia x JOIN referencia r ON r.id=x.referencia_id
            WHERE x.afirmacao_id=a.id AND r.estado='ativa')""").fetchall():
        if a["id"] not in disparos:
            disparos.setdefault(a["id"], {})["REF-EM-QUARENTENA"] = {"referencias": rotulos(a["id"])}
    return quarentena.declarar(con, REGRAS_DE_REFERENCIA, disparos)["declaradas"]
