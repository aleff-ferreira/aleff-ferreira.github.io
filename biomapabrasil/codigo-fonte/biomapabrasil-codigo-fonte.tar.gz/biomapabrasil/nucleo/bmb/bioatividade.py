# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Bioatividade medida (ChEMBL): uma afirmação por par molécula–alvo, com o valor central de todas as medidas.

Mostrar a medida mais potente de cada par exagera a potência de forma sistemática: entre várias medidas, a mais
extrema é a que mais provavelmente carrega erro de unidade ou de transcrição. Aqui, cada par (molécula, alvo, tipo
de medida) é resumido pela MEDIANA do pChEMBL das medidas válidas, com o número de medidas, o número de publicações
e a faixa observada. Cada medida considerada fica em `medida_bioatividade`, usada ou excluída, com o motivo.

Critérios de exclusão de uma medida (o primeiro que se aplica):
  relacao_nao_exata        relação diferente de «=»
  comentario_de_validade   o ChEMBL sinaliza o valor (fora da faixa típica, erro de autor, unidade suspeita…)
  duplicata_potencial      o ChEMBL sinaliza provável repetição de outra publicação
  tipo_nao_comparavel      tipo de medida fora de IC50, EC50, Ki, Kd, AC50, XC50, ED50, MIC, GI50
  alvo_nao_atribuido       alvo provisório («unchecked», «no relevant target»…)
  inativa_ou_inconclusiva  o comentário de atividade do ChEMBL diz «inactive», «inconclusive», «not active»
  ensaio_de_razao          a descrição do ensaio é de razão ou índice de seletividade, não de potência
  alvo_mutante             ensaio sobre variante mutante do alvo
  unidade_nao_molar        unidade padronizada diferente de nM
  discrepante_da_mediana   com 3 medidas ou mais, a que dista mais de 3 unidades de pChEMBL (1000×) da mediana

Um par é retido (não vai a público) quando:
  BIO-SEM-MEDIDA-VALIDA      nenhuma medida passa nos critérios
  BIO-DISCORDANTE            só duas medidas, que divergem em 3 ordens de grandeza ou mais
  BIO-EXTREMO-NAO-REPLICADO  valor central abaixo de 100 pM (pChEMBL ≥ 10) vindo de uma única publicação
  BIO-FORA-DA-SELECAO        medida válida, mas fora dos pares de maior peso de evidência da molécula
"""
from __future__ import annotations

import math
import re
import statistics

from .conectores import chembl

LIMIAR_DISCREPANCIA = 3.0        # unidades de pChEMBL
LIMIAR_EXTREMO = 10.0            # pChEMBL ≥ 10  ⇔  ≤ 100 pM
_INATIVA = re.compile(r"\b(inactive|not active|inconclusive|no activity|not determined)\b", re.IGNORECASE)
_RAZAO = re.compile(r"\b(ratio|selectivity index|fold[- ]selectiv\w+)\b", re.IGNORECASE)
_ORDEM_NATUREZA = {"proteina_unica": 0, "complexo_proteico": 1, "familia_proteica": 2}
REGRAS_DE_BIOATIVIDADE = ("BIO-SEM-MEDIDA-VALIDA", "BIO-DISCORDANTE", "BIO-EXTREMO-NAO-REPLICADO", "BIO-FORA-DA-SELECAO")


def _num(v):
    try:
        return float(v) if v is not None else None
    except (TypeError, ValueError):
        return None


def motivo_de_exclusao(a: dict) -> str | None:
    """Por que uma medida bruta do ChEMBL não entra no agregado; None quando entra."""
    if a.get("standard_relation") != "=":
        return "relacao_nao_exata"
    if a.get("data_validity_comment"):
        return "comentario_de_validade"
    if a.get("potential_duplicate"):
        return "duplicata_potencial"
    if a.get("standard_type") not in chembl.TIPOS_PADRAO:
        return "tipo_nao_comparavel"
    if not a.get("target_chembl_id") or (a.get("target_pref_name") or "").strip().lower() in chembl.ALVOS_SEM_ATRIBUICAO:
        return "alvo_nao_atribuido"
    if _INATIVA.search(a.get("activity_comment") or ""):
        return "inativa_ou_inconclusiva"
    if _RAZAO.search(a.get("assay_description") or ""):
        return "ensaio_de_razao"
    if (a.get("assay_variant_mutation") or "").strip():
        return "alvo_mutante"
    if (a.get("standard_units") or "") != "nM":
        return "unidade_nao_molar"
    if _num(a.get("pchembl_value")) is None or _num(a.get("standard_value")) is None:
        return "unidade_nao_molar"
    return None


def agregar_par(medidas: list[dict]) -> dict:
    """Resume as medidas de UM par (molécula, alvo, tipo). Devolve o agregado e, por medida, se foi usada.

    Saída: {"usadas": [...], "excluidas": [(medida, motivo)], "n", "n_documentos", "pchembl", "valor_nm",
            "min_nm", "max_nm", "agregacao": 'mediana'|'unica'|None, "regra": código ou None, "dados_regra": {...}}
    """
    usadas, excluidas = [], []
    for a in sorted(medidas, key=lambda x: x["activity_id"]):
        m = motivo_de_exclusao(a)
        (excluidas.append((a, m)) if m else usadas.append(a))
    if len(usadas) >= 3:
        mediana = statistics.median(_num(a["pchembl_value"]) for a in usadas)
        longe = [a for a in usadas if abs(_num(a["pchembl_value"]) - mediana) > LIMIAR_DISCREPANCIA]
        if longe and len(usadas) - len(longe) >= 2:
            excluidas += [(a, "discrepante_da_mediana") for a in longe]
            usadas = [a for a in usadas if a not in longe]
    res = {"usadas": usadas, "excluidas": excluidas, "n": len(usadas), "regra": None, "dados_regra": {},
           "n_documentos": len({a.get("document_chembl_id") for a in usadas if a.get("document_chembl_id")}),
           "pchembl": None, "valor_nm": None, "min_nm": None, "max_nm": None, "agregacao": None}
    if not usadas:
        motivos = sorted({m for _, m in excluidas})
        res["regra"] = "BIO-SEM-MEDIDA-VALIDA"
        res["dados_regra"] = {"n": len(excluidas), "motivos": ", ".join(motivos)}
        return res
    ps = [_num(a["pchembl_value"]) for a in usadas]
    valores = [_num(a["standard_value"]) for a in usadas]
    res["min_nm"], res["max_nm"] = min(valores), max(valores)
    if len(usadas) == 2 and abs(ps[0] - ps[1]) >= LIMIAR_DISCREPANCIA:
        res["regra"] = "BIO-DISCORDANTE"
        res["dados_regra"] = {"n": 2, "dispersao": f"{abs(ps[0] - ps[1]):.1f}".replace(".", ",")}
    p = statistics.median(ps)
    res["pchembl"] = round(p, 2)
    res["valor_nm"] = float(f"{10 ** (9 - p):.3g}") if len(usadas) > 1 else valores[0]
    res["agregacao"] = "mediana" if len(usadas) > 1 else "unica"
    if res["regra"] is None and p >= LIMIAR_EXTREMO and res["n_documentos"] <= 1:
        tipo = usadas[0].get("standard_type")
        res["regra"] = "BIO-EXTREMO-NAO-REPLICADO"
        res["dados_regra"] = {"medida": f"{tipo} = {res['valor_nm']:g} nM"}
    return res


def agrupar(medidas: list[dict]) -> dict:
    """{(alvo_chembl_id, tipo): [medidas]} — medida sem alvo ou sem tipo fica de fora do agrupamento."""
    grupos = {}
    for a in medidas:
        if a.get("target_chembl_id") and a.get("standard_type"):
            grupos.setdefault((a["target_chembl_id"], a["standard_type"]), []).append(a)
    return grupos


def ordem_de_selecao(par, agregado, natureza):
    """Chave de ordenação dos pares de uma molécula: alvo molecular individual primeiro, depois o mais documentado.
    A potência entra por último, só para desempatar — nunca como critério principal."""
    return (_ORDEM_NATUREZA.get(natureza, 3), -agregado["n_documentos"], -agregado["n"], -(agregado["pchembl"] or 0),
            par[0], par[1])


def tipo_de_ensaio(usadas) -> str | None:
    tipos = sorted({a.get("assay_type") for a in usadas if a.get("assay_type")})
    return "+".join(tipos) if tipos else None


def contexto(usadas) -> dict:
    """O que se sabe do contexto experimental sem consultar outro recurso: formatos de ensaio e anos."""
    formatos = sorted({(a.get("bao_label") or "").strip() for a in usadas if (a.get("bao_label") or "").strip()})
    anos = sorted({int(a["document_year"]) for a in usadas if str(a.get("document_year") or "").isdigit()})
    return {"formatos": formatos, "anos": [anos[0], anos[-1]] if anos else None}


def potencia_legivel(valor_nm):
    if valor_nm is None or not math.isfinite(valor_nm):
        return None
    return valor_nm
