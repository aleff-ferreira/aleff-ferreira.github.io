# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Identidade taxonômica: a que espécie aceita pertence o organismo que a FONTE nomeia.

Regra do projeto: um registro de composto só é ligado a um táxon quando o organismo nomeado pela fonte resolve,
no backbone do GBIF, para a mesma espécie aceita. A resolução usa, nesta ordem:

  1. o identificador taxonômico que a própria fonte fornece (LOTUS traz a chave do GBIF de cada organismo);
  2. casamento ESTRITO do nome como a fonte o escreve — binômio ou infraespecífico, nunca truncado — com reino ou
     família como contexto quando a fonte os dá.

Um nome que consta entre os sinônimos de um táxon não basta: «Annona muricata Vell.» é sinônimo de Annona montana,
mas «Annona muricata» sem autoria numa base de química é, para o backbone, a graviola de Lineu. E «Oryza sativa
var. grandiglumis» ser sinônimo de Oryza grandiglumis não torna o arroz parte dela. Por isso a autoria e a categoria
dos nomes são preservadas, e a decisão é do organismo da fonte para o táxon, nunca do sinônimo para a fonte.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from .util import agora, sem_acento

API = "https://api.gbif.org/v1"
CATEGORIAS_DE_ESPECIE_OU_ABAIXO = {"SPECIES", "SUBSPECIES", "VARIETY", "FORM", "SUBVARIETY", "SUBFORM", "INFRASPECIFIC_NAME",
                                   "INFRASUBSPECIFIC_NAME", "CULTIVAR", "STRAIN"}
_RUIDO_AUTORIA = {"ex", "in", "et", "fil", "f", "and"}


def canonico(nome: str | None) -> str:
    return re.sub(r"\s+", " ", (nome or "").strip())


def chave(nome: str | None) -> str:
    """Forma de comparação do nome canônico: minúsculas, sem acento, espaços simples. Não remove epítetos."""
    return sem_acento(canonico(nome)).lower()


def genero(nome: str | None) -> str | None:
    partes = canonico(nome).split()
    return partes[0].lower() if partes else None


def tokens_autoria(autoria: str | None) -> frozenset:
    """Autoria como conjunto de sobrenomes: sem anos, iniciais, 'ex' nem 'fil.'.

    '(Spruce ex Müll.Arg.) Woodson' == '(Spruce ex Müll. Arg.) R. E.Woodson', mas 'L.' != 'Vell.'.
    """
    a = re.sub(r"\b(1[5-9]|20)\d\d\b", " ", autoria or "")
    toks = [sem_acento(t).lower() for t in re.findall(r"[A-Za-zÀ-ÿ]+", a)]
    toks = [t for t in toks if t not in _RUIDO_AUTORIA]
    longos = [t for t in toks if len(t) >= 3]
    return frozenset(longos if longos else toks)


def mesma_autoria(a: str | None, b: str | None) -> bool:
    ta, tb = tokens_autoria(a), tokens_autoria(b)
    return bool(ta) and ta == tb


def separar_autoria(nome_completo: str | None, nome_canonico: str | None) -> str | None:
    s, c = canonico(nome_completo), canonico(nome_canonico)
    if c and s.lower().startswith(c.lower()):
        return s[len(c):].strip() or None
    return None


# ───────────────────────── consultas ao backbone ─────────────────────────
def pedido_uso(key):
    return (f"{API}/species/{int(key)}", None)


def interpretar_uso(resp) -> dict | None:
    d = resp.dados if (resp is not None and isinstance(getattr(resp, "dados", None), dict)) else None
    if not d or not d.get("key"):
        return None
    return {
        "key": d.get("key"), "nome": d.get("canonicalName") or d.get("scientificName"),
        "nome_completo": d.get("scientificName"),
        "autoria": d.get("authorship") or separar_autoria(d.get("scientificName"), d.get("canonicalName")),
        "categoria": d.get("rank"), "status": d.get("taxonomicStatus"), "aceito_key": d.get("acceptedKey"),
        "especie_key": d.get("speciesKey"), "reino": d.get("kingdom"), "familia": d.get("family"),
        "consulta_id": getattr(resp, "consulta_id", None),
    }


def uso(cli, key) -> dict | None:
    url, params = pedido_uso(key)
    try:
        return interpretar_uso(cli.get(url, params, fonte="gbif"))
    except Exception:
        return None


def especie_aceita(cli, u: dict | None, _visto=None) -> dict | None:
    """Sobe do uso até a ESPÉCIE aceita: sinônimo → aceito; infraespecífico aceito → espécie. None se não chega lá."""
    visto = set() if _visto is None else _visto
    atual = u
    while atual and atual["key"] not in visto:
        visto.add(atual["key"])
        if atual.get("aceito_key") and atual["aceito_key"] != atual["key"]:
            atual = uso(cli, atual["aceito_key"])
            continue
        cat = (atual.get("categoria") or "").upper()
        if cat == "SPECIES":
            return atual
        if cat in CATEGORIAS_DE_ESPECIE_OU_ABAIXO and atual.get("especie_key") and atual["especie_key"] != atual["key"]:
            atual = uso(cli, atual["especie_key"])
            continue
        return None
    return None


def casar_nome(cli, nome: str, reino: str | None = None, familia: str | None = None) -> dict | None:
    """Casamento estrito no backbone: só aceita correspondência EXATA em espécie ou abaixo."""
    params = {"name": canonico(nome), "strict": "true"}
    if reino:
        params["kingdom"] = reino
    if familia:
        params["family"] = familia
    try:
        r = cli.get(f"{API}/species/match", params, fonte="gbif")
    except Exception:
        return None
    d = r.dados if isinstance(r.dados, dict) else {}
    if (d.get("matchType") or "").upper() != "EXACT" or not d.get("usageKey"):
        return None
    if (d.get("rank") or "").upper() not in CATEGORIAS_DE_ESPECIE_OU_ABAIXO:
        return None
    return uso(cli, d["usageKey"])


def sinonimos_completos(cli, key, por_pagina: int = 300, max_paginas: int = 8) -> tuple[list[dict], int | None]:
    """Todos os sinônimos do uso aceito, com autoria, categoria e status. Sem teto de 60 e sem descartar nada:
    quem decide o que serve para casar registros é `Resolvedor`, pelo organismo da fonte."""
    saida, cid, offset = [], None, 0
    for _ in range(max_paginas):
        try:
            r = cli.get(f"{API}/species/{int(key)}/synonyms", {"limit": por_pagina, "offset": offset}, fonte="gbif")
        except Exception:
            break
        d = r.dados if isinstance(r.dados, dict) else {}
        cid = cid or r.consulta_id
        for s in d.get("results") or []:
            nome = canonico(s.get("canonicalName"))
            if not nome or len(nome.split()) < 2:
                continue
            saida.append({"nome": nome, "nome_completo": s.get("scientificName"),
                          "autoria": s.get("authorship") or separar_autoria(s.get("scientificName"), nome),
                          "categoria": s.get("rank"), "status": s.get("taxonomicStatus"), "gbif_key": s.get("key")})
        if d.get("endOfRecords", True) or not d.get("results"):
            break
        offset += por_pagina
    return saida, cid


# ───────────────────────── decisão ─────────────────────────
@dataclass
class Decisao:
    fonte_id: str
    nome_fonte: str
    id_fonte: str
    decisao: str                       # aceito | aceito_mesmo_nome_e_autoria | homonimo_nao_resolvido | fora_do_escopo | nao_resolvido
    via: str                           # identificador_da_fonte | nome_estrito | nao_resolvido
    taxon_id: int | None = None
    gbif_key: int | None = None
    gbif_nome_completo: str | None = None
    gbif_autoria: str | None = None
    gbif_categoria: str | None = None
    gbif_status: str | None = None
    especie_aceita_key: int | None = None
    especie_aceita_nome: str | None = None
    consulta_id: int | None = None

    @property
    def liga(self) -> bool:
        return self.decisao in ("aceito", "aceito_mesmo_nome_e_autoria")


def decidir(taxa_por_key: dict, taxa_por_nome: dict, nome_fonte: str, u: dict | None, sp: dict | None) -> tuple[str, int | None]:
    """Decisão pura (sem rede), a partir do uso `u` que a fonte indica e da espécie aceita `sp` a que ele leva.

    taxa_por_key: {gbif_key: {"id", "gbif_key", "nome", "autoria"}} · taxa_por_nome: {chave(nome aceito): mesma linha}.
    """
    t = taxa_por_nome.get(chave(nome_fonte))
    if t is not None and u is not None:
        # O nome da fonte é, letra por letra, o nome aceito de um táxon do banco.
        if sp and sp["key"] == t.get("gbif_key"):
            return "aceito", t["id"]
        if mesma_autoria(u.get("autoria"), t.get("autoria")):
            return "aceito_mesmo_nome_e_autoria", t["id"]      # o backbone tem o mesmo nome duas vezes
        # O identificador da fonte leva a um homônimo de outro autor. Identificadores de bases de química são
        # atribuídos por casamento automático de nome; não dá para saber qual dos dois o artigo estudou. O registro
        # não vai nem para este táxon nem para aquele a que o homônimo leva.
        return "homonimo_nao_resolvido", t["id"]
    if sp and sp["key"] in taxa_por_key:
        return "aceito", taxa_por_key[sp["key"]]["id"]
    if sp is not None:
        return "fora_do_escopo", None
    if t is not None and u is None:
        # Sem identificador e sem resposta do backbone para o texto, mas o nome é, letra por letra, o nome aceito
        # do táxon — o mesmo texto com que o próprio táxon foi reconciliado.
        return "aceito", t["id"]
    return "nao_resolvido", None


class Resolvedor:
    """Resolve organismos de uma fonte e guarda cada decisão em `organismo_fonte`."""

    def __init__(self, con, cli):
        self.con, self.cli = con, cli
        self.taxa_por_key, self.taxa_por_nome = {}, {}
        for t in con.execute("SELECT id, gbif_key, nome, autoria, reino, familia FROM taxon"):
            linha = dict(t)
            self.taxa_por_key[t["gbif_key"]] = linha
            self.taxa_por_nome[chave(t["nome"])] = linha

    def _gravar(self, d: Decisao, familia=None) -> None:
        self.con.execute(
            "INSERT INTO organismo_fonte (fonte_id, nome_fonte, id_fonte, familia_fonte, gbif_key, gbif_nome_completo, "
            "gbif_autoria, gbif_categoria, gbif_status, especie_aceita_key, especie_aceita_nome, via, taxon_id, decisao, "
            "consulta_id, resolvido_em) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(fonte_id, nome_fonte, id_fonte) DO UPDATE SET familia_fonte=excluded.familia_fonte, "
            "gbif_key=excluded.gbif_key, gbif_nome_completo=excluded.gbif_nome_completo, gbif_autoria=excluded.gbif_autoria, "
            "gbif_categoria=excluded.gbif_categoria, gbif_status=excluded.gbif_status, "
            "especie_aceita_key=excluded.especie_aceita_key, especie_aceita_nome=excluded.especie_aceita_nome, "
            "via=excluded.via, taxon_id=excluded.taxon_id, decisao=excluded.decisao, consulta_id=excluded.consulta_id, "
            "resolvido_em=excluded.resolvido_em",
            (d.fonte_id, d.nome_fonte, d.id_fonte, familia, d.gbif_key, d.gbif_nome_completo, d.gbif_autoria,
             d.gbif_categoria, d.gbif_status, d.especie_aceita_key, d.especie_aceita_nome, d.via, d.taxon_id, d.decisao,
             d.consulta_id, agora()))

    def resolver(self, fonte_id: str, nome_fonte: str, id_fonte: str | int | None = None,
                 familia: str | None = None, reino: str | None = None) -> Decisao:
        nome_fonte = canonico(nome_fonte)
        id_txt = str(id_fonte).strip() if id_fonte not in (None, "") else ""
        u, via = None, "nao_resolvido"
        if id_txt.isdigit():
            u = uso(self.cli, int(id_txt))
            via = "identificador_da_fonte" if u else via
        if u is None and nome_fonte:
            u = casar_nome(self.cli, nome_fonte, reino=reino, familia=familia)
            via = "nome_estrito" if u else "nao_resolvido"
        sp = especie_aceita(self.cli, u) if u else None
        decisao, taxon_id = decidir(self.taxa_por_key, self.taxa_por_nome, nome_fonte, u, sp)
        if u is None and decisao == "aceito":
            via = "nome_aceito_identico"
        d = Decisao(fonte_id=fonte_id, nome_fonte=nome_fonte, id_fonte=id_txt, decisao=decisao, via=via, taxon_id=taxon_id,
                    gbif_key=(u or {}).get("key"), gbif_nome_completo=(u or {}).get("nome_completo"),
                    gbif_autoria=(u or {}).get("autoria"), gbif_categoria=(u or {}).get("categoria"),
                    gbif_status=(u or {}).get("status"), especie_aceita_key=(sp or {}).get("key"),
                    especie_aceita_nome=(sp or {}).get("nome_completo"), consulta_id=(u or {}).get("consulta_id"))
        self._gravar(d, familia)
        return d

    def resolver_varios(self, fonte_id: str, itens, log=None) -> dict:
        """itens: iterável de (nome_fonte, id_fonte, familia, reino). Devolve {(nome_fonte, id_fonte_txt): Decisao}.

        Pré-carrega em paralelo os usos que têm identificador; o resto (cadeias de sinônimo, casamento por nome)
        sai do cache em disco do cliente HTTP nas reconstruções seguintes.
        """
        itens = list(dict.fromkeys((canonico(n), str(i).strip() if i not in (None, "") else "", f, r) for n, i, f, r in itens))
        if hasattr(self.cli, "get_varios"):
            # 1ª rodada: os usos indicados pela fonte; 2ª e 3ª: os aceitos e as espécies a que eles levam.
            pendentes, vistos = {int(i) for _, i, _, _ in itens if i.isdigit()}, set()
            for _ in range(3):
                pendentes = sorted(pendentes - vistos)
                if not pendentes:
                    break
                proximos = set()
                for ini in range(0, len(pendentes), 400):
                    lote = pendentes[ini:ini + 400]
                    for r in self.cli.get_varios([pedido_uso(k) for k in lote], fonte="gbif", ignorar_erros=True):
                        u = interpretar_uso(r)
                        if u:
                            proximos.update(k for k in (u.get("aceito_key"), u.get("especie_key")) if k)
                vistos.update(pendentes)
                pendentes = proximos
        saida = {}
        for n, (nome, id_txt, familia, reino) in enumerate(itens, 1):
            saida[(nome, id_txt)] = self.resolver(fonte_id, nome, id_txt, familia=familia, reino=reino)
            if log and n % 1000 == 0:
                log(f"    organismos resolvidos: {n}/{len(itens)}")
        self.con.commit()
        return saida


def atualizar_sinonimos_do_taxon(con, cli, taxon_id: int, gbif_key: int) -> int:
    """Regrava os sinônimos de origem GBIF do táxon com autoria, categoria, status e chave. Nenhum nome é truncado."""
    lista, cid = sinonimos_completos(cli, gbif_key)
    if cid is None and not lista:
        return 0          # sem resposta do backbone: mantém o que havia
    con.execute("DELETE FROM taxon_sinonimo WHERE taxon_id=? AND origem='gbif'", (taxon_id,))
    aceito = con.execute("SELECT nome FROM taxon WHERE id=?", (taxon_id,)).fetchone()["nome"]
    vistos = set()
    for s in lista:
        if chave(s["nome"]) == chave(aceito) or chave(s["nome"]) in vistos:
            continue
        vistos.add(chave(s["nome"]))
        con.execute(
            "INSERT INTO taxon_sinonimo (taxon_id, nome, origem, nome_completo, autoria, categoria, status_gbif, gbif_key, consulta_id) "
            "VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(taxon_id, nome) DO UPDATE SET nome_completo=excluded.nome_completo, "
            "autoria=excluded.autoria, categoria=excluded.categoria, status_gbif=excluded.status_gbif, "
            "gbif_key=excluded.gbif_key, consulta_id=excluded.consulta_id",
            (taxon_id, s["nome"], "gbif", s["nome_completo"], s["autoria"], s["categoria"], s["status"], s["gbif_key"], cid))
    return len(vistos)


def generos_de_interesse(con) -> set[str]:
    """Gêneros dos nomes aceitos e de todos os sinônimos: delimita quais organismos das fontes vale a pena resolver."""
    g = {genero(r["nome"]) for r in con.execute("SELECT nome FROM taxon")}
    g |= {genero(r["nome"]) for r in con.execute("SELECT nome FROM taxon_sinonimo")}
    g.discard(None)
    return g
