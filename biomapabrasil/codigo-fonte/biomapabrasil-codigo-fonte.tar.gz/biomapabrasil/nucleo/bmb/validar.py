# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Validador dos cinco princípios e das invariantes do banco.

Cada verificação é uma consulta SQL que devolve as LINHAS QUE VIOLAM a regra. O banco já recusa
várias violações por restrição (CHECK); o validador cobre o que uma restrição não alcança e confere,
depois de cada construção, que nada escapou. Erro bloqueia a exportação; aviso só é reportado.

Princípios do dono do projeto:
  1. todo número tem fonte consultável e data da consulta;
  2. ausência é declarada, nunca um zero silencioso;
  3. imagem só com licença verificável por máquina (CC0 ou CC BY) e autor/origem;
  4. associação documentada nunca é apresentada como eficácia;
  5. acessibilidade (verificada no front-end, não aqui).
"""
import json
import re

# Palavras que sugerem alegação de eficácia. Os enunciados da plataforma nascem de modelo fixo
# (texto.py) e não devem contê-las; a lista barra regressões e textos de curadoria.
PALAVRAS_EFICACIA = re.compile(
    r"\b(cura|curar|curativ[oa]|trata(r|mento)?\s+d[eao]|combate|eficaz|eficácia comprovada|comprovadamente|"
    r"previne|milagros[oa]|remédio para|medicamento para|tem efeito (anti|contra))\b", re.IGNORECASE)

# (id, nível, descrição, SQL que devolve as violações)
VERIFICACOES = [
    # ── Princípio 1: fonte e data ──
    ("P1.taxon_ocorrencia_sem_fonte", "erro", "táxon com contagem de ocorrência sem consulta registrada",
     "SELECT id, nome FROM taxon WHERE n_br IS NOT NULL AND ocorr_consulta_id IS NULL"),
    ("P1.ocorrencia_uf_sem_fonte", "erro", "contagem por UF sem consulta",
     "SELECT taxon_id, uf_sigla FROM ocorrencia_uf WHERE consulta_id IS NULL"),
    ("P1.afirmacao_sem_consulta", "erro", "afirmação sem consulta (fonte, URL e data)",
     "SELECT a.id FROM afirmacao a LEFT JOIN consulta c ON c.id=a.consulta_id WHERE c.id IS NULL"),
    ("P1.consulta_sem_data", "erro", "consulta sem data",
     "SELECT id FROM consulta WHERE consultado_em IS NULL OR consultado_em = ''"),
    ("P1.fonte_sem_licenca", "erro", "fonte sem licença declarada",
     "SELECT id FROM fonte WHERE licenca IS NULL OR licenca = ''"),
    ("P1.molecula_fase_sem_fonte", "erro", "fase clínica informada sem consulta",
     "SELECT id, nome FROM molecula WHERE max_fase_clinica IS NOT NULL AND fase_consulta_id IS NULL"),
    ("P1.ocorrencia_bacia_sem_fonte", "erro", "contagem por bacia hidrográfica sem consulta registrada",
     "SELECT taxon_id, bacia_id FROM ocorrencia_bacia WHERE consulta_id IS NULL"),
    ("P1.celula_lacuna_sem_fonte", "erro", "célula de lacuna 0,5° sem consulta do GBIF registrada",
     "SELECT id, lon, lat FROM celula_lacuna WHERE gbif_consulta_id IS NULL"),
    ("P1.estrutura_3d_sem_fonte", "erro", "geometria 3D sem consulta registrada",
     "SELECT id, codigo FROM estrutura_3d WHERE consulta_id IS NULL"),
    ("P1.via_biologica_sem_fonte", "erro", "via biológica Reactome sem consulta registrada",
     "SELECT id, reactome_id FROM via_biologica WHERE consulta_id IS NULL"),
    ("P1.relacao_molecula_sem_fonte", "erro", "relação de linhagem bioinspirada sem consulta registrada",
     "SELECT id FROM relacao_molecula WHERE consulta_id IS NULL"),
    # ── Princípio 2: ausência declarada ──
    ("P2.recorte_sem_motivo", "erro", "táxon sem motivo do recorte (com os números)",
     "SELECT id, nome FROM taxon WHERE motivo_recorte IS NULL OR length(motivo_recorte) < 20"),
    ("P2.recorte_sem_duas_bases", "erro", "recorte que não declara as duas bases (com e sem UF)",
     "SELECT id, nome FROM taxon WHERE n_br IS NOT NULL AND (n_br_com_uf IS NULL OR (n_br > 0 AND fracao_al_total IS NULL) "
     "OR motivo_recorte NOT LIKE '%não têm UF%')"),
    ("P2.cobertura_nula_sem_consulta", "erro", "cobertura de compostos ou toxinas com valor mas sem consulta",
     "SELECT id, nome FROM taxon WHERE (compostos_fonte IS NOT NULL AND lotus_consulta_id IS NULL) "
     "OR (toxinas_fonte IS NOT NULL AND uniprot_consulta_id IS NULL)"),
    ("P2.procedencia_inventada", "erro", "procedência do material preenchida sem verificação humana",
     "SELECT a.id FROM afirmacao a WHERE a.procedencia_material IS NOT NULL AND NOT EXISTS "
     "(SELECT 1 FROM verificacao v WHERE v.afirmacao_id=a.id AND v.decisao IN ('confirmada','corrigida'))"),
    ("P2.passagem_vazia", "aviso", "afirmação de função de toxina sem a passagem da fonte",
     "SELECT id FROM afirmacao WHERE tipo='funcao_toxina' AND (passagem IS NULL OR passagem = '')"),
    ("P2.taxon_no_recorte_sem_composto_nem_toxina", "aviso",
     "táxon no recorte cuja fonte de moléculas não foi consultada",
     "SELECT id, nome FROM taxon WHERE no_recorte=1 AND compostos_fonte IS NULL AND toxinas_fonte IS NULL"),
    # ── Princípio 3: imagens ──
    ("P3.imagem_licenca", "erro", "imagem com licença fora de CC0/CC BY",
     "SELECT id, url FROM midia WHERE licenca NOT IN ('CC0','CC BY')"),
    ("P3.imagem_sem_autor", "erro", "imagem sem autor",
     "SELECT id, url FROM midia WHERE autor IS NULL OR trim(autor) = ''"),
    ("P3.imagem_sem_origem", "erro", "imagem sem página de origem",
     "SELECT id, url FROM midia WHERE pagina IS NULL OR trim(pagina) = ''"),
    ("P3.miniatura_sem_hash", "erro", "miniatura local sem hash de integridade",
     "SELECT id FROM midia WHERE arquivo IS NOT NULL AND arquivo_sha256 IS NULL"),
    ("P3.midia_quarentena_sem_motivo", "erro", "imagem em quarentena sem motivo registrado",
     "SELECT id, url FROM midia WHERE estado='quarentena' AND (motivo_quarentena IS NULL OR trim(motivo_quarentena) = '')"),
    ("P3.midia_quarentena_com_arquivo", "erro", "imagem em quarentena ainda com miniatura pública vinculada",
     "SELECT id, arquivo FROM midia WHERE estado='quarentena' AND arquivo IS NOT NULL"),
    # ── Princípio 4: associação não é eficácia ──
    ("P4.clinico_com_organismo", "erro", "efeito clínico ligado a organismo (deve descrever só o fármaco)",
     "SELECT id FROM afirmacao WHERE tipo='efeito_clinico_documentado' AND taxon_id IS NOT NULL"),
    ("P4.atividade_com_organismo", "erro", "atividade medida ligada a organismo (é medida da molécula isolada)",
     "SELECT id FROM afirmacao WHERE tipo='atividade_biologica' AND taxon_id IS NOT NULL"),
    ("P4.clinico_sem_aprovacao", "erro", "efeito clínico de molécula que não está em fase 4",
     "SELECT a.id FROM afirmacao a JOIN molecula m ON m.id=a.molecula_id "
     "WHERE a.tipo='efeito_clinico_documentado' AND IFNULL(m.max_fase_clinica,0) < 4"),
    ("P4.verificado_sem_verificacao", "erro", "afirmação 'verificado' sem registro de verificação humana",
     "SELECT a.id FROM afirmacao a WHERE a.estado='verificado' AND NOT EXISTS "
     "(SELECT 1 FROM verificacao v WHERE v.afirmacao_id=a.id AND v.decisao IN ('confirmada','corrigida'))"),
    ("P4.quarentena_sem_motivo", "erro", "quarentena sem motivo",
     "SELECT id FROM afirmacao WHERE estado='quarentena' AND (motivo_quarentena IS NULL OR motivo_quarentena = '')"),
    ("P4.retratada_sustentando", "erro", "afirmação ativa sustentada só por referência retratada",
     "SELECT a.id FROM afirmacao a WHERE a.estado NOT IN ('quarentena','rejeitado') "
     "AND EXISTS (SELECT 1 FROM afirmacao_referencia x WHERE x.afirmacao_id=a.id) "
     "AND NOT EXISTS (SELECT 1 FROM afirmacao_referencia x JOIN referencia r ON r.id=x.referencia_id "
     "WHERE x.afirmacao_id=a.id AND r.retratada=0)"),
    ("P4.alvo_sem_atribuicao_ativo", "erro", "atividade ativa ligada a alvo provisório/não molecular do ChEMBL",
     "SELECT a.id, l.nome FROM afirmacao a JOIN alvo l ON l.id=a.alvo_id "
     "WHERE a.tipo='atividade_biologica' AND a.estado NOT IN ('quarentena','rejeitado') "
     "AND lower(trim(l.nome)) IN ('unchecked','unknown','no relevant target','non-molecular target',"
     "'non-protein target','molecular identity unknown','unspecified')"),
    ("P4.clinico_mecanismo_unknown", "erro", "afirmação clínica com mecanismo 'Unknown' não filtrado",
     "SELECT id, texto FROM afirmacao WHERE tipo='efeito_clinico_documentado' "
     "AND estado NOT IN ('quarentena','rejeitado') "
     "AND (texto LIKE '%Mecanismo registrado: Unknown%' OR lower(trim(IFNULL(passagem,''))) = 'unknown')"),
    ("P4.clinico_retirado_sem_aviso", "erro", "fármaco com retirada registrada apresentado sem ressalva no enunciado clínico",
     "SELECT a.id, m.nome FROM afirmacao a JOIN molecula m ON m.id=a.molecula_id "
     "WHERE a.tipo='efeito_clinico_documentado' AND a.estado NOT IN ('quarentena','rejeitado') "
     "AND m.fase_retirado=1 AND a.texto NOT LIKE '%retirad%'"),
    # ── identidade taxonômica (migração 008) ──
    ("T.composto_sem_organismo_da_fonte", "erro", "composto público sem o organismo que a fonte nomeia",
     "SELECT a.id FROM afirmacao a WHERE a.tipo='composto_em_organismo' AND a.fonte_id IN ('lotus','nubbe','npatlas') "
     "AND a.estado IN ('candidato','em_revisao') AND (a.organismo_na_fonte IS NULL OR a.organismo_na_fonte = '')"),
    ("T.composto_de_organismo_nao_resolvido_para_o_taxon", "erro",
     "composto público cujo organismo da fonte não foi resolvido no backbone para ESTE táxon",
     "SELECT a.id FROM afirmacao a WHERE a.tipo='composto_em_organismo' AND a.fonte_id IN ('lotus','nubbe','npatlas') "
     "AND a.estado IN ('candidato','em_revisao') AND a.organismo_na_fonte IS NOT NULL AND NOT EXISTS ("
     "SELECT 1 FROM organismo_fonte o WHERE o.fonte_id=a.fonte_id AND o.taxon_id=a.taxon_id "
     "AND o.decisao IN ('aceito','aceito_mesmo_nome_e_autoria') "
     "AND ('; ' || a.organismo_na_fonte || '; ') LIKE ('%; ' || o.nome_fonte || '; %'))"),
    ("T.sinonimo_sem_autoria", "aviso", "táxon do recorte com sinônimo do GBIF ainda sem chave do uso (formato antigo)",
     "SELECT DISTINCT s.taxon_id FROM taxon_sinonimo s JOIN taxon t ON t.id=s.taxon_id "
     "WHERE s.origem='gbif' AND s.gbif_key IS NULL AND t.no_recorte=1"),
    # ── regras de retenção ──
    ("Q.quarentena_sem_regra", "erro", "afirmação em quarentena sem código de regra",
     "SELECT id FROM afirmacao WHERE estado='quarentena' AND IFNULL(quarentena_origem,'regra')='regra' AND regra_quarentena IS NULL"),
    ("Q.regra_fora_do_catalogo", "erro", "código de regra que não está no catálogo",
     "SELECT DISTINCT a.regra_quarentena FROM afirmacao a WHERE a.regra_quarentena IS NOT NULL "
     "AND a.regra_quarentena NOT IN (SELECT codigo FROM regra_quarentena)"),
    ("Q.publica_com_regra_ativa", "erro", "afirmação pública que dispara regra de retenção",
     "SELECT DISTINCT a.id FROM afirmacao a JOIN afirmacao_regra r ON r.afirmacao_id=a.id "
     "WHERE a.estado IN ('candidato','em_revisao')"),
    ("Q.regra_sem_disparo", "erro", "afirmação retida por regra que não consta mais como disparada",
     "SELECT a.id FROM afirmacao a WHERE a.estado='quarentena' AND a.quarentena_origem='regra' "
     "AND NOT EXISTS (SELECT 1 FROM afirmacao_regra r WHERE r.afirmacao_id=a.id)"),
    ("Q.publica_de_molecula_sem_organismo", "erro",
     "medida ou efeito clínico público de molécula sem registro publicado em organismo nem linhagem publicada",
     "SELECT a.id FROM afirmacao a WHERE a.taxon_id IS NULL AND a.estado IN ('candidato','em_revisao') AND a.classe_acesso='publico' "
     "AND NOT EXISTS (SELECT 1 FROM afirmacao o WHERE o.molecula_id=a.molecula_id AND o.taxon_id IS NOT NULL "
     "AND o.estado IN ('candidato','em_revisao','verificado') AND o.classe_acesso='publico') "
     "AND NOT EXISTS (SELECT 1 FROM relacao_molecula rm JOIN referencia r ON r.id=rm.referencia_id "
     "JOIN referencia c ON c.id=COALESCE(r.duplicata_de, r.id) WHERE (rm.origem_id=a.molecula_id OR rm.destino_id=a.molecula_id) "
     "AND rm.estado IN ('candidato','em_revisao','verificado') AND c.estado='ativa' AND c.duplicata_de IS NULL AND c.retratada=0)"),
    # ── procedência e localidade (CARE / SisGen) ──
    ("P2.coluna_de_procedencia_antiga", "erro", "coluna antiga de procedência por distribuição preenchida",
     "SELECT id FROM afirmacao WHERE nivel_procedencia IS NOT NULL UNION ALL SELECT id FROM taxon WHERE escopo_biogeografico IS NOT NULL"),
    ("P2.organismo_sem_procedencia_declarada", "erro", "afirmação ligada a organismo sem `procedencia_declarada`",
     "SELECT id FROM afirmacao WHERE tipo IN ('composto_em_organismo','funcao_toxina') AND procedencia_declarada IS NULL"),
    ("P2.procedencia_de_curador_sem_verificacao", "erro", "procedência atribuída a curador sem verificação humana registrada",
     "SELECT a.id FROM afirmacao a WHERE a.procedencia_declarada LIKE 'curador_%' AND NOT EXISTS "
     "(SELECT 1 FROM verificacao v WHERE v.afirmacao_id=a.id AND v.decisao IN ('confirmada','corrigida'))"),
    ("P2.coleta_fora_da_amazonia_publica", "erro", "composto público com coleta fora da Amazônia confirmada em fonte primária",
     "SELECT id FROM afirmacao WHERE tipo='composto_em_organismo' AND estado IN ('candidato','em_revisao','verificado') "
     "AND (procedencia_declarada='curador_artigo_fora_da_amazonia' "
     "OR (procedencia_artigo IN ('brasil_fora_da_amazonia_legal','exterior','ambiente_marinho') "
     "AND IFNULL(procedencia_declarada,'') != 'curador_artigo_amazonia'))"),
    ("C.localidade_mais_fina_que_uf", "erro", "localidade mais fina que país e UF guardada no banco",
     "SELECT id FROM afirmacao WHERE localidade_declarada IS NOT NULL "
     "OR (pais_coleta_declarado IS NOT NULL AND pais_coleta_declarado NOT GLOB '[A-Z][A-Z]') "
     "OR (procedencia_artigo_local IS NOT NULL AND procedencia_artigo_local NOT GLOB '[A-Z][A-Z]' "
     "AND procedencia_artigo_local NOT GLOB '[A-Z][A-Z]-[A-Z][A-Z]') "
     "OR (uf_coleta_declarada IS NOT NULL AND replace(replace(uf_coleta_declarada, ', ', ''), ',', '') GLOB '*[^A-Z]*')"),
    ("C.procedencia_de_curador_com_localidade", "erro", "procedência registrada por curador com mais que país e UF",
     "SELECT id FROM verificacao WHERE procedencia_material IS NOT NULL AND (procedencia_material GLOB '*[0-9]*' "
     "OR procedencia_material LIKE '%,%' OR length(procedencia_material) > 40)"),
    # ── evidência ──
    ("V.afirmacao_sem_nivel_de_evidencia", "erro", "afirmação sem nível de evidência",
     "SELECT id FROM afirmacao WHERE nivel_evidencia IS NULL"),
    ("V.evidencia_de_curador_sem_verificacao", "erro", "nível «curador» sem verificação humana",
     "SELECT a.id FROM afirmacao a WHERE a.nivel_evidencia='curador' AND NOT EXISTS "
     "(SELECT 1 FROM verificacao v WHERE v.afirmacao_id=a.id AND v.decisao IN ('confirmada','corrigida'))"),
    ("V.trecho_sem_hash", "erro", "nível «artigo_trecho» sem hash e sem referência do trecho",
     "SELECT id FROM afirmacao WHERE nivel_evidencia='artigo_trecho' AND (passagem_sha256 IS NULL OR passagem_referencia_id IS NULL)"),
    # ── bioatividade agregada ──
    ("B.atividade_publica_sem_agregacao", "erro", "atividade pública que não é um agregado de medidas",
     "SELECT id FROM afirmacao WHERE tipo='atividade_biologica' AND estado IN ('candidato','em_revisao') "
     "AND (medida_agregacao IS NULL OR medida_n IS NULL OR medida_n < 1 OR origem NOT LIKE 'chembl:agregado:%')"),
    ("B.agregado_diverge_das_medidas", "erro", "número de medidas do agregado difere do livro de medidas",
     "SELECT a.id FROM afirmacao a WHERE a.tipo='atividade_biologica' AND a.medida_n IS NOT NULL AND a.medida_n != "
     "(SELECT COUNT(*) FROM medida_bioatividade m WHERE m.afirmacao_id=a.id AND m.usada=1)"),
    ("B.alvo_publico_sem_natureza", "erro", "atividade pública em alvo sem natureza classificada",
     "SELECT a.id FROM afirmacao a JOIN alvo l ON l.id=a.alvo_id WHERE a.tipo='atividade_biologica' "
     "AND a.estado IN ('candidato','em_revisao') AND l.natureza IS NULL"),
    ("B.clinico_sem_fonte_regulatoria", "aviso", "efeito clínico público sem fonte regulatória listada pelo ChEMBL",
     "SELECT id FROM afirmacao WHERE tipo='efeito_clinico_documentado' AND estado IN ('candidato','em_revisao') "
     "AND (fontes_regulatorias IS NULL OR fontes_regulatorias = '[]')"),
    # ── não constituintes ──
    ("N.nao_constituinte_publico", "erro", "fármaco sintético, contaminante ou elemento químico como constituinte público",
     "SELECT a.id FROM afirmacao a JOIN molecula m ON m.id=a.molecula_id WHERE a.tipo='composto_em_organismo' "
     "AND a.estado IN ('candidato','em_revisao') "
     "AND m.restricao_ocorrencia IN ('farmaco_ou_reagente_sintetico','contaminante_provavel','elemento_quimico')"),
    # ── referências e linhagens ──
    ("R.doi_e_pmid_divergentes_ativa", "erro", "referência ativa cujo DOI e PMID são obras diferentes",
     "SELECT id, doi, pmid FROM referencia WHERE doi_pmid_coerente = 0 AND estado = 'ativa'"),
    ("R.vinculo_em_duplicata", "erro", "afirmação ligada a linha de referência marcada como duplicata",
     "SELECT x.afirmacao_id, x.referencia_id FROM afirmacao_referencia x JOIN referencia r ON r.id=x.referencia_id "
     "WHERE r.duplicata_de IS NOT NULL"),
    ("R.ponteiro_para_duplicata", "erro", "passagem, frase de coleta, leitura de curador ou linhagem apontando para linha duplicada de referência",
     "SELECT 'afirmacao.passagem' AS onde, a.id FROM afirmacao a JOIN referencia r ON r.id=a.passagem_referencia_id WHERE r.duplicata_de IS NOT NULL "
     "UNION ALL SELECT 'afirmacao.procedencia_artigo', a.id FROM afirmacao a JOIN referencia r ON r.id=a.procedencia_artigo_referencia_id WHERE r.duplicata_de IS NOT NULL "
     "UNION ALL SELECT 'verificacao', v.id FROM verificacao v JOIN referencia r ON r.id=v.referencia_id WHERE r.duplicata_de IS NOT NULL "
     "UNION ALL SELECT 'relacao_molecula', m.id FROM relacao_molecula m JOIN referencia r ON r.id=m.referencia_id WHERE r.duplicata_de IS NOT NULL"),
    ("R.publica_so_com_referencia_retida", "erro", "afirmação pública sustentada só por referências retidas",
     "SELECT a.id FROM afirmacao a WHERE a.estado IN ('candidato','em_revisao') "
     "AND EXISTS (SELECT 1 FROM afirmacao_referencia x WHERE x.afirmacao_id=a.id) AND NOT EXISTS ("
     "SELECT 1 FROM afirmacao_referencia x JOIN referencia r ON r.id=x.referencia_id WHERE x.afirmacao_id=a.id AND r.estado='ativa')"),
    ("R.referencia_retida_sem_regra", "erro", "referência retida sem regra e motivo",
     "SELECT id FROM referencia WHERE estado='quarentena' AND (regra_quarentena IS NULL OR motivo_quarentena IS NULL)"),
    ("L.linhagem_publica_sem_trecho", "erro", "linhagem pública sem trecho confirmatório conferido",
     "SELECT id FROM relacao_molecula WHERE estado IN ('candidato','em_revisao','verificado') "
     "AND (trecho IS NULL OR trecho_sha256 IS NULL OR trecho_conferido_em IS NULL OR chave IS NULL)"),
    ("L.linhagem_publica_com_referencia_retida", "erro", "linhagem pública citando referência retida ou incoerente",
     "SELECT rm.id FROM relacao_molecula rm JOIN referencia r ON r.id=rm.referencia_id "
     "WHERE rm.estado IN ('candidato','em_revisao','verificado') AND (r.estado != 'ativa' OR r.doi_pmid_coerente = 0)"),
    ("L.linhagem_retida_sem_motivo", "erro", "linhagem retida ou rejeitada sem regra e motivo",
     "SELECT id FROM relacao_molecula WHERE estado IN ('quarentena','rejeitado') AND (regra_quarentena IS NULL OR motivo_quarentena IS NULL)"),
    # ── identidade química ──
    ("M.conectividade_incoerente", "erro", "bloco de conectividade diferente do início do InChIKey",
     "SELECT id FROM molecula WHERE inchikey IS NOT NULL AND IFNULL(inchikey_conectividade,'') != substr(inchikey,1,14)"),
    ("M.massa_sem_distincao", "aviso", "pequena molécula com estrutura e sem as duas massas calculadas",
     "SELECT id FROM molecula WHERE tipo='pequena_molecula' AND smiles IS NOT NULL AND (massa_monoisotopica IS NULL OR massa_media IS NULL)"),
    # ── universo taxonômico ──
    ("U.universo_sem_arquivo_de_origem", "erro", "espécie do universo sem consulta (arquivo e hash) registrada",
     "SELECT u.id FROM universo_checklist u LEFT JOIN consulta c ON c.id=u.consulta_id WHERE c.id IS NULL OR c.sha256 IS NULL OR length(c.sha256) != 64"),
    ("U.universo_nome_nao_binomial", "erro", "nome aceito do universo que não é um binômio",
     "SELECT id, nome_aceito FROM universo_checklist WHERE length(trim(nome_aceito)) - length(replace(trim(nome_aceito), ' ', '')) != 1"),
    ("U.universo_duplicado", "erro", "mesma espécie aceita duas vezes na mesma fonte do universo",
     "SELECT fonte, lower(nome_aceito) AS nome, IFNULL(autoria,'') AS autoria, COUNT(*) AS n FROM universo_checklist "
     "GROUP BY 1,2,3 HAVING n > 1"),
    ("U.quimica_fora_do_recorte_do_universo", "erro", "marca de química aberta em espécie sem domínio Amazônia declarado",
     "SELECT id FROM universo_checklist WHERE tem_quimica_aberta=1 AND bioma_amazonia_declarado=0"),
    ("U.vinculo_com_outro_reino", "erro", "espécie do universo ligada a táxon de outro reino",
     "SELECT u.id FROM universo_checklist u JOIN taxon t ON t.id=u.taxon_id_bmb WHERE t.reino != u.reino"),
    # ── agregados do GBIF ──
    ("G.soma_por_uf", "erro", "contagens por UF não somam o total com UF do táxon",
     "SELECT t.id, t.nome FROM taxon t WHERE t.n_br_com_uf IS NOT NULL AND t.n_br_com_uf != "
     "(SELECT IFNULL(SUM(o.n),0) FROM ocorrencia_uf o WHERE o.taxon_id=t.id)"),
    ("G.soma_amazonia_legal", "erro", "contagem na Amazônia Legal difere da soma das nove UFs",
     "SELECT t.id, t.nome FROM taxon t WHERE t.n_al IS NOT NULL AND t.n_al != (SELECT IFNULL(SUM(o.n),0) FROM ocorrencia_uf o "
     "WHERE o.taxon_id=t.id AND o.uf_sigla IN ('AC','AM','AP','MA','MT','PA','RO','RR','TO'))"),
    ("G.ordem_das_contagens", "erro", "contagens fora de ordem (Amazônia Legal ≤ com UF ≤ Brasil)",
     "SELECT id, nome FROM taxon WHERE n_al > n_br_com_uf OR n_br_com_uf > n_br"),
    ("G.fracao_incoerente", "erro", "fração amazônica diferente da razão das contagens",
     "SELECT id, nome FROM taxon WHERE (n_br_com_uf > 0 AND fracao_al_com_uf IS NOT NULL AND abs(fracao_al_com_uf - 1.0*n_al/n_br_com_uf) > 0.001) "
     "OR (n_br > 0 AND fracao_al_total IS NOT NULL AND abs(fracao_al_total - 1.0*n_al/n_br) > 0.001)"),
    ("G.consulta_de_outro_taxon", "erro", "contagem de ocorrência cuja consulta ao GBIF é de outro táxon",
     "SELECT t.id, t.nome FROM taxon t JOIN consulta c ON c.id=t.ocorr_consulta_id "
     "WHERE c.url LIKE '%taxonKey=%' AND c.url NOT LIKE '%taxonKey=' || t.gbif_key AND c.url NOT LIKE '%taxonKey=' || t.gbif_key || '&%'"),
    ("G.uf_inexistente", "erro", "contagem em sigla que não é unidade da federação",
     "SELECT taxon_id, uf_sigla FROM ocorrencia_uf WHERE uf_sigla NOT IN ('AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS',"
     "'MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO')"),
    ("G.celula_fora_da_grade", "erro", "célula de lacuna fora de coordenadas válidas ou com densidade incoerente",
     "SELECT id FROM celula_lacuna WHERE lon < -180 OR lon > 180 OR lat < -90 OR lat > 90 "
     "OR abs(densidade_km2 - 1.0*n_ocorrencias_gbif/area_km2) > 0.01 * (1 + densidade_km2)"),
    # ── fotografias ──
    ("F.imagem_repetida_entre_taxons", "erro", "mesma imagem ativa atribuída a mais de um táxon",
     "SELECT arquivo_sha256, COUNT(DISTINCT taxon_id) AS n FROM midia WHERE arquivo_sha256 IS NOT NULL AND estado='ativo' "
     "GROUP BY arquivo_sha256 HAVING n > 1"),
    ("F.imagem_sem_dimensoes", "erro", "miniatura ativa sem dimensões válidas",
     "SELECT id FROM midia WHERE estado='ativo' AND arquivo IS NOT NULL AND (IFNULL(largura,0) <= 0 OR IFNULL(altura,0) <= 0)"),
    ("F.imagem_de_consulta_de_outro_taxon", "erro", "imagem cuja consulta de ocorrências do GBIF é de outro táxon",
     "SELECT m.id FROM midia m JOIN taxon t ON t.id=m.taxon_id JOIN consulta c ON c.id=m.consulta_id "
     "WHERE c.url LIKE '%/occurrence/search%taxonKey=%' AND c.url NOT LIKE '%taxonKey=' || t.gbif_key "
     "AND c.url NOT LIKE '%taxonKey=' || t.gbif_key || '&%'"),
    ("F.imagem_sem_registro_de_origem", "erro", "imagem do GBIF sem o identificador da ocorrência",
     "SELECT m.id FROM midia m JOIN consulta c ON c.id=m.consulta_id WHERE c.fonte_id='gbif' "
     "AND (m.gbif_ocorrencia IS NULL OR trim(m.gbif_ocorrencia) = '')"),
    ("F.pais_da_imagem_invalido", "erro", "país da imagem fora do formato ISO-2",
     "SELECT id FROM midia WHERE pais IS NOT NULL AND pais NOT GLOB '[A-Z][A-Z]'"),
    # ── invariantes estruturais ──
    ("E.molecula_sem_identidade", "erro", "molécula sem InChIKey nem UniProt",
     "SELECT id, nome FROM molecula WHERE inchikey IS NULL AND uniprot_acc IS NULL"),
    ("E.nome_com_mojibake", "erro", "registro com caractere substituto Unicode (U+FFFD) em nome ou bibliografia",
     "SELECT 'molecula' AS onde, id, nome AS valor FROM molecula WHERE nome LIKE '%' || char(65533) || '%' OR IFNULL(nome_na_fonte,'') LIKE '%' || char(65533) || '%' "
     "UNION ALL SELECT 'taxon', id, nome FROM taxon WHERE nome LIKE '%' || char(65533) || '%' OR IFNULL(autoria,'') LIKE '%' || char(65533) || '%' "
     "UNION ALL SELECT 'alvo', id, nome FROM alvo WHERE nome LIKE '%' || char(65533) || '%' "
     "UNION ALL SELECT 'referencia', id, COALESCE(titulo, revista, autores) FROM referencia "
     "WHERE IFNULL(titulo,'') LIKE '%' || char(65533) || '%' OR IFNULL(autores,'') LIKE '%' || char(65533) || '%' OR IFNULL(revista,'') LIKE '%' || char(65533) || '%'"),
    ("E.afirmacao_sem_prontidao", "aviso", "afirmação sem perfil de prontidão (rode a etapa 'prontidao')",
     "SELECT a.id FROM afirmacao a LEFT JOIN prontidao p ON p.afirmacao_id=a.id WHERE p.afirmacao_id IS NULL"),
    ("E.referencia_nao_resolvida", "aviso", "referência ativa ainda não resolvida em PubMed/Crossref",
     "SELECT r.id, r.doi, r.pmid FROM referencia r WHERE r.resolvida=0 AND ("
     "r.consulta_id IS NULL OR EXISTS ("
     "SELECT 1 FROM afirmacao_referencia ar JOIN afirmacao a ON a.id=ar.afirmacao_id "
     "WHERE ar.referencia_id=r.id AND a.estado NOT IN ('quarentena','rejeitado')))"),
    ("E.taxon_nao_especie", "erro", "táxon que não é espécie",
     "SELECT id, nome, rank FROM taxon WHERE rank <> 'SPECIES'"),
    ("E.estrutura_3d_sem_hash", "erro", "arquivo de geometria 3D sem hash SHA-256",
     "SELECT id, arquivo_geometria FROM estrutura_3d WHERE arquivo_geometria IS NOT NULL AND geometria_sha256 IS NULL"),
]


def validar(con):
    erros, avisos, ok = [], [], []
    for vid, nivel, descricao, sql in VERIFICACOES:
        linhas = [dict(r) for r in con.execute(sql).fetchall()]
        item = {"id": vid, "descricao": descricao, "n": len(linhas), "amostra": linhas[:5]}
        if linhas:
            (erros if nivel == "erro" else avisos).append(item)
        else:
            ok.append(vid)
    # Princípio 4 por texto: nenhum enunciado, passagem de curadoria ou nota pode soar como alegação de eficácia.
    suspeitos = []
    for r in con.execute("SELECT id, texto FROM afirmacao").fetchall():
        m = PALAVRAS_EFICACIA.search(r["texto"] or "")
        if m:
            suspeitos.append({"id": f"afirmacao:{r['id']}", "trecho": m.group(0)})
    for r in con.execute("SELECT id, texto FROM relacao_molecula").fetchall():
        m = PALAVRAS_EFICACIA.search(r["texto"] or "")
        if m:
            suspeitos.append({"id": f"relacao_molecula:{r['id']}", "trecho": m.group(0)})
    if suspeitos:
        erros.append({"id": "P4.texto_com_alegacao", "descricao": "enunciado com termo de alegação de eficácia",
                      "n": len(suspeitos), "amostra": suspeitos[:5]})
    else:
        ok.append("P4.texto_com_alegacao")
    # Governança regulatória: nenhuma substância proscrita/estrita (Portaria 344 F1/F2/A1/E) ativa sem quarentena
    from . import quimica
    nomes_ruins = []
    for r in con.execute(
        "SELECT DISTINCT m.id, m.nome FROM molecula m "
        "WHERE m.id IN ("
        "  SELECT molecula_id FROM afirmacao WHERE taxon_id IS NOT NULL AND estado NOT IN ('quarentena','rejeitado') AND classe_acesso='publico' "
        "  UNION SELECT origem_id FROM relacao_molecula WHERE estado IN ('candidato','em_revisao','verificado') "
        "  UNION SELECT destino_id FROM relacao_molecula WHERE estado IN ('candidato','em_revisao','verificado')"
        ")"
    ).fetchall():
        if quimica.nome_quimico_invalido(r["nome"], permitir_inchikey_canonico=True):
            nomes_ruins.append({"id": r["id"], "nome": r["nome"]})
    if nomes_ruins:
        erros.append({"id": "M.nome_placeholder_registro",
                      "descricao": "molécula pública com código bruto de registro, InChIKey truncado ou rótulo de impureza como nome",
                      "n": len(nomes_ruins), "amostra": nomes_ruins[:5]})
    else:
        ok.append("M.nome_placeholder_registro")
    proscritas = []
    for r in con.execute(
        "SELECT DISTINCT m.id, m.nome, m.inchikey FROM molecula m JOIN afirmacao a ON a.molecula_id=m.id "
        "WHERE m.inchikey IS NOT NULL AND a.estado NOT IN ('quarentena','rejeitado') AND a.classe_acesso='publico'"
    ).fetchall():
        achado = quimica.substancia_proscrita_344(r["inchikey"])
        if achado:
            proscritas.append({"id": r["id"], "nome": r["nome"], "lista": achado[0], "referencia": achado[1]})
    if proscritas:
        erros.append({"id": "G.substancia_proscrita_344",
                      "descricao": "substância proscrita/entorpecente (Portaria 344) em exibição pública",
                      "n": len(proscritas), "amostra": proscritas[:5]})
    else:
        ok.append("G.substancia_proscrita_344")
    # CARE / SisGen: testemunho declarado pela base só como código de coleção, nunca com localidade embutida
    from .conectores import ena
    vouchers = [{"id": r["id"], "voucher": r["voucher_declarado_base"]} for r in con.execute(
        "SELECT id, voucher_declarado_base FROM afirmacao WHERE voucher_declarado_base IS NOT NULL")
        if any(ena.voucher_sem_localidade(v) is None for v in r["voucher_declarado_base"].split("; "))]
    if vouchers:
        erros.append({"id": "C.voucher_com_localidade", "descricao": "testemunho com texto de localidade", "n": len(vouchers),
                      "amostra": vouchers[:5]})
    else:
        ok.append("C.voucher_com_localidade")
    # Integridade referencial do SQLite
    fk = con.execute("PRAGMA foreign_key_check").fetchall()
    if fk:
        erros.append({"id": "E.chave_estrangeira", "descricao": "violação de chave estrangeira", "n": len(fk),
                      "amostra": [tuple(x) for x in fk[:5]]})
    else:
        ok.append("E.chave_estrangeira")
    return {"erros": erros, "avisos": avisos, "ok": ok}


def imprimir(resultado, log=print):
    for item in resultado["erros"]:
        log(f"✗ ERRO  {item['id']}: {item['descricao']} ({item['n']}) {json.dumps(item['amostra'], ensure_ascii=False)[:200]}")
    for item in resultado["avisos"]:
        log(f"! aviso {item['id']}: {item['descricao']} ({item['n']})")
    log(f"✓ {len(resultado['ok'])} verificações sem violação · {len(resultado['avisos'])} avisos · {len(resultado['erros'])} erros")


def relatorio(con):
    """Texto com as contagens e a cobertura do banco (para o terminal e para o relatório público)."""
    q = lambda sql, *p: con.execute(sql, p).fetchone()[0]
    linhas = [
        "BioMapaBrasil · relatório do banco",
        f"  táxons: {q('SELECT COUNT(*) FROM taxon')} (no recorte: {q('SELECT COUNT(*) FROM taxon WHERE no_recorte=1')}; "
        f"predominantes: {q('SELECT COUNT(*) FROM taxon WHERE predominio_al=?', 'predominante')})",
        f"  moléculas: {q('SELECT COUNT(*) FROM molecula')}  ·  referências: {q('SELECT COUNT(*) FROM referencia')} "
        f"(resolvidas: {q('SELECT COUNT(*) FROM referencia WHERE resolvida=1')}, retratadas: {q('SELECT COUNT(*) FROM referencia WHERE retratada=1')})",
        f"  afirmações: {q('SELECT COUNT(*) FROM afirmacao')}",
    ]
    for tipo, estado, n in con.execute("SELECT tipo, estado, COUNT(*) FROM afirmacao GROUP BY 1,2 ORDER BY 1,2"):
        linhas.append(f"      {tipo:<28} {estado:<12} {n}")
    linhas.append(f"  imagens: {q('SELECT COUNT(*) FROM midia')}  ·  consultas registradas: {q('SELECT COUNT(*) FROM consulta')}")
    linhas.append(
        f"  expansão v2: bacias={q('SELECT COUNT(*) FROM ocorrencia_bacia WHERE n > 0')} vínculos · "
        f"lacunas_05={q('SELECT COUNT(*) FROM celula_lacuna')} células · "
        f"estruturas_3d={q('SELECT COUNT(*) FROM estrutura_3d')} · "
        f"vias_reactome={q('SELECT COUNT(*) FROM via_biologica')} · "
        f"linhagens={q('SELECT COUNT(*) FROM relacao_molecula')}"
    )
    return "\n".join(linhas)
