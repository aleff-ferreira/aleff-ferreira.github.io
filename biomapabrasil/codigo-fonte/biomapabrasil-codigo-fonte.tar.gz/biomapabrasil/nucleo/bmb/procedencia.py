# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Procedência do material estudado e distribuição da espécie: duas coisas diferentes, em colunas diferentes.

Três perguntas, três respostas separadas:

1. O que se DECLARA sobre onde o material foi coletado?  →  `afirmacao.procedencia_declarada`
     curador_artigo_amazonia                      curador leu o artigo: coleta na Amazônia. Único nível verificado em fonte primária.
     curador_artigo_fora_da_amazonia              curador leu o artigo: coleta fora da Amazônia.
     base_declara_amazonia_legal                  a base de origem (NuBBE-DB, ENA) declara UF da Amazônia Legal. Não foi conferido no artigo.
     base_declara_brasil_fora_da_amazonia_legal   a base declara UF brasileira fora da Amazônia Legal.
     base_declara_pais_pan_amazonico              a base declara só o país (sem UF). País não situa a coleta na Amazônia.
     base_declara_exterior                        a base declara país fora da Pan-Amazônia.
     nao_declarada                                a base não declara local de coleta.

2. O que o TEXTO ABERTO do artigo declara, quando uma frase de coleta foi localizada automaticamente?
   →  `afirmacao.procedencia_artigo` (+ país/UF em `procedencia_artigo_local`; a frase não é guardada, só o hash)

3. Onde a ESPÉCIE ocorre?  →  `taxon.distribuicao_br`
   Contexto de distribuição, vindo da Flora e Funga do Brasil / CTFB e das contagens do GBIF no Brasil. Uma espécie
   endêmica da Amazônia pode ter sido estudada a partir de material cultivado em outro continente; por isso a
   distribuição NUNCA entra como procedência de uma afirmação.

Nada mais fino que país e unidade da federação é guardado em qualquer um dos três campos (CARE / SisGen).
`afirmacao.procedencia_material` continua reservada ao que um curador registra depois de ler o artigo.
"""
from __future__ import annotations

import json
from collections import Counter

from . import config, quarentena

PAISES_PAN_AMAZONICOS = {"BR", "BO", "CO", "EC", "GF", "GY", "PE", "SR", "VE"}
UFS_AMAZONIA_LEGAL = set(config.UF_AMAZONIA_LEGAL)

# Procedência verificada em fonte primária por pessoa: só esta.
PROCEDENCIA_PRIMARIA_VERIFICADA = ("curador_artigo_amazonia",)
# Coleta na Amazônia declarada por alguém (curador ou base). Rótulo e filtro dizem QUEM declara.
PROCEDENCIA_AMAZONICA_DECLARADA = ("curador_artigo_amazonia", "base_declara_amazonia_legal")

ROTULOS_PROCEDENCIA = {
    "curador_artigo_amazonia": "Coleta na Amazônia conferida no artigo por curador",
    "curador_artigo_fora_da_amazonia": "Coleta fora da Amazônia conferida no artigo por curador",
    "base_declara_amazonia_legal": "Coleta na Amazônia Legal declarada pela base de origem",
    "base_declara_brasil_fora_da_amazonia_legal": "Coleta no Brasil fora da Amazônia Legal, declarada pela base de origem",
    "base_declara_pais_pan_amazonico": "País de coleta declarado pela base de origem, sem unidade da federação",
    "base_declara_exterior": "Coleta fora dos países amazônicos, declarada pela base de origem",
    "nao_declarada": "Local de coleta não declarado pela base de origem",
}
ROTULOS_PROCEDENCIA_ARTIGO = {
    "amazonia_legal": "O artigo declara coleta na Amazônia Legal",
    "pais_pan_amazonico": "O artigo declara coleta em país amazônico, sem situá-la na Amazônia",
    "brasil_fora_da_amazonia_legal": "O artigo declara coleta no Brasil fora da Amazônia Legal",
    "exterior": "O artigo declara coleta fora dos países amazônicos",
    "ambiente_marinho": "O artigo declara material de origem marinha",
}
# Classes de `procedencia_artigo` que situam a coleta fora da Amazônia.
PROCEDENCIA_ARTIGO_FORA_DA_AMAZONIA = ("brasil_fora_da_amazonia_legal", "exterior", "ambiente_marinho")
ROTULOS_DISTRIBUICAO = {
    "endemica_do_brasil_restrita_ao_dominio_amazonia": "Endêmica do Brasil, restrita ao domínio Amazônia",
    "endemica_do_brasil_com_ocorrencia_na_amazonia": "Endêmica do Brasil, com ocorrência na Amazônia",
    "registros_brasileiros_concentrados_na_amazonia_legal": "Registros brasileiros concentrados na Amazônia Legal",
    "registros_brasileiros_dispersos": "Registros brasileiros em várias regiões",
    "introduzida_ou_naturalizada": "Introduzida ou naturalizada no Brasil",
    "fora_do_recorte": "Fora do recorte amazônico",
    "indeterminada": "Distribuição não classificada",
}


def _biomas(t) -> set[str]:
    try:
        lista = json.loads(t["biomas_json"]) if t["biomas_json"] else []
    except (TypeError, ValueError):
        lista = []
    return {str(b).strip().lower() for b in lista or [] if b}


def classificar_distribuicao_taxon(t) -> str:
    """`taxon.distribuicao_br`: o que o checklist nacional e as contagens brasileiras do GBIF dizem da espécie.

    Cada rótulo descreve literalmente a medida usada. «Registros brasileiros concentrados na Amazônia Legal» não
    afirma que a espécie é amazônica: as contagens são só do Brasil, e uma espécie pantropical pode tê-las assim.
    """
    estab = (t["origem_estabelecimento"] or "").strip().lower()
    endem = (t["endemismo_br"] or "").strip().lower()
    pred = (t["predominio_al"] or "").strip().lower()
    if estab in ("naturalizada", "cultivada", "introduzida", "exotica", "exótica", "introduced"):
        return "introduzida_ou_naturalizada"
    if not t["no_recorte"]:
        return "fora_do_recorte"
    biomas = _biomas(t)
    tem_amz = any("amaz" in b for b in biomas)
    if endem in ("endemica", "endêmica", "endemic") and tem_amz:
        return ("endemica_do_brasil_restrita_ao_dominio_amazonia" if len(biomas) == 1
                else "endemica_do_brasil_com_ocorrencia_na_amazonia")
    if pred == "predominante":
        return "registros_brasileiros_concentrados_na_amazonia_legal"
    if pred == "nao_predominante":
        return "registros_brasileiros_dispersos"
    return "indeterminada"


def classificar_declaracao(af, verif_row=None) -> str | None:
    """`afirmacao.procedencia_declarada` para afirmações ligadas a organismo; None para as demais.

    A distribuição da espécie não participa. Sem leitura de curador e sem declaração da base, o resultado é
    `nao_declarada` — nunca um nível amazônico inferido.
    """
    if af["tipo"] not in ("composto_em_organismo", "funcao_toxina"):
        return None
    if verif_row is not None and verif_row["decisao"] in ("confirmada", "corrigida"):
        esc = (verif_row["escopo_geografico_lido"] or "").strip()
        if esc in ("amazonia_br", "pan_amazonia"):
            return "curador_artigo_amazonia"
        if esc in ("brasil_extra_amazonia", "exterior_nao_amazonico"):
            return "curador_artigo_fora_da_amazonia"
    ufs = {u.strip() for u in (af["uf_coleta_declarada"] or "").upper().split(",") if u.strip()}
    pais = (af["pais_coleta_declarado"] or "").strip().upper()
    if ufs:
        if ufs <= UFS_AMAZONIA_LEGAL:
            return "base_declara_amazonia_legal"
        if not (ufs & UFS_AMAZONIA_LEGAL):
            return "base_declara_brasil_fora_da_amazonia_legal"
        return "base_declara_pais_pan_amazonico"      # UFs dos dois lados: o que se sabe com segurança é o país
    if pais:
        return "base_declara_pais_pan_amazonico" if pais in PAISES_PAN_AMAZONICOS else "base_declara_exterior"
    return "nao_declarada"


def classe_do_local(pais: str | None, uf: str | None) -> str | None:
    """Classe de `procedencia_artigo` para um par país/UF lido no texto do artigo."""
    pais = (pais or "").strip().upper()
    uf = (uf or "").strip().upper()
    if not pais:
        return None
    if pais == "BR":
        if uf:
            return "amazonia_legal" if uf in UFS_AMAZONIA_LEGAL else "brasil_fora_da_amazonia_legal"
        return "pais_pan_amazonico"
    return "pais_pan_amazonico" if pais in PAISES_PAN_AMAZONICOS else "exterior"


REGRAS_DE_PROCEDENCIA = ("PROV-FORA-DA-AMAZONIA",)
_NOME_PAIS = {"BR": "Brasil", "BO": "Bolívia", "CO": "Colômbia", "EC": "Equador", "GF": "Guiana Francesa", "GY": "Guiana",
              "PE": "Peru", "SR": "Suriname", "VE": "Venezuela"}


def _local_legivel(codigo: str | None) -> str:
    """'BR-SP' → 'São Paulo é UF de fora da Amazônia Legal' fica a cargo do modelo; aqui só o nome do lugar."""
    if not codigo:
        return "local fora da Amazônia"
    pais, _, uf = codigo.partition("-")
    return f"{_NOME_PAIS.get(pais, pais)}{' (' + uf + ')' if uf else ''}"


def recalcular_procedencia_banco(con) -> dict:
    """Atualiza `taxon.distribuicao_br` e `afirmacao.procedencia_declarada`, e declara a regra que retém coleta
    fora da Amazônia confirmada em fonte primária (curador ou frase de coleta localizada no artigo).

    As colunas antigas `taxon.escopo_biogeografico` e `afirmacao.nivel_procedencia` ficam sempre NULL.
    """
    cont_tax, cont_af = Counter(), Counter()
    for t in con.execute("SELECT * FROM taxon").fetchall():
        dist = classificar_distribuicao_taxon(t)
        con.execute("UPDATE taxon SET distribuicao_br=?, escopo_biogeografico=NULL WHERE id=?", (dist, t["id"]))
        cont_tax[dist] += 1

    ult_verif = {}
    for v in con.execute("SELECT * FROM verificacao WHERE decisao IN ('confirmada','corrigida') ORDER BY em, id").fetchall():
        ult_verif[v["afirmacao_id"]] = v

    disparos, lote = {}, []
    for a in con.execute("SELECT a.*, t.nome AS t_nome FROM afirmacao a LEFT JOIN taxon t ON t.id=a.taxon_id").fetchall():
        decl = classificar_declaracao(a, ult_verif.get(a["id"]))
        lote.append((decl, a["id"]))
        if decl:
            cont_af[decl] += 1
        if a["tipo"] != "composto_em_organismo":
            continue
        if decl == "curador_artigo_fora_da_amazonia":
            disparos[a["id"]] = {"PROV-FORA-DA-AMAZONIA": {"taxon": a["t_nome"], "local": "local fora da Amazônia (leitura de curador)"}}
        elif decl != "curador_artigo_amazonia" and a["procedencia_artigo"] in PROCEDENCIA_ARTIGO_FORA_DA_AMAZONIA:
            local = "ambiente marinho" if a["procedencia_artigo"] == "ambiente_marinho" else _local_legivel(a["procedencia_artigo_local"])
            disparos[a["id"]] = {"PROV-FORA-DA-AMAZONIA": {"taxon": a["t_nome"], "local": local}}
    con.executemany("UPDATE afirmacao SET procedencia_declarada=?, nivel_procedencia=NULL WHERE id=?", lote)
    quarentena.registrar_catalogo(con)
    res = quarentena.declarar(con, REGRAS_DE_PROCEDENCIA, disparos)
    con.commit()
    return {"distribuicao_taxons": dict(cont_tax), "procedencia_declarada": dict(cont_af),
            "coleta_fora_da_amazonia_em_fonte_primaria": res["declaradas"].get("PROV-FORA-DA-AMAZONIA", 0)}
