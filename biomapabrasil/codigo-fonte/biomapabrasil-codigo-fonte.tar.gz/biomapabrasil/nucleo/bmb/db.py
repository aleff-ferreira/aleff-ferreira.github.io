# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Banco SQLite: conexão, migrações numeradas e o registro das fontes de dados."""
import sqlite3
from pathlib import Path

from . import config

MIGRACOES_DIR = Path(__file__).parent / "migracoes"

# Fontes e licenças, como verificadas. Cada afirmação aponta a sua fonte, então a licença viaja com o dado.
FONTES = [
    ("gbif", "GBIF — Global Biodiversity Information Facility", "https://www.gbif.org",
     "CC0 / CC BY / CC BY-NC (por conjunto de dados)", "https://www.gbif.org/terms/data-user",
     "Backbone taxonômico, contagens agregadas de ocorrência e mídia. Cada imagem declara a própria licença."),
    ("uniprot", "UniProt Consortium — UniProtKB/Swiss-Prot (Tox-Prot)", "https://www.uniprot.org",
     "CC BY 4.0", "https://creativecommons.org/licenses/by/4.0/",
     "Toxinas animais revisadas manualmente, com função anotada e evidência por publicação."),
    ("lotus", "LOTUS — natural products occurrences (registro congelado no Zenodo)", "https://lotus.naturalproducts.net",
     "CC BY 4.0", "https://creativecommons.org/licenses/by/4.0/",
     "Pares estrutura–organismo com a referência que os sustenta e taxonomia química NPClassifier. Lido do registro "
     "congelado 10.5281/zenodo.19360665, que declara licença CC BY 4.0 (os dados do LOTUS no Wikidata são CC0)."),
    ("pubchem", "PubChem (NCBI/NLM)", "https://pubchem.ncbi.nlm.nih.gov",
     "Domínio público (NCBI); dados de contribuintes podem ter termos próprios",
     "https://www.ncbi.nlm.nih.gov/home/about/policies/",
     "Identificadores e propriedades de compostos."),
    ("chembl", "ChEMBL (EMBL-EBI)", "https://www.ebi.ac.uk/chembl",
     "CC BY-SA 3.0", "https://creativecommons.org/licenses/by-sa/3.0/",
     "Atividade medida, alvo, fase clínica e indicações de fármacos aprovados. Compartilha-igual."),
    ("pubmed", "PubMed (NCBI/NLM)", "https://pubmed.ncbi.nlm.nih.gov",
     "Metadados públicos (NLM)", "https://www.nlm.nih.gov/databases/download/terms_and_conditions.html",
     "Metadados bibliográficos."),
    ("crossref", "Crossref", "https://www.crossref.org",
     "CC0 (metadados)", "https://www.crossref.org/documentation/retrieve-metadata/rest-api/",
     "Metadados bibliográficos por DOI."),
    ("datacite", "DataCite", "https://datacite.org",
     "CC0 (metadados)", "https://support.datacite.org/docs/datacite-data-file-use-policy",
     "Metadados de DOIs registrados fora do Crossref: conjuntos de dados, relatórios e teses."),
    ("doi_org", "DOI Foundation — sistema de resolução (doi.org)", "https://www.doi.org",
     "Serviço de resolução (sem conteúdo redistribuído)", "https://www.doi.org/the-identifier/resources/factsheets/doi-resolution-documentation",
     "Confirma se um DOI está registrado."),
    ("ibge", "IBGE — Instituto Brasileiro de Geografia e Estatística", "https://www.ibge.gov.br",
     "CC BY 4.0", "https://www.ibge.gov.br/acesso-informacao/institucional/politica-de-uso.html",
     "Unidades federativas, códigos, malhas territoriais e biomas oficiais."),
    ("flora_funga_br", "Flora e Funga do Brasil — Jardim Botânico do Rio de Janeiro (via GBIF)", "https://floradobrasil.jbrj.gov.br",
     "CC BY 4.0", "https://creativecommons.org/licenses/by/4.0/",
     "Origem nativa/introduzida, endemismo, domínios fitogeográficos, forma de vida e substrato de plantas e fungos."),
    ("ctfb", "Catálogo Taxonômico da Fauna do Brasil (JBRJ / PNUD via GBIF)", "http://fauna.jbrj.gov.br",
     "CC BY 4.0", "https://creativecommons.org/licenses/by/4.0/",
     "Nomenclatura, origem, forma de vida e hábitat da fauna brasileira."),
    ("nubbe", "NuBBE-DB — Brazilian Biodiversity Natural Products Database (UNESP / ChemNet)", "https://nubbe.iq.unesp.br",
     "MIT / Atribuição aberta (ChemNet / NuBBE)", "https://github.com/chemnet-io/nubbeKG/blob/main/LICENSE",
     "Produtos naturais isolados de espécies estudadas no Brasil, com DOI, estado de coleta declarado e classe."),
    ("npatlas", "The Natural Products Atlas (NPAtlas)", "https://www.npatlas.org",
     "CC BY 4.0", "https://creativecommons.org/licenses/by/4.0/",
     "Produtos naturais microbianos e fúngicos curados com referência primária de isolamento."),
    ("rcsb_pdb", "RCSB Protein Data Bank (wwPDB)", "https://www.rcsb.org",
     "CC0 1.0", "https://creativecommons.org/publicdomain/zero/1.0/",
     "Estruturas tridimensionais experimentais de biomoléculas e ligantes (cristalografia de raios X, RMN, crio-EM)."),
    ("cod", "Crystallography Open Database (COD)", "https://www.crystallography.net/cod/",
     "CC0 1.0", "https://creativecommons.org/publicdomain/zero/1.0/",
     "Estruturas cristalográficas tridimensionais experimentais de pequenas moléculas e produtos naturais determinadas por difração de raios X e nêutrons de monocristal (domínio público CC0)."),
    ("alphafold", "AlphaFold Protein Structure Database (EMBL-EBI / Google DeepMind)", "https://alphafold.ebi.ac.uk",
     "CC BY 4.0", "https://creativecommons.org/licenses/by/4.0/",
     "Modelos computacionais preditos de estrutura proteica com confiança por resíduo (pLDDT)."),
    ("esm_atlas", "ESM Metagenomic Atlas — ESMFold v1 (Meta FAIR)", "https://esmatlas.com",
     "CC BY 4.0", "https://creativecommons.org/licenses/by/4.0/",
     "Predições computacionais atômicas de estrutura proteica por modelo de linguagem evolutiva ESMFold v1 com métrica pLDDT por resíduo, empregadas quando a sequência madura não consta no AlphaFold DB."),
    ("reactome", "Reactome Pathway Knowledgebase", "https://reactome.org",
     "CC BY 4.0", "https://creativecommons.org/licenses/by/4.0/",
     "Vias biológicas humanas curadas associadas a alvos proteicos."),
    ("wikimedia_commons", "Wikimedia Commons", "https://commons.wikimedia.org",
     "CC0 / CC BY (verificada individualmente por imagem)", "https://commons.wikimedia.org/wiki/Commons:Licensing",
     "Fotografias e ilustrações científicas sob licenças livres CC0 ou CC BY."),
    ("europepmc", "Europe PMC (EMBL-EBI)", "https://europepmc.org",
     "CC0 / Acesso Aberto (metadados e resumos)", "https://europepmc.org/Copyright",
     "Resumos e trechos abertos de publicações científicas para apoio à curadoria humana."),
    ("ana_hydrosheds", "ANA / HydroSHEDS / Natural Earth — Sub-bacias Hidrográficas", "https://www.hydrosheds.org",
     "CC BY 4.0 / Domínio público", "https://www.hydrosheds.org/terms-of-use",
     "Sub-bacias hidrográficas amazônicas para agregação espacial de diversidade e amostragem."),
    ("aws_terrarium", "Mapzen / AWS Open Data Terrain Tiles (SRTM / ETOPO1 / GMTED)", "https://registry.opendata.aws/terrain-tiles/",
     "Domínio público / Atribuição aberta (USGS SRTM, NOAA ETOPO1)", "https://github.com/tilezen/joerd/blob/master/docs/data-sources.md",
     "Grade altimétrica e batimétrica física calibrada em metros sobre o nível do mar."),
    ("terrabrasilis_cnuc", "INPE TerraBrasilis (PRODES) & MMA CNUC / FUNAI (síntese espacial 0,5°)", "https://terrabrasilis.dpi.inpe.br",
     "Dados Abertos Governamentais (Brasil) / CC BY-SA 4.0", "https://www.gov.br/governodigital/pt-br/dados-abertos",
     "Indicadores espaciais agregados em células de 0,5° de pressão antrópica e cobertura de áreas protegidas."),
    ("rdkit_local", "RDKit Cheminformatics (cálculo determinístico local)", "https://www.rdkit.org",
     "BSD-3-Clause (software); dados calculados CC0", "https://github.com/rdkit/rdkit/blob/master/license.txt",
     "Cálculo local reproduzível de descritores físico-químicos, esqueletos de Murcko, projeção química e confôrmeros 3D ETKDGv3."),
    ("ena", "European Nucleotide Archive (EMBL-EBI ENA Portal)", "https://www.ebi.ac.uk/ena/browser/home",
     "CC0 1.0 / Domínio público (INSDC)", "https://www.ebi.ac.uk/ena/browser/about/policies",
     "Metadados geográficos de país/estado e testemunho (specimen_voucher) de sequências EMBL/GenBank ligadas ao UniProt."),
    ("jbrj_dwca", "Flora e Funga do Brasil — Arquivo Darwin Core Oficial (IPT JBRJ)", "https://ipt.jbrj.gov.br/jbrj/resource?r=lista_especies_flora_brasil",
     "CC BY 4.0", "https://creativecommons.org/licenses/by/4.0/",
     "Universo taxonômico aceito completo de plantas e fungos do Brasil, domínios fitogeográficos (Amazônia) e endemismo."),
    ("ctfb_dwca", "Catálogo Taxonômico da Fauna do Brasil — Arquivo Darwin Core Oficial (IPT JBRJ)", "https://ipt.jbrj.gov.br/jbrj/resource?r=catalogo_taxonomico_da_fauna_do_brasil",
     "CC BY 4.0", "https://creativecommons.org/licenses/by/4.0/",
     "Universo taxonômico aceito completo da fauna brasileira, origem e distribuição estadual."),
    ("curadoria", "Curadoria BioMapaBrasil", "https://aleff-ferreira.github.io/biomapabrasil/",
     "CC BY 4.0", "https://creativecommons.org/licenses/by/4.0/",
     "Decisões editoriais da equipe: lista inicial de espécies, linhagens farmacológicas com a obra citada "
     "e conferência de passagens por curador."),
]


def conectar(caminho=None):
    caminho = Path(caminho or config.DB_PATH)
    caminho.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(caminho)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    con.execute("PRAGMA journal_mode = WAL")
    migrar(con)
    return con


def versao_atual(con):
    return con.execute("PRAGMA user_version").fetchone()[0]


def migrar(con):
    """Aplica, em ordem, as migrações NNN_*.sql ainda não aplicadas."""
    atual = versao_atual(con)
    for arq in sorted(MIGRACOES_DIR.glob("[0-9][0-9][0-9]_*.sql")):
        numero = int(arq.name[:3])
        if numero <= atual:
            continue
        con.executescript(arq.read_text(encoding="utf-8"))
        con.execute(f"PRAGMA user_version = {numero}")
        con.commit()
    registrar_fontes(con)
    # o catálogo de regras de retenção é dado de referência do código, como a lista de fontes
    from . import quarentena
    quarentena.registrar_catalogo(con)
    con.commit()


def registrar_fontes(con):
    con.executemany(
        "INSERT INTO fonte (id, nome, url, licenca, licenca_url, descricao) VALUES (?,?,?,?,?,?) "
        "ON CONFLICT(id) DO UPDATE SET nome=excluded.nome, url=excluded.url, licenca=excluded.licenca, "
        "licenca_url=excluded.licenca_url, descricao=excluded.descricao", FONTES)
    con.commit()
