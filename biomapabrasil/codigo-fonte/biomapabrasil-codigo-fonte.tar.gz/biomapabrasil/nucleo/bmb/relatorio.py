# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Relatório dos dados em Markdown, gerado do próprio banco: números reais, nunca digitados à mão.

É um relatório de construção, para quem mantém o banco: traz também o que ficou retido, por regra. Os números do
que é público saem da mesma seleção dos pacotes do site (`bmb.exportar.pacotes`).
"""
import json
import statistics
from pathlib import Path

from . import __version__, config, procedencia, quarentena
from .exportar import pacotes
from .util import agora, milhar

TIPOS = {"composto_em_organismo": "Composto relatado em organismo (LOTUS / NuBBE-DB / NPAtlas)",
         "funcao_toxina": "Função de toxina (UniProt Tox-Prot)",
         "atividade_biologica": "Bioatividade por par molécula–alvo (ChEMBL)",
         "efeito_clinico_documentado": "Efeito clínico de fármaco aprovado (ChEMBL)"}
GRUPOS = {"planta": "Plantas", "animal_peconhento": "Animais com toxinas", "fungo": "Fungos", "outro": "Outros animais"}


def _tabela(cabecalho, linhas):
    saida = ["| " + " | ".join(cabecalho) + " |", "|" + "|".join("---" for _ in cabecalho) + "|"]
    saida += ["| " + " | ".join("" if c is None else str(c) for c in l) + " |" for l in linhas]
    return "\n".join(saida)


def gerar_markdown(con):
    q = lambda sql, *a: con.execute(sql, a).fetchone()[0]
    ctx = pacotes.Contexto(con)
    c = ctx.contagens()
    L = []
    L.append("# Relatório dos dados do BioMapaBrasil\n")
    L.append(f"Gerado em {agora()[:10]} por `bmb {__version__}` a partir do banco de dados da plataforma. Todos os números abaixo vêm de consultas ao banco; "
             "cada um tem, no banco, a consulta de origem (fonte, endereço, data, tamanho e hash da resposta). "
             "Relatório de construção: inclui as contagens de registros retidos e não faz parte do site.\n")

    # visão geral
    L.append("## Visão geral\n")
    L.append(_tabela(["Item", "Quantidade"], [
        ("Táxons no banco", milhar(c["taxons"])),
        ("Táxons dentro do recorte amazônico", milhar(c["taxons_no_recorte"])),
        ("Táxons com metade ou mais dos registros brasileiros na Amazônia Legal (nas duas bases)", milhar(c["taxons_com_predominio_de_registros_na_amazonia_legal"])),
        ("Afirmações no banco (todos os estados)", milhar(q("SELECT COUNT(*) FROM afirmacao"))),
        ("Afirmações públicas", milhar(c["afirmacoes_publicas"])),
        ("Pares distintos táxon–molécula com afirmação pública de composto", milhar(c["pares_taxon_molecula"])),
        ("Pares afirmados por mais de uma base de origem", milhar(c["pares_taxon_molecula_em_mais_de_uma_base"])),
        ("Moléculas públicas", milhar(c["moleculas"])),
        ("Estruturas (InChIKey) e conectividades 2D entre as moléculas públicas", f"{milhar(c['moleculas_inchikey'])} e {milhar(c['conectividades_2d'])}"),
        ("Referências no banco", f"{milhar(q('SELECT COUNT(*) FROM referencia'))} ({milhar(q('SELECT COUNT(*) FROM referencia WHERE resolvida=1'))} conferidas em PubMed/Crossref)"),
        ("Obras citadas por registro público", milhar(c["referencias"])),
        ("Consultas às fontes registradas", milhar(q("SELECT COUNT(*) FROM consulta"))),
        ("Imagens com licença CC0/CC BY e autor", milhar(c["imagens"])),
        ("Verificações humanas registradas", milhar(q("SELECT COUNT(*) FROM verificacao"))),
    ]) + "\n")

    if q("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='universo_checklist'"):
        tot_uc = q("SELECT COUNT(*) FROM universo_checklist WHERE bioma_amazonia_declarado=1")
        if tot_uc > 0:
            com_q_uc = q("SELECT COUNT(*) FROM universo_checklist WHERE bioma_amazonia_declarado=1 AND tem_quimica_aberta=1")
            sem_q_uc = tot_uc - com_q_uc
            L.append("## Universo taxonômico amazônico e matéria escura química\n")
            L.append(
                "Cruzamento dos catálogos nacionais oficiais (**Flora e Funga do Brasil / JBRJ** + **Catálogo Taxonômico da Fauna do Brasil / CTFB**) "
                "com ocorrência declarada no domínio Amazônia contra o conjunto aberto consolidado (LOTUS + NuBBE-DB + NPAtlas + UniProt Tox-Prot):\n"
            )
            linhas_uc = []
            for grp, rot in (("planta", "Plantas"), ("fungo", "Fungos"), ("animal_peconhento", "Animais peçonhentos"), ("animal_outro", "Demais animais")):
                nt = q("SELECT COUNT(*) FROM universo_checklist WHERE bioma_amazonia_declarado=1 AND grupo_bmb=?", grp)
                nq = q("SELECT COUNT(*) FROM universo_checklist WHERE bioma_amazonia_declarado=1 AND grupo_bmb=? AND tem_quimica_aberta=1", grp)
                if nt:
                    linhas_uc.append((rot, milhar(nt), milhar(nq), milhar(nt - nq), f"{(nt - nq) * 100.0 / nt:.2f}%".replace(".", ",")))
            linhas_uc.append(("**Total Bioma Amazônia**", f"**{milhar(tot_uc)}**", f"**{milhar(com_q_uc)}**", f"**{milhar(sem_q_uc)}**", f"**{sem_q_uc * 100.0 / tot_uc:.2f}%**".replace(".", ",")))
            L.append(_tabela(["Grupo biológico", "Espécies aceitas na Amazônia", "Com química aberta", "Sem química aberta (dark matter)", "Fração dark matter"], linhas_uc) + "\n")

    # recorte e distribuição
    L.append("## Recorte amazônico\n")
    L.append(f"Regra: pelo menos {config.N_AL_MIN} registros do GBIF nas UFs da Amazônia Legal ({', '.join(config.UF_AMAZONIA_LEGAL)}). O predomínio "
             f"(metade ou mais dos registros brasileiros) só é afirmado quando as duas bases concordam: só registros com UF atribuída e todos os registros do Brasil.\n")
    linhas = []
    for chave, rot in GRUPOS.items():
        n = q("SELECT COUNT(*) FROM taxon WHERE grupo=?", chave)
        if not n:
            continue
        linhas.append((rot, n, q("SELECT COUNT(*) FROM taxon WHERE grupo=? AND no_recorte=1", chave),
                       q("SELECT COUNT(*) FROM taxon WHERE grupo=? AND predominio_al='predominante'", chave),
                       q("SELECT COUNT(*) FROM taxon WHERE grupo=? AND predominio_al='indeterminado' AND no_recorte=1", chave),
                       q("SELECT COUNT(*) FROM taxon WHERE grupo=? AND predominio_al='nao_predominante' AND no_recorte=1", chave)))
    L.append(_tabela(["Grupo", "No banco", "No recorte", "Predomina", "Indeterminado", "Marginal"], linhas) + "\n")
    L.append("### Distribuição da espécie no Brasil (`taxon.distribuicao_br`)\n")
    L.append("Contexto de distribuição, do checklist nacional e das contagens brasileiras do GBIF. Não é procedência do material de nenhum estudo.\n")
    L.append(_tabela(["Distribuição", "Táxons"], [(procedencia.ROTULOS_DISTRIBUICAO[k], milhar(n)) for k, n in c["taxons_por_distribuicao"].items()]) + "\n")
    tox = con.execute("SELECT resumo FROM etapa WHERE nome='taxons'").fetchone()
    if tox and tox["resumo"]:
        r = json.loads(tox["resumo"])
        motivos = {"outro_reino": "são de outro reino (bactérias, vírus, plantas ou fungos, fora do escopo de animais com toxinas)",
                   "sem_correspondencia": "não têm correspondência no backbone", "correspondencia_aproximada": "só casaram de forma aproximada",
                   "so_nivel_superior": "só casaram com um nível taxonômico superior"}
        detalhe = "; ".join(f"{milhar(r[f'rejeicao:{k}'])} {v}" for k, v in motivos.items() if r.get(f"rejeicao:{k}"))
        L.append(f"Tox-Prot: {milhar(r.get('toxprot_organismos', 0))} organismos com toxina revisada; {milhar(r.get('toxprot_fora_do_recorte', 0))} ficaram fora do recorte "
                 f"(menos de {config.N_AL_MIN} registros na Amazônia Legal) e {milhar(r.get('nome_rejeitado_toxprot', 0))} tiveram o nome rejeitado em vez de aceito em silêncio"
                 + (f" ({detalhe})" if detalhe else "") + ".\n")
    L.append("Táxons da semente que estão fora do recorte (o banco guarda o motivo, com os números):\n")
    fora = con.execute("SELECT nome, n_br, n_al, predominio_al FROM taxon WHERE no_recorte=0 ORDER BY nome").fetchall()
    L.append(_tabela(["Táxon", "Registros no Brasil", "Na Amazônia Legal"], [(f"*{t['nome']}*", milhar(t["n_br"] or 0), milhar(t["n_al"] or 0)) for t in fora]) + "\n" if fora else "Nenhum.\n")

    # afirmações
    L.append("## Afirmações\n")
    L.append(_tabela(["Tipo", "Registro de base curada", "Em revisão", "Verificado", "Quarentena", "Rejeitado"], [
        (TIPOS[t], *(milhar(q("SELECT COUNT(*) FROM afirmacao WHERE tipo=? AND estado=?", t, e))
                     for e in ("candidato", "em_revisao", "verificado", "quarentena", "rejeitado")))
        for t in TIPOS]) + "\n")
    L.append("«Registro de base curada» é o que a base de origem registra, com a publicação indicada. Só a leitura de curador, registrada em "
             "`verificacao`, leva a «verificado».\n")
    L.append("### Nível de evidência das afirmações públicas (`nivel_evidencia`)\n")
    L.append(_tabela(["Nível", "Afirmações públicas"],
                     [(pacotes.ROTULOS_EVIDENCIA[k], milhar(n)) for k, n in c["afirmacoes_por_evidencia"].items()]) + "\n")
    L.append("### Procedência declarada do material (`procedencia_declarada`)\n")
    L.append("Só afirmações ligadas a organismo. O rótulo diz quem declara: curador que leu o artigo ou a base de origem. "
             "A distribuição da espécie não entra aqui.\n")
    L.append(_tabela(["Procedência declarada", "Afirmações públicas"],
                     [(procedencia.ROTULOS_PROCEDENCIA[k], milhar(n)) for k, n in c["procedencia_declarada"].items()]) + "\n")
    n_artigo = q(f"SELECT COUNT(*) FROM afirmacao WHERE procedencia_artigo IS NOT NULL AND {pacotes.sql_publica()}")
    L.append(f"Afirmações públicas em que uma frase de coleta do texto aberto do artigo foi localizada: {milhar(n_artigo)}.\n")

    # retenções
    res = quarentena.resumo(con)
    L.append("## Retenções\n")
    L.append("Registros que estão no banco e não vão a público, pela regra de maior precedência que cada um dispara. "
             "O livro completo, com o motivo de cada registro, é gravado por `bmb exportar` em `saida/interno/retencoes.json`.\n")
    linhas = [(codigo, quarentena.REGRAS[codigo].titulo if codigo in quarentena.REGRAS else "decisão de curador ou retenção sem código", milhar(n))
              for codigo, n in res["afirmacoes_por_regra"].items()]
    L.append(_tabela(["Regra", "O que retém", "Afirmações em quarentena"], linhas) + "\n" if linhas else "Nenhuma afirmação em quarentena.\n")
    if res["afirmacoes_por_grupo"]:
        L.append(_tabela(["Grupo de regras", "Afirmações em quarentena"], [(g, milhar(n)) for g, n in res["afirmacoes_por_grupo"].items()]) + "\n")
    L.append(_tabela(["Outros registros fora do público", "Quantidade"], [
        ("Afirmações rejeitadas por curador", milhar(q("SELECT COUNT(*) FROM afirmacao WHERE estado='rejeitado'"))),
        ("Afirmações em estado público com acesso restrito ou comunitário", milhar(q(f"SELECT COUNT(*) FROM afirmacao WHERE estado IN {pacotes.SQL_ESTADOS} AND classe_acesso <> 'publico'"))),
        ("Bioatividade e efeito clínico de molécula sem ocorrência pública nem linhagem pública",
         milhar(q(f"SELECT COUNT(*) FROM afirmacao a WHERE {pacotes.sql_publica('a')} AND a.taxon_id IS NULL AND a.molecula_id NOT IN ({pacotes.SQL_MOLECULAS_PUBLICAS})"))),
        ("Referências retidas, por regra", ", ".join(f"{k}: {milhar(n)}" for k, n in res["referencias_por_regra"].items()) or "0"),
        ("Linhas de referência duplicadas de outra obra", milhar(q("SELECT COUNT(*) FROM referencia WHERE duplicata_de IS NOT NULL"))),
        ("Linhagens por estado e regra", ", ".join(f"{k.rstrip('|')}: {milhar(n)}" for k, n in res["linhagens_por_estado"].items()) or "0"),
        ("Imagens retidas", milhar(q("SELECT COUNT(*) FROM midia WHERE estado='quarentena'"))),
    ]) + "\n")

    # cobertura
    L.append("## Cobertura de moléculas por táxon\n")
    linhas = []
    for chave, rot, campo in (("planta", "Plantas", "compostos_fonte"), ("fungo", "Fungos", "compostos_fonte"), ("animal_peconhento", "Animais com toxinas", "toxinas_fonte")):
        vals = [r[0] for r in con.execute(f"SELECT {campo} FROM taxon WHERE grupo=? AND no_recorte=1 AND {campo} IS NOT NULL", (chave,))]
        if not vals:
            continue
        linhas.append((rot, len(vals), sum(1 for v in vals if v == 0), int(statistics.median(vals)), max(vals), milhar(sum(vals))))
    L.append(_tabela(["Grupo", "Táxons consultados", "Sem nenhuma molécula na fonte", "Mediana por táxon", "Máximo", "Total atribuído pelas fontes"], linhas) + "\n")
    atribuido = q("SELECT COALESCE(SUM(compostos_fonte), 0) FROM taxon WHERE compostos_fonte IS NOT NULL")
    L.append(f"As fontes atribuem {milhar(atribuido)} pares táxon–composto aos táxons consultados; {milhar(c['pares_taxon_molecula'])} estão a público. "
             "A diferença são registros retidos (seção anterior). Não há teto de moléculas por táxon.\n")
    L.append("Táxons com mais moléculas a público:\n")
    no_publico = sorted(((ctx.compostos_do_taxon.get(t["id"], {}).get("total", 0), t) for t in con.execute(
        "SELECT id, nome, grupo, compostos_fonte, toxinas_fonte FROM taxon WHERE no_recorte=1")), key=lambda par: (-par[0], par[1]["nome"]))[:12]
    L.append(_tabela(["Táxon", "Grupo", "Compostos a público", "Atribuídos pelas fontes"], [
        (f"*{t['nome']}*", GRUPOS[t["grupo"]], milhar(n), milhar(t["compostos_fonte"]) if t["compostos_fonte"] is not None else "—")
        for n, t in no_publico]) + "\n")

    # moléculas
    L.append("## Moléculas\n")
    L.append(_tabela(["Item", "Quantidade"], [
        ("Moléculas no banco", milhar(q("SELECT COUNT(*) FROM molecula"))),
        ("Pequenas moléculas", milhar(q("SELECT COUNT(*) FROM molecula WHERE tipo='pequena_molecula'"))),
        ("Peptídeos e proteínas (toxinas)", milhar(q("SELECT COUNT(*) FROM molecula WHERE tipo<>'pequena_molecula'"))),
        ("Com as duas massas calculadas da estrutura (monoisotópica e média)", milhar(q("SELECT COUNT(*) FROM molecula WHERE massa_monoisotopica IS NOT NULL AND massa_media IS NOT NULL"))),
        ("Com estereocentro indefinido na estrutura", milhar(q("SELECT COUNT(*) FROM molecula WHERE IFNULL(estereocentros_indefinidos, 0) > 0"))),
        ("Com registro no PubChem", milhar(q("SELECT COUNT(*) FROM molecula WHERE pubchem_cid IS NOT NULL"))),
        ("Com registro no ChEMBL", milhar(q("SELECT COUNT(*) FROM molecula WHERE chembl_id IS NOT NULL"))),
        ("Públicas com medida de bioatividade (par molécula–alvo)", milhar(len(ctx.n_ativ))),
        ("Públicas que são fármaco aprovado com indicação registrada", milhar(len(ctx.clinico))),
        ("Estrutura 2D desenhada", milhar(q("SELECT COUNT(*) FROM molecula WHERE desenho IS NOT NULL"))),
        ("Nome diverge entre a fonte e o PubChem (identidade fixada pelo InChIKey)", milhar(q("SELECT COUNT(*) FROM molecula WHERE nome_divergente=1"))),
    ]) + "\n")
    aprov = sorted((ctx.mol[mid]["nome"], ctx.mol[mid]["chembl_id"]) for mid in ctx.clinico)
    if aprov:
        L.append("Moléculas públicas que são fármaco aprovado (a aprovação é do fármaco isolado, **não** do organismo):\n")
        L.append(", ".join(f"{nome} ({chembl})" for nome, chembl in aprov) + ".\n")

    # imagens
    L.append("## Imagens\n")
    com = q("SELECT COUNT(DISTINCT taxon_id) FROM midia WHERE estado='ativo' AND arquivo IS NOT NULL")
    L.append(f"{milhar(com)} táxons têm ao menos uma fotografia com licença CC0 ou CC BY e autor identificado; {milhar(q('SELECT COUNT(*) FROM taxon WHERE no_recorte=1') - com)} "
             "táxons do recorte não têm e mostram isso na tela (ausência declarada). ")
    lic = con.execute("SELECT licenca, COUNT(*) FROM midia WHERE estado='ativo' AND arquivo IS NOT NULL GROUP BY 1").fetchall()
    L.append("Licenças: " + (", ".join(f"{r[0]}: {r[1]}" for r in lic) or "nenhuma imagem")
             + f". Autores distintos: {milhar(q('SELECT COUNT(DISTINCT autor) FROM midia WHERE estado=? AND arquivo IS NOT NULL', 'ativo'))}.\n")

    # prontidão
    L.append("## Prontidão da evidência\n")
    L.append("O índice mede a completude do registro para reutilização, em sete dimensões. **Não é nota de eficácia.**\n")
    linhas = [(TIPOS[t], milhar(n), f"{m:.2f}".replace(".", ","), f"{lo:.2f}".replace(".", ","), f"{hi:.2f}".replace(".", ",")) for t, n, m, lo, hi in con.execute(
        "SELECT a.tipo, COUNT(*), AVG(p.indice), MIN(p.indice), MAX(p.indice) FROM prontidao p JOIN afirmacao a ON a.id=p.afirmacao_id GROUP BY a.tipo")]
    L.append(_tabela(["Tipo", "Afirmações", "Índice médio", "Mínimo", "Máximo"], linhas) + "\n")
    linhas = []
    for dim in config.DIMENSOES:
        cont = {e: q(f"SELECT COUNT(*) FROM prontidao WHERE {dim}=?", e) for e in config.ESTADOS_DIMENSAO}
        linhas.append((dim.replace("_", " "), *(milhar(cont[e]) for e in config.ESTADOS_DIMENSAO)))
    L.append(_tabela(["Dimensão", *[e.replace("_", " ") for e in config.ESTADOS_DIMENSAO]], linhas) + "\n")

    # fontes
    L.append("## Fontes e datas de consulta\n")
    L.append(_tabela(["Fonte", "Licença", "Consultas", "Primeira", "Última", "Versão"], [
        (f["nome"], f["licenca"], milhar(f["n"]), (f["a"] or "")[:10] or "—", (f["b"] or "")[:10] or "—", f["v"] or "—")
        for f in con.execute("SELECT f.nome, f.licenca, COUNT(c.id) n, MIN(c.consultado_em) a, MAX(c.consultado_em) b, MAX(c.versao_fonte) v "
                             "FROM fonte f LEFT JOIN consulta c ON c.fonte_id=f.id GROUP BY f.id ORDER BY n DESC")]) + "\n")

    # exclusões e rejeições
    rej = [json.loads(r["detalhe"]) for r in con.execute("SELECT detalhe FROM evento_proveniencia WHERE entidade='semente_rejeitada'")]
    L.append("## Nomes da semente que não entraram\n")
    L.append(_tabela(["Nome", "Motivo"], [(r["nome"], r["motivo"]) for r in rej]) + "\n" if rej else "Nenhum.\n")

    # etapas
    L.append("## Etapas da construção\n")
    from .construir import ETAPAS
    etapas = {e["nome"]: e for e in con.execute("SELECT nome, concluida_em FROM etapa")}
    restantes = [k for k in sorted(etapas) if k not in ETAPAS]
    L.append(_tabela(["Etapa", "Concluída em (UTC)"], [(n, (etapas[n]["concluida_em"] or "não concluída")[:19].replace("T", " ")) for n in (*ETAPAS, *restantes) if n in etapas]) + "\n")
    return "\n".join(L)


def gravar_markdown(con, caminho):
    Path(caminho).parent.mkdir(parents=True, exist_ok=True)
    Path(caminho).write_text(gerar_markdown(con), encoding="utf-8")
