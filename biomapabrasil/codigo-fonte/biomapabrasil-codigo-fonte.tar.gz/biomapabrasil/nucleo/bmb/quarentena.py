# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Regras de retenção: por que um registro não vai a público, dito de forma reprodutível.

Cada regra tem um código estável, um escopo e um modelo de motivo. As etapas da construção declaram quais regras
cada afirmação dispara (`afirmacao_regra`); o estado (`quarentena` ou de volta a `candidato`) é derivado disso por
`aplicar_estados`, sempre do mesmo jeito. Nada é apagado: o registro retido continua no banco, com a regra, o motivo
e o evento de proveniência. Decisões de curador nunca são desfeitas por regra.

Os grupos seguem as correções da auditoria externa de 2026-11-15:
  identidade_taxonomica · linhagens · referencias · procedencia · nao_constituinte · bioatividade · evidencia · fonte
"""
from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import dataclass

from .util import agora


@dataclass(frozen=True)
class Regra:
    codigo: str
    escopo: str
    grupo: str
    titulo: str
    modelo: str


# A ordem é a precedência: quando uma afirmação dispara várias regras, vale o motivo da primeira desta lista.
_REGRAS = (
    Regra("REG-344", "afirmacao", "regulatorio",
          "Substância sob controle especial",
          "Portaria SVS/MS nº 344/1998 — {lista} ({substancia}): substância sujeita a proibição ou controle especial "
          "estrito no Brasil; retida em quarentena regulatória rastreável."),
    Regra("REF-RETRATADA", "afirmacao", "referencias",
          "Todas as referências foram retratadas",
          "Todas as referências de sustentação foram retratadas: {referencias}"),
    Regra("TAX-ESPECIE-DIVERGENTE", "afirmacao", "identidade_taxonomica",
          "A fonte atribui o registro a outra espécie aceita",
          "A fonte atribui este registro a {organismo_fonte}, que o backbone do GBIF resolve como {especie_aceita}, "
          "espécie aceita diferente de {taxon}. O vínculo vinha de casamento por nome sem autoria."),
    Regra("TAX-HOMONIMO", "afirmacao", "identidade_taxonomica",
          "Homônimo não resolvido",
          "O nome {organismo_fonte} é usado por mais de um táxon; o identificador da fonte aponta para {uso_fonte}, "
          "com autoria diferente da de {taxon} {autoria_taxon}. Sem leitura do artigo não se sabe a qual se refere."),
    Regra("TAX-NAO-RESOLVIDO", "afirmacao", "identidade_taxonomica",
          "Organismo da fonte não resolvido no backbone",
          "A fonte atribui este registro a {organismo_fonte}, nome sem identificador taxonômico e sem correspondência "
          "exata e única no backbone do GBIF. O vínculo com {taxon} vinha de um sinônimo sem autoria."),
    Regra("NAT-SEMISSINTETICO", "afirmacao", "nao_constituinte",
          "Derivado semissintético ou produto de biotransformação",
          "O NuBBE-DB registra este composto como {tipo_isolamento}: derivado preparado a partir de um constituinte "
          "de {taxon}, não um composto isolado do organismo."),
    Regra("NAT-CONTROLE", "afirmacao", "nao_constituinte",
          "Fármaco ou reagente usado como controle de ensaio",
          "{substancia} é {classe_restricao}; consta em {taxon} por herança de um registro em que figura como "
          "controle ou padrão de ensaio, não como constituinte."),
    Regra("NAT-ELEMENTO", "afirmacao", "nao_constituinte",
          "Elemento químico registrado como molécula",
          "{substancia} é um elemento químico (teor mineral), não um metabólito do organismo."),
    Regra("NAT-CONTAMINANTE", "afirmacao", "nao_constituinte",
          "Provável contaminante de laboratório",
          "{substancia} é um plastificante frequente como contaminante analítico; a ocorrência em {taxon} exige "
          "confirmação antes de ir a público."),
    Regra("MOL-SEM-ESTRUTURA", "afirmacao", "nao_constituinte",
          "Molécula sem estrutura conferível",
          "A estrutura de {substancia} não pôde ser conferida (SMILES e InChIKey da fonte divergem)."),
    Regra("LIT-OUTRA-ESPECIE", "afirmacao", "identidade_taxonomica",
          "O artigo citado trata de outra espécie",
          "O título ou resumo do(s) artigo(s) citado(s) nomeia {especie_no_artigo} e não {taxon} nem seus sinônimos."),
    Regra("PROV-FORA-DA-AMAZONIA", "afirmacao", "procedencia",
          "Coleta fora da Amazônia declarada no artigo",
          "O texto do artigo declara que o material de {taxon} foi coletado em {local} — fora da Amazônia."),
    Regra("LIT-SEM-MENCAO", "afirmacao", "evidencia",
          "O texto lido não menciona organismo nem composto",
          "O {nivel_texto} do(s) artigo(s) citado(s) foi lido e não menciona {taxon}, o gênero, seus sinônimos nem "
          "o composto."),
    Regra("REF-INEXISTENTE", "afirmacao", "referencias",
          "Referência não localizada",
          "Referência bibliográfica não localizada no Crossref/PubMed após consulta verificada: {referencias}"),
    Regra("REF-EM-QUARENTENA", "afirmacao", "referencias",
          "Todas as referências estão retidas",
          "Todas as referências desta afirmação estão retidas: {referencias}"),
    Regra("BIO-ALVO-PROVISORIO", "afirmacao", "bioatividade",
          "Alvo provisório no ChEMBL",
          "Alvo provisório/não específico no ChEMBL ({alvo}): medida fenotípica ou não atribuída a alvo molecular "
          "identificado."),
    Regra("BIO-SEM-MEDIDA-VALIDA", "afirmacao", "bioatividade",
          "Nenhuma medida válida",
          "Nenhuma das {n} medida(s) do ChEMBL para este par molécula–alvo passou nos critérios: {motivos}."),
    Regra("BIO-EXTREMO-NAO-REPLICADO", "afirmacao", "bioatividade",
          "Potência extrema sem replicação",
          "Uma única medida ({medida}) indica potência abaixo de 100 pM sem replicação independente; valores assim "
          "costumam vir de erro de unidade na origem."),
    Regra("BIO-DISCORDANTE", "afirmacao", "bioatividade",
          "Medidas discordantes",
          "As {n} medidas disponíveis divergem em {dispersao} ordens de grandeza; não há base para um valor central."),
    Regra("BIO-FORA-DA-SELECAO", "afirmacao", "bioatividade",
          "Par molécula–alvo fora da seleção por peso de evidência",
          "Medida válida, mas fora dos {limite} pares molécula–alvo de maior peso de evidência de {substancia} "
          "(alvo molecular individual primeiro, depois número de publicações). A seleção anterior era pela potência máxima."),
    Regra("MOL-SEM-ORGANISMO", "afirmacao", "escopo",
          "Molécula sem registro publicado em organismo",
          "{substancia} não tem registro publicado em organismo do banco nem linhagem publicada; a medida ou o efeito "
          "clínico, sozinho, não liga a molécula a espécie nenhuma."),
    Regra("FONTE-NAO-SUSTENTA", "afirmacao", "fonte",
          "O registro deixou de constar na fonte",
          "A reextração de {fonte} não reproduz este registro para {taxon}."),
    Regra("LEGADO-SEM-CODIGO", "afirmacao", "fonte",
          "Retenção anterior à migração 008",
          "{motivo_legado}"),
    # ── fora do escopo `afirmacao`
    Regra("REF-DOI-INEXISTENTE", "referencia", "referencias",
          "DOI inexistente",
          "O DOI {doi} não está registrado (Crossref: não encontrado; doi.org: {resposta_handle})."),
    Regra("REF-DOI-PMID-DIVERGENTES", "referencia", "referencias",
          "DOI e PMID são obras diferentes",
          "O PMID {pmid} é «{titulo_pmid}» (DOI {doi_do_pmid}); o DOI armazenado {doi} é {obra_do_doi}."),
    Regra("REF-RETRATACAO", "referencia", "referencias",
          "Obra retratada",
          "A obra foi retratada ({origem_do_aviso})."),
    Regra("LIN-CITACAO-INVALIDA", "relacao_molecula", "linhagens",
          "Citação não corresponde a obra sobre a linhagem",
          "Os identificadores citados não levam a uma obra sobre a relação {origem} → {destino}: {detalhe}."),
    Regra("LIN-NAO-CONFIRMADA", "relacao_molecula", "linhagens",
          "Relação sem trecho confirmatório",
          "Não há trecho de texto publicado, lido nesta construção, que confirme a relação {origem} → {destino}. "
          "Aguarda leitura e assinatura de curador."),
    Regra("LIN-CONTRADITA", "relacao_molecula", "linhagens",
          "Relação contradita pela literatura",
          "A literatura de desenho do fármaco indica outra origem para {destino}: {detalhe}."),
)

REGRAS: dict[str, Regra] = {r.codigo: r for r in _REGRAS}
PRECEDENCIA: dict[str, int] = {r.codigo: i for i, r in enumerate(_REGRAS)}

# Regra derivada do estado das outras afirmações: é o próprio `aplicar_estados` que a declara e retira.
REGRA_DERIVADA = "MOL-SEM-ORGANISMO"

# Regras que valem mesmo para afirmação já verificada por curador: a lei proíbe, a fonte deixou de existir, ou a
# própria leitura (do curador ou do texto do artigo) situa a coleta fora da Amazônia.
REGRAS_SOBRE_VERIFICADO = {"REG-344", "REF-RETRATADA", "REF-INEXISTENTE", "REF-EM-QUARENTENA", "PROV-FORA-DA-AMAZONIA"}

# Motivos em texto livre gravados antes da migração 008, reconhecidos pelo começo.
_LEGADO = (
    ("Portaria SVS/MS nº 344", "REG-344"),
    ("Todas as referências de sustentação foram retratadas", "REF-RETRATADA"),
    ("Referência bibliográfica não localizada", "REF-INEXISTENTE"),
    ("Alvo provisório/não específico no ChEMBL", "BIO-ALVO-PROVISORIO"),
)


class _Padrao(dict):
    def __missing__(self, chave):
        return "—"


def motivo(codigo: str, **dados) -> str:
    """Texto do motivo a partir do modelo fixo da regra; campo ausente vira travessão, nunca erro."""
    return REGRAS[codigo].modelo.format_map(_Padrao({k: ("—" if v in (None, "") else v) for k, v in dados.items()}))


def registrar_catalogo(con) -> None:
    con.executemany(
        "INSERT INTO regra_quarentena (codigo, escopo, grupo, titulo, modelo) VALUES (?,?,?,?,?) "
        "ON CONFLICT(codigo) DO UPDATE SET escopo=excluded.escopo, grupo=excluded.grupo, titulo=excluded.titulo, "
        "modelo=excluded.modelo", [(r.codigo, r.escopo, r.grupo, r.titulo, r.modelo) for r in _REGRAS])


def adotar_legado(con) -> int:
    """Dá código às retenções gravadas em texto livre antes da migração 008 (o texto é preservado)."""
    n = 0
    for a in con.execute("SELECT id, motivo_quarentena FROM afirmacao WHERE estado='quarentena' "
                         "AND regra_quarentena IS NULL AND motivo_quarentena IS NOT NULL").fetchall():
        codigo = next((c for prefixo, c in _LEGADO if a["motivo_quarentena"].startswith(prefixo)), "LEGADO-SEM-CODIGO")
        con.execute("UPDATE afirmacao SET regra_quarentena=?, quarentena_origem=COALESCE(quarentena_origem,'regra') "
                    "WHERE id=?", (codigo, a["id"]))
        con.execute("INSERT OR IGNORE INTO afirmacao_regra (afirmacao_id, codigo, detalhe, detectada_em) VALUES (?,?,?,?)",
                    (a["id"], codigo, json.dumps({"motivo_legado": a["motivo_quarentena"]}, ensure_ascii=False), agora()))
        n += 1
    return n


def declarar(con, codigos_geridos, disparos: dict[int, dict[str, dict]], entre=None) -> dict:
    """Substitui, para os códigos geridos por quem chama, o conjunto de afirmações que os disparam.

    `disparos`: {afirmacao_id: {codigo: dados_do_modelo}}. Códigos fora de `codigos_geridos` não são tocados.
    `entre`: quando a chamada só examinou parte das afirmações (construção parcial), o conjunto de ids examinados;
    regras de afirmações fora dele ficam como estavam. Devolve contagens por código. Chamar `aplicar_estados` depois.
    """
    geridos = sorted(set(codigos_geridos))
    for c in geridos:
        if c not in REGRAS or REGRAS[c].escopo != "afirmacao":
            raise ValueError(f"regra desconhecida ou fora do escopo de afirmação: {c}")
    marcas = ",".join("?" * len(geridos))
    antes = {(r["afirmacao_id"], r["codigo"]) for r in con.execute(
        f"SELECT afirmacao_id, codigo FROM afirmacao_regra WHERE codigo IN ({marcas})", geridos)}
    if entre is not None:
        entre = set(entre)
        antes = {x for x in antes if x[0] in entre}
    agora_ = agora()
    depois = set()
    for aid, por_codigo in disparos.items():
        for codigo, dados in por_codigo.items():
            if codigo not in geridos:
                raise ValueError(f"{codigo} não está entre os códigos geridos por esta chamada")
            depois.add((aid, codigo))
            con.execute(
                "INSERT INTO afirmacao_regra (afirmacao_id, codigo, detalhe, detectada_em) VALUES (?,?,?,?) "
                "ON CONFLICT(afirmacao_id, codigo) DO UPDATE SET detalhe=excluded.detalhe",
                (aid, codigo, json.dumps(dados or {}, ensure_ascii=False, sort_keys=True), agora_))
    for aid, codigo in antes - depois:
        con.execute("DELETE FROM afirmacao_regra WHERE afirmacao_id=? AND codigo=?", (aid, codigo))
    cont = defaultdict(int)
    for _, codigo in depois:
        cont[codigo] += 1
    return {"declaradas": dict(cont), "retiradas": len(antes - depois)}


def _evento_padrao(con, entidade, entidade_id, atividade, detalhe):
    con.execute("INSERT INTO evento_proveniencia (entidade, entidade_id, atividade, agente, em, detalhe) VALUES (?,?,?,?,?,?)",
                (entidade, entidade_id, atividade, "software:bmb", agora(), detalhe))


def aplicar_estados(con, registrar_evento=_evento_padrao) -> dict:
    """Deriva `estado`, `regra_quarentena` e `motivo_quarentena` de `afirmacao_regra`. Determinístico e idempotente.

    * afirmação com regra(s): vai (ou fica) em quarentena com a regra de maior precedência;
    * afirmação em quarentena por regra e sem regra nenhuma: volta a `candidato`;
    * quarentena ou rejeição decidida por curador não é alterada; `verificado` só cede às regras de
      `REGRAS_SOBRE_VERIFICADO`.

    Depois da primeira passada declara a regra derivada (medida ou efeito clínico de molécula que ficou sem registro
    publicado em organismo) e repete a derivação. A regra derivada só atinge afirmações sem táxon, que não entram na
    definição de molécula pública: uma repetição basta.
    """
    resultado = _derivar_estados(con, registrar_evento)
    if _declarar_molecula_sem_organismo(con):
        segunda = _derivar_estados(con, registrar_evento)
        resultado = {"retidas_agora": resultado["retidas_agora"] + segunda["retidas_agora"],
                     "motivo_atualizado": resultado["motivo_atualizado"] + segunda["motivo_atualizado"],
                     "liberadas": resultado["liberadas"] + segunda["liberadas"],
                     "em_quarentena_por_regra": segunda["em_quarentena_por_regra"]}
    return resultado


def _declarar_molecula_sem_organismo(con) -> int:
    """Atualiza quem dispara a regra derivada. Devolve quantas declarações mudaram (0 = nada a refazer)."""
    from .exportar.pacotes import SQL_MOLECULAS_PUBLICAS      # definição única de molécula pública
    devem = {r["id"]: r["nome"] for r in con.execute(
        f"SELECT a.id, m.nome FROM afirmacao a JOIN molecula m ON m.id=a.molecula_id WHERE a.taxon_id IS NULL "
        f"AND a.tipo IN ('atividade_biologica','efeito_clinico_documentado') "
        f"AND a.molecula_id NOT IN ({SQL_MOLECULAS_PUBLICAS})")}
    tem = {r[0] for r in con.execute("SELECT afirmacao_id FROM afirmacao_regra WHERE codigo=?", (REGRA_DERIVADA,))}
    agora_ = agora()
    for aid in sorted(set(devem) - tem):
        con.execute("INSERT INTO afirmacao_regra (afirmacao_id, codigo, detalhe, detectada_em) VALUES (?,?,?,?)",
                    (aid, REGRA_DERIVADA, json.dumps({"substancia": devem[aid]}, ensure_ascii=False, sort_keys=True), agora_))
    for aid in sorted(tem - set(devem)):
        con.execute("DELETE FROM afirmacao_regra WHERE afirmacao_id=? AND codigo=?", (aid, REGRA_DERIVADA))
    return len(set(devem) ^ tem)


def _derivar_estados(con, registrar_evento) -> dict:
    por_af = defaultdict(list)
    for r in con.execute("SELECT afirmacao_id, codigo, detalhe FROM afirmacao_regra"):
        por_af[r["afirmacao_id"]].append((r["codigo"], r["detalhe"]))
    agora_ = agora()
    n_ret = n_mud = n_lib = 0
    por_regra = defaultdict(int)
    atuais = {r["id"]: r for r in con.execute(
        "SELECT id, estado, regra_quarentena, motivo_quarentena, quarentena_origem FROM afirmacao "
        "WHERE estado='quarentena' OR id IN (SELECT afirmacao_id FROM afirmacao_regra)")}
    for aid, regras in por_af.items():
        a = atuais.get(aid)
        if a is None or a["estado"] == "rejeitado":
            continue
        if a["estado"] == "quarentena" and a["quarentena_origem"] == "curador":
            continue
        regras = [x for x in regras if x[0] in REGRAS]
        if a["estado"] == "verificado":
            regras = [x for x in regras if x[0] in REGRAS_SOBRE_VERIFICADO]
        if not regras:
            continue
        codigo, detalhe = min(regras, key=lambda x: PRECEDENCIA[x[0]])
        dados = json.loads(detalhe) if detalhe else {}
        texto_motivo = dados.get("motivo_legado") or motivo(codigo, **dados)
        por_regra[codigo] += 1
        if a["estado"] == "quarentena" and a["regra_quarentena"] == codigo and a["motivo_quarentena"] == texto_motivo:
            continue
        era_quarentena = a["estado"] == "quarentena"
        con.execute("UPDATE afirmacao SET estado='quarentena', regra_quarentena=?, motivo_quarentena=?, "
                    "quarentena_origem='regra', atualizado_em=? WHERE id=?", (codigo, texto_motivo, agora_, aid))
        if registrar_evento:
            registrar_evento(con, "afirmacao", aid, "quarentena", f"{codigo}: {texto_motivo}")
        n_mud += 1 if era_quarentena else 0
        n_ret += 0 if era_quarentena else 1
    for aid, a in atuais.items():
        if a["estado"] == "quarentena" and a["quarentena_origem"] == "regra" and aid not in por_af:
            con.execute("UPDATE afirmacao SET estado='candidato', regra_quarentena=NULL, motivo_quarentena=NULL, "
                        "quarentena_origem=NULL, atualizado_em=? WHERE id=?", (agora_, aid))
            if registrar_evento:
                registrar_evento(con, "afirmacao", aid, "liberacao",
                                 f"Regra {a['regra_quarentena'] or 'anterior'} deixou de se aplicar; volta a candidato.")
            n_lib += 1
    return {"retidas_agora": n_ret, "motivo_atualizado": n_mud, "liberadas": n_lib, "em_quarentena_por_regra": dict(por_regra)}


def reter_referencia(con, referencia_id: int, codigo: str, registrar_evento=None, **dados) -> bool:
    if REGRAS[codigo].escopo != "referencia":
        raise ValueError(f"{codigo} não é regra de referência")
    texto_motivo = motivo(codigo, **dados)
    atual = con.execute("SELECT estado, regra_quarentena, motivo_quarentena FROM referencia WHERE id=?", (referencia_id,)).fetchone()
    if atual and atual["estado"] == "quarentena" and atual["regra_quarentena"] == codigo and atual["motivo_quarentena"] == texto_motivo:
        return False
    con.execute("UPDATE referencia SET estado='quarentena', regra_quarentena=?, motivo_quarentena=? WHERE id=?",
                (codigo, texto_motivo, referencia_id))
    if registrar_evento:
        registrar_evento(con, "referencia", referencia_id, "quarentena", f"{codigo}: {texto_motivo}")
    return True


def liberar_referencia(con, referencia_id: int, registrar_evento=None) -> bool:
    atual = con.execute("SELECT estado FROM referencia WHERE id=?", (referencia_id,)).fetchone()
    if not atual or atual["estado"] != "quarentena":
        return False
    con.execute("UPDATE referencia SET estado='ativa', regra_quarentena=NULL, motivo_quarentena=NULL WHERE id=?", (referencia_id,))
    if registrar_evento:
        registrar_evento(con, "referencia", referencia_id, "liberacao", "Condição de retenção deixou de valer.")
    return True


def resumo(con) -> dict:
    """Contagens para o relatório interno. Não vai para os pacotes públicos."""
    return {
        "afirmacoes_por_regra": {r["regra_quarentena"] or "(sem código)": r["n"] for r in con.execute(
            "SELECT regra_quarentena, COUNT(*) n FROM afirmacao WHERE estado='quarentena' GROUP BY 1 ORDER BY 2 DESC")},
        "afirmacoes_por_grupo": {r["grupo"]: r["n"] for r in con.execute(
            "SELECT q.grupo, COUNT(*) n FROM afirmacao a JOIN regra_quarentena q ON q.codigo=a.regra_quarentena "
            "WHERE a.estado='quarentena' GROUP BY 1 ORDER BY 2 DESC")},
        "referencias_por_regra": {r["regra_quarentena"]: r["n"] for r in con.execute(
            "SELECT regra_quarentena, COUNT(*) n FROM referencia WHERE estado='quarentena' GROUP BY 1")},
        "linhagens_por_estado": {f"{r['estado']}|{r['regra_quarentena'] or ''}": r["n"] for r in con.execute(
            "SELECT estado, regra_quarentena, COUNT(*) n FROM relacao_molecula GROUP BY 1,2")},
    }
