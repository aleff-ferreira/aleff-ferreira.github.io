# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Fragmentos de dados científicos sob demanda (`dados/viz/*.json`) para os observatórios visuais v2.

Nenhum destes arquivos entra no orçamento da primeira tela (`orcamento.py`); são baixados apenas
quando a pessoa navega para `#/galaxia`, `#/fluxo`, `#/floresta` ou `#/filoquimica`.
Cada pacote traz proveniência explícita (`consultas`) e alternativa tabular reproduzível.

Só registros públicos, pela seleção de `pacotes.Contexto`: afirmações em estado e acesso públicos, moléculas com
registro público e linhagens públicas. Medida de bioatividade é o valor central de um par molécula–alvo.
"""
from collections import Counter, defaultdict
import json
import math

from .. import config, quimica_espaco, texto
from . import pacotes

SEM_MEDIDA = "Sem medida de bioatividade neste banco"

ORDEM_ESTRATOS = [
    ("emergente", "Emergente", "Árvores que ultrapassam o dossel contínuo."),
    ("dossel", "Dossel", "Árvores da copa contínua da floresta."),
    ("sub_bosque", "Sub-bosque", "Arvoretas, arbustos e palmeiras abaixo do dossel."),
    ("liana_epifita", "Lianas, cipós e epífitas", "Trepadeiras lenhosas, hemiepífitas e epífitas."),
    ("solo_serrapilheira", "Solo, serrapilheira e madeira morta", "Ervas terrestres, fungos e fauna de serrapilheira."),
    ("aquatico_ripario", "Igapó, várzea e ambiente aquático", "Macrófitas, árvores de áreas periodicamente inundadas e fauna aquática."),
    ("nao_informado", "Estrato não informado na fonte", "Espécies sem perfil vertical nas bases consultadas. O estrato não é inferido."),
]



# Nome exibido para um nível da classificação que a fonte não informa.
_NIVEL_SEM_NOME = {"reino": "(reino não atribuído)", "filo": "(filo não atribuído)", "classe": "(classe não atribuída)",
                   "ordem": "(ordem não atribuída)", "familia": "(família não atribuída)", "genero": "(gênero não atribuído)"}

def _escrever(caminho, obj):
    caminho.parent.mkdir(parents=True, exist_ok=True)
    dados = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    caminho.write_bytes(dados)
    return len(dados)


def _registrar_consulta(ctx, mapa_c, lista_c, cid):
    if not cid or cid not in ctx.consultas:
        return None
    if cid not in mapa_c:
        c = ctx.consultas[cid]
        f = ctx.fontes[c["fonte_id"]]
        mapa_c[cid] = len(lista_c)
        lista_c.append({
            "fonte": c["fonte_id"],
            "fonte_nome": f["nome"],
            "licenca": f["licenca"],
            "url": c["url"],
            "data": c["consultado_em"][:10],
            "versao": c["versao_fonte"],
        })
    return mapa_c[cid]


def _pchembl_estimado(tipo, relacao, valor, unidade):
    if valor is None or valor <= 0 or relacao not in ("=", "<", "<="):
        return None
    u = (unidade or "").strip()
    fator = {"M": 1.0, "mM": 1e-3, "uM": 1e-6, "µM": 1e-6, "nM": 1e-9, "pM": 1e-12}.get(u)
    if not fator:
        return None
    molar = valor * fator
    if molar <= 0 or molar >= 1:
        return None
    if (tipo or "").upper() in ("IC50", "KI", "KD", "EC50", "AC50", "GI50", "MIC"):
        return round(-math.log10(molar), 2)
    return None


def _maior_pchembl_por_molecula(con, ctx):
    """Maior pChEMBL entre os pares molécula–alvo públicos de cada molécula pública. O valor de cada par é o valor
    central (mediana) das medidas válidas, não a medida mais potente."""
    maior = {}
    for r in con.execute(
        f"SELECT a.molecula_id, a.medida_tipo, a.medida_relacao, a.medida_valor, a.medida_unidade "
        f"FROM afirmacao a WHERE a.tipo='atividade_biologica' AND {pacotes.sql_publica('a')}"
    ):
        if r["molecula_id"] not in ctx.mols_publicas:
            continue
        p = _pchembl_estimado(r["medida_tipo"], r["medida_relacao"], r["medida_valor"], r["medida_unidade"])
        if p is not None and p > maior.get(r["molecula_id"], -1):
            maior[r["molecula_id"]] = p
    return maior


def exportar_galaxia(con, ctx, destino_viz):
    """Espaço químico 2D (Morgan ECFP4 + UMAP determinístico) + árvore geradora mínima (TMAP) + Murcko."""
    mapa_c, consultas = {}, []

    # Maior pChEMBL entre os pares molécula–alvo de cada molécula (cada par entra pelo valor central das suas medidas)
    max_pch = _maior_pchembl_por_molecula(con, ctx)

    fontes_mol = defaultdict(set)
    cids_fontes = set()
    for r in con.execute(f"SELECT a.molecula_id, a.fonte_id, a.consulta_id FROM afirmacao a WHERE {pacotes.sql_publica('a')}"):
        if r["molecula_id"] not in ctx.mols_publicas:
            continue
        fontes_mol[r["molecula_id"]].add(r["fonte_id"])
        if r["consulta_id"]:
            cids_fontes.add(r["consulta_id"])
    for cid in sorted(cids_fontes)[:24]:
        _registrar_consulta(ctx, mapa_c, consultas, cid)

    for r in con.execute("SELECT id FROM consulta WHERE fonte_id='rdkit_local' ORDER BY id DESC LIMIT 2"):
        _registrar_consulta(ctx, mapa_c, consultas, r["id"])

    mols_validas = []
    cont_murcko = Counter()
    for mid in sorted(ctx.mol):
        m = ctx.mol[mid]
        if m["umap_x"] is None or m["umap_y"] is None:
            continue
        if mid not in ctx.mols_publicas:
            continue
        mols_validas.append(m)
        if m.get("murcko_smiles"):
            cont_murcko[m["murcko_smiles"]] += 1

    top_murcko = [s for s, n in sorted(cont_murcko.items(), key=lambda kv: (-kv[1], kv[0]))[:28] if n >= 2]
    idx_murcko = {s: i for i, s in enumerate(top_murcko)}
    scaffolds = [{"id": i, "smiles": s, "n": cont_murcko[s]} for i, s in enumerate(top_murcko)]

    colunas = [
        "id", "nome", "classe", "mw", "clogp", "tpsa", "fsp3", "qed", "npl",
        "max_pch", "fase", "pains", "scaf", "taxa", "x", "y", "estrutura", "fontes", "coleta_amazonica_declarada",
    ]
    linhas = []
    pos_por_id = {}
    cont_classes = Counter()
    dic_classes: list[str] = []
    idx_classe: dict[str, int] = {}
    dic_fontes: list[list[str]] = []
    idx_fontes: dict[tuple[str, ...], int] = {}
    escala_xy = 10000
    for m in mols_validas:
        mid = m["id"]
        pos_por_id[mid] = len(linhas)
        classe = m["classe_quimica"] or m["familia"] or "Sem classe atribuída"
        cont_classes[classe] += 1
        ic = idx_classe.get(classe)
        if ic is None:
            ic = len(dic_classes)
            dic_classes.append(classe)
            idx_classe[classe] = ic
        f_tup = tuple(sorted(fontes_mol.get(mid, ())))
        if_idx = idx_fontes.get(f_tup)
        if if_idx is None:
            if_idx = len(dic_fontes)
            dic_fontes.append(list(f_tup))
            idx_fontes[f_tup] = if_idx
        nome_curto = m["nome"] if len(m["nome"]) <= 48 else m["nome"][:47] + "…"
        fase = int(m["max_fase_clinica"]) if m["max_fase_clinica"] is not None else 0
        if mid in ctx.clinico:
            fase = max(fase, 4)
        qx = max(-32767, min(32767, int(round(float(m["umap_x"]) * escala_xy))))
        qy = max(-32767, min(32767, int(round(float(m["umap_y"]) * escala_xy))))
        des = m["desenho"]
        if isinstance(des, str) and des.startswith("estruturas_lotes/") and ".json#" in des:
            des = "#" + des[len("estruturas_lotes/"):].replace(".json#", "#")
        linhas.append([
            mid,
            nome_curto,
            ic,
            round(pacotes.massa_publica(m), 1) if pacotes.massa_publica(m) is not None else None,
            round(m["clogp"], 2) if m.get("clogp") is not None else None,
            round(m["tpsa"], 1) if m.get("tpsa") is not None else None,
            round(m["fsp3"], 2) if m.get("fsp3") is not None else None,
            round(m["qed"], 2) if m.get("qed") is not None else None,
            round(m["np_likeness"], 2) if m.get("np_likeness") is not None else None,
            max_pch.get(mid),
            fase,
            1 if m.get("alerta_pains") else 0,
            idx_murcko.get(m.get("murcko_smiles"), -1),
            ctx.n_taxa_da_mol.get(mid, 0),
            qx,
            qy,
            des,
            if_idx,
            1 if mid in ctx.mol_coleta_amazonica else 0,
        ])

    brutas = []
    arq_tmap = config.SAIDA_DIR / "tmap_arestas.json"
    if arq_tmap.exists():
        try:
            brutas = json.loads(arq_tmap.read_text(encoding="utf-8"))
        except Exception:
            brutas = []

    def _mapear_arestas(lista_brutas):
        vistas = set()
        saida = []
        for u, v, sim in lista_brutas:
            if u in pos_por_id and v in pos_por_id:
                ia, ib = pos_por_id[u], pos_por_id[v]
                if ia != ib:
                    par = (min(ia, ib), max(ia, ib))
                    if par not in vistas:
                        vistas.add(par)
                        saida.append([par[0], par[1], round(float(sim), 3)])
        saida.sort(key=lambda e: (e[0], e[1]))
        return saida

    arestas = _mapear_arestas(brutas) if brutas else []
    if not arestas and len(pos_por_id) >= 2:
        arestas = _mapear_arestas(quimica_espaco.calcular_arestas_tmap(con))

    classes_top = [{"nome": c, "n": n} for c, n in sorted(cont_classes.items(), key=lambda kv: (-kv[1], kv[0]))[:18]]
    return _escrever(destino_viz / "galaxia.json", {
        "esquema": 1,
        "quantizacao_xy": "int16",
        "escala_xy": escala_xy,
        "dicionario_classes": dic_classes,
        "dicionario_fontes": dic_fontes,
        "metodo": "Impressões digitais circulares Morgan ECFP4 (2048 bits, raio 2, similaridade de Tanimoto) projetadas em 2D com inicialização espectral laplaciana determinística (semente 20261111) + árvore geradora mínima (TMAP).",
        "aviso_epistemico": "Proximidade no espaço químico é similaridade topológica 2D (Tanimoto ECFP4) entre estruturas. Alvo farmacológico e efeito clínico são outros registros, com fonte própria.",
        "notas_das_colunas": {
            "mw": "massa monoisotópica (Da)",
            "max_pch": "maior pChEMBL entre os pares molécula–alvo da molécula; cada par entra pelo valor central (mediana) das suas medidas válidas no ChEMBL",
            "coleta_amazonica_declarada": "1 quando há afirmação pública com coleta na Amazônia declarada por curador ou pela base de origem",
        },
        "colunas": colunas,
        "linhas": linhas,
        "arestas": arestas,
        "scaffolds": scaffolds,
        "classes": classes_top,
        "consultas": consultas,
    })


def exportar_fluxo(con, ctx, destino_viz):
    """Grafo aluvial de 4 estágios (Bacia → Família → Classe Química → Via/Alvo/Fármaco) + linhagens bioinspiradas."""
    mapa_c, consultas = {}, []

    nomes_bacia = {r["id"]: r["nome"] for r in con.execute("SELECT id, nome FROM bacia_hidrografica")}
    # bacias por táxon
    bacias_t = defaultdict(list)
    for r in con.execute("SELECT taxon_id, bacia_id, n, consulta_id FROM ocorrencia_bacia WHERE n > 0 ORDER BY bacia_id"):
        bacias_t[r["taxon_id"]].append((r["bacia_id"], r["n"]))
        _registrar_consulta(ctx, mapa_c, consultas, r["consulta_id"])

    # Se ocorrencia_bacia estiver vazia (ex.: teste unitário mínimo), usa Amazônia Legal agregada por UF
    usar_uf_fallback = len(bacias_t) == 0
    if usar_uf_fallback:
        for r in con.execute("SELECT taxon_id, uf_sigla, n, consulta_id FROM ocorrencia_uf WHERE n > 0 ORDER BY uf_sigla"):
            if r["uf_sigla"] in config.UF_AMAZONIA_LEGAL:
                bacias_t[r["taxon_id"]].append((f"uf_{r['uf_sigla']}", r["n"]))
                _registrar_consulta(ctx, mapa_c, consultas, r["consulta_id"])
                nomes_bacia[f"uf_{r['uf_sigla']}"] = f"UF {r['uf_sigla']}"

    # Vias Reactome dos alvos de medida pública, e só deles: via e consulta de alvo sem medida publicada não entram,
    # de modo que o arquivo é o mesmo a partir do banco de trabalho ou da cópia só com registros publicados.
    # A consulta citada é a do vínculo: a busca feita para o próprio alvo (`Contexto.vias_por_alvo`).
    vias_por_alvo = defaultdict(list)
    for aid in sorted(ctx.alvos_publicos):
        for v in ctx.vias_por_alvo.get(aid, ()):
            vias_por_alvo[aid].append((v["reactome_id"], v["nome"]))
            _registrar_consulta(ctx, mapa_c, consultas, v["consulta_id"])

    # Moléculas com medida de bioatividade, fármaco aprovado ou linhagem bioinspirada. Só proteína única é chamada
    # de alvo; as demais naturezas (linhagem celular, organismo inteiro, tecido…) aparecem com o próprio nome.
    destinos_mol = defaultdict(set)
    for r in con.execute(
        f"SELECT a.molecula_id, a.alvo_id, a.consulta_id, al.nome AS alvo_nome, al.organismo, al.natureza "
        f"FROM afirmacao a JOIN alvo al ON al.id=a.alvo_id "
        f"WHERE a.tipo='atividade_biologica' AND {pacotes.sql_publica('a')}"
    ):
        if r["molecula_id"] not in ctx.mols_publicas:
            continue
        _registrar_consulta(ctx, mapa_c, consultas, r["consulta_id"])
        vias = vias_por_alvo.get(r["alvo_id"], [])
        if vias:
            for vid, vnome in vias[:2]:
                destinos_mol[r["molecula_id"]].add(f"Via: {vnome[:42]}")
        elif r["alvo_nome"]:
            rotulo = texto.ROTULO_NATUREZA_ALVO.get(r["natureza"] or "indeterminado") or "alvo"
            destinos_mol[r["molecula_id"]].add(f"{rotulo[0].upper()}{rotulo[1:]}: {r['alvo_nome'][:38]}")

    linhagens = []
    for r in ctx.linhagens:
        mo = ctx.mol[r["origem_id"]]
        md = ctx.mol[r["destino_id"]]
        _registrar_consulta(ctx, mapa_c, consultas, r["consulta_id"])
        destinos_mol[mo["id"]].add(f"Fármaco: {md['nome'][:34]}")
        especies_origem = [
            {"gbif": t["gbif_key"], "nome": t["nome"], "grupo": t["grupo"]}
            for t in con.execute(
                f"SELECT DISTINCT t.gbif_key, t.nome, t.grupo FROM afirmacao a JOIN taxon t ON t.id=a.taxon_id "
                f"WHERE a.molecula_id=? AND {pacotes.sql_publica('a')} ORDER BY t.nome",
                (mo["id"],),
            )
        ]
        ref_info = None
        rid = ctx.ref_publica(r["referencia_id"])
        if rid is not None:
            rf = ctx.refs[rid]
            ref_info = {"doi": rf["doi"], "pmid": rf["pmid"], "titulo": rf["titulo"], "ano": rf["ano"]}
        linhagens.append({
            "id": r["id"],
            "tipo": r["tipo"],
            "origem": {"id": mo["id"], "nome": mo["nome"], "tipo": mo["tipo"], "formula": mo["formula"],
                       "estrutura": mo["desenho"], "uniprot": mo["uniprot_acc"]},
            "destino": {"id": md["id"], "nome": md["nome"], "chembl": md["chembl_id"], "formula": md["formula"],
                        "estrutura": md["desenho"], "fase": md["max_fase_clinica"], "retirado": bool(md["fase_retirado"])},
            "especies_origem": especies_origem,
            "texto": r["texto"],
            "trecho": r.get("trecho"), "trecho_fonte": r.get("trecho_fonte"),
            "referencia": ref_info,
            "consulta": _registrar_consulta(ctx, mapa_c, consultas, r["consulta_id"]),
        })

    for mid in ctx.clinico:
        m = ctx.mol.get(mid)
        if m and m.get("categoria_clinica") == "farmaco_secundario":
            destinos_mol[mid].add(f"Fármaco: {m['nome'][:34]}")

    # Constrói fluxos ponderados (Bacia -> Família -> Classe/Tipo Molecular -> Destino Biológico)
    cont_fam = Counter()
    cont_cls = Counter()
    cont_dst = Counter()
    triplas = []

    sql_rel = (
        f"SELECT DISTINCT a.taxon_id, a.molecula_id, t.familia, t.grupo, t.nome AS t_nome, "
        f"m.classe_quimica, m.familia AS m_fam, m.tipo AS m_tipo "
        f"FROM afirmacao a JOIN taxon t ON t.id=a.taxon_id JOIN molecula m ON m.id=a.molecula_id "
        f"WHERE t.no_recorte=1 AND {pacotes.sql_publica('a')}"
    )
    for r in con.execute(sql_rel):
        tid, mid = r["taxon_id"], r["molecula_id"]
        bacias = bacias_t.get(tid, [])
        if not bacias:
            continue
        fam = r["familia"] or f"Grupo {r['grupo']}"
        cls = r["classe_quimica"] or r["m_fam"] or (
            "Toxinas proteicas/peptídicas" if r["m_tipo"] in ("proteina", "peptideo") else "Outras classes naturais"
        )
        dsts = sorted(destinos_mol.get(mid, ()))
        if not dsts:
            dsts = [SEM_MEDIDA]
        triplas.append((bacias, fam, cls, dsts))
        cont_fam[fam] += 1
        cont_cls[cls] += 1
        for d in dsts:
            if d != SEM_MEDIDA:
                cont_dst[d] += 1

    top_fams = {k for k, _ in cont_fam.most_common(14)}
    top_clss = {k for k, _ in cont_cls.most_common(12)}
    top_dsts = {k for k, _ in cont_dst.most_common(13)}

    elos_01 = Counter()
    elos_12 = Counter()
    elos_23 = Counter()

    for bacias, fam, cls, dsts in triplas:
        fam_k = fam if fam in top_fams else "Outras famílias"
        cls_k = cls if cls in top_clss else "Outras classes químicas"
        peso_bacia = 1.0 / max(1, len(bacias))
        for bid, _ in bacias:
            b_nome = nomes_bacia.get(bid, bid)
            elos_01[(b_nome, fam_k)] += peso_bacia
        elos_12[(fam_k, cls_k)] += 1.0
        peso_d = 1.0 / max(1, len(dsts))
        for d in dsts:
            if d == SEM_MEDIDA:
                d_k = d
            else:
                d_k = d if d in top_dsts else "Outras vias e alvos medidos"
            elos_23[(cls_k, d_k)] += peso_d

    nos = []
    idx_no = {}

    def obter_no(coluna, rotulo):
        chave = (coluna, rotulo)
        if chave not in idx_no:
            idx_no[chave] = len(nos)
            nos.append({"id": len(nos), "coluna": coluna, "nome": rotulo})
        return idx_no[chave]

    links = []
    for mapa_elos, col_a, col_b in ((elos_01, 0, 1), (elos_12, 1, 2), (elos_23, 2, 3)):
        for (na, nb), val in sorted(mapa_elos.items(), key=lambda kv: (-kv[1], kv[0][0], kv[0][1])):
            if val < 0.25:
                continue
            ia = obter_no(col_a, na)
            ib = obter_no(col_b, nb)
            links.append({"origem": ia, "destino": ib, "valor": round(float(val), 2), "transpoe_portao": col_a == 2})

    return _escrever(destino_viz / "fluxo.json", {
        "esquema": 1,
        "colunas_diagrama": [
            "01 · Bacia hidrográfica",
            "02 · Família biológica",
            "03 · Classe molecular isolada",
            "04 · Alvo, via Reactome ou fármaco",
        ],
        "portao_isolamento": {
            "entre_colunas": [2, 3],
            "titulo": "Portão de Isolamento Molecular e Síntese (Princípio 4)",
            "aviso": "À esquerda, ocorrências de organismos e os compostos relatados neles. À direita, medidas de moléculas isoladas em ensaio (ChEMBL e Reactome) e fármacos aprovados ou inspirados. A passagem entre os dois lados é o isolamento da molécula.",
        },
        "nos": nos,
        "links": links,
        "linhagens": linhagens,
        "consultas": consultas,
    })


def exportar_floresta(con, ctx, destino_viz):
    """Estratificação vertical empírica da floresta amazônica (JBRJ Flora e Funga + CTFB + GBIF)."""
    mapa_c, consultas = {}, []

    classes_por_taxon = defaultdict(Counter)
    n_mol_por_taxon = Counter()
    aprov_por_taxon = set()
    for r in con.execute(
        f"SELECT DISTINCT a.taxon_id, a.molecula_id, m.classe_quimica, m.familia, m.tipo, m.categoria_clinica "
        f"FROM afirmacao a JOIN molecula m ON m.id=a.molecula_id WHERE a.taxon_id IS NOT NULL AND {pacotes.sql_publica('a')}"
    ):
        tid, mid = r["taxon_id"], r["molecula_id"]
        n_mol_por_taxon[tid] += 1
        cls = r["classe_quimica"] or r["familia"] or (
            "Toxinas peptídicas/proteicas" if r["tipo"] in ("proteina", "peptideo") else "Outras classes"
        )
        classes_por_taxon[tid][cls] += 1
        if mid in ctx.clinico and (r["categoria_clinica"] or "farmaco_secundario") == "farmaco_secundario":
            aprov_por_taxon.add(tid)

    por_estrato = {k: [] for k, _, _ in ORDEM_ESTRATOS}
    classes_estrato = {k: Counter() for k, _, _ in ORDEM_ESTRATOS}

    for t in con.execute("SELECT * FROM taxon WHERE no_recorte=1 ORDER BY nome"):
        est = t["estrato_florestal"] if t["estrato_florestal"] in por_estrato else "nao_informado"
        if t["checklist_consulta_id"]:
            _registrar_consulta(ctx, mapa_c, consultas, t["checklist_consulta_id"])
        pop = json.loads(t["nomes_populares"] or "[]")
        biomas = json.loads(t["biomas_json"] or "[]") if t["biomas_json"] else []
        n_m = n_mol_por_taxon.get(t["id"], 0)
        por_estrato[est].append({
            "gbif": t["gbif_key"],
            "nome": t["nome"],
            "popular": pop[0]["nome"] if pop else None,
            "grupo": t["grupo"],
            "familia": t["familia"],
            "forma_vida": t["forma_vida"],
            "endemismo": t["endemismo_br"],
            "biomas": biomas,
            "mma": t["categoria_mma"],
            "iucn": t["iucn"],
            "moleculas": n_m,
            "aprovado": t["id"] in aprov_por_taxon,
            "fonte_checklist": t["checklist_fonte"],
        })
        classes_estrato[est].update(classes_por_taxon.get(t["id"], {}))

    estratos_out = []
    for chave, titulo, descricao in ORDEM_ESTRATOS:
        lista = sorted(por_estrato[chave], key=lambda x: (-x["moleculas"], x["nome"]))
        top_cls = [{"classe": c, "n": n} for c, n in classes_estrato[chave].most_common(8)]
        estratos_out.append({
            "id": chave,
            "titulo": titulo,
            "descricao": descricao,
            "n_especies": len(lista),
            "n_relacoes_moleculares": sum(x["moleculas"] for x in lista),
            "classes_quimicas": top_cls,
            "especies": lista,
        })

    return _escrever(destino_viz / "floresta.json", {
        "esquema": 1,
        "aviso_metodologico": "O estrato vertical vem dos perfis de forma de vida e hábitat publicados na Flora e Funga do Brasil (JBRJ), no Catálogo Taxonômico da Fauna do Brasil (CTFB) e no GBIF. Espécie sem registro de estrato fica em 'Estrato não informado na fonte'.",
        "estratos": estratos_out,
        "consultas": consultas,
    })


def exportar_filoquimica(con, ctx, destino_viz):
    """Árvore filogenética–quimiotaxonômica radial com 5 anéis concêntricos de métricas."""
    mapa_c, consultas = {}, []

    # Métricas por táxon
    classes_t = defaultdict(Counter)
    pront_t = defaultdict(list)
    pch_t = defaultdict(float)

    max_pch_mol = _maior_pchembl_por_molecula(con, ctx)

    for r in con.execute(
        f"SELECT a.id, a.taxon_id, a.molecula_id, m.classe_quimica, m.familia, m.tipo "
        f"FROM afirmacao a JOIN molecula m ON m.id=a.molecula_id "
        f"WHERE a.taxon_id IS NOT NULL AND {pacotes.sql_publica('a')}"
    ):
        tid, mid = r["taxon_id"], r["molecula_id"]
        cls = r["classe_quimica"] or r["familia"] or (
            "Toxinas proteicas/peptídicas" if r["tipo"] in ("proteina", "peptideo") else "Outras"
        )
        classes_t[tid][cls] += 1
        pr = ctx.prontidao.get(r["id"], {}).get("indice")
        if pr is not None:
            pront_t[tid].append(float(pr))
        if mid in max_pch_mol and max_pch_mol[mid] > pch_t[tid]:
            pch_t[tid] = max_pch_mol[mid]

    raiz = {"nome": "Táxons do recorte", "nivel": "raiz", "filhos": {}}

    def inserir_caminho(partes, folha):
        atual = raiz
        niveis = tuple(_NIVEL_SEM_NOME)
        for niv, p in zip(niveis, partes):
            chave = p or _NIVEL_SEM_NOME[niv]
            if chave not in atual["filhos"]:
                atual["filhos"][chave] = {"nome": chave, "nivel": niv, "filhos": {}}
            atual = atual["filhos"][chave]
        atual.setdefault("especies", []).append(folha)

    total_folhas = 0
    for t in con.execute("SELECT * FROM taxon WHERE no_recorte=1 ORDER BY reino, filo, classe, ordem, familia, genero, nome"):
        if t["ocorr_consulta_id"]:
            _registrar_consulta(ctx, mapa_c, consultas, t["ocorr_consulta_id"])
        pop = json.loads(t["nomes_populares"] or "[]")
        prs = pront_t.get(t["id"], [])
        media_pr = round(sum(prs) / len(prs), 3) if prs else None
        top_c = [[c, n] for c, n in classes_t[t["id"]].most_common(4)]
        n_mols = sum(classes_t[t["id"]].values())
        folha = {
            "gbif": t["gbif_key"],
            "nome": t["nome"],
            "popular": pop[0]["nome"] if pop else None,
            "grupo": t["grupo"],
            "n_mol": n_mols,
            "classes": top_c,
            "max_pch": round(pch_t[t["id"]], 2) if pch_t.get(t["id"], 0) > 0 else None,
            "prontidao": media_pr,
            "iucn": t["iucn"],
            "mma": t["categoria_mma"],
            "endemismo": t["endemismo_br"],
            "predominio": t["predominio_al"],
            "estrato": t["estrato_florestal"],
        }
        inserir_caminho([t["reino"], t["filo"], t["classe"], t["ordem"], t["familia"], t["genero"]], folha)
        total_folhas += 1

    def serializar(no):
        saida = {"nome": no["nome"], "nivel": no["nivel"]}
        filhos = [serializar(v) for _, v in sorted(no.get("filhos", {}).items())]
        especies = no.get("especies", [])
        if filhos:
            saida["filhos"] = filhos
        if especies:
            saida["especies"] = especies
        return saida

    return _escrever(destino_viz / "filoquimica.json", {
        "esquema": 1,
        "total_especies": total_folhas,
        "aneis": [
            {"anel": 1, "titulo": "Impressão química / toxínica", "nota": "Classe química ou família molecular predominante nos registros públicos do táxon."},
            {"anel": 2, "titulo": "Maior potência in vitro entre as moléculas (pChEMBL)", "nota": "Maior pChEMBL entre os pares molécula–alvo das moléculas relatadas no táxon; cada par entra pelo valor central das suas medidas válidas no ChEMBL. É medida da molécula isolada."},
            {"anel": 3, "titulo": "Completude do registro (sete dimensões)", "nota": "Média do índice de completude documental das afirmações públicas do táxon."},
            {"anel": 4, "titulo": "Conservação (IUCN / Lista MMA)", "nota": "Categorias oficiais de ameaça quando avaliadas."},
            {"anel": 5, "titulo": "Endemismo e concentração dos registros", "nota": "Endemismo no Brasil (Flora e Funga do Brasil / CTFB) e fração dos registros brasileiros do GBIF que está na Amazônia Legal."},
        ],
        "arvore": serializar(raiz),
        "consultas": consultas,
    })


def exportar_materia_escura(con, ctx, destino_viz):
    """Panorama das espécies amazônicas aceitas nos catálogos nacionais sem química aberta e gêneros prioritários."""
    mapa_c, consultas = {}, []
    tem_tabela = con.execute(
        "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='universo_checklist'"
    ).fetchone()[0]
    total = com_quimica = end_sem = 0
    por_grupo = {}
    familias = {}
    generos = {}

    if tem_tabela:
        rows = con.execute(
            "SELECT nome_aceito, familia, genero, grupo_bmb, endemismo_br, tem_quimica_aberta, consulta_id "
            "FROM universo_checklist WHERE bioma_amazonia_declarado = 1 ORDER BY nome_aceito"
        ).fetchall()
        cids_vistos = set()
        for r in rows:
            cid = r["consulta_id"]
            if cid and cid not in cids_vistos:
                cids_vistos.add(cid)
                _registrar_consulta(ctx, mapa_c, consultas, cid)
            total += 1
            tem_q = bool(r["tem_quimica_aberta"])
            if tem_q:
                com_quimica += 1
            eh_end = str(r["endemismo_br"] or "").lower().startswith("endemic")
            if eh_end and not tem_q:
                end_sem += 1

            g_cod = r["grupo_bmb"] or "outro"
            pg = por_grupo.setdefault(g_cod, {"grupo": g_cod, "total": 0, "com_quimica": 0, "sem_quimica": 0, "endemicas_sem_quimica": 0})
            pg["total"] += 1
            if tem_q:
                pg["com_quimica"] += 1
            else:
                pg["sem_quimica"] += 1
                if eh_end:
                    pg["endemicas_sem_quimica"] += 1

            fam = (r["familia"] or "").strip() or "Família não informada"
            pf = familias.setdefault(fam, {"familia": fam, "grupos": Counter(), "total": 0, "com_quimica": 0, "sem_quimica": 0, "endemicas_sem_quimica": 0})
            pf["grupos"][g_cod] += 1
            pf["total"] += 1
            if tem_q:
                pf["com_quimica"] += 1
            else:
                pf["sem_quimica"] += 1
                if eh_end:
                    pf["endemicas_sem_quimica"] += 1

            nome = (r["nome_aceito"] or "").strip()
            gen = (r["genero"] or "").strip() or (nome.split()[0] if len(nome.split()) >= 2 else "")
            if gen:
                gn = generos.setdefault(
                    gen,
                    {"genero": gen, "familias": Counter(), "grupos": Counter(),
                     "total": 0, "com_quimica": 0, "sem_quimica": 0, "endemicas_sem_quimica": 0,
                     "exemplos": [], "exemplos_gerais": []},
                )
                gn["familias"][fam] += 1
                gn["grupos"][g_cod] += 1
                gn["total"] += 1
                if tem_q:
                    gn["com_quimica"] += 1
                else:
                    gn["sem_quimica"] += 1
                    if eh_end:
                        gn["endemicas_sem_quimica"] += 1
                        if len(gn["exemplos"]) < 5 and len(nome.split()) >= 2:
                            gn["exemplos"].append(nome)
                    elif len(gn["exemplos_gerais"]) < 5 and len(nome.split()) >= 2:
                        gn["exemplos_gerais"].append(nome)

    sem_quimica = total - com_quimica
    pct_sem = round(100.0 * sem_quimica / total, 2) if total else 0.0
    grupos_out = sorted(por_grupo.values(), key=lambda x: -x["total"])
    familias_out = [
        {
            "familia": f["familia"],
            "grupo": f["grupos"].most_common(1)[0][0],
            "total": f["total"],
            "com_quimica": f["com_quimica"],
            "sem_quimica": f["sem_quimica"],
            "endemicas_sem_quimica": f["endemicas_sem_quimica"],
        }
        for f in sorted(familias.values(), key=lambda x: (-x["sem_quimica"], x["familia"]))[:30]
    ]
    quotas = [("planta", 40), ("animal_outro", 20), ("animal_peconhento", 15), ("fungo", 15), ("outro", 5)]
    generos_sel = []
    vistos_gen = set()
    for grp_cod, limite in quotas:
        cands = [
            g for g in generos.values()
            if g["sem_quimica"] > 0 and g["grupos"].most_common(1)[0][0] == grp_cod and g["genero"] not in vistos_gen
        ]
        cands.sort(key=lambda x: (-x["endemicas_sem_quimica"], -x["sem_quimica"], x["genero"]))
        for g in cands[:limite]:
            vistos_gen.add(g["genero"])
            exemplos = (g["exemplos"] + [e for e in g["exemplos_gerais"] if e not in g["exemplos"]])[:5]
            generos_sel.append({
                "genero": g["genero"],
                "familia": g["familias"].most_common(1)[0][0],
                "grupo": grp_cod,
                "total": g["total"],
                "com_quimica": g["com_quimica"],
                "sem_quimica": g["sem_quimica"],
                "endemicas_sem_quimica": g["endemicas_sem_quimica"],
                "exemplos_endemicos": exemplos,
            })
    generos_out = sorted(generos_sel, key=lambda x: (-x["endemicas_sem_quimica"], -x["sem_quimica"], x["genero"]))
    return _escrever(destino_viz / "materia_escura.json", {
        "esquema": 1,
        "total_especies": total,
        "com_quimica_aberta": com_quimica,
        "sem_quimica_aberta": sem_quimica,
        "pct_sem_quimica": pct_sem,
        "endemicas_br_sem_quimica": end_sem,
        "por_grupo": grupos_out,
        "familias": familias_out,
        "generos_prioritarios": generos_out,
        "consultas": consultas,
    })


def exportar_viz_tudo(con, ctx, destino, log=print):
    destino_viz = destino / "viz"
    destino_viz.mkdir(parents=True, exist_ok=True)
    res = {
        "galaxia.json": exportar_galaxia(con, ctx, destino_viz),
        "fluxo.json": exportar_fluxo(con, ctx, destino_viz),
        "floresta.json": exportar_floresta(con, ctx, destino_viz),
        "filoquimica.json": exportar_filoquimica(con, ctx, destino_viz),
        "materia_escura.json": exportar_materia_escura(con, ctx, destino_viz),
    }
    log("  observatórios viz: " + ", ".join(f"{k} ({v / 1024:.1f} KB)" for k, v in res.items()))
    return res
