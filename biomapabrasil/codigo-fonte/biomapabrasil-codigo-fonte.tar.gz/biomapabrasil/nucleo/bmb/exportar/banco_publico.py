# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Banco de distribuição: cópia do banco de trabalho só com os registros publicados.

O banco de trabalho (`config.DB_PATH`) é o registro completo da construção: guarda também o que foi retido, com a
regra e o motivo, e é o que a curadoria usa. O arquivo que acompanha uma Release é esta cópia. Ela tem o mesmo
esquema, os mesmos identificadores e, lida pela API ou pelo exportador, produz exatamente os mesmos pacotes.

O conjunto do que é público é o de `pacotes.Contexto`, definido uma vez só. Nada é apagado do banco de trabalho.

Uso:  python -m bmb.exportar.banco_publico <destino.sqlite>
"""
from __future__ import annotations

import re
import sqlite3
import sys
from pathlib import Path

from .. import config, db, quarentena
from . import pacotes

# Atividades de proveniência que descrevem um registro publicado. As demais registram o trabalho interno de
# retenção, correção e fusão, e ficam só no banco de trabalho.
EVENTOS_PUBLICOS = ("extracao", "agregacao", "reconciliacao", "verificacao", "publicacao")
ENTIDADES_DE_EVENTO = ("afirmacao", "taxon", "molecula", "referencia", "midia", "relacao_molecula")
DECISOES_DE_ORGANISMO_PUBLICAS = ("aceito", "aceito_mesmo_nome_e_autoria")
# tabela -> colunas que ficam vazias na cópia (o esquema é o mesmo; o conteúdo interno não acompanha)
COLUNAS_INTERNAS = {
    "afirmacao": ("motivo_quarentena", "regra_quarentena", "quarentena_origem", "conferencia_literatura"),
    "referencia": ("motivo_quarentena", "regra_quarentena"),
    "relacao_molecula": ("motivo_quarentena", "regra_quarentena"),
    "midia": ("motivo_quarentena",),
    "medida_bioatividade": ("motivo_exclusao",),
    "verificacao": ("nota", "rodada_benchmark"),
    "etapa": ("resumo",),
}
TABELAS_INTERNAS = ("afirmacao_regra", "regra_quarentena", "amostra_benchmark", "taxon_sinonimo_legado")


def _colunas(pub, tabela):
    return {r[1]: r for r in pub.execute(f"PRAGMA table_info([{tabela}])")}


def _tabelas(pub):
    return [r[0] for r in pub.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' "
                                      "AND sql NOT LIKE 'CREATE VIRTUAL TABLE%' ORDER BY name")
            if not re.match(r"busca_(?:config|content|data|docsize|idx)$", r[0])]


def _guardar(pub, nome, ids):
    pub.execute(f"CREATE TEMP TABLE {nome} (id INTEGER PRIMARY KEY)")
    pub.executemany(f"INSERT OR IGNORE INTO {nome} (id) VALUES (?)", ((i,) for i in ids))


def gerar(con, destino, log=print) -> dict:
    """Grava em `destino` a cópia pública do banco aberto em `con`. Devolve as contagens do que ficou."""
    destino = Path(destino)
    origem = con.execute("PRAGMA database_list").fetchone()[2]
    if origem and Path(origem).resolve() == destino.resolve():
        raise ValueError("o destino da cópia pública é o próprio banco de trabalho")
    destino.parent.mkdir(parents=True, exist_ok=True)
    for sufixo in ("", "-wal", "-shm"):
        Path(str(destino) + sufixo).unlink(missing_ok=True)

    ctx = pacotes.Contexto(con)
    manter = {
        "k_af": ctx.afirmacoes_exportadas(),
        "k_ref": ctx.referencias_citadas(),
        "k_mol": set(ctx.mols_publicas),
        "k_alvo": set(ctx.alvos_publicos),
        "k_3d": {e["id"] for lista in (*ctx.estruturas3d.values(), *ctx.estruturas3d_alvo.values()) for e in lista},
        "k_rel": {d["id"] for d in ctx.linhagens},
    }
    canonica = {rid: r["duplicata_de"] for rid, r in ctx.refs.items() if r.get("duplicata_de")}
    con.commit()
    con.execute("VACUUM INTO ?", (str(destino),))

    pub = sqlite3.connect(destino)
    pub.row_factory = sqlite3.Row
    try:
        pub.execute("PRAGMA foreign_keys = OFF")
        for nome, ids in manter.items():
            _guardar(pub, nome, ids)

        # vínculo que ainda aponta para uma linha duplicada passa a apontar para a obra (num banco validado não há nenhum)
        for dup, can in canonica.items():
            pub.execute("UPDATE OR IGNORE afirmacao_referencia SET referencia_id=? WHERE referencia_id=?", (can, dup))

        # ── registros fora do público, e o que depende só deles ──
        for tabela in ("afirmacao_referencia", "prontidao", "verificacao", "medida_bioatividade"):
            pub.execute(f"DELETE FROM {tabela} WHERE afirmacao_id NOT IN (SELECT id FROM k_af)")
        pub.execute("DELETE FROM afirmacao_referencia WHERE referencia_id NOT IN (SELECT id FROM k_ref)")
        pub.execute("DELETE FROM medida_bioatividade WHERE usada = 0")
        pub.execute("DELETE FROM afirmacao WHERE id NOT IN (SELECT id FROM k_af)")
        # passagem e frase de coleta cuja obra não é citável não acompanham a afirmação
        pub.execute("UPDATE afirmacao SET passagem=NULL, passagem_origem=NULL, passagem_referencia_id=NULL, passagem_sha256=NULL "
                    "WHERE passagem_referencia_id IS NOT NULL AND passagem_referencia_id NOT IN (SELECT id FROM k_ref)")
        pub.execute("UPDATE afirmacao SET procedencia_artigo=NULL, procedencia_artigo_local=NULL, procedencia_artigo_referencia_id=NULL, "
                    "procedencia_artigo_sha256=NULL WHERE procedencia_artigo_referencia_id IS NOT NULL "
                    "AND procedencia_artigo_referencia_id NOT IN (SELECT id FROM k_ref)")
        if _colunas(pub, "verificacao")["referencia_id"][3]:       # coluna obrigatória: a leitura sai junto com a obra
            pub.execute("DELETE FROM verificacao WHERE referencia_id NOT IN (SELECT id FROM k_ref)")
        else:
            pub.execute("UPDATE verificacao SET referencia_id=NULL WHERE referencia_id IS NOT NULL AND referencia_id NOT IN (SELECT id FROM k_ref)")
        pub.execute("DELETE FROM relacao_molecula WHERE id NOT IN (SELECT id FROM k_rel)")
        pub.execute("DELETE FROM estrutura_3d WHERE id NOT IN (SELECT id FROM k_3d) OR (molecula_id IS NOT NULL AND molecula_id NOT IN (SELECT id FROM k_mol)) "
                    "OR (alvo_id IS NOT NULL AND alvo_id NOT IN (SELECT id FROM k_alvo))")
        pub.execute("DELETE FROM molecula WHERE id NOT IN (SELECT id FROM k_mol)")
        pub.execute("DELETE FROM alvo_via WHERE alvo_id NOT IN (SELECT id FROM k_alvo)")
        pub.execute("DELETE FROM alvo WHERE id NOT IN (SELECT id FROM k_alvo)")
        pub.execute("DELETE FROM via_biologica WHERE id NOT IN (SELECT via_id FROM alvo_via)")
        pub.execute("DELETE FROM referencia WHERE id NOT IN (SELECT id FROM k_ref)")
        pub.execute("DELETE FROM midia WHERE estado <> 'ativo'")
        marcas = ",".join("?" * len(DECISOES_DE_ORGANISMO_PUBLICAS))
        pub.execute(f"DELETE FROM organismo_fonte WHERE decisao NOT IN ({marcas}) OR taxon_id IS NULL", DECISOES_DE_ORGANISMO_PUBLICAS)

        # ── proveniência: só os eventos que descrevem um registro que ficou ──
        pub.execute(f"DELETE FROM evento_proveniencia WHERE atividade NOT IN ({','.join('?' * len(EVENTOS_PUBLICOS))}) "
                    f"OR entidade NOT IN ({','.join('?' * len(ENTIDADES_DE_EVENTO))})", (*EVENTOS_PUBLICOS, *ENTIDADES_DE_EVENTO))
        for entidade in ENTIDADES_DE_EVENTO:
            pub.execute(f"DELETE FROM evento_proveniencia WHERE entidade=? AND entidade_id NOT IN (SELECT id FROM {entidade})", (entidade,))

        # ── conteúdo interno de tabelas e colunas que permanecem no esquema ──
        for tabela in TABELAS_INTERNAS:
            pub.execute(f"DELETE FROM {tabela}")
        for tabela, colunas in COLUNAS_INTERNAS.items():
            info = _colunas(pub, tabela)
            for c in colunas:
                if c in info:
                    pub.execute(f"UPDATE {tabela} SET {c} = {'NULL' if not info[c][3] else chr(39) * 2}")

        # ── índice de busca e consultas: só o que ainda tem a que se referir ──
        pub.execute("DELETE FROM busca WHERE tipo='molecula' AND CAST(ref_id AS INTEGER) NOT IN (SELECT id FROM k_mol)")
        referidas = set()
        for tabela in _tabelas(pub):
            for fk in pub.execute(f"PRAGMA foreign_key_list([{tabela}])").fetchall():
                if fk[2] == "consulta":
                    referidas.update(r[0] for r in pub.execute(f"SELECT DISTINCT [{fk[3]}] FROM [{tabela}] WHERE [{fk[3]}] IS NOT NULL"))
        _guardar(pub, "k_cons", referidas)
        pub.execute("DELETE FROM consulta WHERE id NOT IN (SELECT id FROM k_cons)")
        pub.commit()

        problemas = conferir(pub)
        if problemas:
            raise RuntimeError("a cópia pública do banco não passou na conferência: " + "; ".join(problemas[:8]))
        resumo = {t: pub.execute(f"SELECT COUNT(*) FROM [{t}]").fetchone()[0]
                  for t in ("afirmacao", "molecula", "referencia", "relacao_molecula", "taxon", "consulta", "medida_bioatividade")}
        for nome in (*manter, "k_cons"):
            pub.execute(f"DROP TABLE temp.{nome}")
        pub.commit()
        pub.execute("PRAGMA journal_mode = DELETE")
        pub.execute("VACUUM")
    except Exception:
        pub.close()
        destino.unlink(missing_ok=True)
        raise
    pub.close()
    resumo["bytes"] = destino.stat().st_size
    log(f"  banco de distribuição em {destino}: {resumo['afirmacao']} afirmações, {resumo['molecula']} moléculas, "
        f"{resumo['referencia']} referências ({resumo['bytes'] / 1e6:.1f} MB)")
    return resumo


def conferir(pub) -> list[str]:
    """O que há de errado em uma cópia pública: lista vazia quando está íntegra e sem conteúdo interno."""
    problemas = []
    if pub.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
        problemas.append("integrity_check falhou")
    orfas = pub.execute("PRAGMA foreign_key_check").fetchall()
    if orfas:
        problemas.append(f"{len(orfas)} linha(s) com chave estrangeira sem destino (ex.: {tuple(orfas[0])})")
    testes = [
        ("afirmação fora dos estados públicos", f"SELECT COUNT(*) FROM afirmacao WHERE NOT ({pacotes.sql_publica()})"),
        ("referência que não é obra citável", f"SELECT COUNT(*) FROM referencia WHERE NOT ({pacotes.SQL_REFERENCIA_PUBLICA})"),
        ("linhagem fora dos estados públicos", f"SELECT COUNT(*) FROM relacao_molecula WHERE estado NOT IN {pacotes.SQL_ESTADOS}"),
        ("imagem fora do público", "SELECT COUNT(*) FROM midia WHERE estado <> 'ativo'"),
        ("medida fora do agregado", "SELECT COUNT(*) FROM medida_bioatividade WHERE usada = 0"),
    ]
    testes += [(f"tabela interna {t} com linhas", f"SELECT COUNT(*) FROM {t}") for t in TABELAS_INTERNAS]
    for tabela, colunas in COLUNAS_INTERNAS.items():
        info = _colunas(pub, tabela)
        testes += [(f"{tabela}.{c} preenchida", f"SELECT COUNT(*) FROM {tabela} WHERE IFNULL({c}, '') <> ''") for c in colunas if c in info]
    for nome, sql in testes:
        n = pub.execute(sql).fetchone()[0]
        if n:
            problemas.append(f"{nome}: {n}")
    # nenhum valor de texto traz código de regra ou identificador do lado interno
    padrao = "|".join(re.escape(x) for x in sorted((*pacotes.IDENTIFICADORES_INTERNOS, *quarentena.REGRAS), key=len, reverse=True))
    regex = re.compile(padrao)
    pub.create_function("tem_interno", 1, lambda v: 1 if isinstance(v, str) and regex.search(v) else 0)
    for tabela in _tabelas(pub):
        for coluna, info in _colunas(pub, tabela).items():
            if (info[2] or "").upper() not in ("TEXT", ""):
                continue
            n = pub.execute(f"SELECT COUNT(*) FROM [{tabela}] WHERE tem_interno([{coluna}])").fetchone()[0]
            if n:
                problemas.append(f"{tabela}.{coluna}: {n} valor(es) com identificador interno")
    return problemas


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if len(argv) != 1:
        print(__doc__)
        return 2
    con = db.conectar(config.DB_PATH)
    try:
        gerar(con, argv[0])
    finally:
        con.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
