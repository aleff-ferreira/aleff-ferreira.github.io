# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Pacotes de dados estáticos para o site: pequenos, fragmentados e com proveniência embutida.

Metas de desempenho do dono do projeto (400 kbps, 400 ms, Android de entrada) ditam o formato:
  * `indice.json` pequeno, para busca e mapa, carregado no início;
  * um arquivo por táxon e um por molécula, carregados só quando alguém abre o perfil;
  * referências e consultas (fonte, URL, data) como listas por pacote, citadas por índice.

Fronteira entre o público e o interno (docs/dev/CONTRATO_DE_DADOS.md): daqui só sai registro em estado público, de
acesso público, sustentado por obra ativa. Este módulo é o único lugar que define o que é público; os demais
exportadores e a API usam as definições daqui. O livro do que ficou de fora, com a regra e o motivo, é gravado em
`config.SAIDA_DIR / "interno"`, que não faz parte de nenhuma pasta servida a um navegador.
"""
import hashlib
import json
import re
import shutil
from collections import Counter
from pathlib import Path

from .. import __version__, config, curadoria, procedencia, quarentena, texto, validar
from ..conectores import ena
from ..util import agora

# ═══════════════════════════ o que é público ═══════════════════════════
# Nomes usados fora dos exportadores, que não mudam de nome nem de sentido (docs/dev/CONTRATO_DE_DADOS.md §1.1):
# `SQL_MOLECULAS_PUBLICAS` (regra derivada de `bmb.quarentena`); `sql_publica`, `SQL_ESTADOS`, `SQL_REFERENCIA_PUBLICA`,
# `IDENTIFICADORES_INTERNOS` e, de `Contexto`, `afirmacoes_exportadas`, `referencias_citadas`, `mols_publicas`,
# `alvos_publicos`, `linhagens` e `refs` (cópia de distribuição do banco, `bmb.exportar.banco_publico`).
ESTADOS_PUBLICOS = ("candidato", "em_revisao", "verificado")
SQL_ESTADOS = "('candidato','em_revisao','verificado')"
# Fragmento usado como `estado IN {SQL_PUBLICO}`: além do estado, só entra o que tem acesso público.
# Afirmações marcadas pelo curador como 'restrito' ou 'comunitario' (sensibilidade) nunca saem.
SQL_PUBLICO = SQL_ESTADOS + " AND classe_acesso = 'publico'"
# Obra citável: ativa, não é linha duplicada de outra e não foi retratada.
SQL_REFERENCIA_PUBLICA = "estado = 'ativa' AND duplicata_de IS NULL AND retratada = 0"
TIPOS_DE_ORGANISMO = ("composto_em_organismo", "funcao_toxina")
STATUS_DE_SINONIMO_FORA = ("PROPARTE_SYNONYM", "MISAPPLIED", "DOUBTFUL")


def sql_publica(apelido=""):
    """Condição SQL de afirmação em estado e acesso públicos, para a tabela `afirmacao` com o apelido dado."""
    p = f"{apelido}." if apelido else ""
    return f"{p}estado IN {SQL_ESTADOS} AND {p}classe_acesso = 'publico'"


def sql_linhagem_publica(apelido="rm"):
    """Linhagem em estado público cuja obra citada é citável (a linha duplicada vale pela obra a que remete)."""
    return (f"{apelido}.estado IN {SQL_ESTADOS} AND EXISTS (SELECT 1 FROM referencia r_ JOIN referencia c_ "
            f"ON c_.id = COALESCE(r_.duplicata_de, r_.id) WHERE r_.id = {apelido}.referencia_id "
            f"AND c_.estado = 'ativa' AND c_.duplicata_de IS NULL AND c_.retratada = 0)")


# Molécula pública: relatada em algum táxon por afirmação pública, ou parte de uma linhagem pública. Medida de
# bioatividade e efeito clínico só saem para essas moléculas: sozinhos, não ligam a molécula a organismo nenhum do banco.
SQL_MOLECULAS_PUBLICAS = (
    f"SELECT molecula_id FROM afirmacao WHERE taxon_id IS NOT NULL AND {sql_publica()} "
    f"UNION SELECT origem_id FROM relacao_molecula rm WHERE {sql_linhagem_publica('rm')} "
    f"UNION SELECT destino_id FROM relacao_molecula rm WHERE {sql_linhagem_publica('rm')}")


def sql_afirmacao_exportada(apelido="a"):
    """Condição SQL completa de afirmação que sai: pública e, se não é ligada a organismo, de molécula pública."""
    return (f"{sql_publica(apelido)} AND ({apelido}.taxon_id IS NOT NULL "
            f"OR {apelido}.molecula_id IN ({SQL_MOLECULAS_PUBLICAS}))")


# ═══════════════════════════ rótulos e texto público ═══════════════════════════
# Nível de evidência (`afirmacao.nivel_evidencia`), do mais forte ao mais fraco. Definido aqui, uma vez. A tradução de
# cada rótulo está no dicionário do site (`nucleo/semente/i18n/en.json`), cuja chave é o próprio texto em pt-BR.
ROTULOS_EVIDENCIA = {
    "curador": "Conferido por curador",
    "artigo_trecho": "Trecho localizado no artigo",
    "artigo_cita_organismo": "Artigo cita o organismo",
    "base_curada": "Transcrito de base curada",
}
ORDEM_EVIDENCIA = tuple(ROTULOS_EVIDENCIA)
_SQL_ORDEM_EVIDENCIA = ("CASE {c} " + " ".join(f"WHEN '{k}' THEN {i}" for i, k in enumerate(ORDEM_EVIDENCIA))
                        + f" ELSE {len(ORDEM_EVIDENCIA)} END")

CODIGO_GRUPO = {"planta": "P", "fungo": "F", "animal_peconhento": "A", "outro": "O"}
CODIGO_TIPO = {"pequena_molecula": "s", "peptideo": "p", "proteina": "t"}

PRINCIPIOS = [
    {"n": 1, "titulo": "Todo número tem fonte e data",
     "texto": "Cada contagem, enunciado e medida aponta a consulta de onde veio: fonte, endereço e data da consulta original."},
    {"n": 2, "titulo": "Ausência é declarada",
     "texto": "Quando a fonte não informa o local de coleta, a passagem do artigo ou uma imagem licenciada, o registro diz isso. "
              "Zero é resultado de consulta; dado que a fonte não traz aparece como não informado."},
    {"n": 3, "titulo": "Imagem só com licença verificável",
     "texto": "Fotografias entram com licença CC0 ou CC BY legível por máquina, com autor e página de origem. O site redistribui só a miniatura."},
    {"n": 4, "titulo": "Associação documentada não é eficácia",
     "texto": "Um composto relatado em um organismo é um registro de ocorrência química. Uma medida de bioatividade descreve a "
              "molécula isolada em um ensaio. Um efeito clínico descreve o fármaco aprovado. Nenhum desses registros descreve efeito "
              "do organismo, do extrato ou da planta."},
    {"n": 5, "titulo": "Acessível a todos",
     "texto": "Navegação por teclado, leitor de tela, respeito a prefers-reduced-motion e contraste AA nos temas claro e escuro."},
]
ESTADOS_TEXTO = {
    "candidato": "Registro de base curada; passagem da publicação ainda não lida por curador.",
    "em_revisao": "Em revisão por curador.",
    "verificado": "Passagem lida e confirmada na publicação por curador.",
}
TEXTO_DA_POLITICA_DE_EXCLUSAO = (
    "Espécies de uso ritual ou sagrado de povos indígenas e plantas de uso controlado ficam fora da plataforma, em "
    "qualquer fonte de dados. A inclusão de uma espécie de uso ritual depende de protocolo acordado com as comunidades.")
# A fonte «curadoria» descreve, no banco, todo o trabalho editorial da equipe; a descrição pública diz o que dela sai.
DESCRICAO_PUBLICA_DE_FONTE = {
    "curadoria": "Decisões editoriais da equipe: lista inicial de espécies, linhagens farmacológicas com a obra citada "
                 "e conferência de passagens por curador.",
}


def rotulos():
    """Dicionários de rótulos em pt-BR que o manifesto publica, para o site não repetir texto fixo."""
    return {
        "evidencia": dict(ROTULOS_EVIDENCIA),
        "procedencia": dict(procedencia.ROTULOS_PROCEDENCIA),
        "procedencia_artigo": dict(procedencia.ROTULOS_PROCEDENCIA_ARTIGO),
        "distribuicao_br": dict(procedencia.ROTULOS_DISTRIBUICAO),
        # `proteina_unica` é null: alvo molecular individual não leva qualificação
        "natureza_alvo": dict(texto.ROTULO_NATUREZA_ALVO),
    }


def fonte_publica(f):
    """Linha de `fonte` como sai: mesma fonte, com a descrição pública quando a do banco fala de trabalho interno."""
    f = dict(f)
    if f["id"] in DESCRICAO_PUBLICA_DE_FONTE:
        f["descricao"] = DESCRICAO_PUBLICA_DE_FONTE[f["id"]]
    return f


# Pedaço de um código de coleção: sigla em maiúsculas («INPA», «INPA-H», «J.») ou identificador com dígito
# («22410», «MCZ:Herp:A-12345», «geoCA1»). Palavra comum não é nem uma coisa nem outra.
_PEDACO_DE_CODIGO = re.compile(r"^(?:[A-Z]{1,12}(?:[-:/][A-Z]{1,8}){0,3}\.?|[A-Za-z0-9.:/_#<>()-]*\d[A-Za-z0-9.:/_#<>()-]*)$")


def voucher_publico(valor):
    """Testemunho que a base de origem declara, só como código de coleção: siglas e identificadores com dígito.

    Uma palavra comum no texto (lugar, nome de coletor, frase) faz o testemunho não sair: o campo não leva
    localidade mais fina que país e UF nem por via indireta.
    """
    partes = []
    for bruto in (valor or "").split("; "):
        v = ena.voucher_sem_localidade(bruto)
        if v and not curadoria.localidade_fina(v) and all(_PEDACO_DE_CODIGO.match(p) for p in v.split()):
            partes.append(v)
    return "; ".join(partes) or None


def conectividade(m):
    """Bloco de conectividade do InChIKey (esqueleto 2D, sem estereoquímica) de uma linha de `molecula`."""
    return m.get("inchikey_conectividade") or ((m.get("inchikey") or "")[:14] or None)


def _escrever(caminho, obj):
    caminho.parent.mkdir(parents=True, exist_ok=True)
    dados = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    caminho.write_bytes(dados)
    return len(dados)


def _lista_json(valor):
    try:
        d = json.loads(valor) if valor else []
    except (TypeError, ValueError):
        return []
    return d if isinstance(d, list) else []


# ═══════════════════════════ contexto ═══════════════════════════
class Contexto:
    """Pré-carrega, uma vez, as tabelas pequenas que todos os pacotes consultam e fixa o conjunto do que é público."""

    def __init__(self, con, pasta_3d=None):
        self.con = con
        self.consultas = {r["id"]: dict(r) for r in con.execute("SELECT * FROM consulta")}
        self.refs = {r["id"]: dict(r) for r in con.execute("SELECT * FROM referencia")}
        self.mol = {r["id"]: dict(r) for r in con.execute("SELECT * FROM molecula")}
        self.alvos = {r["id"]: dict(r) for r in con.execute("SELECT * FROM alvo")}
        self.fontes = {r["id"]: fonte_publica(r) for r in con.execute("SELECT * FROM fonte")}
        self.taxon_nome = {r["id"]: r["nome"] for r in con.execute("SELECT id, nome FROM taxon")}
        # referências de cada afirmação: só obras citáveis, sem repetição
        self.refs_da_af = {}
        for r in con.execute("SELECT afirmacao_id, referencia_id FROM afirmacao_referencia ORDER BY afirmacao_id, referencia_id"):
            rid = self.ref_publica(r["referencia_id"])
            if rid is not None:
                lista = self.refs_da_af.setdefault(r["afirmacao_id"], [])
                if rid not in lista:
                    lista.append(rid)
        self.prontidao = {r["afirmacao_id"]: dict(r) for r in con.execute("SELECT * FROM prontidao")}
        # última verificação humana válida de cada afirmação (a mais recente vence)
        self.verificacao = {}
        for r in con.execute("SELECT * FROM verificacao WHERE decisao IN ('confirmada','corrigida') ORDER BY em, id"):
            self.verificacao[r["afirmacao_id"]] = dict(r)

        # linhagens e moléculas públicas
        self.linhagens = [dict(r) for r in con.execute(
            f"SELECT rm.* FROM relacao_molecula rm WHERE {sql_linhagem_publica('rm')} ORDER BY rm.id")
            if r["origem_id"] in self.mol and r["destino_id"] in self.mol]
        self.em_relacao = {x for d in self.linhagens for x in (d["origem_id"], d["destino_id"])}
        self.relacoes_mol = {}
        for d in self.linhagens:
            self.relacoes_mol.setdefault(d["origem_id"], []).append(("origem", d))
            self.relacoes_mol.setdefault(d["destino_id"], []).append(("destino", d))
        self.n_taxa_da_mol = {r[0]: r[1] for r in con.execute(
            f"SELECT molecula_id, COUNT(DISTINCT taxon_id) FROM afirmacao WHERE taxon_id IS NOT NULL AND {sql_publica()} GROUP BY 1")}
        self.mols_publicas = set(self.n_taxa_da_mol) | self.em_relacao
        self.n_ativ, self.clinico, self.alvos_publicos = {}, {}, set()
        for r in con.execute(f"SELECT id, tipo, molecula_id, alvo_id FROM afirmacao WHERE taxon_id IS NULL AND {sql_publica()} ORDER BY id"):
            mid = r["molecula_id"]
            if mid not in self.mols_publicas:
                continue
            if r["tipo"] == "atividade_biologica":
                self.n_ativ[mid] = self.n_ativ.get(mid, 0) + 1
                if r["alvo_id"]:
                    self.alvos_publicos.add(r["alvo_id"])
            elif r["tipo"] == "efeito_clinico_documentado":
                self.clinico.setdefault(mid, r["id"])
        self.n_conectividade = Counter(c for c in (conectividade(self.mol[m]) for m in self.mols_publicas) if c)

        # coleta na Amazônia declarada (por curador ou pela base de origem), por táxon e por molécula
        amz = procedencia.PROCEDENCIA_AMAZONICA_DECLARADA
        self.taxon_coleta_amazonica, self.mol_coleta_amazonica = set(), set()
        for r in con.execute(f"SELECT DISTINCT taxon_id, molecula_id FROM afirmacao WHERE taxon_id IS NOT NULL AND {sql_publica()} "
                             f"AND procedencia_declarada IN ({','.join('?' * len(amz))})", amz):
            self.taxon_coleta_amazonica.add(r["taxon_id"])
            self.mol_coleta_amazonica.add(r["molecula_id"])

        # cobertura por táxon: moléculas com afirmação pública de composto, no total e por base de origem
        self.compostos_do_taxon = {}
        for r in con.execute(f"SELECT taxon_id, fonte_id, COUNT(DISTINCT molecula_id) AS n FROM afirmacao "
                             f"WHERE tipo='composto_em_organismo' AND {sql_publica()} GROUP BY 1, 2"):
            self.compostos_do_taxon.setdefault(r["taxon_id"], {})[r["fonte_id"]] = r["n"]
        for r in con.execute(f"SELECT taxon_id, COUNT(DISTINCT molecula_id) AS n FROM afirmacao "
                             f"WHERE tipo='composto_em_organismo' AND {sql_publica()} GROUP BY 1"):
            self.compostos_do_taxon.setdefault(r["taxon_id"], {})["total"] = r["n"]

        # sinônimos exibidos: fora os que o backbone marca como pro parte, mal aplicado ou duvidoso
        self.sinonimos = {}
        marcas = ",".join("?" * len(STATUS_DE_SINONIMO_FORA))
        # Só nomes que o backbone registra como sinônimo. Os nomes pelos quais a espécie foi procurada na semente e no
        # UniProt (`origem` 'semente' e 'uniprot') incluem nomes vernáculos e subespécies: não são sinônimos.
        for r in con.execute(f"SELECT taxon_id, nome, autoria, categoria FROM taxon_sinonimo "
                             f"WHERE origem = 'gbif' AND IFNULL(status_gbif, '') NOT IN ({marcas}) ORDER BY taxon_id, nome",
                             STATUS_DE_SINONIMO_FORA):
            s = {"nome": r["nome"]}
            if r["autoria"]:
                s["autoria"] = r["autoria"]
            if r["categoria"]:
                s["categoria"] = r["categoria"]
            self.sinonimos.setdefault(r["taxon_id"], []).append(s)

        self.bacias_nomes = {r["id"]: r["nome"] for r in con.execute("SELECT id, nome FROM bacia_hidrografica")}
        # Vias Reactome de cada alvo. A consulta citada é a do vínculo (a busca feita para o próprio alvo), não a da
        # linha da via, que guarda a busca do primeiro alvo em que a via apareceu.
        self.vias_por_alvo = {}
        for r in con.execute("SELECT av.alvo_id, vb.id AS via_id, vb.reactome_id, vb.nome, vb.especie, vb.doi, av.consulta_id "
                             "FROM alvo_via av JOIN via_biologica vb ON vb.id=av.via_id ORDER BY vb.reactome_id, av.alvo_id"):
            self.vias_por_alvo.setdefault(r["alvo_id"], []).append(dict(r))
        from ..conformeros import validar_arquivo
        from . import ensembles
        pastas = (pasta_3d, config.SAIDA_DIR) if pasta_3d else (config.SAIDA_DIR, config.APP_DIR / "dados")
        self.estruturas3d = {}
        self.estruturas3d_alvo = {}
        for r in con.execute(
            "SELECT * FROM estrutura_3d ORDER BY CASE natureza WHEN 'experimental' THEN 0 WHEN 'predicao_computacional' THEN 1 ELSE 2 END, COALESCE(resolucao_angstrom, 999.0) ASC, id"
        ):
            d3 = dict(r)
            if r["molecula_id"] and r["molecula_id"] in self.mols_publicas:
                grafo = validar_arquivo(r, self.mol[r["molecula_id"]], pastas)
                if grafo is not False:
                    if pasta_3d:
                        ref = ensembles.referencia(pasta_3d, r["arquivo_geometria"], r["geometria_sha256"])
                        if ref:
                            d3["arquivo_publico"] = ref
                    if grafo:
                        d3["grafo_validado"] = grafo
                    self.estruturas3d.setdefault(r["molecula_id"], []).append(d3)
            if r["alvo_id"] and r["alvo_id"] in self.alvos_publicos:
                self.estruturas3d_alvo.setdefault(r["alvo_id"], []).append(d3)
        self.por_conectividade = {}
        for mid in sorted(self.mols_publicas):
            m_ = self.mol[mid]
            bl = conectividade(m_)
            if bl:
                self.por_conectividade.setdefault(bl, []).append({
                    "id": mid,
                    "nome": m_["nome"],
                    "inchikey": m_["inchikey"],
                    "tem_3d": bool(self.estruturas3d.get(mid)),
                })
        self._afirmacoes_exportadas = self._referencias_citadas = self._consultas_publicas = self._contagens = None

    # ── o que é público ──
    def ref_publica(self, rid):
        """Id da obra citável que corresponde à linha `rid` de `referencia`; None se a obra não sai.

        Uma linha marcada como duplicata remete à obra de que é cópia; obra retida ou retratada não é citada.
        """
        r = self.refs.get(rid)
        if r is not None and r.get("duplicata_de"):
            rid = r["duplicata_de"]
            r = self.refs.get(rid)
        if r is None or r.get("duplicata_de") or r.get("estado", "ativa") != "ativa" or r.get("retratada"):
            return None
        return rid

    def mol_publica(self, mid):
        return mid in self.mols_publicas

    def contagens(self):
        """Contagens do que é público (ver `contagens`), calculadas uma vez por contexto."""
        if self._contagens is None:
            self._contagens = contagens(self)
        return self._contagens

    def afirmacoes_exportadas(self):
        """Ids de todas as afirmações que saem (a mesma seleção de `sql_afirmacao_exportada`)."""
        if self._afirmacoes_exportadas is None:
            self._afirmacoes_exportadas = {r[0] for r in self.con.execute(
                f"SELECT a.id FROM afirmacao a WHERE {sql_afirmacao_exportada('a')}")}
        return self._afirmacoes_exportadas

    def referencias_citadas(self):
        """Ids das obras citáveis que algum registro público cita: afirmação, passagem, leitura de curador ou linhagem."""
        if self._referencias_citadas is None:
            ids, exportadas = set(), self.afirmacoes_exportadas()
            for aid in exportadas:
                ids.update(self.refs_da_af.get(aid, ()))
            marcas = sql_afirmacao_exportada("a")
            for r in self.con.execute(f"SELECT a.id, a.estado, a.passagem_referencia_id, a.procedencia_artigo_referencia_id "
                                      f"FROM afirmacao a WHERE {marcas} AND (a.passagem_referencia_id IS NOT NULL "
                                      f"OR a.procedencia_artigo_referencia_id IS NOT NULL OR a.estado='verificado')"):
                candidatos = [r["passagem_referencia_id"], r["procedencia_artigo_referencia_id"]]
                if r["estado"] == "verificado" and r["id"] in self.verificacao:
                    candidatos.append(self.verificacao[r["id"]]["referencia_id"])
                ids.update(x for x in (self.ref_publica(c) for c in candidatos if c) if x is not None)
            ids.update(x for x in (self.ref_publica(d["referencia_id"]) for d in self.linhagens) if x is not None)
            self._referencias_citadas = ids
        return self._referencias_citadas

    def consultas_publicas(self):
        """Ids das consultas que sustentam algum registro público: a proveniência do que sai, e só dela."""
        if self._consultas_publicas is not None:
            return self._consultas_publicas
        con, ids = self.con, set()

        def juntar(sql, params=()):
            for r in con.execute(sql, params):
                ids.update(v for v in r if v is not None)

        juntar("SELECT ocorr_consulta_id, iucn_consulta_id, lotus_consulta_id, uniprot_consulta_id, checklist_consulta_id, "
               "bioma_consulta_id FROM taxon")
        juntar("SELECT DISTINCT consulta_id FROM ocorrencia_uf")
        juntar("SELECT DISTINCT consulta_id FROM ocorrencia_bacia")
        juntar("SELECT consulta_id FROM territorio")
        juntar("SELECT consulta_id FROM bacia_hidrografica")
        juntar("SELECT DISTINCT gbif_consulta_id, pressao_consulta_id FROM celula_lacuna")
        juntar("SELECT DISTINCT consulta_id FROM universo_checklist WHERE bioma_amazonia_declarado=1")
        juntar("SELECT DISTINCT consulta_id FROM midia WHERE estado='ativo' AND arquivo IS NOT NULL")
        juntar(f"SELECT DISTINCT consulta_id FROM taxon_sinonimo WHERE origem = 'gbif' AND IFNULL(status_gbif, '') NOT IN "
               f"({','.join('?' * len(STATUS_DE_SINONIMO_FORA))})", STATUS_DE_SINONIMO_FORA)
        juntar(f"SELECT DISTINCT a.consulta_id FROM afirmacao a WHERE {sql_afirmacao_exportada('a')}")
        for mid in self.mols_publicas:
            m = self.mol[mid]
            ids.update(v for v in (m.get("pubchem_consulta_id"), m.get("fase_consulta_id"), m.get("atividades_consulta_id"),
                                   m.get("medidas_consulta_id")) if v)
        for rid in self.referencias_citadas():
            r = self.refs[rid]
            ids.update(v for v in (r.get("consulta_id"), r.get("texto_consulta_id")) if v)
        ids.update(d["consulta_id"] for d in self.linhagens if d.get("consulta_id"))
        for lista in (*self.estruturas3d.values(), *self.estruturas3d_alvo.values()):
            ids.update(e["consulta_id"] for e in lista if e.get("consulta_id"))
        for aid in self.alvos_publicos:
            if self.alvos[aid].get("alvo_consulta_id"):
                ids.add(self.alvos[aid]["alvo_consulta_id"])
            ids.update(v["consulta_id"] for v in self.vias_por_alvo.get(aid, ()) if v.get("consulta_id"))
        self._consultas_publicas = {i for i in ids if i in self.consultas}
        return self._consultas_publicas


class Pacote:
    """Lista de referências e de consultas de UM pacote, com remissão por índice."""

    def __init__(self, ctx):
        self.ctx, self.refs, self.consultas = ctx, [], []
        self._r, self._c = {}, {}

    def ref(self, rid):
        """Índice, na lista `refs` do pacote, da obra citável da linha `rid`; None se a obra não sai."""
        rid = self.ctx.ref_publica(rid)
        if rid is None:
            return None
        if rid not in self._r:
            r = self.ctx.refs[rid]
            autores = json.loads(r["autores"]) if r["autores"] else []
            self._r[rid] = len(self.refs)
            item = {"doi": r["doi"], "pmid": r["pmid"], "titulo": r["titulo"],
                    "autores": (autores[:3] + (["et al."] if len(autores) > 3 else [])),
                    "revista": r["revista"], "ano": r["ano"], "aviso": r["aviso"], "resolvida": bool(r["resolvida"])}
            if r.get("tipo_obra"):
                item["tipo_obra"] = r["tipo_obra"]
            if r.get("texto_nivel"):
                item["texto_nivel"] = r["texto_nivel"]
            self.refs.append(item)
        return self._r[rid]

    def consulta(self, cid):
        if cid is None:
            return None
        if cid not in self._c:
            c = self.ctx.consultas[cid]
            f = self.ctx.fontes[c["fonte_id"]]
            self._c[cid] = len(self.consultas)
            self.consultas.append({"fonte": c["fonte_id"], "fonte_nome": f["nome"], "licenca": f["licenca"],
                                   "url": c["url"], "data": c["consultado_em"][:10], "versao": c["versao_fonte"]})
        return self._c[cid]

    def fechar(self, corpo):
        corpo["refs"], corpo["consultas"] = self.refs, self.consultas
        return corpo


# ═══════════════════════════ afirmação em forma pública ═══════════════════════════
_SO_UFS = re.compile(r"^[A-Z]{2}(?:, ?[A-Z]{2})*$")
_SO_PAIS = re.compile(r"^[A-Z]{2}$")
_SO_PAIS_UF = re.compile(r"^[A-Z]{2}(?:-[A-Z]{2})?$")
_ORIGEM_DA_PASSAGEM_POR_TIPO = {"funcao_toxina": "anotacao_uniprot", "efeito_clinico_documentado": "mecanismo_chembl"}
# Passagens que são frase de artigo (digitada por curador ou localizada no resumo ou no texto aberto): o texto só sai
# sem localidade mais fina que país e UF. Anotação do UniProt e mecanismo do ChEMBL descrevem função, não coleta.
_ORIGENS_DE_TEXTO_DE_ARTIGO = ("curador", "resumo", "texto_completo_aberto")


def passagem_publica(ctx, a):
    """Passagem que sustenta a afirmação: (texto ou None, origem ou None, id da referência de onde saiu ou None).

    Afirmação verificada: vale o trecho que o curador conferiu, como está em `verificacao`. Nas demais vale o que a
    conferência automática ou a base de origem gravaram; a frase só vem em texto quando pôde ser guardada (obra de
    acesso aberto, sem local de coleta) — do contrário sai a origem e a obra, sem o texto. Frase de artigo, digitada
    por curador ou localizada no resumo ou no texto aberto, passa pelo limite de localidade da curadoria: nada mais
    fino que país e UF sai, nem em citação.
    """
    v = ctx.verificacao.get(a["id"]) if a["estado"] == "verificado" else None
    if v is not None:
        trecho = v["passagem_conferida"]
        return (None if curadoria.localidade_fina(trecho) else trecho), "curador", v["referencia_id"]
    trecho, origem = a["passagem"], a.get("passagem_origem")
    if origem is None and trecho:
        origem = _ORIGEM_DA_PASSAGEM_POR_TIPO.get(a["tipo"])
    if origem in _ORIGENS_DE_TEXTO_DE_ARTIGO and curadoria.localidade_fina(trecho):
        trecho = None
    return trecho, origem, a.get("passagem_referencia_id")


def organismo_na_fonte(ctx, a):
    """Nome(s) pelo(s) qual(is) a fonte chama o organismo, quando diferem do nome aceito do táxon; None se são iguais."""
    aceito = " ".join((ctx.taxon_nome.get(a.get("taxon_id")) or "").split()).casefold()
    nomes = [" ".join(n.split()) for n in (a.get("organismo_na_fonte") or "").split(";")]
    diferentes = [n for n in nomes if n and n.casefold() != aceito]
    return "; ".join(dict.fromkeys(diferentes)) or None


def _campos_de_organismo(pk, a):
    """Procedência declarada, país e UF de coleta e o que o artigo declara: só em afirmação ligada a organismo.

    País é ISO-2 e UF é sigla; valor fora desse formato não sai (nenhum campo leva localidade mais fina).
    `pk` é o pacote em que a obra do artigo é citada por índice; sem pacote (tabelas), o índice não é emitido.
    """
    if a["tipo"] not in TIPOS_DE_ORGANISMO:
        return {}
    d = {"procedencia": a.get("procedencia_declarada") or "nao_declarada"}
    if a.get("uf_coleta_declarada") and _SO_UFS.match(a["uf_coleta_declarada"]):
        d["uf_coleta"] = a["uf_coleta_declarada"]
    if a.get("pais_coleta_declarado") and _SO_PAIS.match(a["pais_coleta_declarado"]):
        d["pais_coleta"] = a["pais_coleta_declarado"]
    if a.get("procedencia_artigo"):
        pa = {"classe": a["procedencia_artigo"]}
        if a.get("procedencia_artigo_local") and _SO_PAIS_UF.match(a["procedencia_artigo_local"]):
            pa["local"] = a["procedencia_artigo_local"]
        idx = pk.ref(a["procedencia_artigo_referencia_id"]) if pk is not None and a.get("procedencia_artigo_referencia_id") else None
        if idx is not None:
            pa["ref"] = idx
        d["procedencia_artigo"] = pa
    return d


def _medida(a):
    """Medida de um par molécula–alvo: valor central em nM, quantas medidas e publicações o sustentam e a faixa observada."""
    m = {"tipo": a["medida_tipo"], "valor": a["medida_valor"], "unidade": a["medida_unidade"],
         "agregacao": a.get("medida_agregacao"), "n": a.get("medida_n"), "n_publicacoes": a.get("medida_n_documentos"),
         "min": a.get("medida_min"), "max": a.get("medida_max")}
    if a["medida_relacao"] and a["medida_relacao"] != "=":
        m["relacao"] = a["medida_relacao"]          # o valor central de um agregado é sempre «=»; outra relação nunca é omitida
    return m


def _alvo(alvo):
    return {"nome": alvo["nome"], "organismo": alvo["organismo"], "chembl": alvo["chembl_id"], "uniprot": alvo["uniprot_acc"],
            "natureza": alvo.get("natureza") or "indeterminado"}


def _afirmacao(ctx, pk, a, completa=False):
    """Afirmação em forma pública (contrato §3.1). `completa` inclui o perfil de prontidão por dimensão."""
    a_d = dict(a)
    p = ctx.prontidao.get(a_d["id"], {})
    passagem, origem_passagem, ref_passagem = passagem_publica(ctx, a_d)
    d = {"id": a_d["id"], "tipo": a_d["tipo"], "estado": a_d["estado"], "enunciado": a_d["texto"],
         "evidencia": a_d.get("nivel_evidencia") or "base_curada", "passagem": passagem,
         "metodo": a_d["metodo"], "refs": [pk.ref(r) for r in ctx.refs_da_af.get(a_d["id"], [])],
         "fonte": a_d["fonte_id"], "consulta": pk.consulta(a_d["consulta_id"]), "indice": p.get("indice")}
    if origem_passagem:
        d["passagem_origem"] = origem_passagem
        idx = pk.ref(ref_passagem) if ref_passagem else None
        if idx is not None:
            d["passagem_ref"] = idx
    if a_d["tipo"] in TIPOS_DE_ORGANISMO:
        nome_na_fonte = organismo_na_fonte(ctx, a_d)
        if nome_na_fonte:
            d["organismo_na_fonte"] = nome_na_fonte
        d.update(_campos_de_organismo(pk, a_d))
        voucher = voucher_publico(a_d.get("voucher_declarado_base"))
        if voucher:
            d["voucher_base"] = voucher
    if a_d.get("validacao_manual_fonte"):
        d["validacao_fonte"] = bool(a_d["validacao_manual_fonte"])
    if a_d.get("escopo_referencia") and a_d["escopo_referencia"] != "especifica":
        d["escopo_ref"] = a_d["escopo_referencia"]
    if a_d["tipo"] == "atividade_biologica":
        d["medida"] = _medida(a_d)
        if a_d.get("ensaio_tipo"):
            d["ensaio_tipo"] = a_d["ensaio_tipo"]
        alvo = ctx.alvos.get(a_d["alvo_id"]) if a_d["alvo_id"] else None
        d["alvo"] = _alvo(alvo) if alvo else None
    if a_d["tipo"] == "efeito_clinico_documentado":
        fontes_reg = [{"tipo": x.get("tipo"), "id": x.get("id"), "url": x.get("url")}
                      for x in _lista_json(a_d.get("fontes_regulatorias")) if isinstance(x, dict) and x.get("tipo") and x.get("id")]
        if fontes_reg:
            d["fontes_regulatorias"] = fontes_reg
    v = ctx.verificacao.get(a_d["id"]) if a_d["estado"] == "verificado" else None
    if v:
        # Da leitura do curador sai o que é estruturado: a classe geográfica que ele marcou, não o texto que digitou.
        d["verificacao"] = {"em": v["em"][:10], "curador": v["curador"], "decisao": v["decisao"],
                            "referencia": pk.ref(v["referencia_id"]) if v["referencia_id"] else None,
                            "acesso_texto": v.get("acesso_texto"), "escopo_geografico_lido": v.get("escopo_geografico_lido"),
                            "voucher": curadoria.voucher_de_colecao(v["voucher"])}
    if completa:
        d["prontidao"] = {k: p.get(k) for k in config.DIMENSOES}
        d["notas"] = p.get("notas")
    return d


# ═══════════════════════════ pacote de táxon ═══════════════════════════
def _foco_par(r):
    if r["foco_x"] is None or r["foco_y"] is None:
        return None
    return [round(r["foco_x"], 1), round(r["foco_y"], 1)]


LOTE_MOL_TAXON = 115


def massa_publica(m):
    """`massa` pública é a monoisotópica calculada da estrutura; sem ela, o campo fica vazio em vez de trazer a da fonte."""
    return m.get("massa_monoisotopica")


def _representante(afs):
    """Entre as afirmações públicas de um mesmo par táxon–molécula, a de evidência mais forte; no empate, a que tem
    coleta amazônica declarada e, depois, a mais antiga."""
    def chave(a):
        ev = ORDEM_EVIDENCIA.index(a["nivel_evidencia"]) if a["nivel_evidencia"] in ORDEM_EVIDENCIA else len(ORDEM_EVIDENCIA)
        return (ev, 0 if a["procedencia_declarada"] in procedencia.PROCEDENCIA_AMAZONICA_DECLARADA else 1, a["id"])
    return min(afs, key=chave)


def _refs_do_par(ctx, afs):
    return sorted({r for x in afs for r in ctx.refs_da_af.get(x["id"], [])})


def _item_molecula_taxon(ctx, pk, mid, afs):
    m = ctx.mol[mid]
    a = dict(_representante(afs))
    fontes_af = sorted({x["fonte_id"] for x in afs})
    af = {"id": a["id"], "tipo": a["tipo"], "estado": a["estado"], "evidencia": a.get("nivel_evidencia") or "base_curada",
          "indice": ctx.prontidao.get(a["id"], {}).get("indice"),
          "refs": [pk.ref(r) for r in ctx.refs_da_af.get(a["id"], [])]}
    af.update(_campos_de_organismo(pk, a))
    if a.get("escopo_referencia") and a["escopo_referencia"] != "especifica":
        af["escopo_ref"] = a["escopo_referencia"]
    if a["tipo"] == "funcao_toxina":
        af["passagem"] = passagem_publica(ctx, a)[0]
        af["experimental"] = "ECO:0000269" in (a["metodo"] or "")
    aprovado = mid in ctx.clinico
    massa = massa_publica(m)
    return {
        "id": mid, "nome": m["nome"], "tipo": m["tipo"], "classe": m["classe_quimica"], "familia": m["familia"],
        "formula": m["formula"], "massa": round(massa, 2) if massa else None, "uniprot": m["uniprot_acc"],
        "comprimento_aa": m["comprimento_aa"], "estrutura": m["desenho"], "n_publicacoes": len(_refs_do_par(ctx, afs)),
        "n_atividades": ctx.n_ativ.get(mid, 0), "aprovado": aprovado,
        **({"retirado": True} if aprovado and m["fase_retirado"] else {}),
        **({"categoria_clinica": m["categoria_clinica"]} if aprovado and m["categoria_clinica"] else {}),
        **({"pains": True} if m["alerta_pains"] else {}),
        **({"fontes": fontes_af} if len(fontes_af) > 1 or (fontes_af and fontes_af[0] not in ("lotus", "uniprot")) else {}),
        **({"n_afirmacoes": len(afs)} if len(afs) > 1 else {}),
        "afirmacao": af,
    }


def _decodificar_biocultural(valor):
    if not valor or not str(valor).strip():
        return []
    s = str(valor).strip()
    if s.startswith("["):
        try:
            d = json.loads(s)
            return d if isinstance(d, list) else [{"nota": str(d)}]
        except json.JSONDecodeError:
            return [{"nota": s}]
    if s.startswith("{"):
        try:
            d = json.loads(s)
            return [d] if isinstance(d, dict) else [{"nota": str(d)}]
        except json.JSONDecodeError:
            return [{"nota": s}]
    return [{"nota": s}]


def cobertura_do_taxon(ctx, td):
    """Moléculas com afirmação pública de composto no táxon, no total e por base. None = fonte não consultada para o
    táxon; 0 = consultada e sem composto (ausência declarada)."""
    c = ctx.compostos_do_taxon.get(td["id"], {})
    consultado = td.get("lotus_consulta_id") is not None or bool(c)
    valor = lambda chave: c.get(chave, 0) if consultado else None
    return {"compostos": valor("total"), "compostos_lotus": valor("lotus"), "compostos_nubbe": valor("nubbe"),
            "compostos_npatlas": valor("npatlas")}


def pacote_taxon(ctx, t, paginar=False):
    con, pk = ctx.con, Pacote(ctx)
    uf = {r["uf_sigla"]: r["n"] for r in con.execute("SELECT uf_sigla, n FROM ocorrencia_uf WHERE taxon_id=? ORDER BY uf_sigla", (t["id"],))}
    bacias = [
        {"id": r["bacia_id"], "nome": ctx.bacias_nomes.get(r["bacia_id"], r["bacia_id"]),
         "n": r["n"], "consulta": pk.consulta(r["consulta_id"])}
        for r in con.execute("SELECT * FROM ocorrencia_bacia WHERE taxon_id=? AND n > 0 ORDER BY n DESC, bacia_id", (t["id"],))
    ]
    biocult = _decodificar_biocultural(t["contexto_biocultural"])
    imagens = [{"arquivo": r["arquivo"], "largura": r["largura"], "altura": r["altura"], "autor": r["autor"],
                "licenca": r["licenca"], "pagina": r["pagina"], "instituicao": r["instituicao"],
                **({"pais": r["pais"]} if r["pais"] else {}),
                **({"v": r["arquivo_sha256"][:6]} if r["arquivo_sha256"] else {}),
                **({"foco": _foco_par(r)} if _foco_par(r) else {}),
                **({"nota": round(r["nota_enquadramento"], 3)} if r["nota_enquadramento"] is not None else {})}
               for r in con.execute(
                   "SELECT * FROM midia WHERE taxon_id=? AND estado='ativo' AND arquivo IS NOT NULL ORDER BY COALESCE(nota_enquadramento, 0) DESC, id ASC",
                   (t["id"],))]
    populares = json.loads(t["nomes_populares"]) if t["nomes_populares"] else []
    biomas_br = json.loads(t["biomas_json"]) if t["biomas_json"] else []

    por_mol = {}
    cids_nubbe, cids_npatlas = set(), set()
    for a in con.execute(f"SELECT * FROM afirmacao WHERE taxon_id=? AND estado IN {SQL_PUBLICO} ORDER BY id", (t["id"],)):
        por_mol.setdefault(a["molecula_id"], []).append(a)
        if a["fonte_id"] == "nubbe" and a["consulta_id"]:
            cids_nubbe.add(a["consulta_id"])
        elif a["fonte_id"] == "npatlas" and a["consulta_id"]:
            cids_npatlas.add(a["consulta_id"])

    # Ordena antes de materializar as referências no Pacote, para que cada página leve só suas próprias referências
    chaves_ord = []
    for mid, afs in por_mol.items():
        chaves_ord.append((-len(_refs_do_par(ctx, afs)), -ctx.n_ativ.get(mid, 0), ctx.mol[mid]["nome"].lower(), mid))
    chaves_ord.sort()
    mids_ord = [x[3] for x in chaves_ord]

    paginas_extras = []
    nomes_paginas = []
    if paginar and len(mids_ord) > LOTE_MOL_TAXON:
        mids_principais = mids_ord[:LOTE_MOL_TAXON]
        for idx_pag, ini in enumerate(range(LOTE_MOL_TAXON, len(mids_ord), LOTE_MOL_TAXON), start=2):
            fatia_ids = mids_ord[ini:ini + LOTE_MOL_TAXON]
            pk_p = Pacote(ctx)
            itens_p = [_item_molecula_taxon(ctx, pk_p, mid, por_mol[mid]) for mid in fatia_ids]
            arq_nome = f"{t['gbif_key']}_p{idx_pag}.json"
            nomes_paginas.append(f"dados/taxa/{arq_nome}")
            paginas_extras.append((arq_nome, pk_p.fechar({
                "esquema": 1, "gbif": t["gbif_key"], "pagina": idx_pag, "moleculas": itens_p,
            })))
    else:
        mids_principais = mids_ord

    moleculas = [_item_molecula_taxon(ctx, pk, mid, por_mol[mid]) for mid in mids_principais]

    td = dict(t)
    corpo = {
        "esquema": 1, "id": td["id"], "gbif": td["gbif_key"], "nome": td["nome"], "autoria": td["autoria"], "grupo": td["grupo"],
        "taxonomia": {k: td[k] for k in ("reino", "filo", "classe", "ordem", "familia", "genero")},
        "populares": populares, "sinonimos": ctx.sinonimos.get(td["id"], []),
        "origem_estabelecimento": td.get("origem_estabelecimento"),
        "distribuicao_br": td.get("distribuicao_br") or "indeterminada",
        "ecologia": {
            "endemismo_br": td.get("endemismo_br"),
            "biomas": biomas_br,
            "forma_vida": td.get("forma_vida"),
            "estrato_florestal": td.get("estrato_florestal"),
            "categoria_mma": td.get("categoria_mma"),
            "fonte_checklist": td.get("checklist_fonte"),
            "consulta": pk.consulta(td.get("checklist_consulta_id")),
        },
        "iucn": {"categoria": td["iucn"], "consulta": pk.consulta(td["iucn_consulta_id"])} if td.get("iucn_consulta_id") else None,
        "recorte": {"dentro": bool(td["no_recorte"]), "n_al": td["n_al"], "n_al_exato": td.get("n_al_exato"),
                    "n_br": td["n_br"], "n_br_com_uf": td["n_br_com_uf"],
                    "n_bioma_amazonia": td.get("n_bioma_amazonia"), "n_ma_oeste44": td.get("n_ma_oeste44"),
                    "consulta_bioma": pk.consulta(td.get("bioma_consulta_id")),
                    "fracao_com_uf": td["fracao_al_com_uf"], "fracao_total": td["fracao_al_total"], "predominio": td["predominio_al"],
                    "motivo": td["motivo_recorte"], "consulta": pk.consulta(td["ocorr_consulta_id"]),
                    "origem_inclusao": td["origem_inclusao"], "correspondencia_gbif": td["gbif_correspondencia"],
                    "confianca_gbif": td["gbif_confianca"]},
        "uf": uf,
        "bacias": bacias,
        "contexto_biocultural": biocult,
        "imagens": imagens,
        "cobertura": {**cobertura_do_taxon(ctx, td),
                      "consulta_lotus": pk.consulta(td["lotus_consulta_id"]), "toxinas_fonte": td["toxinas_fonte"],
                      "consulta_uniprot": pk.consulta(td["uniprot_consulta_id"]),
                      "consulta_nubbe": pk.consulta(min(cids_nubbe)) if cids_nubbe else None,
                      "consulta_npatlas": pk.consulta(min(cids_npatlas)) if cids_npatlas else None},
        "total_moleculas": len(mids_ord),
        "paginas_moleculas": nomes_paginas,
        "moleculas": moleculas,
    }
    fechado = pk.fechar(corpo)
    return (fechado, paginas_extras) if paginar else fechado


# ═══════════════════════════ pacote de molécula ═══════════════════════════
LIMITE_OCORRE_PACOTE = 80
LIMITE_ATIV_PACOTE = 60


def _linhagem(ctx, pk, papel, rel):
    """Linhagem em forma pública, vista da molécula que ocupa o `papel` ('origem' ou 'destino')."""
    outro = ctx.mol[rel["destino_id"] if papel == "origem" else rel["origem_id"]]
    idx = pk.ref(rel["referencia_id"])
    return {
        "papel": papel,  # 'origem' (molécula natural/protótipo) ou 'destino' (fármaco bioinspirado)
        "tipo": rel["tipo"],
        "parceiro": {"id": outro["id"], "nome": outro["nome"], "chembl": outro["chembl_id"],
                     "estrutura": outro["desenho"], "fase": outro["max_fase_clinica"]},
        "texto": rel["texto"],
        "trecho": rel.get("trecho"), "trecho_fonte": rel.get("trecho_fonte"),
        "refs": [idx] if idx is not None else [],
        "consulta": pk.consulta(rel["consulta_id"]),
    }


def pacote_molecula(ctx, m):
    """Pacote de uma molécula pública (quem chama confere `ctx.mol_publica`)."""
    m = dict(m)
    con, pk = ctx.con, Pacote(ctx)
    mid = m["id"]
    amz = procedencia.PROCEDENCIA_AMAZONICA_DECLARADA
    # Ocorrências: táxons do recorte primeiro; depois evidência mais forte e coleta amazônica declarada.
    linhas_oc = con.execute(
        f"SELECT a.*, t.gbif_key, t.nome AS t_nome, t.grupo, t.nomes_populares, t.no_recorte FROM afirmacao a "
        f"JOIN taxon t ON t.id=a.taxon_id WHERE a.molecula_id=? AND a.estado IN {SQL_PUBLICO} "
        f"ORDER BY t.no_recorte DESC, {_SQL_ORDEM_EVIDENCIA.format(c='a.nivel_evidencia')}, "
        f"CASE WHEN a.procedencia_declarada IN ({','.join('?' * len(amz))}) THEN 0 ELSE 1 END, t.nome, a.id",
        (mid, *amz),
    ).fetchall()
    # Em moléculas ubíquas (p.ex. beta-sitosterol, quercetina), limita a 80 ocorrências e declara o total exato (Princípio 2)
    ocorre = []
    for idx_o, r in enumerate(linhas_oc[:LIMITE_OCORRE_PACOTE]):
        pop = json.loads(r["nomes_populares"]) if r["nomes_populares"] else []
        ocorre.append({"taxon": r["taxon_id"], "gbif": r["gbif_key"], "nome": r["t_nome"], "grupo": r["grupo"],
                       "popular": pop[0]["nome"] if pop else None, "no_recorte": bool(r["no_recorte"]),
                       "afirmacao": _afirmacao(ctx, pk, r, completa=(idx_o < 35))})
    # Atividades: alvo molecular individual primeiro, depois o par mais documentado. A potência só desempata.
    linhas_ativ = con.execute(
        f"SELECT a.* FROM afirmacao a LEFT JOIN alvo l ON l.id=a.alvo_id "
        f"WHERE a.molecula_id=? AND a.tipo='atividade_biologica' AND a.estado IN {SQL_PUBLICO} "
        f"ORDER BY CASE l.natureza WHEN 'proteina_unica' THEN 0 WHEN 'complexo_proteico' THEN 1 WHEN 'familia_proteica' THEN 2 ELSE 3 END, "
        f"COALESCE(a.medida_n_documentos, 0) DESC, COALESCE(a.medida_n, 0) DESC, a.medida_valor, a.id", (mid,),
    ).fetchall()
    atividades = []
    for idx_a, r in enumerate(linhas_ativ[:LIMITE_ATIV_PACOTE]):
        a = _afirmacao(ctx, pk, r, completa=(idx_a < 25))
        if a["alvo"] is not None:
            vias = [
                {"id": v["reactome_id"], "nome": v["nome"], "consulta": pk.consulta(v["consulta_id"])}
                for v in ctx.vias_por_alvo.get(r["alvo_id"], [])[:3]
            ]
            if vias:
                a["alvo"]["vias_reactome"] = vias
            if ctx.estruturas3d_alvo.get(r["alvo_id"]):
                ea = ctx.estruturas3d_alvo[r["alvo_id"]][0]
                a["alvo"]["estrutura_3d"] = {
                    "natureza": ea["natureza"], "fonte": ea["fonte_id"], "acesso": ea["codigo"],
                    "metodo": ea["metodo"], "resolucao": ea["resolucao_angstrom"], "plddt": ea["plddt_medio"],
                    "arquivo": ea["arquivo_geometria"], "consulta": pk.consulta(ea["consulta_id"]),
                }
        a["sistema"] = r["sistema_experimental"]
        atividades.append(a)
    clinico = None
    cid = ctx.clinico.get(mid)
    if cid:
        a = con.execute("SELECT * FROM afirmacao WHERE id=?", (cid,)).fetchone()
        clinico = _afirmacao(ctx, pk, a, completa=True)

    from ..conformeros import limitacao
    estruturas_3d = [
        {
            "id": e["id"],
            "natureza": e["natureza"], "fonte": e["fonte_id"], "acesso": e["codigo"],
            "metodo": e["metodo"], "resolucao": e["resolucao_angstrom"], "plddt": e["plddt_medio"],
            "energia_kcal_mol": e["energia_kcal_mol"], "n_elementos": e["n_atomos_ou_residuos"],
            "n_ss": e["n_pontes_dissulfeto"], "tem_sdf_3d": bool(e.get("tem_sdf_3d")),
            "arquivo": e.get("arquivo_publico") or e["arquivo_geometria"], "sha256": e["geometria_sha256"],
            **({"grafo_validado": e["grafo_validado"]} if e.get("grafo_validado") else {}),
            "consulta": pk.consulta(e["consulta_id"]),
        }
        for e in ctx.estruturas3d.get(mid, [])
    ]

    linhagens = [_linhagem(ctx, pk, papel, rel) for papel, rel in ctx.relacoes_mol.get(mid, [])]

    fq = None
    if any(m.get(k) is not None for k in ("clogp", "tpsa", "fsp3", "qed", "np_likeness")):
        fq = {
            "clogp": m.get("clogp"), "tpsa": m.get("tpsa"), "fsp3": m.get("fsp3"),
            "hbd": m.get("hbd"), "hba": m.get("hba"), "qed": m.get("qed"),
            "np_likeness": m.get("np_likeness"), "murcko_smiles": m.get("murcko_smiles"),
            "umap": [round(m["umap_x"], 4), round(m["umap_y"], 4)] if m.get("umap_x") is not None and m.get("umap_y") is not None else None,
        }

    bloco = conectividade(m)
    corpo = {
        "esquema": 1, "id": mid, "nome": m["nome"], "nome_na_fonte": m["nome_na_fonte"], "nome_divergente": bool(m["nome_divergente"]),
        "tipo": m["tipo"], "classe": m["classe_quimica"], "familia": m["familia"], "formula": m["formula"],
        "massa": massa_publica(m), "massa_monoisotopica": m.get("massa_monoisotopica"), "massa_media": m.get("massa_media"),
        "comprimento_aa": m["comprimento_aa"], "inchikey": m["inchikey"], "conectividade": bloco,
        "n_mesma_conectividade": ctx.n_conectividade.get(bloco) if bloco else None,
        "mesma_conectividade": [x for x in ctx.por_conectividade.get(bloco, ()) if x["id"] != mid][:12] if bloco else [],
        "estereocentros": m.get("estereocentros"), "estereocentros_indefinidos": m.get("estereocentros_indefinidos"),
        "smiles": m["smiles"], "estrutura": m["desenho"],
        "ids": {"pubchem": m["pubchem_cid"], "chembl": m["chembl_id"], "lotus": m["lotus_id"], "uniprot": m["uniprot_acc"],
                "nubbe": m.get("nubbe_id"), "npatlas": m.get("npatlas_id"),
                "pdb": json.loads(m["pdb_ids"]) if m["pdb_ids"] else []},
        "fisico_quimica": fq,
        "estruturas_3d": estruturas_3d,
        **({"limitacao_3d": limitacao(m["smiles"], m["inchikey"])} if not estruturas_3d and m["tipo"] == "pequena_molecula" else {}),
        "linhagens": linhagens,
        "fase": {"maxima": m["max_fase_clinica"], "retirado": None if m["fase_retirado"] is None else bool(m["fase_retirado"]),
                 "categoria_clinica": m["categoria_clinica"], "consulta": pk.consulta(m["fase_consulta_id"])},
        "pains": [x.strip() for x in (m["alerta_pains"] or "").split(";") if x.strip()],
        "controle_regulatorio": m["controle_regulatorio"],
        "total_ocorrencias": len(linhas_oc),
        "ocorrencias_truncadas": max(0, len(linhas_oc) - len(ocorre)),
        "total_atividades": len(linhas_ativ),
        "atividades_truncadas": max(0, len(linhas_ativ) - len(atividades)),
        "ocorre_em": ocorre, "atividades": atividades, "clinico": clinico,
    }
    return pk.fechar(corpo)


# ═══════════════════════════ índices ═══════════════════════════
def indice_taxa(ctx):
    con = ctx.con
    ufs = {}
    for r in con.execute("SELECT taxon_id, uf_sigla, n FROM ocorrencia_uf WHERE n > 0"):
        ufs.setdefault(r["taxon_id"], {})[r["uf_sigla"]] = r["n"]
    bacias = {}
    for r in con.execute("SELECT taxon_id, bacia_id, n FROM ocorrencia_bacia WHERE n > 0"):
        bacias.setdefault(r["taxon_id"], {})[r["bacia_id"]] = r["n"]
    n_img = {r[0]: r[1] for r in con.execute("SELECT taxon_id, COUNT(*) FROM midia WHERE estado='ativo' AND arquivo IS NOT NULL GROUP BY 1")}
    foco_capa = {}
    for r in con.execute(
            "SELECT taxon_id, foco_x, foco_y FROM midia WHERE estado='ativo' AND arquivo IS NOT NULL ORDER BY COALESCE(nota_enquadramento, 0) DESC, id ASC"):
        if r["taxon_id"] not in foco_capa and r["foco_x"] is not None and r["foco_y"] is not None:
            fx, fy = round(r["foco_x"]), round(r["foco_y"])
            foco_capa[r["taxon_id"]] = [fx, fy] if (abs(fx - 50) >= 6 or abs(fy - 46) >= 6) else 0
    n_mol = {r[0]: r[1] for r in con.execute(
        f"SELECT taxon_id, COUNT(DISTINCT molecula_id) FROM afirmacao WHERE taxon_id IS NOT NULL AND estado IN {SQL_PUBLICO} GROUP BY 1")}
    n_af = {r[0]: r[1] for r in con.execute(
        f"SELECT taxon_id, COUNT(*) FROM afirmacao WHERE taxon_id IS NOT NULL AND estado IN {SQL_PUBLICO} GROUP BY 1")}
    n_ver = {r[0]: r[1] for r in con.execute(
        "SELECT taxon_id, COUNT(*) FROM afirmacao WHERE taxon_id IS NOT NULL AND estado='verificado' AND classe_acesso='publico' GROUP BY 1")}
    aprov = {r["taxon_id"] for r in con.execute(
        f"SELECT DISTINCT a.taxon_id, a.molecula_id FROM afirmacao a JOIN molecula m ON m.id=a.molecula_id "
        f"WHERE a.taxon_id IS NOT NULL AND {sql_publica('a')} AND IFNULL(m.categoria_clinica, 'farmaco_secundario') = 'farmaco_secundario'")
        if r["molecula_id"] in ctx.clinico}
    colunas = ["id", "gbif", "nome", "populares", "grupo", "familia", "recorte", "predominio", "n_al", "n_br", "moleculas",
               "afirmacoes", "verificadas", "imagens", "aprovado", "sinonimos", "uf", "bacias", "foco", "estrato", "endemismo", "bioma_am",
               "distribuicao_br", "coleta_amazonica_declarada"]
    linhas = []
    for t in con.execute("SELECT * FROM taxon ORDER BY nome"):
        td = dict(t)
        pop = json.loads(td["nomes_populares"]) if td["nomes_populares"] else []
        por = [p["nome"] for p in pop if p.get("idioma") == "por"]
        nomes = (por + [p["nome"] for p in pop if p.get("idioma") != "por"])[:3]
        linhas.append([td["id"], td["gbif_key"], td["nome"], nomes, CODIGO_GRUPO[td["grupo"]], td["familia"], td["no_recorte"],
                       {"predominante": "p", "nao_predominante": "n", "indeterminado": "i", None: None}[td["predominio_al"]],
                       td["n_al"], td["n_br"], n_mol.get(td["id"], 0), n_af.get(td["id"], 0), n_ver.get(td["id"], 0),
                       n_img.get(td["id"], 0), 1 if td["id"] in aprov else 0,
                       [s["nome"] for s in ctx.sinonimos.get(td["id"], [])[:1]], ufs.get(td["id"], {}),
                       bacias.get(td["id"], {}), foco_capa.get(td["id"]), td["estrato_florestal"], td["endemismo_br"], td["n_bioma_amazonia"],
                       td.get("distribuicao_br") or "indeterminada", 1 if td["id"] in ctx.taxon_coleta_amazonica else 0])
    return {"esquema": 1, "colunas": colunas, "linhas": linhas,
            "legenda": {"grupo": {"P": "planta", "F": "fungo", "A": "animal com toxinas", "O": "outro"},
                        "predominio": {"p": "predominante", "n": "não predominante", "i": "indeterminado"},
                        "bacias": dict(sorted(ctx.bacias_nomes.items()))}}


def indice_mapa(ix_completo):
    """Índice colunar ultra-enxuto de primeira tela (mapa + visão geral + UFs); `indice.json` completo carrega sob demanda."""
    cols_src = {c: i for i, c in enumerate(ix_completo["colunas"])}
    colunas = ["id", "gbif", "nome", "popular", "grupo", "recorte", "predominio", "n_al", "moleculas", "imagens", "aprovado", "foco",
               "coleta_amazonica_declarada"]
    brutas = []
    ufs_set = set()
    for l in ix_completo["linhas"]:
        pops = l[cols_src["populares"]] or []
        uf_d = l[cols_src["uf"]] or {}
        ufs_set.update(uf_d.keys())
        brutas.append((
            [
                l[cols_src["id"]], l[cols_src["gbif"]], l[cols_src["nome"]], pops[0] if pops else "",
                l[cols_src["grupo"]], l[cols_src["recorte"]], l[cols_src["predominio"]],
                l[cols_src["n_al"]], l[cols_src["moleculas"]], l[cols_src["imagens"]],
                l[cols_src["aprovado"]], l[cols_src["foco"]], l[cols_src["coleta_amazonica_declarada"]],
            ],
            uf_d,
        ))
    brutas.sort(key=lambda par: (par[0][4], par[0][6] or "", -par[0][5], -par[0][8], par[0][2]))
    ufs_ordem = sorted(ufs_set)
    bit_por_uf = {u: (1 << i) for i, u in enumerate(ufs_ordem)}
    dados_cols = {c: [par[0][i] for par in brutas] for i, c in enumerate(colunas)}
    # Máscara de bits de 27 UFs por táxon (~1,8 KB gzip em vez de 26,8 KB): presença exata na 1ª tela;
    # contagens finas por (táxon, UF) carregam sob demanda em indice.json ao abrir um estado ou métrica de registros.
    dados_cols["uf_mask"] = [
        sum(bit_por_uf[u] for u, cnt in par[1].items() if cnt > 0 and u in bit_por_uf)
        for par in brutas
    ]
    return {
        "esquema": 2, "parcial": True, "ufs_formato": "bitmask_27", "colunas": colunas,
        "dados": dados_cols, "ufs": ufs_ordem, "legenda": ix_completo["legenda"],
    }


def indice_sinonimos(ctx):
    """Índice completo de sinônimos sob demanda (mantém indice.json enxuto na primeira tela). Só nomes, para a busca."""
    gbif_do_taxon = {r["id"]: r["gbif_key"] for r in ctx.con.execute("SELECT id, gbif_key FROM taxon")}
    sins = {str(gbif_do_taxon[tid]): [s["nome"] for s in lista]
            for tid, lista in sorted(ctx.sinonimos.items(), key=lambda par: gbif_do_taxon.get(par[0], 0)) if tid in gbif_do_taxon}
    return {"esquema": 1, "por_gbif": sins}


def _abrev(nome, n=34):
    return nome if len(nome) <= n else nome[:n - 1] + "…"


def indice_moleculas(ctx):
    """Índice colunar leve para busca e catálogo (nomes abreviados: o nome completo vai no pacote da molécula)."""
    colunas = ["id", "nome", "tipo", "taxa", "atividades", "aprovado", "retirado", "cat_clin", "coleta_amazonica_declarada", "n3d", "classe"]
    linhas = []
    mapa_cat = {"farmaco_secundario": "s", "metabolito_ou_insumo": "i"}
    mapa_3d = {"experimental": "e", "predicao_computacional": "p", "conformero_calculado": "c"}
    dic_classes = sorted({(ctx.mol[mid]["classe_quimica"] or ctx.mol[mid]["familia"] or "") for mid in ctx.mols_publicas} - {""})
    idx_classe = {c: i for i, c in enumerate(dic_classes)}
    for mid in sorted(ctx.mols_publicas):
        m = ctx.mol[mid]
        aprov = 1 if mid in ctx.clinico else 0
        ret = 1 if (aprov and m["fase_retirado"]) else 0
        cat = mapa_cat.get(m["categoria_clinica"], "") if aprov else ""
        ests = ctx.estruturas3d.get(mid)
        n3d = mapa_3d.get(ests[0]["natureza"], "c") if ests else ""
        cls = m["classe_quimica"] or m["familia"] or ""
        linhas.append([mid, _abrev(m["nome"]), CODIGO_TIPO[m["tipo"]], ctx.n_taxa_da_mol.get(mid, 0),
                       ctx.n_ativ.get(mid, 0), aprov, ret, cat, 1 if mid in ctx.mol_coleta_amazonica else 0, n3d,
                       idx_classe.get(cls, -1)])
    linhas.sort(key=lambda r: (r[2], -r[5], r[7], -r[8], -r[4], -r[3], r[1].lower(), r[0]))
    dados_cols = {c: [r[i] for r in linhas] for i, c in enumerate(colunas)}
    return {
        "esquema": 2, "colunas": colunas, "dados": dados_cols,
        "dicionario_classes": dic_classes,
        "legenda": {"tipo": {"s": "pequena molécula", "p": "peptídeo", "t": "proteína"},
                    "cat_clin": {"s": "fármaco de metabólito secundário", "i": "metabólito primário ou insumo ubíquo"},
                    "n3d": {"e": "experimental", "p": "predição computacional", "c": "confôrmero calculado"}},
    }


def indice_inchikeys(ctx, ix_mols):
    """InChIKeys e fórmulas alinhados 1-a-1 com `moleculas_indice.json`, carregados sob demanda na busca e no catálogo."""
    ids = ix_mols["dados"]["id"]
    iks = [(ctx.mol[mid]["inchikey"] or "").replace("-UHFFFAOYSA-N", "~") for mid in ids]
    formulas = [ctx.mol[mid]["formula"] or "" for mid in ids]
    return {"esquema": 1, "iks": iks, "formulas": formulas}


def territorios(ctx):
    con = ctx.con
    saida = []
    for u in con.execute("SELECT * FROM territorio WHERE tipo='uf' ORDER BY nome"):
        r = con.execute("SELECT COUNT(DISTINCT o.taxon_id) AS n_taxa, COALESCE(SUM(o.n),0) AS n_reg FROM ocorrencia_uf o "
                        "JOIN taxon t ON t.id=o.taxon_id WHERE o.uf_sigla=? AND t.no_recorte=1 AND o.n>0", (u["sigla"],)).fetchone()
        saida.append({"sigla": u["sigla"], "nome": u["nome"], "codigo_ibge": u["codigo"], "amazonia_legal": bool(u["amazonia_legal"]),
                      "taxons_no_recorte_com_registro": r["n_taxa"], "registros_gbif_dos_taxons_do_banco": r["n_reg"]})
    return {"esquema": 1, "ufs": saida,
            "nota": "Contagens dos táxons deste banco, não de toda a biodiversidade da UF. Registros do GBIF sem UF atribuída não entram."}


# ═══════════════════════════ manifesto ═══════════════════════════
def politica_de_exclusao():
    """Espécies que ficam fora da plataforma por decisão editorial (uso ritual, uso controlado), como a semente as lista."""
    import tomllib
    try:
        with open(config.SEMENTE_DIR / "taxa.toml", "rb") as f:
            especies = [{"nome": e["nome"], "motivo": e["motivo"]} for e in tomllib.load(f).get("excluidos", [])]
    except OSError:
        especies = []
    return {"texto": TEXTO_DA_POLITICA_DE_EXCLUSAO, "especies": especies}


def _destaques(con, ctx):
    """Chaves GBIF dos táxons escolhidos na semente para o destaque 'floresta → fármaco aprovado' (só se há molécula aprovada pública)."""
    import tomllib
    try:
        with open(config.SEMENTE_DIR / "taxa.toml", "rb") as f:
            nomes = tomllib.load(f).get("destaques", {}).get("nomes", [])
    except OSError:
        return []
    saida = []
    for n in nomes:
        t = con.execute("SELECT t.id, t.gbif_key FROM taxon t WHERE t.no_recorte=1 AND (t.nome=? OR t.id IN (SELECT taxon_id FROM taxon_sinonimo WHERE nome=?))", (n, n)).fetchone()
        if t and any(r[0] in ctx.clinico for r in con.execute(
                f"SELECT DISTINCT molecula_id FROM afirmacao WHERE taxon_id=? AND {sql_publica()}", (t["id"],))):
            saida.append(t["gbif_key"])
    return saida


def contagens(ctx):
    """Contagens do que é público, cada uma com o nome do que conta (contrato §3.4). Nenhuma soma inclui registro não publicado."""
    con = ctx.con
    q = lambda sql, p=(): con.execute(sql, p).fetchone()[0]
    exportada = sql_afirmacao_exportada("a")
    por_tipo = {t: 0 for t in ("composto_em_organismo", "atividade_biologica", "funcao_toxina", "efeito_clinico_documentado")}
    por_evidencia = {k: 0 for k in ORDEM_EVIDENCIA}
    for r in con.execute(f"SELECT a.tipo, IFNULL(a.nivel_evidencia, 'base_curada') AS ev, COUNT(*) AS n FROM afirmacao a WHERE {exportada} GROUP BY 1, 2"):
        por_tipo[r["tipo"]] = por_tipo.get(r["tipo"], 0) + r["n"]
        por_evidencia[r["ev"]] = por_evidencia.get(r["ev"], 0) + r["n"]
    declarada = {k: 0 for k in procedencia.ROTULOS_PROCEDENCIA}
    for r in con.execute(f"SELECT IFNULL(procedencia_declarada, 'nao_declarada') AS p, COUNT(*) AS n FROM afirmacao "
                         f"WHERE taxon_id IS NOT NULL AND {sql_publica()} GROUP BY 1"):
        declarada[r["p"]] = declarada.get(r["p"], 0) + r["n"]
    distribuicao = {k: 0 for k in procedencia.ROTULOS_DISTRIBUICAO}
    for r in con.execute("SELECT IFNULL(distribuicao_br, 'indeterminada') AS d, COUNT(*) AS n FROM taxon GROUP BY 1"):
        distribuicao[r["d"]] = distribuicao.get(r["d"], 0) + r["n"]
    composto = f"tipo='composto_em_organismo' AND {sql_publica()}"
    com_inchikey = [m for m in (ctx.mol[i] for i in ctx.mols_publicas) if m["inchikey"]]
    est3d = [e for lista in (*ctx.estruturas3d.values(), *ctx.estruturas3d_alvo.values()) for e in lista]
    return {
        "taxons": q("SELECT COUNT(*) FROM taxon"), "taxons_no_recorte": q("SELECT COUNT(*) FROM taxon WHERE no_recorte=1"),
        "taxons_com_predominio_de_registros_na_amazonia_legal": q("SELECT COUNT(*) FROM taxon WHERE predominio_al='predominante'"),
        "plantas": q("SELECT COUNT(*) FROM taxon WHERE no_recorte=1 AND grupo='planta'"),
        "animais_com_toxinas": q("SELECT COUNT(*) FROM taxon WHERE no_recorte=1 AND grupo='animal_peconhento'"),
        "fungos": q("SELECT COUNT(*) FROM taxon WHERE no_recorte=1 AND grupo='fungo'"),
        "taxons_por_distribuicao": distribuicao,
        "moleculas": len(ctx.mols_publicas),
        "moleculas_inchikey": len(com_inchikey),
        "conectividades_2d": len({conectividade(m) for m in com_inchikey}),
        "referencias": len(ctx.referencias_citadas()),
        "imagens": q("SELECT COUNT(*) FROM midia WHERE estado='ativo' AND arquivo IS NOT NULL"),
        "afirmacoes_publicas": sum(por_tipo.values()),
        "afirmacoes_por_tipo": por_tipo,
        "afirmacoes_por_evidencia": por_evidencia,
        "afirmacoes_verificadas": q(f"SELECT COUNT(*) FROM afirmacao a WHERE a.estado='verificado' AND {exportada}"),
        "pares_taxon_molecula": q(f"SELECT COUNT(*) FROM (SELECT DISTINCT taxon_id, molecula_id FROM afirmacao WHERE {composto})"),
        "pares_taxon_molecula_em_mais_de_uma_base": q(
            f"SELECT COUNT(*) FROM (SELECT taxon_id, molecula_id FROM afirmacao WHERE {composto} GROUP BY 1, 2 HAVING COUNT(DISTINCT fonte_id) > 1)"),
        "procedencia_declarada": declarada,
        "consultas_registradas": len(ctx.consultas_publicas()),
        "estruturas_3d": len({e["id"] for e in est3d}),
        "estruturas_3d_experimentais": len({e["id"] for e in est3d if e["natureza"] == "experimental"}),
        "moleculas_com_3d": len(ctx.estruturas3d),
        "vias_reactome": len({v["reactome_id"] for aid in ctx.alvos_publicos for v in ctx.vias_por_alvo.get(aid, ())}),
        "linhagens_bioinspiradas": len(ctx.linhagens),
        "bacias_hidrograficas": q("SELECT COUNT(*) FROM bacia_hidrografica"),
    }


def fontes_com_consultas(ctx):
    """Fontes como saem no manifesto, na tabela de fontes e na API: licença, descrição e as consultas que sustentam o que é público."""
    por_fonte = {}
    for cid in ctx.consultas_publicas():
        c = ctx.consultas[cid]
        por_fonte.setdefault(c["fonte_id"], []).append(c)
    saida = []
    for f in ctx.fontes.values():
        cs = por_fonte.get(f["id"], [])
        datas = sorted(c["consultado_em"] for c in cs if c["consultado_em"])
        saida.append({"id": f["id"], "nome": f["nome"], "url": f["url"], "licenca": f["licenca"], "licenca_url": f["licenca_url"],
                      "descricao": f["descricao"], "consultas": len(cs),
                      "primeira_consulta": datas[0][:10] if datas else None, "ultima_consulta": datas[-1][:10] if datas else None,
                      "versoes": sorted({c["versao_fonte"] for c in cs if c["versao_fonte"]})})
    return saida


def manifesto(con, ctx, destino, hashes, log):
    q = lambda sql: con.execute(sql).fetchone()[0]
    # Da construção sai só o nome de cada etapa concluída e a data; o resumo de cada etapa é registro interno.
    etapas = {r["nome"]: {"concluida_em": r["concluida_em"]}
              for r in con.execute("SELECT nome, concluida_em FROM etapa WHERE concluida_em IS NOT NULL ORDER BY concluida_em, nome")}

    universo = None
    if q("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='universo_checklist'"):
        tot_am = q("SELECT COUNT(*) FROM universo_checklist WHERE bioma_amazonia_declarado=1")
        if tot_am > 0:
            com_q = q("SELECT COUNT(*) FROM universo_checklist WHERE bioma_amazonia_declarado=1 AND tem_quimica_aberta=1")
            por_g_tot = {r[0]: r[1] for r in con.execute(
                "SELECT grupo_bmb, COUNT(*) FROM universo_checklist WHERE bioma_amazonia_declarado=1 GROUP BY 1")}
            por_g_q = {r[0]: r[1] for r in con.execute(
                "SELECT grupo_bmb, COUNT(*) FROM universo_checklist WHERE bioma_amazonia_declarado=1 AND tem_quimica_aberta=1 GROUP BY 1")}
            universo = {
                "especies_aceitas_bioma_amazonia": tot_am,
                "com_quimica_aberta": com_q,
                "sem_quimica_aberta_dark_matter": tot_am - com_q,
                "fracao_dark_matter": round((tot_am - com_q) / tot_am, 4),
                "por_grupo": {g: {"aceitas": por_g_tot.get(g, 0), "com_quimica": por_g_q.get(g, 0)} for g in sorted(por_g_tot)},
                "fontes_catalogo": ["Flora e Funga do Brasil (JBRJ DwC-A)", "Catálogo Taxonômico da Fauna do Brasil (CTFB DwC-A)"],
            }

    corpo = {
        "esquema": 1, "gerado_em": agora(), "gerado_por": f"bmb {__version__}",
        "contagens": ctx.contagens(),
        "rotulos": rotulos(),
        **({"universo_checklist": universo} if universo else {}),
        "governanca_sisgen": {
            "marco_legal": "Lei nº 13.123/2015 e Decreto nº 8.772/2016 (SisGen/CGEN, Brasil), Protocolo de Nagoia e Princípios CARE.",
            "escopo_plataforma": "Compilação aberta de metadados bibliográficos secundários; não constitui acesso direto ao patrimônio genético nem substitui cadastro ou notificação de produto acabado no SisGen quando aplicável a pesquisa experimental a jusante.",
            "protecao_territorial": "Local de coleta só como país e unidade da federação. Ocorrências só como contagens agregadas por estado e por sub-bacia. Nenhuma coordenada individual e nenhum conhecimento tradicional associado.",
        },
        "politica_de_exclusao": politica_de_exclusao(),
        "recorte": {"ufs": list(config.UF_AMAZONIA_LEGAL), "n_al_min": config.N_AL_MIN,
                    "fracao_predominante": config.FRACAO_AL_PREDOMINANTE,
                    "descricao": (f"Um táxon entra no recorte amazônico com pelo menos {config.N_AL_MIN} registros do GBIF nas UFs da "
                                  f"Amazônia Legal ({', '.join(config.UF_AMAZONIA_LEGAL)}). A Amazônia Legal administrativa inclui o Maranhão "
                                  "a oeste de 44°W e áreas de Cerrado em MT, TO e MA; por isso o perfil de cada espécie também traz, em separado, "
                                  "os registros no Bioma Amazônia ecológico e no Maranhão a oeste de 44°W. O predomínio amazônico "
                                  f"(metade ou mais dos registros brasileiros) é declarado nas duas bases: só registros com UF e todos os registros.")},
        "destaques_farmaco": _destaques(con, ctx),
        "principios": PRINCIPIOS, "estados": ESTADOS_TEXTO,
        "dimensoes_prontidao": list(config.DIMENSOES),
        "aviso_prontidao": "O índice mede a completude do registro para reutilização. Não é nota de eficácia biológica.",
        "fontes": fontes_com_consultas(ctx), "etapas": etapas, "integridade": hashes,
        "geometria": {
            "ufs": "IBGE (API de malhas), simplificada",
            "relevo": "Duplo modo: `dem_brasil.webp` (sombreado PBR + HBAO ilustrativo) e `altimetria_m.webp` (grade altimétrica sem perdas em metros a.n.m. de Mapzen/AWS Terrarium z=6 para telemetria metrológica)",
            "rios": "Natural Earth 10m (domínio público) + 9 sub-bacias amazônicas (ANA Ottobacias / HydroBASINS) com áreas em EPSG:5880 (SIRGAS 2000 / Brazil Polyconic)",
            "lacunas": "Grade de 0,5° rastreada no SQLite (`celula_lacuna` com `consulta_id`): áreas geodésicas GRS80/EPSG:5880, densidade GBIF × pressão PRODES (INPE TerraBrasilis) e união topológica CNUC ∪ FUNAI sem dupla contagem",
        },
        "licencas_dos_dados": ("Cada afirmação traz a licença da sua fonte. Compilação sob CC BY 4.0 (LOTUS CC BY 4.0, UniProt CC BY 4.0, "
                               "ENA EMBL-Bank Domínio Público, Flora e Funga JBRJ CC BY 4.0, CTFB CC BY 4.0, NPAtlas CC BY 4.0, NuBBE-DB/nubbeKG MIT, "
                               "Reactome CC BY 4.0, wwPDB/RCSB PDB CC0, Crystallography Open Database COD CC0, AlphaFold CC BY 4.0, ESM Metagenomic Atlas CC BY 4.0), "
                               "exceto as afirmações derivadas do ChEMBL (atividade medida e efeito clínico), que mantêm CC BY-SA 3.0, e os "
                               "indicadores de pressão de desmatamento e de área protegida por célula de 0,5° (INPE TerraBrasilis, CNUC, FUNAI), "
                               "que mantêm CC BY-SA 4.0. As duas licenças exigem compartilhamento pela mesma licença."),
        "licenca_do_codigo": "GNU AGPL-3.0 (dual-licenciado com licença comercial da AMAZONIA WORKS). Nome e marca BioMapaBrasil reservados à AMAZONIA WORKS.",
    }
    _escrever(destino / "manifesto.json", corpo)
    return corpo


# ═══════════════════════════ livro interno ═══════════════════════════
PASTA_INTERNA = "interno"
# Arquivos de versões anteriores do pacote público que deixaram de existir; a exportação os apaga do destino.
ARQUIVOS_PUBLICOS_EXTINTOS = ("quarentena.json", "benchmark_validacao.json", "nomes_rejeitados.json")


def livro_de_retencoes(con, ctx=None):
    """Tudo o que está no banco e não vai a público, com a regra e o motivo. Uso interno (contrato §1)."""
    ctx = ctx or Contexto(con)
    regras_por_af = {}
    for r in con.execute("SELECT afirmacao_id, codigo FROM afirmacao_regra ORDER BY afirmacao_id, codigo"):
        regras_por_af.setdefault(r["afirmacao_id"], []).append(r["codigo"])
    base = ("SELECT a.id, a.tipo, a.estado, a.classe_acesso, a.texto, a.origem, a.fonte_id, a.regra_quarentena, a.motivo_quarentena, "
            "a.quarentena_origem, a.organismo_na_fonte, a.molecula_id, t.nome AS taxon, m.nome AS molecula FROM afirmacao a "
            "LEFT JOIN taxon t ON t.id=a.taxon_id JOIN molecula m ON m.id=a.molecula_id ")

    def linha(a, **extra):
        return {"id": a["id"], "tipo": a["tipo"], "estado": a["estado"], "taxon": a["taxon"], "molecula": a["molecula"],
                "enunciado": a["texto"], "origem": a["origem"], "fonte": a["fonte_id"], "regra": a["regra_quarentena"],
                "motivo": a["motivo_quarentena"], "decidida_por": a["quarentena_origem"],
                "regras_disparadas": regras_por_af.get(a["id"], []), "organismo_na_fonte": a["organismo_na_fonte"], **extra}

    afirmacoes = [linha(a) for a in con.execute(base + "WHERE a.estado IN ('quarentena','rejeitado') ORDER BY a.id")]
    restritas = [linha(a, classe_acesso=a["classe_acesso"]) for a in con.execute(
        base + f"WHERE a.estado IN {SQL_ESTADOS} AND a.classe_acesso <> 'publico' ORDER BY a.id")]
    sem_molecula_publica = [linha(a, motivo_da_exportacao="molécula sem ocorrência pública em táxon do banco e fora de linhagem pública")
                            for a in con.execute(base + f"WHERE {sql_publica('a')} AND a.taxon_id IS NULL ORDER BY a.id")
                            if a["molecula_id"] not in ctx.mols_publicas]
    referencias = [{"id": r["id"], "doi": r["doi"], "pmid": r["pmid"], "titulo": r["titulo"], "estado": r["estado"],
                    "regra": r["regra_quarentena"], "motivo": r["motivo_quarentena"], "duplicata_de": r["duplicata_de"],
                    "retratada": bool(r["retratada"])}
                   for r in con.execute(f"SELECT * FROM referencia WHERE NOT ({SQL_REFERENCIA_PUBLICA}) ORDER BY id")]
    publicas = {d["id"] for d in ctx.linhagens}
    linhagens = [{"id": r["id"], "chave": r["chave"], "tipo": r["tipo"], "origem": ctx.mol.get(r["origem_id"], {}).get("nome"),
                  "destino": ctx.mol.get(r["destino_id"], {}).get("nome"), "estado": r["estado"], "regra": r["regra_quarentena"],
                  "motivo": r["motivo_quarentena"] or ("obra citada retida ou retratada" if r["estado"] in ESTADOS_PUBLICOS else None),
                  "texto": r["texto"]}
                 for r in con.execute("SELECT * FROM relacao_molecula ORDER BY id") if r["id"] not in publicas]
    midia = [{"id": r["id"], "taxon_id": r["taxon_id"], "gbif_ocorrencia": r["gbif_ocorrencia"], "pagina": r["pagina"],
              "motivo": r["motivo_quarentena"]} for r in con.execute("SELECT * FROM midia WHERE estado='quarentena' ORDER BY id")]
    return {"esquema": 1, "gerado_em": agora(), "gerado_por": f"bmb {__version__}",
            "nota": "Registro interno: o que está no banco e não foi publicado, com a regra e o motivo. Não vai para pasta servida ao público.",
            "afirmacoes": afirmacoes, "afirmacoes_com_acesso_restrito": restritas,
            "afirmacoes_de_molecula_sem_registro_publico": sem_molecula_publica,
            "referencias": referencias, "linhagens": linhagens, "midia": midia}


def nomes_da_semente_rejeitados(con):
    """Nomes da semente editorial que não entraram no banco, com o motivo. Uso interno."""
    nomes = [json.loads(r["detalhe"]) for r in con.execute(
        "SELECT detalhe FROM evento_proveniencia WHERE entidade='semente_rejeitada' ORDER BY id")]
    return {"esquema": 1, "gerado_em": agora(), "nomes": nomes, "politica_de_exclusao": politica_de_exclusao()["especies"]}


def gravar_interno(con, ctx, log=print):
    """Grava em `config.SAIDA_DIR / "interno"` o livro de retenções, o resumo por regra e os nomes da semente rejeitados."""
    pasta = config.SAIDA_DIR / PASTA_INTERNA
    livro = livro_de_retencoes(con, ctx)
    _escrever(pasta / "retencoes.json", livro)
    resumo = {"esquema": 1, "gerado_em": livro["gerado_em"], **quarentena.resumo(con),
              "afirmacoes_por_estado": {r[0]: r[1] for r in con.execute("SELECT estado, COUNT(*) FROM afirmacao GROUP BY 1 ORDER BY 1")},
              "afirmacoes_com_acesso_restrito": len(livro["afirmacoes_com_acesso_restrito"]),
              "afirmacoes_de_molecula_sem_registro_publico": len(livro["afirmacoes_de_molecula_sem_registro_publico"]),
              "referencias_fora_do_publico": len(livro["referencias"]), "linhagens_fora_do_publico": len(livro["linhagens"]),
              "imagens_retidas": len(livro["midia"])}
    _escrever(pasta / "resumo_retencoes.json", resumo)
    _escrever(pasta / "nomes_rejeitados.json", nomes_da_semente_rejeitados(con))
    log(f"  registro interno em {pasta}: {len(livro['afirmacoes'])} afirmações, {len(livro['referencias'])} referências, "
        f"{len(livro['linhagens'])} linhagens e {len(livro['midia'])} imagens fora do público; "
        f"{len(livro['afirmacoes_de_molecula_sem_registro_publico'])} afirmações de molécula sem ocorrência nem linhagem pública "
        f"e {len(livro['afirmacoes_com_acesso_restrito'])} de acesso restrito não exportadas")
    return pasta


# ═══════════════════════════ fronteira ═══════════════════════════
# Identificadores que só existem do lado interno. Não são palavras da língua: título de artigo nenhum os contém.
IDENTIFICADORES_INTERNOS = (
    "motivo_quarentena", "regra_quarentena", "quarentena_origem", "afirmacao_regra", "afirmacoes_em_quarentena",
    "imagens_em_quarentena", "nivel_procedencia", "escopo_biogeografico", "motivo_exclusao", "taxon_sinonimo_legado",
    "benchmark_validacao", "rodada_benchmark", "amostra_benchmark", "localidade_declarada", "procedencia_material",
    "T1_voucher_amazonia_verificado", "T2a_declarada_amazonia_base", "T2b_declarada_brasil_extra_amazonia",
    "T3a_endemica_amazonia_br", "T3b_nativa_pan_amazonica", "T4_pantropical_ou_global_indeterminada",
    "T5_extra_amazonica_confirmada",
)
ARQUIVOS_INTERNOS = re.compile(r"(?:^|/)(?:quarentena|retencoes|resumo_retencoes|benchmark_validacao|nomes_rejeitados)[^/]*\.(?:json|csv|md)$"
                               r"|\.sqlite(?:-wal|-shm)?$|\.sqlite\.gz$", re.I)
PASTAS_INTERNAS_NA_RAIZ = ("docs", "external_audit_2026-11-15", "nucleo", "scripts", ".git", ".github", "_release")
_EXT_TEXTO = {".json", ".geojson", ".csv", ".tsv", ".txt", ".xml", ".html", ".md"}


def conferir_fronteira(pasta):
    """Lista o que há de interno em uma pasta destinada ao público: [(caminho relativo, o que foi achado)].

    Confere pastas e arquivos que não fazem parte do pacote, e, nos arquivos de texto, identificadores do lado
    interno: códigos de regra, colunas de retenção e os nomes antigos de procedência. Lista vazia = nada interno.
    """
    pasta = Path(pasta)
    codigos = tuple(quarentena.REGRAS)
    padrao = re.compile("|".join(re.escape(x) for x in sorted((*IDENTIFICADORES_INTERNOS, *codigos), key=len, reverse=True)).encode())
    achados = []
    for arq in sorted(p for p in pasta.rglob("*") if p.is_file()):
        rel = arq.relative_to(pasta).as_posix()
        partes = rel.split("/")[:-1]
        interna = PASTA_INTERNA if PASTA_INTERNA in partes else (partes[0] if partes and partes[0] in PASTAS_INTERNAS_NA_RAIZ else None)
        if interna:
            achados.append((rel, f"pasta «{interna}» não faz parte do pacote público"))
            continue
        if ARQUIVOS_INTERNOS.search(rel):
            achados.append((rel, "arquivo que não faz parte do pacote público"))
            continue
        if arq.suffix.lower() == ".zip":
            import zipfile
            with zipfile.ZipFile(arq) as z:
                for nome in z.namelist():
                    m = padrao.search(z.read(nome))
                    if m:
                        achados.append((f"{rel}!{nome}", f"identificador interno «{m.group(0).decode()}»"))
        elif arq.suffix.lower() in _EXT_TEXTO:
            m = padrao.search(arq.read_bytes())
            if m:
                achados.append((rel, f"identificador interno «{m.group(0).decode()}»"))
    return achados


# ═══════════════════════════ orquestração ═══════════════════════════
def _hash_arquivo(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for bloco in iter(lambda: f.read(1 << 20), b""):
            h.update(bloco)
    return h.hexdigest()


def _copiar_midia(destino, log, ctx=None):
    """Copia de `config.SAIDA_DIR` só a mídia de registros públicos: desenhos e geometrias 3D de moléculas e alvos
    públicos, e a miniatura de cada fotografia ativa. Arquivo de registro retido que ainda esteja em disco não é copiado."""
    n = {"estruturas_lotes": 0, "estruturas": 0, "imagens": 0, "estruturas3d_lotes": 0, "estruturas3d": 0}
    if (destino / "estruturas").exists() and (config.SAIDA_DIR / "estruturas_lotes").exists():
        shutil.rmtree(destino / "estruturas")
    if (destino / "estruturas3d").exists() and (config.SAIDA_DIR / "estruturas3d_lotes").exists():
        shutil.rmtree(destino / "estruturas3d")
    iks_publicos = chaves_3d_publicas = None
    arquivos = {}                                   # pasta -> caminhos relativos citados por registro público
    if ctx is not None:
        iks_publicos = {ctx.mol[mid]["inchikey"] for mid in ctx.mols_publicas if ctx.mol[mid].get("inchikey")}
        geometrias = [(e.get("arquivo_geometria") or "").removeprefix("dados/")
                      for lista_e in (*ctx.estruturas3d.values(), *ctx.estruturas3d_alvo.values()) for e in lista_e]
        chaves_3d_publicas = {g.split("#", 1)[1] for g in geometrias if "#" in g}
        from . import ensembles
        n["ensembles"] = ensembles.gravar(destino, config.SAIDA_DIR, (e for grupo in ctx.estruturas3d.values() for e in grupo))
        arquivos["estruturas3d"] = {g for g in geometrias if g.startswith("estruturas3d/") and "#" not in g and not ensembles.NOME.fullmatch(g)}
        arquivos["estruturas"] = {d for d in ((ctx.mol[mid].get("desenho") or "").removeprefix("dados/") for mid in ctx.mols_publicas)
                                  if d.startswith("estruturas/") and "#" not in d}
        arquivos["imagens"] = {r["arquivo"] for r in ctx.con.execute(
            "SELECT arquivo FROM midia WHERE estado='ativo' AND arquivo IS NOT NULL") if r["arquivo"].startswith("imagens/")}
    for sub in ("estruturas_lotes", "estruturas", "imagens", "estruturas3d_lotes", "estruturas3d"):
        origem = config.SAIDA_DIR / sub
        if not origem.exists():
            continue
        alvo = destino / sub
        if alvo.exists():
            shutil.rmtree(alvo)
        filtro = {"estruturas_lotes": iks_publicos, "estruturas3d_lotes": chaves_3d_publicas}.get(sub)
        if filtro is not None:
            alvo.mkdir(parents=True, exist_ok=True)
            for arq_lote in sorted(origem.glob("*.json")):
                d_lote = json.loads(arq_lote.read_text(encoding="utf-8"))
                filtrado = {k: v for k, v in d_lote.items() if k in filtro}
                if filtrado:
                    (alvo / arq_lote.name).write_bytes(
                        json.dumps(filtrado, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8"))
                    n[sub] += 1
        elif sub in arquivos:
            raiz = config.SAIDA_DIR.resolve()
            for rel in sorted(arquivos[sub]):
                arq = (config.SAIDA_DIR / rel).resolve()
                if raiz in arq.parents and arq.is_file():
                    (destino / rel).parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(arq, destino / rel)
                    n[sub] += 1
        else:
            shutil.copytree(origem, alvo)
            n[sub] = sum(1 for _ in alvo.rglob("*") if _.is_file())
    log(f"  mídia copiada: {n}")
    return n


def _copiar_i18n(destino):
    """Copia, como estão, os dicionários de tradução da semente (a chave de cada tradução é o próprio texto em pt-BR)."""
    origem = config.SEMENTE_DIR / "i18n"
    if origem.exists():
        (destino / "i18n").mkdir(parents=True, exist_ok=True)
        for arq in sorted(origem.glob("*.json")):
            shutil.copy2(arq, destino / "i18n" / arq.name)


def exportar_tudo(con, destino=None, log=print, forcar=False):
    from . import dwca, geo, tabular, viz_shards

    resultado = validar.validar(con)
    validar.imprimir(resultado, log)
    if resultado["erros"] and not forcar:
        raise SystemExit("A validação encontrou erros; a exportação foi recusada (use --forcar só para depurar).")
    destino = Path(destino or (config.APP_DIR / "dados"))
    interno = (config.SAIDA_DIR / PASTA_INTERNA).resolve()
    if interno == destino.resolve() or destino.resolve() in interno.parents or interno in destino.resolve().parents:
        raise SystemExit(f"O destino {destino} contém ou fica dentro da pasta de registros internos ({interno}). "
                         "Escolha um destino fora de BMB_SAIDA.")
    tem_fonte_geo = (config.SEMENTE_DIR / "geo_base" / "ufs_base.json").exists()
    dem_salvo = None
    alt_salvo = None
    if (destino / "geo" / "dem_brasil.webp").exists():
        dem_salvo = (destino / "geo" / "dem_brasil.webp").read_bytes()
    if (destino / "geo" / "altimetria_m.webp").exists():
        alt_salvo = (destino / "geo" / "altimetria_m.webp").read_bytes()
    if destino.exists():
        subs_base = ("taxa", "moleculas", "moleculas_lotes", "estruturas_lotes", "viz", "estruturas3d_lotes", "estruturas3d", "estruturas3d_ensembles", "tabelas", "dwca")
        subs = (*subs_base, "geo") if tem_fonte_geo else subs_base
        for sub in subs:
            if (destino / sub).exists():
                shutil.rmtree(destino / sub)
        for extinto in (*ARQUIVOS_PUBLICOS_EXTINTOS, "manifesto.json", "SHA256SUMS.txt"):
            (destino / extinto).unlink(missing_ok=True)
    destino.mkdir(parents=True, exist_ok=True)
    log(f"▸ exportando para {destino}")
    ctx = Contexto(con)

    if tem_fonte_geo:
        geo.exportar_geo(destino, log, con=con)
        if dem_salvo is not None:
            (destino / "geo" / "dem_brasil.webp").write_bytes(dem_salvo)
        if alt_salvo is not None and not (destino / "geo" / "altimetria_m.webp").exists():
            (destino / "geo" / "altimetria_m.webp").write_bytes(alt_salvo)
    _copiar_i18n(destino)
    _copiar_midia(destino, log, ctx=ctx)

    n_t = n_m = n_t_pag = 0
    for t in con.execute("SELECT * FROM taxon ORDER BY id"):
        corpo_t, extras_t = pacote_taxon(ctx, t, paginar=True)
        _escrever(destino / "taxa" / f"{t['gbif_key']}.json", corpo_t)
        for arq_extra, corpo_extra in extras_t:
            _escrever(destino / "taxa" / arq_extra, corpo_extra)
            n_t_pag += 1
        n_t += 1

    mols_exportar = [ctx.mol[mid] for mid in sorted(ctx.mols_publicas)]
    lotes_mol = {f"{b:02x}": {} for b in range(256)}
    gravar_individuais = len(mols_exportar) <= 500
    for m in mols_exportar:
        pm = pacote_molecula(ctx, m)
        lotes_mol[f"{m['id'] & 0xff:02x}"][str(m["id"])] = pm
        if gravar_individuais:
            _escrever(destino / "moleculas" / f"{m['id']}.json", pm)
        n_m += 1
    for bucket, d_lote in lotes_mol.items():
        if d_lote:
            _escrever(destino / "moleculas_lotes" / f"{bucket}.json", d_lote)
    log(f"  pacotes: {n_t} táxons (+{n_t_pag} páginas extras), {n_m} moléculas ({sum(1 for d in lotes_mol.values() if d)} lotes)")

    tam = {}
    ix_taxa = indice_taxa(ctx)
    tam["indice.json"] = _escrever(destino / "indice.json", ix_taxa)
    tam["indice_mapa.json"] = _escrever(destino / "indice_mapa.json", indice_mapa(ix_taxa))
    tam["sinonimos_indice.json"] = _escrever(destino / "sinonimos_indice.json", indice_sinonimos(ctx))
    ix_mols = indice_moleculas(ctx)
    tam["moleculas_indice.json"] = _escrever(destino / "moleculas_indice.json", ix_mols)
    tam["inchikeys_indice.json"] = _escrever(destino / "inchikeys_indice.json", indice_inchikeys(ctx, ix_mols))
    tam["territorios.json"] = _escrever(destino / "territorios.json", territorios(ctx))
    viz_shards.exportar_viz_tudo(con, ctx, destino, log)
    for nome, b in tam.items():
        log(f"  {nome}: {b / 1024:.1f} KB")

    tabular.exportar_csv(con, ctx, destino / "tabelas", log)
    dwca.exportar_dwca(con, ctx, destino / "dwca", log)

    # O que ficou de fora, com a regra e o motivo, vai para a pasta interna — nunca para o destino público.
    gravar_interno(con, ctx, log)

    # Fronteira: antes de assinar o conjunto, confere que nada interno entrou em nenhum arquivo do destino.
    internos = conferir_fronteira(destino)
    if internos:
        for rel, o_que in internos[:20]:
            log(f"✗ FRONTEIRA {rel}: {o_que}")
        raise SystemExit(f"A exportação parou: {len(internos)} arquivo(s) do destino trazem conteúdo interno. Nada foi assinado.")

    # integridade: SHA-256 de cada arquivo; o manifesto guarda o dos pacotes de topo e o do conjunto
    soma, topo = hashlib.sha256(), {}
    linhas_soma = []
    for p in sorted(destino.rglob("*")):
        if not p.is_file() or p.name in ("manifesto.json", "SHA256SUMS.txt"):
            continue
        h = _hash_arquivo(p)
        rel = p.relative_to(destino).as_posix()
        linhas_soma.append(f"{h}  {rel}")
        soma.update(f"{h}{rel}".encode())
        if "/" not in rel:
            topo[rel] = {"bytes": p.stat().st_size, "sha256": h}
    hashes = {"algoritmo": "sha256", "arquivos_de_topo": topo, "conjunto": soma.hexdigest(), "n_arquivos": len(linhas_soma)}
    corpo = manifesto(con, ctx, destino, hashes, log)
    (destino / "SHA256SUMS.txt").write_text("\n".join(linhas_soma) + "\n", encoding="utf-8")
    log(f"✓ exportação concluída: {len(linhas_soma)} arquivos; conjunto sha256 {hashes['conjunto'][:16]}…")
    return corpo
