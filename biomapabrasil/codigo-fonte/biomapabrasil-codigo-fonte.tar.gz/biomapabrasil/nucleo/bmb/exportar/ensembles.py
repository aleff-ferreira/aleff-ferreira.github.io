"""Lotes ZIP de membros gzip independentes, acessíveis por intervalo HTTP em hospedagem estática."""
import gzip
import hashlib
import re
from collections import defaultdict
from pathlib import Path
from zipfile import BadZipFile, ZIP_STORED, ZipFile, ZipInfo

PASTA = "estruturas3d_ensembles"
NOME = re.compile(r"estruturas3d/(ens_(\d+)_[0-9a-f]{16}\.json)$")


def localizar(raiz, ref):
    nome = NOME.fullmatch((ref or "").removeprefix("dados/"))
    if nome:
        return Path(raiz) / PASTA / f"{int(nome[2]) % 256:02x}.zip", nome[1] + ".gz"
    return None


def _ref_publica(arq, membro, sha):
    # Os membros gravados têm nomes ASCII, cabeçalho local sem campos extras e payload gzip sem recompressão ZIP.
    inicio = membro.header_offset + 30 + len(membro.filename) + len(membro.extra)
    return f"{PASTA}/{arq.name}#{inicio}:{membro.file_size}:{sha[:16]}"


def referencia(raiz, ref, sha):
    alvo = localizar(raiz, ref)
    if alvo and alvo[0].is_file():
        try:
            with ZipFile(alvo[0]) as lote:
                return _ref_publica(alvo[0], lote.getinfo(alvo[1]), sha)
        except (BadZipFile, OSError, KeyError):
            return None
    return None


def ler_membro(arq, nome):
    with ZipFile(arq) as lote:
        return gzip.decompress(lote.read(nome))


def gravar(destino, origem, registros):
    por_lote = defaultdict(list)
    for e in registros:
        alvo = localizar(destino, e["arquivo_geometria"])
        if alvo:
            por_lote[alvo[0]].append((alvo[1], e))
    for arq, itens in sorted(por_lote.items()):
        arq.parent.mkdir(parents=True, exist_ok=True)
        with ZipFile(arq, "w", compression=ZIP_STORED) as lote:
            for nome, e in sorted(itens, key=lambda par: par[0]):
                ref = e["arquivo_geometria"].removeprefix("dados/")
                local = Path(origem) / ref
                corpo = local.read_bytes() if local.is_file() else ler_membro(*localizar(origem, ref))
                sha = hashlib.sha256(corpo).hexdigest()
                if sha != e["geometria_sha256"]:
                    raise ValueError(f"SHA-256 divergente para {ref}")
                info = ZipInfo(nome)
                lote.writestr(info, gzip.compress(corpo, compresslevel=6, mtime=0))
                e["arquivo_publico"] = _ref_publica(arq, info, sha)
    return len(por_lote)
