# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Geometria cartográfica e geodésica do mapa: UFs, rios, relevo, sub-bacias oficiais e grade de lacunas.

Todas as geometrias vêm de fontes abertas verificadas em `nucleo/semente/geo_base/` e no SQLite:
  * UFs: IBGE (CC BY 4.0);
  * Amazônia Legal e Bioma Amazônia 1:250.000: IBGE / INPE TerraBrasilis WFS (GRS80 / EPSG:5880);
  * Sub-bacias hidrográficas: ANA / HydroBASINS Level-5 Pfafstetter (CC BY 4.0) recortadas pela Amazônia Legal;
  * Relevo e altimetria: Mapzen/AWS Open Data Terrarium (domínio público / atribuição aberta);
  * Rios: Natural Earth 10m (domínio público);
  * Lacunas: `celula_lacuna` no SQLite (GBIF + PRODES + união topológica CNUC ∪ FUNAI em EPSG:5880).
"""
import json
import re
import shutil

from .. import config
from ..conectores import geometrias_oficiais as go
from ..conectores import hidrografia_lacunas as hl
from ..projecao import inv, proj


def _escrever(caminho, obj):
    caminho.parent.mkdir(parents=True, exist_ok=True)
    caminho.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    return caminho


def _aneis_geojson(d):
    """Converte o path SVG 'M x,y L x,y ... Z' (espaço do mapa) em anéis de [lon, lat]."""
    aneis = []
    for parte in re.findall(r"M[^M]+", d):
        pts = [(float(a), float(b)) for a, b in re.findall(r"(-?\d+\.?\d*),(-?\d+\.?\d*)", parte)]
        if len(pts) < 3:
            continue
        anel = [[round(lon, 4), round(lat, 4)] for lon, lat in (inv(x, y) for x, y in pts)]
        if anel[0] != anel[-1]:
            anel.append(anel[0])
        aneis.append([anel])
    return aneis


def _exportar_bacias(geo_dir, con=None):
    contagens = {}
    consultas = []
    mapa_c = {}
    if con is not None:
        for r in con.execute(
            "SELECT ob.bacia_id, COUNT(DISTINCT ob.taxon_id) AS n_taxa, COALESCE(SUM(ob.n), 0) AS n_ocorr, "
            "MAX(ob.consulta_id) AS cid "
            "FROM ocorrencia_bacia ob JOIN taxon t ON t.id=ob.taxon_id "
            "WHERE t.no_recorte=1 AND ob.n > 0 GROUP BY ob.bacia_id"
        ):
            cid = r["cid"]
            idx_c = None
            if cid:
                if cid not in mapa_c:
                    c = con.execute(
                        "SELECT c.*, f.nome AS fonte_nome, f.licenca FROM consulta c JOIN fonte f ON f.id=c.fonte_id WHERE c.id=?",
                        (cid,),
                    ).fetchone()
                    if c:
                        mapa_c[cid] = len(consultas)
                        consultas.append({
                            "fonte": c["fonte_id"], "fonte_nome": c["fonte_nome"], "licenca": c["licenca"],
                            "url": c["url"], "data": c["consultado_em"][:10],
                        })
                idx_c = mapa_c.get(cid)
            contagens[r["bacia_id"]] = {
                "especies_no_recorte": r["n_taxa"], "ocorrencias_gbif": r["n_ocorr"], "consulta": idx_c,
            }

    lim = go.carregar_limites_oficiais()
    bacias_out = []
    for b in hl.BACIAS_AMAZONICAS:
        est = contagens.get(b["id"], {"especies_no_recorte": 0, "ocorrencias_gbif": 0, "consulta": None})
        cx, cy = proj(b.get("rep_lon", -60.0), b.get("rep_lat", -4.0))
        d_svg = go.aneis_para_svg_d(b.get("aneis_display") or [[list(p) for p in b["anel"]]])
        bacias_out.append({
            "id": b["id"], "nome": b["nome"], "rio_principal": b["rio_principal"],
            "area_km2": b["area_km2"], "cor": b["cor_hex"],
            "pfaf_ids_l5": b.get("pfaf_ids_l5", []),
            "cx": round(cx, 1), "cy": round(cy, 1),
            "d": d_svg,
            **est,
        })
    _escrever(geo_dir / "bacias.json", {
        "esquema": 1,
        "crs_geodesico": go.CRS_GEODESICO,
        "bacias": bacias_out,
        "bioma_amazonia_area_km2": lim["bioma_amazonia"]["area_km2"],
        "amazonia_legal_area_km2": lim["amazonia_legal"]["area_km2"],
        "bioma_amazonia_d": go.aneis_para_svg_d(lim["bioma_amazonia"]["aneis_display"]),
        "amazonia_legal_d": go.aneis_para_svg_d(lim["amazonia_legal"]["aneis_display"]),
        "meridiano_44w_nota": "A Amazônia Legal segue a malha municipal oficial do IBGE / LC 124/2007 (incluindo o Maranhão ocidental).",
        "fonte": "HydroSHEDS / HydroBASINS Level-5 Pfafstetter (CC BY 4.0) recortadas pela Amazônia Legal oficial IBGE / INPE TerraBrasilis e Bioma Amazônia IBGE 1:250.000 (áreas geodésicas GRS80 / EPSG:5880)",
        "consultas": consultas,
    })
    return len(bacias_out)


def _compactar_path_inteiro(d):
    """Arredonda coordenadas do path SVG de exibição (0..1000 × 0..1050) para inteiros após gerar ufs.geojson."""
    d_int = re.sub(r"-?\d+\.\d+", lambda m: str(round(float(m.group(0)))), d)
    # Remove vértices consecutivos idênticos gerados pelo arredondamento
    partes = []
    for seg in re.findall(r"M[^M]+", d_int):
        fechou = seg.rstrip().endswith("Z")
        pts = []
        for par in re.findall(r"-?\d+,-?\d+", seg):
            if not pts or pts[-1] != par:
                pts.append(par)
        if len(pts) >= 3:
            partes.append("M" + "L".join(pts) + ("Z" if fechou else ""))
    return "".join(partes) or d_int


def exportar_geo(destino, log=print, con=None):
    from PIL import Image

    gbase = go.caminho_geo_base()
    ufs_doc = json.loads((gbase / "ufs_base.json").read_text(encoding="utf-8"))
    ufs = ufs_doc["ufs"]
    geo = destino / "geo"
    resumo = {}

    feats = [
        {
            "type": "Feature",
            "properties": {"sigla": u["s"], "nome": u["n"], "regiao": u["rn"], "amazonia_legal": u["al"]},
            "geometry": {"type": "MultiPolygon", "coordinates": _aneis_geojson(u["d"])},
        }
        for u in ufs
    ]
    _escrever(geo / "ufs.geojson", {"type": "FeatureCollection", "features": feats})

    ufs_compactas = [
        {**u, "cx": round(u["cx"], 1), "cy": round(u["cy"], 1), "d": _compactar_path_inteiro(u["d"])}
        for u in ufs
    ]
    _escrever(geo / "ufs.json", {
        "W": ufs_doc["W"], "H": ufs_doc["H"], "ufs": ufs_compactas,
        "nota": "al: 2 = UF inteira na Amazônia Legal; 1 = parcialmente (MA); 0 = fora. "
                "Coordenadas no espaço do mapa (Mercator, 0..1000 x 0..1050,1).",
    })
    resumo["ufs"] = len(ufs_compactas)

    with Image.open(gbase / "relevo_base.webp") as im:
        im = im.convert("RGB")
        im.save(geo / "relevo.webp", "WEBP", quality=60, method=6)
        pequeno = im.resize((int(im.width * 0.36), int(im.height * 0.36)), Image.LANCZOS)
        pequeno.save(geo / "relevo_pequeno.webp", "WEBP", quality=25, method=6)
    resumo["relevo_bytes"] = (geo / "relevo.webp").stat().st_size
    resumo["relevo_pequeno_bytes"] = (geo / "relevo_pequeno.webp").stat().st_size

    # Relevo baixado uma vez (etapa de mídia) e guardado em SAIDA_DIR/geo: segue para o pacote como está.
    for nome_relevo, chave in (("altimetria_m.webp", "altimetria_m_bytes"), ("dem_brasil.webp", "dem_brasil_bytes")):
        origem_relevo = config.SAIDA_DIR / "geo" / nome_relevo
        if origem_relevo.exists():
            shutil.copy2(origem_relevo, geo / nome_relevo)
            resumo[chave] = (geo / nome_relevo).stat().st_size

    rios_doc = json.loads((gbase / "rios_ne10m.json").read_text(encoding="utf-8"))
    _escrever(geo / "rios.json", rios_doc)
    resumo["rios"] = len(rios_doc["rios"])

    resumo["bacias"] = _exportar_bacias(geo, con=con)

    n_db_lac = con.execute("SELECT COUNT(*) FROM celula_lacuna").fetchone()[0] if con is not None else 0
    if n_db_lac > 0:
        cols = ["x", "y", "w", "h", "lon", "lat", "n", "km2", "d", "bacia", "pressao", "prot", "biv"]
        linhas_lac = []
        cids = set()
        for r in con.execute("SELECT * FROM celula_lacuna ORDER BY id"):
            linhas_lac.append([
                round(r["x_mapa"], 2), round(r["y_mapa"], 2), round(r["w_mapa"], 2), round(r["h_mapa"], 2),
                round(r["lon"], 3), round(r["lat"], 3), r["n_ocorrencias_gbif"], round(r["area_km2"], 1),
                round(r["densidade_km2"], 5), r["bacia_id"],
                round(r["pressao_desmatamento"], 3) if r["pressao_desmatamento"] is not None else None,
                round(r["cobertura_protegida"], 3) if r["cobertura_protegida"] is not None else None,
                r["prioridade_bivariada"],
            ])
            for k in ("gbif_consulta_id", "pressao_consulta_id"):
                if r[k]:
                    cids.add(r[k])
        consultas_lac = []
        for cid in sorted(cids):
            c = con.execute(
                "SELECT c.*, f.nome AS fonte_nome, f.licenca FROM consulta c JOIN fonte f ON f.id=c.fonte_id WHERE c.id=?",
                (cid,),
            ).fetchone()
            if c:
                consultas_lac.append({
                    "id": c["id"], "fonte": c["fonte_id"], "fonte_nome": c["fonte_nome"],
                    "licenca": c["licenca"], "url": c["url"], "data": c["consultado_em"][:10],
                })
        _escrever(geo / "lacunas.json", {
            "colunas": cols, "linhas": linhas_lac, "passo_graus": 0.5,
            "crs_geodesico": go.CRS_GEODESICO,
            "fonte": "SQLite celula_lacuna: GBIF (densidade em grade 0,5° sobre GRS80), INPE TerraBrasilis PRODES e união vetorial EPSG:5880 MMA/CNUC ∪ FUNAI",
            "consultas": consultas_lac,
            "aviso": "Ausência de registro não é ausência biológica: é lacuna de amostragem. A classe bivariada cruza cegueira amostral (G1..G3) × pressão PRODES (P1..P3).",
        })
        resumo["celulas_lacunas"] = len(linhas_lac)
    else:
        molde = go.carregar_grade_molde_05deg()
        cols = ["x", "y", "w", "h", "lon", "lat", "n", "km2", "d"]
        _escrever(geo / "lacunas.json", {
            "colunas": cols,
            "linhas": [[c["x"], c["y"], c["w"], c["h"], c["lon"], c["lat"], 0, c["km2"], 0.0] for c in molde],
            "passo_graus": 0.5,
            "crs_geodesico": go.CRS_GEODESICO,
            "fonte": "Grade geodésica GRS80 de 0,5° sobre a Amazônia Legal, sem contagens de ocorrência",
            "aviso": "Ausência de registro não é ausência biológica: é lacuna de amostragem.",
        })
        resumo["celulas_lacunas"] = len(molde)
    log(f"  geometria: {resumo}")
    return resumo
