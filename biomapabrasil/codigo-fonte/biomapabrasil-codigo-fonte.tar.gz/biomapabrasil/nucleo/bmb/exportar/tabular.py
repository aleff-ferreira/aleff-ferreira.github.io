# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Tabelas CSV (UTF-8 com BOM, para abrir direto no Excel) com proveniência em cada linha.

Só registros públicos, pela mesma seleção dos pacotes do site (`pacotes.Contexto`): afirmações em estado e acesso
públicos, moléculas com registro público, obras citáveis, linhagens públicas e as consultas que sustentam isso.
"""
import csv
import json

from .. import curadoria
from . import pacotes


def _gravar(caminho, colunas, linhas):
    caminho.parent.mkdir(parents=True, exist_ok=True)
    with open(caminho, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, lineterminator="\r\n")
        w.writerow(colunas)
        n = 0
        for l in linhas:
            w.writerow(["" if v is None else v for v in l])
            n += 1
    return n


def exportar_csv(con, ctx, destino, log=print):
    n = {}
    cons = lambda cid: ctx.consultas.get(cid)

    def url_data(cid):
        c = cons(cid) if cid else None
        return (c["url"], c["consultado_em"][:10]) if c else (None, None)

    def doi_pmid(rid):
        r = ctx.refs.get(ctx.ref_publica(rid)) if rid else None
        return (r["doi"], r["pmid"]) if r else (None, None)

    # táxons
    linhas = []
    for t in con.execute("SELECT * FROM taxon ORDER BY nome"):
        td = dict(t)
        u, d = url_data(td["ocorr_consulta_id"])
        pop = "; ".join(p["nome"] for p in json.loads(td["nomes_populares"] or "[]"))
        biomas = "; ".join(json.loads(td["biomas_json"] or "[]"))
        linhas.append([td["id"], td["gbif_key"], td["nome"], td["autoria"], td["rank"], td["reino"], td["filo"], td["classe"], td["ordem"],
                       td["familia"], td["genero"], td["grupo"], pop, td["no_recorte"], td["predominio_al"],
                       td.get("distribuicao_br") or "indeterminada",
                       td["n_br"], td["n_br_com_uf"], td["n_al"], td.get("n_al_exato"), td["n_bioma_amazonia"], td["n_ma_oeste44"],
                       td["fracao_al_com_uf"], td["fracao_al_total"], td["endemismo_br"], biomas, td["forma_vida"], td["estrato_florestal"],
                       td["categoria_mma"], td["iucn"], td["motivo_recorte"], td["origem_inclusao"], u, d])
    n["taxa"] = _gravar(destino / "taxa.csv",
                        ["taxon_id", "gbif_key", "nome_cientifico", "autoria", "rank", "reino", "filo", "classe", "ordem", "familia",
                         "genero", "grupo", "nomes_populares", "no_recorte", "predominio_amazonico", "distribuicao_br",
                         "n_registros_br", "n_registros_br_com_uf", "n_registros_amazonia_legal", "n_registros_al_exato_wkt",
                         "n_registros_bioma_amazonia", "n_registros_ma_oeste44w", "fracao_al_so_com_uf", "fracao_al_todos",
                         "endemismo_br", "biomas_br", "forma_vida", "estrato_florestal", "categoria_mma", "categoria_iucn",
                         "motivo_recorte", "origem_inclusao", "consulta_url", "consulta_data"], linhas)

    # ocorrências agregadas por UF (nunca coordenadas individuais)
    linhas = []
    for r in con.execute("SELECT o.*, t.gbif_key, t.nome FROM ocorrencia_uf o JOIN taxon t ON t.id=o.taxon_id ORDER BY t.nome, o.uf_sigla"):
        u, d = url_data(r["consulta_id"])
        linhas.append([r["taxon_id"], r["gbif_key"], r["nome"], r["uf_sigla"], r["n"], u, d])
    n["ocorrencias_por_uf"] = _gravar(destino / "ocorrencias_por_uf.csv",
                                      ["taxon_id", "gbif_key", "nome_cientifico", "uf", "n_registros", "consulta_url", "consulta_data"], linhas)

    # ocorrências agregadas por bacia hidrográfica amazônica (remete a consultas.csv por consulta_id + sha256, evitando repetir WKT longo)
    linhas = []
    for r in con.execute(
        "SELECT ob.*, b.nome AS bacia_nome, t.gbif_key, t.nome FROM ocorrencia_bacia ob "
        "JOIN bacia_hidrografica b ON b.id=ob.bacia_id JOIN taxon t ON t.id=ob.taxon_id "
        "WHERE ob.n > 0 ORDER BY t.nome, ob.bacia_id"
    ):
        c_ob = cons(r["consulta_id"]) if r["consulta_id"] else None
        linhas.append([
            r["taxon_id"], r["gbif_key"], r["nome"], r["bacia_id"], r["bacia_nome"], r["n"],
            r["consulta_id"], c_ob["sha256"] if c_ob else None, c_ob["consultado_em"][:10] if c_ob else None,
        ])
    n["ocorrencias_por_bacia"] = _gravar(
        destino / "ocorrencias_por_bacia.csv",
        ["taxon_id", "gbif_key", "nome_cientifico", "bacia_id", "bacia_nome", "n_registros",
         "consulta_id", "consulta_sha256", "consulta_data"],
        linhas,
    )

    # moléculas públicas, com identidade química (estrutura com estereoquímica e esqueleto 2D) e descritores RDKit
    linhas = []
    for m in sorted((ctx.mol[mid] for mid in ctx.mols_publicas), key=lambda m: (m["nome"], m["id"])):
        linhas.append([m["id"], m["tipo"], m["nome"], m["nome_na_fonte"], m["inchikey"], pacotes.conectividade(m), m["smiles"],
                       m["formula"], pacotes.massa_publica(m), m.get("massa_monoisotopica"), m.get("massa_media"),
                       m.get("estereocentros"), m.get("estereocentros_indefinidos"),
                       m["clogp"], m["tpsa"], m["fsp3"], m["hbd"], m["hba"], m["qed"], m["np_likeness"], m["murcko_smiles"],
                       m["classe_quimica"], m["familia"], m["uniprot_acc"], m["comprimento_aa"], m["pdb_ids"], m["pubchem_cid"],
                       m["chembl_id"], m["lotus_id"], m["nubbe_id"], m["npatlas_id"], m["max_fase_clinica"]])
    n["moleculas"] = _gravar(destino / "moleculas.csv",
                             ["molecula_id", "tipo", "nome", "nome_na_fonte", "inchikey", "inchikey_conectividade", "smiles",
                              "formula", "massa", "massa_monoisotopica", "massa_media", "estereocentros", "estereocentros_indefinidos",
                              "clogp", "tpsa", "fsp3", "hbd", "hba", "qed", "np_likeness", "murcko_smiles",
                              "classe", "familia", "uniprot", "comprimento_aa", "pdb_ids", "pubchem_cid",
                              "chembl_id", "lotus_id", "nubbe_id", "npatlas_id", "fase_clinica_max"], linhas)

    # linhagens de fármacos bioinspirados, cada uma com a frase da obra citada
    linhas = []
    for r in ctx.linhagens:
        u, d = url_data(r["consulta_id"])
        doi, pmid = doi_pmid(r["referencia_id"])
        origem, destino_mol = ctx.mol[r["origem_id"]], ctx.mol[r["destino_id"]]
        linhas.append([r["id"], r["tipo"], r["origem_id"], origem["nome"], r["destino_id"], destino_mol["nome"],
                       destino_mol["chembl_id"], r["texto"], r.get("trecho"), r.get("trecho_fonte"), doi, pmid, u, d])
    n["linhagens_bioinspiradas"] = _gravar(destino / "linhagens_bioinspiradas.csv",
                                           ["relacao_id", "tipo_relacao", "origem_molecula_id", "origem_nome",
                                            "destino_molecula_id", "destino_nome", "destino_chembl_id", "enunciado",
                                            "trecho", "trecho_fonte", "doi", "pmid", "consulta_url", "consulta_data"], linhas)

    # afirmações públicas
    linhas = []
    sql = (f"SELECT a.*, t.nome AS t_nome, t.gbif_key, m.nome AS m_nome, m.inchikey, al.nome AS alvo_nome, al.chembl_id AS alvo_chembl, "
           f"al.natureza AS alvo_natureza "
           f"FROM afirmacao a LEFT JOIN taxon t ON t.id=a.taxon_id JOIN molecula m ON m.id=a.molecula_id "
           f"LEFT JOIN alvo al ON al.id=a.alvo_id WHERE {pacotes.sql_afirmacao_exportada('a')} ORDER BY a.id")
    for a in con.execute(sql):
        ad = dict(a)
        u, d = url_data(ad["consulta_id"])
        refs = [ctx.refs[r] for r in ctx.refs_da_af.get(ad["id"], [])]
        p = ctx.prontidao.get(ad["id"], {})
        passagem, passagem_origem, _ = pacotes.passagem_publica(ctx, ad)
        organismo = ad["tipo"] in pacotes.TIPOS_DE_ORGANISMO
        campos = pacotes._campos_de_organismo(None, ad)
        artigo = campos.get("procedencia_artigo") or {}
        linhas.append([ad["id"], ad["tipo"], ad["estado"], ad.get("nivel_evidencia") or "base_curada",
                       ad["taxon_id"], ad["gbif_key"], ad["t_nome"], ad.get("organismo_na_fonte") if organismo else None,
                       ad["molecula_id"], ad["m_nome"], ad["inchikey"],
                       ad["alvo_nome"], ad["alvo_chembl"],
                       (ad["alvo_natureza"] or "indeterminado") if ad["tipo"] == "atividade_biologica" and ad["alvo_id"] else None,
                       ad["texto"], passagem, passagem_origem,
                       ad["metodo"], ad["sistema_experimental"], ad.get("ensaio_tipo"),
                       ad["medida_tipo"], ad["medida_relacao"], ad["medida_valor"], ad["medida_unidade"],
                       ad.get("medida_agregacao"), ad.get("medida_n"), ad.get("medida_n_documentos"), ad.get("medida_min"), ad.get("medida_max"),
                       campos.get("procedencia"), campos.get("pais_coleta"), campos.get("uf_coleta"),
                       artigo.get("classe"), artigo.get("local"),
                       pacotes.voucher_publico(ad.get("voucher_declarado_base")) if organismo else None, ad["fonte_id"],
                       ctx.fontes[ad["fonte_id"]]["licenca"], u, d, p.get("indice"),
                       "; ".join(r["doi"] for r in refs if r["doi"]), "; ".join(r["pmid"] for r in refs if r["pmid"]), ad["classe_acesso"]])
    n["afirmacoes"] = _gravar(destino / "afirmacoes.csv",
                              ["afirmacao_id", "tipo", "estado", "evidencia", "taxon_id", "gbif_key", "nome_taxon", "organismo_na_fonte",
                               "molecula_id", "nome_molecula", "inchikey", "alvo", "alvo_chembl_id", "natureza_alvo",
                               "enunciado", "passagem", "passagem_origem",
                               "metodo", "sistema_experimental", "ensaio_tipo",
                               "medida_tipo", "medida_relacao", "medida_valor", "medida_unidade",
                               "medida_agregacao", "medida_n", "medida_n_documentos", "medida_min", "medida_max",
                               "procedencia_declarada", "pais_coleta_declarado", "uf_coleta_declarada",
                               "procedencia_artigo", "procedencia_artigo_local",
                               "voucher_declarado_base", "fonte", "fonte_licenca", "consulta_url", "consulta_data", "indice_prontidao",
                               "referencias_doi", "referencias_pmid", "classe_acesso"], linhas)

    # leitura de curador que sustenta cada afirmação verificada: o que é estruturado; texto livre do curador não sai
    linhas = []
    exportadas = ctx.afirmacoes_exportadas()
    for aid in sorted(aid for aid in ctx.verificacao if aid in exportadas):
        vd = ctx.verificacao[aid]
        af = con.execute("SELECT * FROM afirmacao WHERE id=?", (aid,)).fetchone()
        if af["estado"] != "verificado":
            continue
        doi, pmid = doi_pmid(vd["referencia_id"])
        linhas.append([aid, vd["curador"], vd["decisao"], vd["em"], doi, pmid, vd.get("acesso_texto"), vd.get("escopo_geografico_lido"),
                       pacotes.passagem_publica(ctx, dict(af))[0], curadoria.voucher_de_colecao(vd["voucher"]),
                       vd["qualidade_experimental"]])
    n["verificacoes"] = _gravar(destino / "verificacoes.csv",
                                ["afirmacao_id", "curador", "decisao", "em", "referencia_doi", "referencia_pmid", "acesso_texto",
                                 "escopo_geografico_lido", "trecho_conferido", "voucher", "qualidade_experimental"], linhas)

    # espécies aceitas no bioma Amazônia nos catálogos nacionais, com a marca de química registrada em base aberta
    if con.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='universo_checklist'").fetchone()[0]:
        qtd_u = con.execute("SELECT COUNT(*) FROM universo_checklist WHERE bioma_amazonia_declarado=1").fetchone()[0]
        if qtd_u:
            linhas_u = [
                [r["fonte"], r["taxon_id_fonte"], r["nome_aceito"], r["autoria"], r["reino"], r["familia"], r["grupo_bmb"],
                 r["status_origem_br"], r["endemismo_br"], r["dominios_fitogeograficos"], r["ufs_distribuicao"],
                 r["tem_quimica_aberta"], r["taxon_id_bmb"]]
                for r in con.execute("SELECT * FROM universo_checklist WHERE bioma_amazonia_declarado=1 ORDER BY grupo_bmb, nome_aceito")
            ]
            n["universo_checklist_amazonia"] = _gravar(
                destino / "universo_checklist_amazonia.csv",
                ["fonte_catalogo", "taxon_id_fonte", "nome_cientifico", "autoria", "reino", "familia", "grupo_bmb",
                 "status_origem_br", "endemismo_br", "dominios_fitogeograficos", "ufs_distribuicao",
                 "tem_quimica_aberta", "taxon_id_bmb"],
                linhas_u,
            )

    # referências: as obras citáveis que algum registro público cita
    linhas = [[r["id"], r["doi"], r["pmid"], r["titulo"], "; ".join(json.loads(r["autores"] or "[]")), r["revista"], r["ano"],
               r.get("tipo_obra"), r["aviso"], r.get("texto_nivel"), r["resolvida"]]
              for r in (ctx.refs[rid] for rid in sorted(ctx.referencias_citadas()))]
    n["referencias"] = _gravar(destino / "referencias.csv",
                               ["referencia_id", "doi", "pmid", "titulo", "autores", "revista", "ano", "tipo_obra", "aviso",
                                "texto_nivel", "resolvida"], linhas)

    # prontidão das afirmações públicas
    linhas = [[p["afirmacao_id"], p["identidade_biologica"], p["procedencia"], p["identidade_quimica"], p["qualidade_experimental"],
               p["rastreabilidade"], p["reutilizacao"], p["sensibilidade"], p["indice"], p["notas"]]
              for p in (ctx.prontidao[aid] for aid in sorted(exportadas) if aid in ctx.prontidao)]
    n["prontidao"] = _gravar(destino / "prontidao.csv",
                             ["afirmacao_id", "identidade_biologica", "procedencia", "identidade_quimica", "qualidade_experimental",
                              "rastreabilidade", "reutilizacao", "sensibilidade", "indice_completude_nao_e_eficacia", "pendencias"], linhas)

    # fontes e as consultas que sustentam o que é público
    n["fontes"] = _gravar(destino / "fontes.csv", ["id", "nome", "url", "licenca", "licenca_url", "descricao"],
                          [[f["id"], f["nome"], f["url"], f["licenca"], f["licenca_url"], f["descricao"]] for f in ctx.fontes.values()])
    n["consultas"] = _gravar(destino / "consultas.csv", ["id", "fonte", "url", "consultado_em", "status", "bytes", "sha256", "versao_fonte"],
                             [[c["id"], c["fonte_id"], c["url"], c["consultado_em"], c["status"], c["bytes"], c["sha256"], c["versao_fonte"]]
                              for c in (ctx.consultas[cid] for cid in sorted(ctx.consultas_publicas()))])
    log(f"  CSV: {n}")
    return n
