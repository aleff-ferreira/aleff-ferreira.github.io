# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Darwin Core Archive (DwC-A) centrado em táxon, para IPT e SiBBr.

Núcleo `Taxon` + extensões VernacularName, ResourceRelationship (táxon -> composto relatado),
MeasurementOrFact (contagens GBIF por UF, com método e data) e Reference.

Só entram afirmações públicas de nível de organismo (LOTUS, NuBBE-DB, NPAtlas e UniProt), com as obras citáveis que
as sustentam. Atividade medida e efeito clínico, derivados do ChEMBL (CC BY-SA 3.0), ficam de fora para que o
arquivo mantenha licença única. Cada relação traz o nível de evidência e a procedência declarada como rótulos.
"""
import html
import json
import zipfile
from datetime import date

from .. import procedencia
from . import pacotes

DWC = "http://rs.tdwg.org/dwc/terms/"
DC = "http://purl.org/dc/terms/"
GBIF_T = "http://rs.gbif.org/terms/1.0/"
FONTES_DO_ARQUIVO = ("lotus", "nubbe", "uniprot", "npatlas")

COLUNAS_TAXON = [("taxonID", DWC), ("scientificName", DWC), ("scientificNameAuthorship", DWC), ("taxonRank", DWC),
                 ("taxonomicStatus", DWC), ("kingdom", DWC), ("phylum", DWC), ("class", DWC), ("order", DWC),
                 ("family", DWC), ("genus", DWC), ("references", DC), ("taxonRemarks", DWC)]
COLUNAS_VERNACULAR = [("taxonID", None), ("vernacularName", DWC), ("language", DC)]
COLUNAS_RELACAO = [("taxonID", None), ("relatedResourceID", DWC), ("relationshipOfResource", DWC),
                   ("relationshipAccordingTo", DWC), ("relationshipEstablishedDate", DWC), ("relationshipRemarks", DWC)]
COLUNAS_MEDIDA = [("taxonID", None), ("measurementType", DWC), ("measurementValue", DWC), ("measurementUnit", DWC),
                  ("measurementDeterminedDate", DWC), ("measurementMethod", DWC), ("measurementRemarks", DWC)]
COLUNAS_REFERENCIA = [("taxonID", None), ("bibliographicCitation", DC), ("identifier", DC)]


def _linha(valores):
    return "\t".join("" if v is None else str(v).replace("\t", " ").replace("\r", " ").replace("\n", " ") for v in valores)


def _tabela(colunas, linhas):
    return "\n".join([_linha([c for c, _ in colunas])] + [_linha(l) for l in linhas]) + "\n"


def _meta(arquivos):
    """meta.xml: o primeiro item de `arquivos` é o núcleo; os demais são extensões ligadas ao coreid."""
    partes = ['<?xml version="1.0" encoding="UTF-8"?>', '<archive xmlns="http://rs.tdwg.org/dwc/text/" metadata="eml.xml">']
    for i, (tag, nome, linha_tipo, colunas) in enumerate(arquivos):
        partes.append(f'  <{tag} encoding="UTF-8" fieldsTerminatedBy="\\t" linesTerminatedBy="\\n" fieldsEnclosedBy="" '
                      f'ignoreHeaderLines="1" rowType="{linha_tipo}">')
        partes.append(f"    <files><location>{nome}</location></files>")
        partes.append(f'    <{"id" if tag == "core" else "coreid"} index="0"/>')
        for j, (termo, ns) in enumerate(colunas):
            if j == 0 or ns is None:
                continue
            partes.append(f'    <field index="{j}" term="{ns}{termo}"/>')
        partes.append(f"  </{tag}>")
    partes.append("</archive>")
    return "\n".join(partes) + "\n"


def _eml(n_taxa, fontes):
    hoje = date.today().isoformat()
    titulo = "BioMapaBrasil: táxons com registros na Amazônia Legal e as moléculas relatadas neles na literatura"
    resumo = ("Táxons com registros do GBIF na Amazônia Legal e as moléculas que bases curadas abertas (LOTUS, NuBBE-DB, UniProt Tox-Prot, "
              "NPAtlas) relacionam a eles, cada relação com a publicação que a sustenta. Cada relação registra que o composto foi relatado "
              "no organismo e traz o nível de evidência e o local de coleta que a base de origem ou um curador declara, limitado a país e "
              "unidade da federação. Medidas de bioatividade e efeito clínico não fazem parte deste arquivo. Contagens por UF são agregadas.")
    licencas = ", ".join(f"{fontes[f]['nome'].split(' — ')[0].split(' (')[0]} ({fontes[f]['licenca']})" for f in FONTES_DO_ARQUIVO if f in fontes)
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<eml:eml xmlns:eml="eml://ecoinformatics.org/eml-2.1.1" packageId="biomapabrasil-{hoje}" system="BioMapaBrasil" xml:lang="pt">
  <dataset>
    <title xml:lang="pt">{html.escape(titulo)}</title>
    <creator><organizationName>Amazonia Works</organizationName></creator>
    <pubDate>{hoje}</pubDate>
    <language>pt</language>
    <abstract><para>{html.escape(resumo)} Táxons: {n_taxa}.</para></abstract>
    <intellectualRights><para>Creative Commons Attribution 4.0 (CC BY 4.0). As relações vêm de: {html.escape(licencas)}. Dados sob CC BY-SA (ChEMBL) são mantidos separados para preservar licença única.</para></intellectualRights>
    <contact><organizationName>Amazonia Works</organizationName></contact>
  </dataset>
</eml:eml>
"""


def exportar_dwca(con, ctx, destino, log=print):
    destino.mkdir(parents=True, exist_ok=True)
    taxa, vern, rel, med, refs = [], [], [], [], []
    marcas = ",".join("?" * len(FONTES_DO_ARQUIVO))
    for t in con.execute("SELECT * FROM taxon WHERE no_recorte=1 ORDER BY nome"):
        tid = f"gbif:{t['gbif_key']}"
        taxa.append([tid, t["nome"], t["autoria"], t["rank"].lower() if t["rank"] else None, "accepted", t["reino"], t["filo"], t["classe"],
                     t["ordem"], t["familia"], t["genero"], f"https://www.gbif.org/species/{t['gbif_key']}", t["motivo_recorte"]])
        for p in json.loads(t["nomes_populares"] or "[]"):
            vern.append([tid, p["nome"], p.get("idioma")])
        c = ctx.consultas.get(t["ocorr_consulta_id"]) if t["ocorr_consulta_id"] else None
        if c:
            data = c["consultado_em"][:10]
            metodo = f"GBIF occurrence search (facet gadmLevel1Gid), {c['url']}"
            med.append([tid, "contagem de registros no Brasil", t["n_br"], "registros", data, metodo, "inclui registros sem UF"])
            med.append([tid, "contagem de registros na Amazônia Legal", t["n_al"], "registros", data, metodo, "só registros com UF atribuída"])
            for r in con.execute("SELECT uf_sigla, n FROM ocorrencia_uf WHERE taxon_id=? ORDER BY uf_sigla", (t["id"],)):
                med.append([tid, f"contagem de registros em {r['uf_sigla']}", r["n"], "registros", data, metodo, None])
        # relações táxon -> composto/toxina e as obras que as sustentam (só fontes de licença compatível com CC BY 4.0)
        for a in con.execute(f"SELECT a.*, m.inchikey, m.uniprot_acc FROM afirmacao a JOIN molecula m ON m.id=a.molecula_id "
                             f"WHERE a.taxon_id=? AND {pacotes.sql_publica('a')} AND a.fonte_id IN ({marcas}) ORDER BY a.id",
                             (t["id"], *FONTES_DO_ARQUIVO)):
            alvo = f"inchikey:{a['inchikey']}" if a["inchikey"] else f"uniprot:{a['uniprot_acc']}"
            ca = ctx.consultas[a["consulta_id"]]
            evidencia = pacotes.ROTULOS_EVIDENCIA[a["nivel_evidencia"] or "base_curada"]
            coleta = procedencia.ROTULOS_PROCEDENCIA[a["procedencia_declarada"] or "nao_declarada"]
            rel.append([tid, alvo, "composto relatado no organismo" if a["tipo"] == "composto_em_organismo" else "toxina anotada no organismo",
                        ctx.fontes[a["fonte_id"]]["nome"], ca["consultado_em"][:10],
                        f"{a['texto']} Evidência: {evidencia}. {coleta}."])
            for rid in ctx.refs_da_af.get(a["id"], []):
                r = ctx.refs[rid]
                autores = "; ".join(json.loads(r["autores"] or "[]")[:3])
                cit = f"{autores} ({r['ano'] or 's.d.'}). {r['titulo'] or '(título não resolvido)'}. {r['revista'] or ''}".strip()
                refs.append([tid, cit, f"https://doi.org/{r['doi']}" if r["doi"] else (f"https://pubmed.ncbi.nlm.nih.gov/{r['pmid']}/" if r["pmid"] else None)])
    # sem repetição de referência por táxon
    vistos, refs_unicas = set(), []
    for r in refs:
        if (r[0], r[2]) not in vistos:
            vistos.add((r[0], r[2]))
            refs_unicas.append(r)
    arquivos = [("core", "taxon.txt", DWC + "Taxon", COLUNAS_TAXON),
                ("extension", "vernacularname.txt", GBIF_T + "VernacularName", COLUNAS_VERNACULAR),
                ("extension", "resourcerelationship.txt", DWC + "ResourceRelationship", COLUNAS_RELACAO),
                ("extension", "measurementorfact.txt", DWC + "MeasurementOrFact", COLUNAS_MEDIDA),
                ("extension", "reference.txt", GBIF_T + "Reference", COLUNAS_REFERENCIA)]
    dados = {"taxon.txt": _tabela(COLUNAS_TAXON, taxa), "vernacularname.txt": _tabela(COLUNAS_VERNACULAR, vern),
             "resourcerelationship.txt": _tabela(COLUNAS_RELACAO, rel), "measurementorfact.txt": _tabela(COLUNAS_MEDIDA, med),
             "reference.txt": _tabela(COLUNAS_REFERENCIA, refs_unicas)}
    caminho = destino / "biomapabrasil_dwca.zip"
    with zipfile.ZipFile(caminho, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("meta.xml", _meta(arquivos))
        z.writestr("eml.xml", _eml(len(taxa), ctx.fontes))
        for nome, conteudo in dados.items():
            z.writestr(nome, conteudo)
    log(f"  DwC-A: {len(taxa)} táxons, {len(rel)} relações, {len(med)} medidas, {len(refs_unicas)} referências ({caminho.stat().st_size/1024:.0f} KB)")
