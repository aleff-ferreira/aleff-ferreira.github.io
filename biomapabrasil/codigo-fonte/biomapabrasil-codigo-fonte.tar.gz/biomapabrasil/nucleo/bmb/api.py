# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""API de consulta (somente leitura), site estático e, opcionalmente, a curadoria local.

* `/api/...`        consulta pública; JSON; CORS aberto para GET; limite de requisições por IP.
* `/curadoria/...`  só com `curadoria_ativa=True`, só em endereço de loopback e com token por sessão: a
                    escrita no banco nunca fica exposta.
* `/`               o site estático (plataforma/app).

Todas as respostas usam os mesmos formatos e a mesma seleção dos pacotes estáticos (bmb.exportar.pacotes), para que
o site, a API e os CSV nunca divirjam: só registro público, e nenhuma contagem que inclua registro não publicado
(docs/dev/CONTRATO_DE_DADOS.md). O livro de retenções e a validação por amostragem só existem com a curadoria
ligada (`/api/quarentena`, `/api/benchmark`), com o token da sessão. SQL sempre parametrizado.
"""
import hashlib
import hmac
import json
import mimetypes
import os
import re
import secrets
import sqlite3
import threading
import time
from pathlib import Path

from starlette.applications import Starlette
from starlette.exceptions import HTTPException
from starlette.middleware import Middleware
from starlette.middleware.cors import CORSMiddleware
from starlette.requests import Request
from starlette.responses import HTMLResponse, JSONResponse, Response
from starlette.routing import Mount, Route
from starlette.staticfiles import StaticFiles

from . import __version__, config, curadoria, db, procedencia, quarentena
from .exportar import pacotes
from .util import sem_acento

MAX_LIMITE = 200
ESTADOS_PUB = pacotes.ESTADOS_PUBLICOS
GRUPOS = ("planta", "fungo", "animal_peconhento", "outro")

mimetypes.add_type("font/woff2", ".woff2")
mimetypes.add_type("font/woff", ".woff")
mimetypes.add_type("chemical/x-mdl-sdfile", ".sdf")


# ═══════════════════════════ estado compartilhado ═══════════════════════════
class Dados:
    """Abre o banco em modo somente leitura e guarda o contexto de leitura, recarregado quando o arquivo muda."""

    def __init__(self, caminho, pasta_3d=None):
        self.pasta_3d = pasta_3d
        self.caminho = Path(caminho)
        self._trava = threading.Lock()
        self._mtime = None
        self._ctx = None

    def conexao(self):
        con = sqlite3.connect(f"file:{self.caminho.as_posix()}?mode=ro", uri=True, check_same_thread=False)
        con.row_factory = sqlite3.Row
        return con

    def versao(self):
        """Instante da última mudança do banco. Conta também o diário WAL: uma escrita confirmada (verificação ou
        quarentena feita na curadoria) fica no diário até o checkpoint, e a leitura pública tem de enxergá-la na hora."""
        instantes = [os.stat(arq).st_mtime_ns for arq in (self.caminho, Path(f"{self.caminho}-wal")) if arq.is_file()]
        return max(instantes, default=0)

    def contexto(self):
        with self._trava:
            v = self.versao()
            if self._ctx is None or v != self._mtime:
                if self._ctx is not None:
                    self._ctx.con.close()
                con = self.conexao()
                self._ctx = pacotes.Contexto(con, self.pasta_3d)       # a conexão fica viva no contexto: ele consulta o banco sob demanda
                self._mtime = v
            return self._ctx

    def fechar(self):
        """Fecha a conexão de leitura (quem monta instantâneos estáticos usa a aplicação uma vez e a descarta)."""
        with self._trava:
            if self._ctx is not None:
                self._ctx.con.close()
            self._ctx = self._mtime = None


class LimiteDeRequisicoes:
    """Balde de fichas por IP: rajada de 120 e reposição de 2 por segundo. Protege o servidor, sem exigir cadastro."""

    def __init__(self, app, capacidade=120, reposicao=2.0):
        self.app, self.cap, self.rep, self.baldes = app, capacidade, reposicao, {}

    async def __call__(self, escopo, receber, enviar):
        if escopo["type"] == "http" and escopo["path"].startswith("/api/"):
            ip = (escopo.get("client") or ("?", 0))[0]
            agora = time.monotonic()
            fichas, ultimo = self.baldes.get(ip, (self.cap, agora))
            fichas = min(self.cap, fichas + (agora - ultimo) * self.rep)
            if fichas < 1:
                resp = JSONResponse({"erro": "Muitas requisições. Espere alguns segundos."}, status_code=429, headers={"Retry-After": "5"})
                return await resp(escopo, receber, enviar)
            self.baldes[ip] = (fichas - 1, agora)
            if len(self.baldes) > 5000:           # evita crescer sem limite
                self.baldes = {k: v for k, v in self.baldes.items() if agora - v[1] < 600}
        await self.app(escopo, receber, enviar)


# ═══════════════════════════ utilidades ═══════════════════════════
def _json(request, corpo, status=200, max_age=300, extra=None):
    estado = request.app.state.dados
    etag = f'W/"{estado.versao()}-{abs(hash(str(request.url))) % 10**8}"'
    if request.headers.get("if-none-match") == etag and status == 200:
        return Response(status_code=304, headers={"ETag": etag})
    cab = {"Cache-Control": f"public, max-age={max_age}", "ETag": etag, **(extra or {})}
    return JSONResponse(corpo, status_code=status, headers=cab, media_type="application/json")


def _erro(msg, status=400):
    return JSONResponse({"erro": msg}, status_code=status, headers={"Cache-Control": "no-store"})


def _paginacao(request):
    try:
        limite = int(request.query_params.get("limite", 50))
        offset = int(request.query_params.get("offset", 0))
    except ValueError:
        raise HTTPException(400, "limite e offset devem ser inteiros")
    return max(1, min(limite, MAX_LIMITE)), max(0, offset)


def _fts(q):
    """Consulta FTS5 com prefixo em cada termo, sem acento. Devolve None se não houver termo utilizável."""
    termos = re.findall(r"\w+", sem_acento(q or ""))
    return " AND ".join(f'"{t}"*' for t in termos[:6]) or None


def _ids_fts(con, tipo, q):
    expr = _fts(q)
    if expr is None:
        return None
    return [r[0] for r in con.execute("SELECT ref_id FROM busca WHERE tipo=? AND busca MATCH ? ORDER BY bm25(busca) LIMIT 2000", (tipo, expr))]


def _marcadores(ids):
    return ",".join("?" * len(ids)) or "NULL"


def _mol_publica(ctx, mid):
    return ctx.mol_publica(mid)


def _inteiro(p, nome):
    try:
        return int(p[nome])
    except ValueError:
        raise HTTPException(400, f"{nome} deve ser inteiro")


def _codigos(valor, validos, nome):
    """Códigos pedidos em um filtro (um ou vários, separados por vírgula), conferidos contra o vocabulário."""
    pedidos = [x.strip() for x in valor.split(",") if x.strip()]
    if not pedidos or any(x not in validos for x in pedidos):
        raise HTTPException(400, f"{nome} deve ser um de: {', '.join(validos)}")
    return pedidos


FILTROS_EXTINTOS = {"escopo": "distribuicao_br", "nivel_procedencia": "procedencia"}


def _recusar_filtros_extintos(p):
    for nome, novo in FILTROS_EXTINTOS.items():
        if nome in p:
            raise HTTPException(400, f"O filtro «{nome}» não existe mais; use «{novo}».")


def _condicoes_de_afirmacao(p, a):
    """Filtros de evidência e de procedência declarada como condições SQL sobre `afirmacao` (apelido `a`): (lista, args)."""
    onde, args = [], []
    if p.get("evidencia"):
        ev = _codigos(p["evidencia"], pacotes.ORDEM_EVIDENCIA, "evidencia")
        onde.append(f"IFNULL({a}.nivel_evidencia, 'base_curada') IN ({_marcadores(ev)})"); args += ev
    if p.get("procedencia"):
        pr = _codigos(p["procedencia"], tuple(procedencia.ROTULOS_PROCEDENCIA), "procedencia")
        onde.append(f"{a}.taxon_id IS NOT NULL AND IFNULL({a}.procedencia_declarada, 'nao_declarada') IN ({_marcadores(pr)})"); args += pr
    if p.get("coleta_amazonica_declarada"):
        if p["coleta_amazonica_declarada"] != "1":
            raise HTTPException(400, "coleta_amazonica_declarada aceita só o valor 1")
        amz = procedencia.PROCEDENCIA_AMAZONICA_DECLARADA
        onde.append(f"{a}.procedencia_declarada IN ({_marcadores(amz)})"); args += amz
    return onde, args


def _resumo_consulta(ctx, cid):
    if cid is None or cid not in ctx.consultas:
        return None
    c = ctx.consultas[cid]
    f = ctx.fontes.get(c["fonte_id"], {})
    return {
        "id": cid,
        "fonte": c["fonte_id"],
        "fonte_nome": f.get("nome"),
        "licenca": f.get("licenca"),
        "url": c["url"],
        "data": (c["consultado_em"] or "")[:10] or None,
        "sha256": c["sha256"],
    }


# ═══════════════════════════ rotas públicas ═══════════════════════════
async def raiz(request):
    spec = especificacao(request.app.state.curadoria_ativa)
    return _json(request, {
        "nome": "BioMapaBrasil · API de consulta", "versao_api": __version__, "somente_leitura": True,
        "documentacao": "/api/docs", "especificacao": "/api/openapi.json",
        "aviso": "Associação documentada não é eficácia. Cada afirmação traz fonte, licença, data da consulta e nível de evidência.",
        "governanca_sisgen": "Compilação aberta de metadados secundários sob a Lei nº 13.123/2015 e Decreto nº 8.772/2016 (SisGen/CGEN), Protocolo de Nagoia e Princípios CARE. Local de coleta só como país e unidade da federação; nenhuma coordenada individual e nenhum conhecimento tradicional associado.",
        "endpoints": [*spec["paths"], "/api/openapi.json", "/api/docs"]})


async def saude(request):
    ctx = request.app.state.dados.contexto()
    con = ctx.con
    q = lambda s: con.execute(s).fetchone()[0]
    c = ctx.contagens()
    return _json(request, {
        "ok": True, "versao": __version__,
        "taxons": c["taxons"],
        "moleculas": c["moleculas"],
        "afirmacoes": c["afirmacoes_publicas"],
        "bacias": c["bacias_hidrograficas"],
        "celulas_lacuna": q("SELECT COUNT(*) FROM celula_lacuna"),
        "estruturas_3d": c["estruturas_3d"],
        "vias_reactome": c["vias_reactome"],
        "linhagens_bioinspiradas": c["linhagens_bioinspiradas"],
        "banco_atualizado_em": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(request.app.state.dados.versao() / 1e9)),
    }, max_age=30)


async def fontes(request):
    ctx = request.app.state.dados.contexto()
    return _json(request, {"fontes": pacotes.fontes_com_consultas(ctx)})


async def taxa(request):
    ctx = request.app.state.dados.contexto()
    con, p = ctx.con, request.query_params
    limite, offset = _paginacao(request)
    _recusar_filtros_extintos(p)
    onde, args = [], []
    if p.get("recorte", "1") != "0":
        onde.append("t.no_recorte = 1")
    if p.get("grupo"):
        if p["grupo"] not in GRUPOS:
            return _erro(f"grupo deve ser um de {', '.join(GRUPOS)}")
        onde.append("t.grupo = ?"); args.append(p["grupo"])
    if p.get("predominio"):
        onde.append("t.predominio_al = ?"); args.append(p["predominio"])
    if p.get("estrato"):
        onde.append("t.estrato_florestal = ?"); args.append(p["estrato"])
    if p.get("distribuicao_br"):
        dist = _codigos(p["distribuicao_br"], tuple(procedencia.ROTULOS_DISTRIBUICAO), "distribuicao_br")
        onde.append(f"IFNULL(t.distribuicao_br, 'indeterminada') IN ({_marcadores(dist)})"); args += dist
    cond_af, args_af = _condicoes_de_afirmacao(p, "afp")
    if cond_af:      # todas as condições valem para UMA mesma afirmação pública do táxon
        onde.append(f"EXISTS (SELECT 1 FROM afirmacao afp WHERE afp.taxon_id=t.id AND {pacotes.sql_publica('afp')} AND {' AND '.join(cond_af)})")
        args += args_af
    if p.get("uf"):
        onde.append("EXISTS (SELECT 1 FROM ocorrencia_uf o WHERE o.taxon_id=t.id AND o.uf_sigla=? AND o.n>0)"); args.append(p["uf"].upper())
    if p.get("bacia"):
        onde.append("EXISTS (SELECT 1 FROM ocorrencia_bacia ob WHERE ob.taxon_id=t.id AND ob.bacia_id IN (?, ?) AND ob.n>0)"); args.extend(_candidatos_bacia_id(p["bacia"]))
    if p.get("q"):
        ids = _ids_fts(con, "taxon", p["q"])
        if ids is None:
            return _erro("q sem termos utilizáveis")
        onde.append(f"t.id IN ({_marcadores(ids)})"); args += ids
    clausula = (" WHERE " + " AND ".join(onde)) if onde else ""
    total = con.execute(f"SELECT COUNT(*) FROM taxon t{clausula}", args).fetchone()[0]
    linhas = con.execute(f"SELECT t.* FROM taxon t{clausula} ORDER BY t.nome LIMIT ? OFFSET ?", (*args, limite, offset)).fetchall()
    itens = []
    for t in linhas:
        td = dict(t)
        pop = json.loads(td["nomes_populares"]) if td["nomes_populares"] else []
        itens.append({"id": td["id"], "gbif": td["gbif_key"], "nome": td["nome"], "populares": [x["nome"] for x in pop][:5], "grupo": td["grupo"],
                      "familia": td["familia"], "no_recorte": bool(td["no_recorte"]), "predominio": td["predominio_al"],
                      "distribuicao_br": td.get("distribuicao_br") or "indeterminada",
                      "coleta_amazonica_declarada": td["id"] in ctx.taxon_coleta_amazonica,
                      "estrato_florestal": td["estrato_florestal"], "endemismo_br": td["endemismo_br"],
                      "n_br": td["n_br"], "n_al": td["n_al"], "n_al_exato": td.get("n_al_exato"),
                      "n_bioma_amazonia": td["n_bioma_amazonia"]})
    return _json(request, {"total": total, "limite": limite, "offset": offset, "itens": itens}, extra={"X-Total-Count": str(total)})


async def taxon(request):
    ctx = request.app.state.dados.contexto()
    try:
        gbif = int(request.path_params["gbif"])
    except ValueError:
        return _erro("gbif deve ser inteiro")
    t = ctx.con.execute("SELECT * FROM taxon WHERE gbif_key=?", (gbif,)).fetchone()
    if t is None:
        return _erro("Táxon não encontrado.", 404)
    return _json(request, pacotes.pacote_taxon(ctx, t))


async def moleculas(request):
    ctx = request.app.state.dados.contexto()
    con, p = ctx.con, request.query_params
    limite, offset = _paginacao(request)
    _recusar_filtros_extintos(p)
    ids_ok = [mid for mid in ctx.mol if _mol_publica(ctx, mid)]
    if p.get("q"):
        achados = _ids_fts(con, "molecula", p["q"])
        if achados is None:
            return _erro("q sem termos utilizáveis")
        ordem = {i: n for n, i in enumerate(achados)}
        ids_ok = sorted((i for i in ids_ok if i in ordem), key=lambda i: ordem[i])
    else:
        ids_ok.sort(key=lambda i: ctx.mol[i]["nome"].lower())
    if p.get("tipo"):
        ids_ok = [i for i in ids_ok if ctx.mol[i]["tipo"] == p["tipo"]]
    if p.get("aprovado") == "1":
        ids_ok = [i for i in ids_ok if i in ctx.clinico]
    if p.get("atividade") == "1":
        ids_ok = [i for i in ids_ok if ctx.n_ativ.get(i)]
    if p.get("tem_3d") == "1":
        ids_ok = [i for i in ids_ok if ctx.estruturas3d.get(i)]
    cond_af, args_af = _condicoes_de_afirmacao(p, "a")
    if cond_af:      # moléculas com alguma afirmação pública que atende a todas as condições
        com = {r[0] for r in con.execute(f"SELECT DISTINCT a.molecula_id FROM afirmacao a WHERE {pacotes.sql_afirmacao_exportada('a')} "
                                         f"AND {' AND '.join(cond_af)}", args_af)}
        ids_ok = [i for i in ids_ok if i in com]
    itens = [{"id": i, "nome": ctx.mol[i]["nome"], "tipo": ctx.mol[i]["tipo"], "inchikey": ctx.mol[i]["inchikey"],
              "conectividade": pacotes.conectividade(ctx.mol[i]), "uniprot": ctx.mol[i]["uniprot_acc"],
              "classe": ctx.mol[i]["classe_quimica"], "massa": pacotes.massa_publica(ctx.mol[i]), "clogp": ctx.mol[i]["clogp"],
              "tpsa": ctx.mol[i]["tpsa"], "fsp3": ctx.mol[i]["fsp3"], "qed": ctx.mol[i]["qed"], "np_likeness": ctx.mol[i]["np_likeness"],
              "tem_3d": bool(ctx.estruturas3d.get(i)), "coleta_amazonica_declarada": i in ctx.mol_coleta_amazonica,
              "taxa": ctx.n_taxa_da_mol.get(i, 0), "atividades": ctx.n_ativ.get(i, 0), "aprovado": i in ctx.clinico}
             for i in ids_ok[offset:offset + limite]]
    return _json(request, {"total": len(ids_ok), "limite": limite, "offset": offset, "itens": itens}, extra={"X-Total-Count": str(len(ids_ok))})


async def molecula(request):
    ctx = request.app.state.dados.contexto()
    try:
        mid = int(request.path_params["id"])
    except ValueError:
        return _erro("id deve ser inteiro")
    m = ctx.con.execute("SELECT * FROM molecula WHERE id=?", (mid,)).fetchone()
    if m is None or not _mol_publica(ctx, mid):
        return _erro("Molécula não encontrada.", 404)
    return _json(request, pacotes.pacote_molecula(ctx, m))


async def afirmacoes(request):
    ctx = request.app.state.dados.contexto()
    con, p = ctx.con, request.query_params
    limite, offset = _paginacao(request)
    _recusar_filtros_extintos(p)
    estados = p.get("estado", "")
    estados = [e for e in estados.split(",") if e] or list(ESTADOS_PUB)
    if any(e not in ESTADOS_PUB for e in estados):
        return _erro(f"estado deve ser um de {', '.join(ESTADOS_PUB)}")
    onde, args = [f"a.estado IN ({_marcadores(estados)})", pacotes.sql_afirmacao_exportada("a")], list(estados)
    if p.get("tipo"):
        onde.append("a.tipo = ?"); args.append(p["tipo"])
    if p.get("molecula"):
        onde.append("a.molecula_id = ?"); args.append(_inteiro(p, "molecula"))
    if p.get("taxon"):
        onde.append("a.taxon_id = (SELECT id FROM taxon WHERE gbif_key = ?)"); args.append(_inteiro(p, "taxon"))
    cond_af, args_af = _condicoes_de_afirmacao(p, "a")
    onde += cond_af; args += args_af
    clausula = " WHERE " + " AND ".join(onde)
    total = con.execute(f"SELECT COUNT(*) FROM afirmacao a{clausula}", args).fetchone()[0]
    pk = pacotes.Pacote(ctx)
    itens = []
    for a in con.execute(f"SELECT a.* FROM afirmacao a{clausula} ORDER BY a.id LIMIT ? OFFSET ?", (*args, limite, offset)):
        d = pacotes._afirmacao(ctx, pk, a, completa=True)
        d.update({"taxon_id": a["taxon_id"], "molecula_id": a["molecula_id"], "alvo_id": a["alvo_id"]})
        itens.append(d)
    return _json(request, pk.fechar({"total": total, "limite": limite, "offset": offset, "itens": itens}), extra={"X-Total-Count": str(total)})


async def uf(request):
    ctx = request.app.state.dados.contexto()
    sigla = request.path_params["sigla"].upper()
    u = ctx.con.execute("SELECT * FROM territorio WHERE tipo='uf' AND sigla=?", (sigla,)).fetchone()
    if u is None:
        return _erro("Estado não encontrado.", 404)
    linhas = ctx.con.execute("SELECT t.gbif_key, t.nome, t.grupo, t.predominio_al, o.n FROM ocorrencia_uf o JOIN taxon t ON t.id=o.taxon_id "
                             "WHERE o.uf_sigla=? AND o.n>0 AND t.no_recorte=1 ORDER BY o.n DESC", (sigla,)).fetchall()
    return _json(request, {"sigla": sigla, "nome": u["nome"], "amazonia_legal": bool(u["amazonia_legal"]),
                           "taxons": [{"gbif": r["gbif_key"], "nome": r["nome"], "grupo": r["grupo"], "predominio": r["predominio_al"], "registros_gbif": r["n"]} for r in linhas],
                           "nota": "Contagens agregadas por estado, só de táxons deste banco. Sem coordenadas individuais."})


def _candidatos_bacia_id(valor: str) -> tuple[str, str]:
    s = (valor or "").strip()
    limpo = s[4:] if s.upper().startswith("BAC:") else s
    return (f"BAC:{limpo.upper()}", limpo.lower())


async def bacias(request):
    ctx = request.app.state.dados.contexto()
    con = ctx.con
    linhas = con.execute(
        """SELECT b.*,
                  COUNT(DISTINCT CASE WHEN ob.n > 0 AND t.no_recorte = 1 THEN ob.taxon_id END) AS n_taxons,
                  COALESCE(SUM(CASE WHEN t.no_recorte = 1 THEN ob.n ELSE 0 END), 0) AS n_ocorrencias_gbif
             FROM bacia_hidrografica b
             LEFT JOIN ocorrencia_bacia ob ON ob.bacia_id = b.id
             LEFT JOIN taxon t ON t.id = ob.taxon_id
         GROUP BY b.id
         ORDER BY b.area_km2 DESC"""
    ).fetchall()
    itens = [
        {
            "id": r["id"],
            "slug": r["id"][4:].lower() if r["id"].upper().startswith("BAC:") else r["id"].lower(),
            "nome": r["nome"],
            "rio_principal": r["rio_principal"],
            "area_km2": r["area_km2"],
            "cor_hex": r["cor_hex"],
            "n_taxons_recorte": r["n_taxons"],
            "n_ocorrencias_gbif": r["n_ocorrencias_gbif"],
            "consulta": _resumo_consulta(ctx, r["consulta_id"]),
        }
        for r in linhas
    ]
    return _json(request, {
        "total": len(itens),
        "bacias": itens,
        "nota": "Sub-bacias hidrográficas amazônicas (ANA/Hydrosheds simplificadas) com contagens agregadas do GBIF.",
    })


async def bacia(request):
    ctx = request.app.state.dados.contexto()
    con = ctx.con
    b = con.execute("SELECT * FROM bacia_hidrografica WHERE id IN (?, ?)", _candidatos_bacia_id(request.path_params["id"])).fetchone()
    if b is None:
        return _erro("Sub-bacia hidrográfica não encontrada.", 404)
    linhas = con.execute(
        """SELECT t.gbif_key, t.nome, t.grupo, t.estrato_florestal, ob.n, ob.consulta_id
             FROM ocorrencia_bacia ob
             JOIN taxon t ON t.id = ob.taxon_id
            WHERE ob.bacia_id = ? AND ob.n > 0 AND t.no_recorte = 1
         ORDER BY ob.n DESC, t.nome""",
        (b["id"],),
    ).fetchall()
    return _json(request, {
        "id": b["id"],
        "slug": b["id"][4:].lower() if b["id"].upper().startswith("BAC:") else b["id"].lower(),
        "nome": b["nome"],
        "rio_principal": b["rio_principal"],
        "area_km2": b["area_km2"],
        "cor_hex": b["cor_hex"],
        "poligono_wkt": b["poligono_wkt"],
        "consulta": _resumo_consulta(ctx, b["consulta_id"]),
        "taxons": [
            {
                "gbif": r["gbif_key"],
                "nome": r["nome"],
                "grupo": r["grupo"],
                "estrato_florestal": r["estrato_florestal"],
                "registros_gbif": r["n"],
                "consulta": _resumo_consulta(ctx, r["consulta_id"]),
            }
            for r in linhas
        ],
        "nota": "Contagens de ocorrências GBIF dentro do polígono WKT da sub-bacia, sem coordenadas individuais.",
    })


async def lacunas(request):
    ctx = request.app.state.dados.contexto()
    con, p = ctx.con, request.query_params
    limite, offset = _paginacao(request)
    onde, args = [], []
    if p.get("bacia"):
        onde.append("c.bacia_id IN (?, ?)"); args.extend(_candidatos_bacia_id(p["bacia"]))
    if p.get("prioridade"):
        onde.append("c.prioridade_bivariada = ?"); args.append(p["prioridade"].upper())
    clausula = (" WHERE " + " AND ".join(onde)) if onde else ""
    total = con.execute(f"SELECT COUNT(*) FROM celula_lacuna c{clausula}", args).fetchone()[0]
    linhas = con.execute(
        f"SELECT c.* FROM celula_lacuna c{clausula} ORDER BY c.densidade_km2 ASC, c.id ASC LIMIT ? OFFSET ?",
        (*args, limite, offset),
    ).fetchall()
    pk = pacotes.Pacote(ctx)
    itens = [
        {
            "id": r["id"],
            "lon": r["lon"],
            "lat": r["lat"],
            "passo_graus": r["passo_graus"],
            "area_km2": r["area_km2"],
            "n_ocorrencias_gbif": r["n_ocorrencias_gbif"],
            "densidade_km2": r["densidade_km2"],
            "bacia_id": r["bacia_id"],
            "pressao_desmatamento": r["pressao_desmatamento"],
            "cobertura_protegida": r["cobertura_protegida"],
            "prioridade_bivariada": r["prioridade_bivariada"],
            "consulta_gbif": pk.consulta(r["gbif_consulta_id"]),
            "consulta_pressao": pk.consulta(r["pressao_consulta_id"]),
        }
        for r in linhas
    ]
    return _json(
        request,
        pk.fechar({
            "total": total, "limite": limite, "offset": offset, "itens": itens,
            "nota": "Grade espacial regular (0,5°) de densidade amostral GBIF × pressão antrópica acumulada (PRODES/INPE).",
        }),
        extra={"X-Total-Count": str(total)},
    )


async def linhagens(request):
    ctx = request.app.state.dados.contexto()
    con = ctx.con
    pk = pacotes.Pacote(ctx)
    itens = []
    for r in ctx.linhagens:                      # só linhagens em estado público, com obra citável
        ori, dst = ctx.mol[r["origem_id"]], ctx.mol[r["destino_id"]]
        taxons_ori = [
            {"gbif": tr["gbif_key"], "nome": tr["nome"], "grupo": tr["grupo"], "no_recorte": bool(tr["no_recorte"])}
            for tr in con.execute(
                f"SELECT DISTINCT t.gbif_key, t.nome, t.grupo, t.no_recorte FROM afirmacao a "
                f"JOIN taxon t ON t.id=a.taxon_id WHERE a.molecula_id=? AND {pacotes.sql_publica('a')} "
                f"ORDER BY t.no_recorte DESC, t.nome LIMIT 8",
                (ori["id"],),
            )
        ]
        itens.append({
            "id": r["id"],
            "tipo": r["tipo"],
            "enunciado": r["texto"],
            "trecho": r.get("trecho"),
            "trecho_fonte": r.get("trecho_fonte"),
            "origem": {
                "id": ori["id"], "nome": ori["nome"], "tipo": ori["tipo"],
                "inchikey": ori["inchikey"], "uniprot": ori["uniprot_acc"],
                "taxons_documentados": taxons_ori,
            },
            "destino": {
                "id": dst["id"], "nome": dst["nome"], "tipo": dst["tipo"],
                "inchikey": dst["inchikey"], "chembl": dst["chembl_id"],
                "max_fase_clinica": dst["max_fase_clinica"],
            },
            "ref": pk.ref(r["referencia_id"]),
            "consulta": pk.consulta(r["consulta_id"]),
        })
    return _json(request, pk.fechar({
        "total": len(itens),
        "linhagens": itens,
        "aviso": "Relação entre moléculas isoladas, com a frase da obra citada. O efeito clínico é do fármaco aprovado.",
    }))


async def vias(request):
    ctx = request.app.state.dados.contexto()
    p = request.query_params
    limite, offset = _paginacao(request)
    # vias ligadas a alvos de medidas públicas; `n_alvos` conta só esses alvos, e a consulta citada é a da busca
    # feita para o primeiro deles (alvo sem medida publicada não entra, nem como origem da consulta)
    por_via = {}
    for aid in sorted(ctx.alvos_publicos):
        for v in ctx.vias_por_alvo.get(aid, ()):
            por_via.setdefault(v["via_id"], [{**v, "id": v["via_id"]}, set()])[1].add(aid)
    linhas = [(v, len(alvos)) for v, alvos in por_via.values()]
    if p.get("q"):
        termo = p["q"].strip().lower()
        linhas = [(v, n) for v, n in linhas if termo in v["nome"].lower() or termo in v["reactome_id"].lower()]
    linhas.sort(key=lambda par: (-par[1], par[0]["reactome_id"]))
    total = len(linhas)
    pk = pacotes.Pacote(ctx)
    itens = [
        {
            "id": v["id"],
            "reactome_id": v["reactome_id"],
            "nome": v["nome"],
            "especie": v["especie"],
            "doi": v["doi"],
            "n_alvos": n,
            "consulta": pk.consulta(v["consulta_id"]),
        }
        for v, n in linhas[offset:offset + limite]
    ]
    return _json(
        request,
        pk.fechar({"total": total, "limite": limite, "offset": offset, "itens": itens}),
        extra={"X-Total-Count": str(total)},
    )


def _carregar_geom_3d_disco(app_dir: Path, arq_rel: str | None, sha=None) -> dict | None:
    if not arq_rel:
        return None
    rel_limpo = arq_rel.removeprefix("dados/").lstrip("/")
    if ".." in Path(rel_limpo.partition("#")[0]).parts:
        return None
    bases = [Path(app_dir) / "dados", Path(app_dir), config.SAIDA_DIR]
    if "#" in rel_limpo:
        sub_arq, chave = rel_limpo.split("#", 1)
        for base in bases:
            cand = base / sub_arq
            if cand.is_file():
                try:
                    d_lote = json.loads(cand.read_text(encoding="utf-8"))
                    if chave in d_lote:
                        from .conectores.estruturas3d import json_canonico_bytes
                        geom = d_lote[chave]
                        if not sha or hashlib.sha256(json_canonico_bytes(geom)).hexdigest() == sha:
                            return geom
                except Exception:
                    continue
        return None
    from .exportar.ensembles import localizar, ler_membro
    for base in bases:
        cand = base / rel_limpo
        pacote = localizar(base, rel_limpo)
        if cand.is_file() or (pacote and pacote[0].is_file()):
            try:
                corpo = cand.read_bytes() if cand.is_file() else ler_membro(*pacote)
                if not sha or hashlib.sha256(corpo).hexdigest() == sha:
                    return json.loads(corpo)
            except Exception:
                continue
    return None


def _gerar_resposta_sdf(request, ctx, r):
    from .conectores import estruturas3d as mod3d

    mid = r["molecula_id"]
    if (mid is not None and not _mol_publica(ctx, mid)) or (mid is None and r["alvo_id"] not in ctx.alvos_publicos):
        return _erro("Estrutura 3D não encontrada.", 404)
    mol_row = ctx.mol.get(mid) if mid is not None else None
    if mid is not None and not any(e["id"] == r["id"] for e in ctx.estruturas3d.get(mid, ())):
        return _erro("Geometria sem identidade verificada.", 404)
    geom = _carregar_geom_3d_disco(Path(request.app.state.app_dir), r["arquivo_geometria"], r["geometria_sha256"])
    if geom is None or not ("b64z" in geom or "a" in geom or geom.get("fmt") == "ensemble-sdf-v1"):
        return _erro("Arquivo atômico 3D verificado indisponível para este modelo.", 404)

    meta = {
        "molecula_id": mid,
        "nome": mol_row["nome"] if mol_row else (ctx.alvos[r["alvo_id"]]["nome"] if r["alvo_id"] in ctx.alvos else r["codigo"]),
        "inchikey": mol_row.get("inchikey") if mol_row else None,
        "formula": mol_row.get("formula") if mol_row else None,
        "natureza": r["natureza"],
        "fonte": r["fonte_id"],
        "acesso": r["codigo"],
        "metodo": r["metodo"],
        "resolucao": r["resolucao_angstrom"],
        "energia": r["energia_kcal_mol"],
    }
    try:
        indice = int(request.query_params.get("conformero", "1"))
        if geom.get("fmt") == "ensemble-sdf-v1" and 1 <= indice <= len(geom["conformeros"]):
            sdf_txt = geom["conformeros"][indice - 1]["sdf"]
        elif indice == 1:
            sdf_txt = mod3d.gerar_sdf_3d(geom, meta)
        else:
            raise ValueError("Confôrmero indisponível.")
    except ValueError as exc:
        return _erro(str(exc), 404)

    slug_base = re.sub(r"[^A-Za-z0-9._-]+", "_", f"biomapabrasil_{r['natureza']}_{r['codigo'] or r['id']}").strip("_")[:80]
    return Response(
        sdf_txt,
        status_code=200,
        media_type="chemical/x-mdl-sdfile; charset=utf-8",
        headers={
            "Content-Disposition": f'attachment; filename="{slug_base}.sdf"',
            "Cache-Control": "public, max-age=3600",
        },
    )


async def estrutura3d_sdf(request):
    ctx = request.app.state.dados.contexto()
    try:
        eid = int(request.path_params["id"])
    except ValueError:
        return _erro("id deve ser inteiro")
    r = ctx.con.execute("SELECT * FROM estrutura_3d WHERE id=?", (eid,)).fetchone()
    if r is None:
        return _erro("Estrutura 3D não encontrada.", 404)
    return _gerar_resposta_sdf(request, ctx, dict(r))


async def molecula_sdf(request):
    ctx = request.app.state.dados.contexto()
    try:
        mid = int(request.path_params["id"])
    except ValueError:
        return _erro("id deve ser inteiro")
    if mid not in ctx.mol or not _mol_publica(ctx, mid):
        return _erro("Molécula não encontrada.", 404)
    ests = [e for e in ctx.estruturas3d.get(mid, []) if e.get("tem_sdf_3d") or e["natureza"] in ("experimental", "conformero_calculado")]
    if not ests:
        return _erro("Estrutura SDF 3D não disponível para esta molécula.", 404)
    return _gerar_resposta_sdf(request, ctx, ests[0])


async def _responder_estruturas3d(request, natureza_forcada=None):
    ctx = request.app.state.dados.contexto()
    p = request.query_params
    limite, offset = _paginacao(request)
    # geometrias de moléculas públicas e de alvos de medidas públicas
    por_id = {e["id"]: e for lista in (*ctx.estruturas3d.values(), *ctx.estruturas3d_alvo.values()) for e in lista}
    linhas = list(por_id.values())
    nat = natureza_forcada or p.get("natureza")
    if nat:
        linhas = [e for e in linhas if e["natureza"] == nat]
    if p.get("fonte"):
        linhas = [e for e in linhas if e["fonte_id"] == p["fonte"]]
    if p.get("molecula"):
        mid = _inteiro(p, "molecula")
        linhas = [e for e in linhas if e["molecula_id"] == mid]
    ordem_nat = {"experimental": 0, "predicao_computacional": 1}
    linhas.sort(key=lambda e: (ordem_nat.get(e["natureza"], 2), e["id"]))
    total = len(linhas)
    pk = pacotes.Pacote(ctx)
    itens = [
        {
            "id": r["id"],
            "molecula_id": r["molecula_id"],
            "molecula_nome": ctx.mol[r["molecula_id"]]["nome"] if r["molecula_id"] in ctx.mol else None,
            "alvo_id": r["alvo_id"],
            "alvo_nome": ctx.alvos[r["alvo_id"]]["nome"] if r["alvo_id"] in ctx.alvos else None,
            "natureza": r["natureza"],
            "fonte": r["fonte_id"],
            "acesso": r["codigo"],
            "metodo": r["metodo"],
            "resolucao_angstrom": r["resolucao_angstrom"],
            "plddt_medio": r["plddt_medio"],
            "energia_kcal_mol": r["energia_kcal_mol"],
            "n_elementos": r["n_atomos_ou_residuos"],
            "n_pontes_dissulfeto": r["n_pontes_dissulfeto"],
            "tem_sdf_3d": bool(r.get("tem_sdf_3d")),
            "sdf_url": f"/api/estruturas3d/{r['id']}/sdf" if r.get("tem_sdf_3d") else None,
            "arquivo": r.get("arquivo_publico") or r["arquivo_geometria"],
            "geometria_sha256": r["geometria_sha256"],
            "consulta": pk.consulta(r["consulta_id"]),
        }
        for r in linhas[offset:offset + limite]
    ]
    return _json(
        request,
        pk.fechar({
            "total": total, "limite": limite, "offset": offset, "itens": itens,
            "aviso": "Cada geometria traz a natureza: experimental (wwPDB e COD), predição computacional (AlphaFold e ESMFold) ou confôrmero calculado (RDKit ETKDGv3+MMFF94s).",
        }),
        extra={"X-Total-Count": str(total)},
    )


async def estruturas3d(request):
    return await _responder_estruturas3d(request)


async def estruturas3d_experimentais(request):
    return await _responder_estruturas3d(request, natureza_forcada="experimental")


async def busca(request):
    ctx = request.app.state.dados.contexto()
    con = ctx.con
    expr = _fts(request.query_params.get("q"))
    if expr is None:
        return _erro("Informe q com ao menos um termo.")
    saida = {"taxa": [], "moleculas": [], "ufs": []}
    for r in con.execute("SELECT tipo, ref_id FROM busca WHERE busca MATCH ? ORDER BY bm25(busca) LIMIT 60", (expr,)):
        if r["tipo"] == "taxon" and len(saida["taxa"]) < 12:
            t = con.execute("SELECT gbif_key, nome, grupo, no_recorte FROM taxon WHERE id=?", (r["ref_id"],)).fetchone()
            if t:
                saida["taxa"].append({"gbif": t["gbif_key"], "nome": t["nome"], "grupo": t["grupo"], "no_recorte": bool(t["no_recorte"])})
        elif r["tipo"] == "molecula" and len(saida["moleculas"]) < 12:
            if _mol_publica(ctx, r["ref_id"]):
                saida["moleculas"].append({"id": r["ref_id"], "nome": ctx.mol[r["ref_id"]]["nome"]})
        elif r["tipo"] == "territorio" and len(saida["ufs"]) < 5:
            u = con.execute("SELECT sigla, nome FROM territorio WHERE id=?", (r["ref_id"],)).fetchone()
            if u:
                saida["ufs"].append({"sigla": u["sigla"], "nome": u["nome"]})
    return _json(request, saida, max_age=60)


async def retencoes_internas(request):
    """Livro de retenções, com regra e motivo. Só existe com a curadoria ligada e exige o token da sessão."""
    _exigir_token(request)
    con = _escrita(request)
    try:
        livro = pacotes.livro_de_retencoes(con)
        return JSONResponse({**livro, "resumo": quarentena.resumo(con)}, headers={"Cache-Control": "no-store"})
    finally:
        con.close()


async def universo_amazonico(request):
    ctx = request.app.state.dados.contexto()
    con = ctx.con
    if not con.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='universo_checklist'").fetchone()[0]:
        return _json(request, {"disponivel": False})
    tot = con.execute("SELECT COUNT(*) FROM universo_checklist WHERE bioma_amazonia_declarado=1").fetchone()[0]
    com_q = con.execute("SELECT COUNT(*) FROM universo_checklist WHERE bioma_amazonia_declarado=1 AND tem_quimica_aberta=1").fetchone()[0]
    por_g = {}
    for r in con.execute("SELECT grupo_bmb, COUNT(*) AS tot, SUM(tem_quimica_aberta) AS q FROM universo_checklist WHERE bioma_amazonia_declarado=1 GROUP BY 1"):
        por_g[r["grupo_bmb"]] = {"aceitas": r["tot"], "com_quimica_aberta": r["q"] or 0, "sem_quimica_dark_matter": r["tot"] - (r["q"] or 0)}
    return _json(request, {
        "disponivel": tot > 0,
        "especies_aceitas_bioma_amazonia": tot,
        "com_quimica_aberta": com_q,
        "sem_quimica_aberta_dark_matter": tot - com_q,
        "fracao_dark_matter": round((tot - com_q) / tot, 4) if tot else None,
        "por_grupo": por_g,
        "fontes_catalogo": ["Flora e Funga do Brasil (JBRJ DwC-A)", "Catálogo Taxonômico da Fauna do Brasil (CTFB DwC-A)"],
    })


async def validacao_interna(request):
    """Validação por amostragem (bmb.benchmark). Só existe com a curadoria ligada e exige o token da sessão."""
    _exigir_token(request)
    arq = config.SAIDA_DIR / pacotes.PASTA_INTERNA / "benchmark_validacao.json"
    if arq.exists():
        try:
            return JSONResponse(json.loads(arq.read_text(encoding="utf-8")), headers={"Cache-Control": "no-store"})
        except (OSError, ValueError):
            pass
    con = _escrita(request)
    try:
        n_am = con.execute("SELECT COUNT(*) FROM amostra_benchmark").fetchone()[0]
        por_est = {r[0]: r[1] for r in con.execute("SELECT estrato, COUNT(*) FROM amostra_benchmark GROUP BY 1")}
        return JSONResponse({"disponivel": n_am > 0, "n_amostra": n_am, "por_estrato": por_est}, headers={"Cache-Control": "no-store"})
    finally:
        con.close()


# ═══════════════════════════ especificação e documentação ═══════════════════════════
def _parametros(*nomes):
    desc = {"limite": ("integer", f"1 a {MAX_LIMITE} (padrão 50)"), "offset": ("integer", "deslocamento (padrão 0)"),
            "q": ("string", "busca por nome, sem acento, com prefixo"), "grupo": ("string", ", ".join(GRUPOS)),
            "uf": ("string", "sigla do estado com registro"), "bacia": ("string", "identificador da sub-bacia hidrográfica amazônica"),
            "estrato": ("string", "emergente | dossel | sub_bosque | liana_epifita | solo_serrapilheira | aquatico_ripario"),
            "distribuicao_br": ("string", "distribuição da espécie no Brasil, um ou vários códigos separados por vírgula: "
                                          + " | ".join(procedencia.ROTULOS_DISTRIBUICAO)),
            "evidencia": ("string", "nível de evidência da afirmação, um ou vários códigos separados por vírgula, do mais forte ao mais fraco: "
                                    + " | ".join(pacotes.ORDEM_EVIDENCIA)),
            "procedencia": ("string", "procedência declarada do material (código exato; vários separados por vírgula): "
                                      + " | ".join(procedencia.ROTULOS_PROCEDENCIA)),
            "coleta_amazonica_declarada": ("string", "1 = só registros com coleta na Amazônia declarada por curador ou pela base de origem ("
                                                     + " | ".join(procedencia.PROCEDENCIA_AMAZONICA_DECLARADA) + ")"),
            "recorte": ("string", "0 inclui táxons fora do recorte amazônico"),
            "predominio": ("string", "predominante | nao_predominante | indeterminado"), "tipo": ("string", "tipo de molécula ou de afirmação"),
            "aprovado": ("string", "1 = só moléculas que são fármaco aprovado"), "atividade": ("string", "1 = só com medida de bioatividade"),
            "tem_3d": ("string", "1 = só moléculas com geometria 3D disponível"),
            "estado": ("string", "candidato, em_revisao, verificado (separados por vírgula)"),
            "molecula": ("integer", "id da molécula"), "taxon": ("integer", "chave GBIF do táxon"),
            "prioridade": ("string", "classe bivariada de lacuna × pressão (ex.: G3_P3)"),
            "natureza": ("string", "experimental | predicao_computacional | conformero_calculado"),
            "fonte": ("string", "identificador da fonte (ex.: rcsb_pdb, alphafold, rdkit_local)")}
    return [{"name": n, "in": "query", "required": False, "schema": {"type": desc[n][0]}, "description": desc[n][1]} for n in nomes]


FILTROS_DE_AFIRMACAO = ("evidencia", "procedencia", "coleta_amazonica_declarada")


def especificacao(curadoria_ativa=False):
    """Documento OpenAPI. As duas rotas internas só constam quando a curadoria está ligada (uso local)."""
    corpo = lambda desc: {"200": {"description": desc, "content": {"application/json": {"schema": {"type": "object"}}}}}
    caminhos = {
            "/api/saude": {"get": {"summary": "Estado do serviço e contagens do que está publicado", "responses": corpo("ok")}},
            "/api/fontes": {"get": {"summary": "Fontes, licenças e datas de consulta", "responses": corpo("lista de fontes")}},
            "/api/universo": {"get": {"summary": "Espécies aceitas no bioma Amazônia nos catálogos nacionais (JBRJ e CTFB) e quantas têm química registrada em base aberta", "responses": corpo("resumo do universo amazônico")}},
            "/api/taxa": {"get": {"summary": "Lista de táxons, com a distribuição da espécie no Brasil", "parameters": _parametros("q", "grupo", "uf", "bacia", "estrato", "distribuicao_br", *FILTROS_DE_AFIRMACAO, "recorte", "predominio", "limite", "offset"), "responses": corpo("página de táxons")}},
            "/api/taxa/{gbif}": {"get": {"summary": "Perfil de um táxon (chave do GBIF)", "parameters": [{"name": "gbif", "in": "path", "required": True, "schema": {"type": "integer"}}], "responses": corpo("perfil completo, com referências e consultas")}},
            "/api/moleculas": {"get": {"summary": "Lista de moléculas", "parameters": _parametros("q", "tipo", "aprovado", "atividade", "tem_3d", *FILTROS_DE_AFIRMACAO, "limite", "offset"), "responses": corpo("página de moléculas")}},
            "/api/moleculas/{id}": {"get": {"summary": "Perfil de uma molécula: identidade química, ocorrências, medidas de bioatividade por par molécula–alvo e efeito clínico", "parameters": [{"name": "id", "in": "path", "required": True, "schema": {"type": "integer"}}], "responses": corpo("perfil completo")}},
            "/api/moleculas/{id}/estrutura3d.sdf": {"get": {"summary": "Download do arquivo BIOVIA MDL SDF 3D (.sdf V2000/V3000) prioritário da molécula", "parameters": [{"name": "id", "in": "path", "required": True, "schema": {"type": "integer"}}, {"name": "conformero", "in": "query", "schema": {"type": "integer", "minimum": 1, "default": 1}}], "responses": {"404": {"description": "Coordenadas indisponíveis"}, "200": {"description": "arquivo SDF 3D", "content": {"chemical/x-mdl-sdfile": {"schema": {"type": "string"}}}}}}},
            "/api/afirmacoes": {"get": {"summary": "Afirmações com fonte, estado, nível de evidência, procedência declarada, prontidão, referências e consulta", "parameters": _parametros("tipo", "estado", "molecula", "taxon", *FILTROS_DE_AFIRMACAO, "limite", "offset"), "responses": corpo("página de afirmações")}},
            "/api/ufs/{sigla}": {"get": {"summary": "Táxons com registro em um estado (contagens agregadas)", "parameters": [{"name": "sigla", "in": "path", "required": True, "schema": {"type": "string"}}], "responses": corpo("táxons do estado")}},
            "/api/bacias": {"get": {"summary": "Sub-bacias hidrográficas amazônicas e contagens agregadas", "responses": corpo("lista de sub-bacias")}},
            "/api/bacias/{id}": {"get": {"summary": "Perfil hidrográfico de uma sub-bacia amazônica e seus táxons no recorte", "parameters": [{"name": "id", "in": "path", "required": True, "schema": {"type": "string"}}], "responses": corpo("perfil da sub-bacia")}},
            "/api/lacunas": {"get": {"summary": "Grade espacial 0,5° de lacunas amostrais GBIF e pressão antrópica PRODES", "parameters": _parametros("bacia", "prioridade", "limite", "offset"), "responses": corpo("página da grade espacial")}},
            "/api/linhagens": {"get": {"summary": "Linhagens farmacológicas: molécula natural e fármaco aprovado, com a frase da obra citada", "responses": corpo("lista de linhagens")}},
            "/api/vias": {"get": {"summary": "Vias biológicas humanas (Reactome) ligadas a alvos moleculares", "parameters": _parametros("q", "limite", "offset"), "responses": corpo("página de vias biológicas")}},
            "/api/estruturas3d": {"get": {"summary": "Geometrias 3D experimentais (wwPDB/COD), preditas (AlphaFold/ESMFold) e calculadas (RDKit)", "parameters": _parametros("natureza", "fonte", "molecula", "limite", "offset"), "responses": corpo("página de estruturas 3D")}},
            "/api/estruturas3d/experimentais": {"get": {"summary": "Geometrias 3D experimentais (wwPDB e COD) com metadados e link SDF", "parameters": _parametros("fonte", "molecula", "limite", "offset"), "responses": corpo("página de estruturas 3D experimentais")}},
            "/api/estruturas3d/{id}/sdf": {"get": {"summary": "Download do arquivo BIOVIA MDL SDF 3D (.sdf V2000/V3000) de uma estrutura 3D", "parameters": [{"name": "id", "in": "path", "required": True, "schema": {"type": "integer"}}, {"name": "conformero", "in": "query", "schema": {"type": "integer", "minimum": 1, "default": 1}}], "responses": {"404": {"description": "Coordenadas indisponíveis"}, "200": {"description": "arquivo SDF 3D", "content": {"chemical/x-mdl-sdfile": {"schema": {"type": "string"}}}}}}},
            "/api/busca": {"get": {"summary": "Busca por nome em táxons, moléculas e estados", "parameters": _parametros("q"), "responses": corpo("resultados agrupados")}},
    }
    if curadoria_ativa:
        token = [{"name": "X-BMB-Token", "in": "header", "required": True, "schema": {"type": "string"}, "description": "token da sessão de curadoria"}]
        caminhos["/api/quarentena"] = {"get": {"summary": "Uso local: livro de retenções, com a regra e o motivo de cada registro", "parameters": token, "responses": corpo("livro de retenções")}}
        caminhos["/api/benchmark"] = {"get": {"summary": "Uso local: validação por amostragem (bmb.benchmark)", "parameters": token, "responses": corpo("relatório da amostra")}}
    return {
        "openapi": "3.0.3",
        "info": {"title": "BioMapaBrasil · API de consulta", "version": __version__,
                 "description": "Somente leitura. Mesmos formatos dos pacotes estáticos do site. Cada afirmação traz fonte, licença, data da consulta, "
                                "nível de evidência e, quando é ligada a um organismo, a procedência declarada do material. "
                                "Associação documentada não é eficácia. Dados sob CC BY 4.0, exceto afirmações do ChEMBL (CC BY-SA 3.0)."},
        "paths": caminhos}


async def openapi(request):
    return _json(request, especificacao(request.app.state.curadoria_ativa), max_age=3600)


async def docs(request):
    spec = especificacao(request.app.state.curadoria_ativa)
    linhas = []
    for caminho, ops in spec["paths"].items():
        op = ops["get"]
        params = "".join(f"<li><code>{p['name']}</code> ({p['schema']['type']}): {p.get('description', '')}</li>" for p in op.get("parameters", []))
        exemplo = caminho if "{" not in caminho and not any(x["in"] == "header" for x in op.get("parameters", [])) else ""
        link = f' <a href="{exemplo}">testar</a>' if exemplo else ""
        linhas.append(f"<section><h2><code>GET {caminho}</code>{link}</h2><p>{op['summary']}</p>{'<ul>' + params + '</ul>' if params else ''}</section>")
    pagina = f"""<!doctype html><html lang="pt-BR" data-tema="escuro"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>API · BioMapaBrasil</title><link rel="stylesheet" href="/css/app.css"></head><body style="display:block">
<main class="pagina" style="padding:2rem 1.4rem"><p class="eyebrow">AMAZONIA WORKS · BIOMAPABRASIL OPENAPI</p><p><a href="/">← Voltar ao BioMapaBrasil</a></p><h1>API de consulta do BioMapaBrasil</h1><p class="sub">{spec['info']['description']}</p>
<p>Especificação OpenAPI: <a href="/api/openapi.json">/api/openapi.json</a>. Limites: até {MAX_LIMITE} itens por página; 120 requisições em rajada e 2 por segundo.</p>
{''.join(linhas)}</main></body></html>"""
    return HTMLResponse(pagina)


# ═══════════════════════════ curadoria (escrita; só local) ═══════════════════════════
def _exigir_token(request):
    esperado = request.app.state.token
    enviado = request.headers.get("x-bmb-token", "")
    if not esperado or not hmac.compare_digest(enviado, esperado):
        raise HTTPException(401, "token da curadoria ausente ou inválido")


async def _corpo(request):
    try:
        d = await request.json()
    except (json.JSONDecodeError, UnicodeDecodeError):
        raise HTTPException(400, "corpo deve ser JSON")
    if not isinstance(d, dict):
        raise HTTPException(400, "corpo deve ser um objeto JSON")
    return d


def _escrita(request):
    return db.conectar(request.app.state.dados.caminho)


async def cur_fila(request):
    _exigir_token(request)
    p = request.query_params
    con = _escrita(request)
    try:
        return JSONResponse(curadoria.fila(
            con, p.get("estado", "candidato"), p.get("tipo") or None, p.get("taxon") or None, p.get("q") or None,
            p.get("limite", 50), p.get("offset", 0),
            rodada_benchmark=p.get("rodada_benchmark") or None,
            papel_curador=p.get("papel_curador") or None,
        ), headers={"Cache-Control": "no-store"})
    finally:
        con.close()


async def cur_detalhe(request):
    _exigir_token(request)
    p = request.query_params
    con = _escrita(request)
    try:
        return JSONResponse(
            curadoria.detalhe(con, int(request.path_params["id"]), papel_curador=p.get("papel_curador") or None),
            headers={"Cache-Control": "no-store"},
        )
    except curadoria.ErroCuradoria as e:
        return _erro(str(e), 404)
    finally:
        con.close()


async def cur_verificar(request):
    _exigir_token(request)
    dados = await _corpo(request)
    con = _escrita(request)
    try:
        return JSONResponse(curadoria.verificar(con, dados), headers={"Cache-Control": "no-store"})
    except curadoria.ErroCuradoria as e:
        return _erro(str(e), e.status)
    finally:
        con.close()


async def cur_quarentena(request):
    _exigir_token(request)
    dados = await _corpo(request)
    con = _escrita(request)
    try:
        return JSONResponse(curadoria.quarentenar(con, dados), headers={"Cache-Control": "no-store"})
    except curadoria.ErroCuradoria as e:
        return _erro(str(e), e.status)
    finally:
        con.close()


async def cur_estatisticas(request):
    _exigir_token(request)
    con = _escrita(request)
    try:
        return JSONResponse(curadoria.estatisticas(con), headers={"Cache-Control": "no-store"})
    finally:
        con.close()


async def cur_europepmc(request):
    _exigir_token(request)
    from .http import Cliente
    con = _escrita(request)
    cli = Cliente(con)
    try:
        return JSONResponse(
            curadoria.prebuscar_europepmc(con, cli, int(request.path_params["id"])),
            headers={"Cache-Control": "no-store"},
        )
    except curadoria.ErroCuradoria as e:
        return _erro(str(e), 404)
    finally:
        cli.fechar()
        con.close()


# ═══════════════════════════ montagem ═══════════════════════════
async def _erro_http(request, exc):
    """Erros da API saem em JSON, no mesmo formato dos demais; fora da API, o texto simples de sempre."""
    if request.url.path.startswith(("/api", "/curadoria/api")):
        return _erro(str(exc.detail), exc.status_code)
    return Response(str(exc.detail), status_code=exc.status_code, media_type="text/plain; charset=utf-8", headers=getattr(exc, "headers", None))


def criar_app(caminho_db=None, app_dir=None, curadoria_ativa=False, token=None):
    caminho_db = Path(caminho_db or config.DB_PATH)
    app_dir = Path(app_dir or config.APP_DIR)
    rotas = [Route("/api/", raiz), Route("/api", raiz), Route("/api/saude", saude), Route("/api/fontes", fontes),
             Route("/api/universo", universo_amazonico),
             Route("/api/taxa", taxa), Route("/api/taxa/{gbif}", taxon),
             Route("/api/moleculas", moleculas), Route("/api/moleculas/{id}", molecula),
             Route("/api/moleculas/{id}/estrutura3d.sdf", molecula_sdf),
             Route("/api/afirmacoes", afirmacoes), Route("/api/ufs/{sigla}", uf),
             Route("/api/bacias", bacias), Route("/api/bacias/{id}", bacia), Route("/api/lacunas", lacunas),
             Route("/api/linhagens", linhagens), Route("/api/vias", vias),
             Route("/api/estruturas3d", estruturas3d), Route("/api/estruturas3d/experimentais", estruturas3d_experimentais),
             Route("/api/estruturas3d/experimentais/index.json", estruturas3d_experimentais),
             Route("/api/estruturas3d/{id}/sdf", estrutura3d_sdf),
             Route("/api/busca", busca),
             Route("/api/openapi.json", openapi), Route("/api/docs", docs)]
    if curadoria_ativa:
        # Uso local: a curadoria e as duas rotas internas (livro de retenções e validação por amostragem). Sem a
        # curadoria ligada, nenhuma delas existe: a resposta é 404 e o OpenAPI não as lista.
        rotas += [Route("/api/quarentena", retencoes_internas), Route("/api/benchmark", validacao_interna),
                  Route("/curadoria/api/fila", cur_fila), Route("/curadoria/api/afirmacao/{id:int}", cur_detalhe),
                  Route("/curadoria/api/referencia/{id:int}/europepmc", cur_europepmc),
                  Route("/curadoria/api/verificar", cur_verificar, methods=["POST"]), Route("/curadoria/api/quarentena", cur_quarentena, methods=["POST"]),
                  Route("/curadoria/api/estatisticas", cur_estatisticas),
                  Mount("/curadoria", StaticFiles(directory=str(Path(__file__).parent / "curadoria_ui"), html=True), name="curadoria_ui")]
    if app_dir.exists():
        rotas.append(Mount("/", StaticFiles(directory=str(app_dir), html=True), name="site"))
    app = Starlette(routes=rotas, exception_handlers={HTTPException: _erro_http}, middleware=[
        Middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["GET"], allow_headers=[], max_age=3600),
        Middleware(LimiteDeRequisicoes)])
    app.state.dados = Dados(caminho_db, app_dir / "dados")
    app.state.app_dir = app_dir
    app.state.curadoria_ativa = bool(curadoria_ativa)
    app.state.token = (token or secrets.token_urlsafe(24)) if curadoria_ativa else None
    return app
