# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Validação por amostragem (ferramenta de desenvolvimento): amostra estratificada de afirmações públicas e duas
comparações sobre ela, que não se confundem.

  A. Revisão por dois curadores. Duas pessoas leem a publicação de cada afirmação sorteada, cada uma sem ver o voto
     da outra (`curadoria.detalhe(..., papel_curador=...)`), e um terceiro decide as divergências. As estatísticas
     de concordância entre avaliadores (concordância bruta, κ de Cohen, AC1 de Gwet, PABAK, com intervalo por
     bootstrap) são calculadas sobre esses pares de votos, e só sobre eles. Sem votos registrados, não há número.

  B. Casamento de texto automático. Dois programas procuram, no título e no resumo das obras citadas (Europe PMC),
     um o nome do organismo ou do alvo, outro o nome do composto. Não são avaliadores e não leem o artigo: o
     resultado diz em quantas afirmações cada busca encontra a palavra. Não é medida de acerto das afirmações.

Este módulo nunca altera `afirmacao.estado`, nunca grava em `verificacao` e nunca promove nada a 'verificado'.
A amostra fica em `amostra_benchmark`, sorteada com semente fixa. As saídas são internas: o JSON vai para
`config.SAIDA_DIR / "interno"` e o Markdown para `docs/dev/`; nenhuma delas entra no pacote público.
"""
from __future__ import annotations

from collections import Counter
import json
from pathlib import Path
import random
import re

import numpy as np

from . import __version__, auditar, config, quimica
from .exportar import pacotes
from .util import agora

RODADA_PADRAO = "v4_2026"            # rodadas anteriores continuam em `amostra_benchmark`, com os estratos da época
SEMENTE_PADRAO = 20261115
N_PADRAO = 360

# Estratos: (id, cota em N = 360, descrição, condição SQL sobre `afirmacao a`). Cada estrato é definido pela base de
# origem (`fonte_id`), pelo tipo de afirmação e, onde a base as distingue, pela procedência declarada
# (`procedencia_declarada`) ou pelo nível de evidência (`nivel_evidencia`). A distribuição da espécie não entra.
ESTRATOS_ALVO = (
    ("lotus_artigo_trecho", 40, "LOTUS · composto em organismo · trecho localizado no artigo",
     "a.fonte_id='lotus' AND a.tipo='composto_em_organismo' AND a.nivel_evidencia='artigo_trecho'"),
    ("lotus_artigo_cita_organismo", 40, "LOTUS · composto em organismo · artigo cita o organismo",
     "a.fonte_id='lotus' AND a.tipo='composto_em_organismo' AND a.nivel_evidencia='artigo_cita_organismo'"),
    ("lotus_base_curada", 40, "LOTUS · composto em organismo · só a transcrição da base",
     "a.fonte_id='lotus' AND a.tipo='composto_em_organismo' AND IFNULL(a.nivel_evidencia,'base_curada')='base_curada'"),
    ("nubbe_base_declara_amazonia_legal", 35, "NuBBE-DB · coleta na Amazônia Legal declarada pela base",
     "a.fonte_id='nubbe' AND a.procedencia_declarada='base_declara_amazonia_legal'"),
    ("nubbe_outra_procedencia", 25, "NuBBE-DB · outra procedência declarada pela base, ou nenhuma",
     "a.fonte_id='nubbe' AND IFNULL(a.procedencia_declarada,'nao_declarada') <> 'base_declara_amazonia_legal'"),
    ("npatlas", 50, "NPAtlas · composto em fungo", "a.fonte_id='npatlas'"),
    ("uniprot_funcao_toxina", 50, "UniProt/Tox-Prot · função de toxina", "a.fonte_id='uniprot'"),
    ("chembl_atividade", 50, "ChEMBL · bioatividade por par molécula–alvo",
     "a.fonte_id='chembl' AND a.tipo='atividade_biologica'"),
    ("chembl_clinico", 30, "ChEMBL · efeito clínico de fármaco aprovado",
     "a.fonte_id='chembl' AND a.tipo='efeito_clinico_documentado'"),
)
ESTRATO_COMPLEMENTO = "complemento"       # preenche o que faltou quando um estrato tem menos afirmações que a cota


def cotas(n_total: int) -> dict[str, int]:
    """Cota de cada estrato para uma amostra de `n_total`, proporcional às cotas de N = 360 (maiores restos primeiro)."""
    exatas = [(eid, cota * n_total / N_PADRAO) for eid, cota, _, _ in ESTRATOS_ALVO]
    saida = {eid: int(v) for eid, v in exatas}
    falta = n_total - sum(saida.values())
    for eid, v in sorted(exatas, key=lambda par: (-(par[1] - int(par[1])), par[0]))[:max(0, falta)]:
        saida[eid] += 1
    return saida


def metricas_concordancia(pares: list[tuple[str, str]], categorias: tuple[str, ...] | None = None,
                          n_bootstrap: int = 10000, seed: int = SEMENTE_PADRAO) -> dict:
    """Calcula concordância bruta, κ de Cohen, AC1 de Gwet, PABAK e IC 95% via bootstrap (B=10.000).

    `pares`: lista de tuplas `(decisao_avaliador_1, decisao_avaliador_2)`.
    Trata o paradoxo de alta prevalência de Feinstein & Cicchetti (1990) via AC1 de Gwet (2008).
    """
    n = len(pares)
    if n == 0:
        return {
            "n_pares": 0,
            "concordancia_bruta": None,
            "kappa_cohen": None,
            "gwet_ac1": None,
            "pabak": None,
            "ic95_bootstrap": {},
            "matriz_contingencia": {},
        }

    if categorias is None:
        vistas = sorted({a for par in pares for a in par})
        categorias = tuple(vistas) if len(vistas) >= 2 else ("positiva", "negativa")
    k = len(categorias)
    idx = {c: i for i, c in enumerate(categorias)}

    mat = np.zeros((k, k), dtype=np.float64)
    a1_arr = np.empty(n, dtype=np.int32)
    a2_arr = np.empty(n, dtype=np.int32)
    for i, (r1, r2) in enumerate(pares):
        i1, i2 = idx[r1], idx[r2]
        mat[i1, i2] += 1.0
        a1_arr[i] = i1
        a2_arr[i] = i2

    def _calc_de_matriz(m: np.ndarray, total: float):
        po = float(np.trace(m) / total)
        marg1 = m.sum(axis=1)
        marg2 = m.sum(axis=0)
        pe_kappa = float(np.sum(marg1 * marg2) / (total * total))
        kappa = 1.0 if abs(1.0 - pe_kappa) < 1e-12 else (po - pe_kappa) / (1.0 - pe_kappa)
        pi_k = (marg1 + marg2) / (2.0 * total)
        pe_ac1 = float(np.sum(pi_k * (1.0 - pi_k)) / max(1, k - 1))
        ac1 = 1.0 if abs(1.0 - pe_ac1) < 1e-12 else (po - pe_ac1) / (1.0 - pe_ac1)
        pabak = 2.0 * po - 1.0
        return po, kappa, ac1, pabak

    po, kappa, ac1, pabak = _calc_de_matriz(mat, float(n))

    ic_boot = {}
    if n >= 5 and n_bootstrap > 0:
        rng = np.random.default_rng(seed)
        amostras_idx = rng.integers(0, n, size=(n_bootstrap, n))
        b_a1 = a1_arr[amostras_idx]
        b_a2 = a2_arr[amostras_idx]
        po_b = np.mean(b_a1 == b_a2, axis=1)

        pe_k_b = np.zeros(n_bootstrap, dtype=np.float64)
        sum_pi_b = np.zeros(n_bootstrap, dtype=np.float64)
        for cat_i in range(k):
            p1 = np.mean(b_a1 == cat_i, axis=1)
            p2 = np.mean(b_a2 == cat_i, axis=1)
            pe_k_b += p1 * p2
            pi = 0.5 * (p1 + p2)
            sum_pi_b += pi * (1.0 - pi)
        pe_ac1_b = sum_pi_b / max(1, k - 1)

        denom_k = 1.0 - pe_k_b
        kappa_b = np.where(np.abs(denom_k) < 1e-12, 1.0, (po_b - pe_k_b) / np.where(np.abs(denom_k) < 1e-12, 1.0, denom_k))
        denom_a = 1.0 - pe_ac1_b
        ac1_b = np.where(np.abs(denom_a) < 1e-12, 1.0, (po_b - pe_ac1_b) / np.where(np.abs(denom_a) < 1e-12, 1.0, denom_a))
        pabak_b = 2.0 * po_b - 1.0

        def _ci(arr):
            lo, hi = np.percentile(arr, [2.5, 97.5])
            return [round(float(lo), 4), round(float(hi), 4)]

        ic_boot = {
            "concordancia_bruta": _ci(po_b),
            "kappa_cohen": _ci(kappa_b),
            "gwet_ac1": _ci(ac1_b),
            "pabak": _ci(pabak_b),
        }

    matriz_dict = {
        categorias[i]: {categorias[j]: int(mat[i, j]) for j in range(k)}
        for i in range(k)
    }
    return {
        "n_pares": n,
        "categorias": list(categorias),
        "concordancia_bruta": round(po, 4),
        "kappa_cohen": round(kappa, 4),
        "gwet_ac1": round(ac1, 4),
        "pabak": round(pabak, 4),
        "ic95_bootstrap": ic_boot,
        "matriz_contingencia": matriz_dict,
    }


def _elegiveis_por_sql(con, where_extra: str, params: tuple = ()) -> list[int]:
    """Afirmações públicas (a mesma seleção dos pacotes do site) com ao menos uma obra citável com DOI ou PMID."""
    sql = f"""
        SELECT a.id
        FROM afirmacao a
        WHERE {pacotes.sql_afirmacao_exportada('a')}
          AND EXISTS (
              SELECT 1 FROM afirmacao_referencia ar
              JOIN referencia r ON r.id = ar.referencia_id
              WHERE ar.afirmacao_id = a.id AND (r.doi IS NOT NULL OR r.pmid IS NOT NULL)
                AND r.estado = 'ativa' AND r.duplicata_de IS NULL AND r.retratada = 0
          )
          AND ({where_extra})
        ORDER BY a.id
    """
    return [r[0] for r in con.execute(sql, params).fetchall()]


def amostrar_benchmark(con, rodada: str = RODADA_PADRAO, seed: int = SEMENTE_PADRAO,
                       n_total: int = N_PADRAO, recriar: bool = False) -> dict:
    """Sorteia ou recupera a amostra estratificada determinística em `amostra_benchmark`."""
    existente = con.execute("SELECT COUNT(*) FROM amostra_benchmark WHERE rodada=?", (rodada,)).fetchone()[0]
    if existente > 0 and not recriar:
        por_est = {r[0]: r[1] for r in con.execute(
            "SELECT estrato, COUNT(*) FROM amostra_benchmark WHERE rodada=? GROUP BY 1", (rodada,))}
        return {"rodada": rodada, "seed": seed, "n_amostra": existente, "por_estrato": por_est, "reutilizada": True}

    if recriar:
        con.execute("DELETE FROM amostra_benchmark WHERE rodada=?", (rodada,))

    rng = random.Random(seed)
    usados: set[int] = set()
    selecionados: list[tuple[str, int]] = []

    def _sortear(estrato: str, ids_cand: list[int], alvo_n: int):
        livres = [i for i in ids_cand if i not in usados]
        rng.shuffle(livres)
        pegos = sorted(livres[:alvo_n])
        for aid in pegos:
            usados.add(aid)
            selecionados.append((estrato, aid))
        return len(pegos)

    cota_de = cotas(n_total)
    for eid, _, _, condicao in ESTRATOS_ALVO:
        _sortear(eid, _elegiveis_por_sql(con, condicao), cota_de[eid])
    # Estrato com menos afirmações elegíveis que a cota: o que falta sai de todas as elegíveis, em estrato próprio.
    if len(selecionados) < n_total:
        _sortear(ESTRATO_COMPLEMENTO, _elegiveis_por_sql(con, "1=1"), n_total - len(selecionados))

    selecionados = selecionados[:n_total]
    ts = agora()
    con.executemany(
        "INSERT OR IGNORE INTO amostra_benchmark (rodada, afirmacao_id, estrato, semente_aleatoria, amostrado_em) VALUES (?,?,?,?,?)",
        [(rodada, aid, est, seed, ts) for est, aid in selecionados],
    )
    con.commit()
    por_est = Counter(est for est, _ in selecionados)
    return {"rodada": rodada, "seed": seed, "n_amostra": len(selecionados), "por_estrato": dict(por_est), "reutilizada": False}


def _buscar_textos_europepmc(con, cli, refs: list[dict], log=print) -> dict[int, dict]:
    """Consulta em lote o Europe PMC REST para obter títulos, resumos e status OA reais das referências."""
    por_ref: dict[int, dict] = {}
    if cli is None or not refs:
        return por_ref

    lote_tam = 12
    for ini in range(0, len(refs), lote_tam):
        fatia = refs[ini:ini + lote_tam]
        termos = []
        for r in fatia:
            if r["doi"]:
                termos.append(f'DOI:"{r["doi"]}"')
            elif r["pmid"]:
                termos.append(f'EXT_ID:{r["pmid"]}')
        if not termos:
            continue
        query = " OR ".join(termos)
        try:
            resp = cli.get(
                "https://www.ebi.ac.uk/europepmc/webservices/rest/search",
                {"query": query, "resultType": "core", "format": "json", "pageSize": "50"},
                fonte="europepmc",
                tentativas=2,
            )
            itens = ((resp.dados.get("resultList") or {}).get("result") or []) if isinstance(resp.dados, dict) else []
        except Exception:
            itens = []

        por_doi = {(it.get("doi") or "").strip().lower(): it for it in itens if it.get("doi")}
        por_pmid = {str(it.get("pmid") or "").strip(): it for it in itens if it.get("pmid")}

        for r in fatia:
            achado = None
            if r["doi"]:
                achado = por_doi.get(r["doi"].strip().lower())
            if achado is None and r["pmid"]:
                achado = por_pmid.get(str(r["pmid"]).strip())
            if achado:
                pmcid = achado.get("pmcid")
                if pmcid and not r.get("pmcid"):
                    con.execute("UPDATE referencia SET pmcid=? WHERE id=?", (pmcid, r["id"]))
                por_ref[r["id"]] = {
                    "titulo": achado.get("title") or r.get("titulo") or "",
                    "resumo": achado.get("abstractText") or "",
                    "pmcid": pmcid,
                    "oa": achado.get("isOpenAccess") == "Y",
                }
        if (ini // lote_tam + 1) % 8 == 0:
            log(f"    Europe PMC benchmark: {min(ini + lote_tam, len(refs))}/{len(refs)} referências consultadas")
    con.commit()
    return por_ref


def _normalizar_busca(txt: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (txt or "").lower()).strip()


# Termos genéricos de química de produtos naturais e de ensaio. Um resumo que traga qualquer um deles conta como
# «menção» no canal do composto quando nem o nome nem a classe aparecem: é o critério mais frouxo dos três.
TERMOS_GENERICOS = (
    "alkaloid", "flavon", "terpen", "sesquiterpen", "diterpen", "triterpen", "steroid", "coumarin",
    "lignan", "xanthon", "saponin", "phenolic", "essential oil", "extract", "isolated", "isolation",
    "constituent", "metabolite", "compound", "phytochem", "venom", "toxin", "phospholipase",
    "metalloproteinase", "peptide", "ic50", "inhibitor", "activity", "cytotox", "antimicrob", "assay",
)
TERMOS_CLINICOS = ("clinical", "patient", "therapy", "approved", "drug", "treatment", "trial", "pharmacol")
MENCAO, SEM_MENCAO = "mencao_encontrada", "mencao_nao_encontrada"


def _casar_texto(item: dict, textos_refs: list[dict], sinonimos_taxon: list[str]) -> dict:
    """Casamento de texto de UMA afirmação contra título e resumo das obras citadas. Dois canais, ambos automáticos:

      canal do organismo ou do alvo   afirmação ligada a organismo: nome aceito, sinônimo, gênero ou família;
                                      bioatividade: qualquer palavra (4+ letras) do nome do alvo;
                                      efeito clínico: um termo de `TERMOS_CLINICOS`
      canal do composto               nome do composto; senão palavra (5+ letras) da classe química;
                                      senão um termo de `TERMOS_GENERICOS`

    Cada canal devolve se achou a palavra e por qual critério. Nenhum dos dois lê o artigo nem confere a afirmação.
    """
    if item["tem_so_retratada"]:
        return {"acesso": "retratado", "canal_organismo_ou_alvo": None, "canal_composto": None,
                "resultado": "referencia_retratada"}

    tem_resumo = any(bool((t.get("resumo") or "").strip()) for t in textos_refs)
    tem_oa = any(bool(t.get("oa")) for t in textos_refs)
    tem_titulo = any(bool((t.get("titulo") or "").strip()) for t in textos_refs)
    acesso = "texto_completo_aberto" if tem_oa else ("resumo_aberto" if tem_resumo else ("apenas_titulo_metadado" if tem_titulo else "indisponivel"))

    corpus = _normalizar_busca(" ".join(f"{t.get('titulo', '')} {t.get('resumo', '')}" for t in textos_refs))

    # Conferência determinística da estrutura: SMILES e InChIKey têm de ser a mesma molécula
    if item["mol_tipo"] == "pequena_molecula" and item["smiles"] and item["inchikey"]:
        ok_rt, _ = quimica.conferir_inchikey(item["smiles"], item["inchikey"])
        if not ok_rt:
            return {"acesso": acesso, "canal_organismo_ou_alvo": None, "canal_composto": None,
                    "resultado": "smiles_e_inchikey_divergem"}

    # Sem resumo aberto não há texto em que procurar: o resultado é a ausência de texto, não uma menção negativa.
    if not tem_resumo and not tem_oa:
        return {"acesso": acesso, "canal_organismo_ou_alvo": None, "canal_composto": None, "resultado": "sem_resumo_aberto"}

    def contem(termo, minimo=4):
        n = _normalizar_busca(termo)
        return len(n) >= minimo and n in corpus

    criterio_a = None
    if item["taxon_nome"]:
        if any(contem(nm) for nm in [item["taxon_nome"], *sinonimos_taxon]):
            criterio_a = "especie_ou_sinonimo"
        elif contem(item["taxon_genero"] or ""):
            criterio_a = "genero"
        elif contem(item["taxon_familia"] or "", 5):
            criterio_a = "familia"
    elif item["alvo_nome"]:
        if any(w in corpus for w in _normalizar_busca(item["alvo_nome"]).split() if len(w) >= 4):
            criterio_a = "palavra_do_nome_do_alvo"
    elif item["tipo"] == "efeito_clinico_documentado":
        if any(w in corpus for w in TERMOS_CLINICOS):
            criterio_a = "termo_clinico_generico"

    criterio_b = None
    if contem(item["mol_nome"]) and not item["mol_nome"].startswith("IK_"):
        criterio_b = "nome_do_composto"
    elif item["mol_classe"] and any(w in corpus for w in _normalizar_busca(item["mol_classe"]).split() if len(w) >= 5):
        criterio_b = "palavra_da_classe_quimica"
    elif any(r in corpus for r in TERMOS_GENERICOS):
        criterio_b = "termo_generico"

    titulo_de_revisao = any(
        pad in _normalizar_busca(textos_refs[0].get("titulo", ""))
        for pad in ("a review", "review of", "systematic review", "meta analysis", "overview of")
    ) if textos_refs else False

    n_canais = (criterio_a is not None) + (criterio_b is not None)
    return {
        "acesso": acesso,
        "canal_organismo_ou_alvo": MENCAO if criterio_a else SEM_MENCAO,
        "canal_composto": MENCAO if criterio_b else SEM_MENCAO,
        "criterio_organismo_ou_alvo": criterio_a,
        "criterio_composto": criterio_b,
        "resultado": ("mencao_nos_dois_canais", "mencao_em_um_canal", "mencao_em_nenhum_canal")[2 - n_canais],
        "titulo_de_revisao": titulo_de_revisao,
    }


def _classe_humana(decisao: str) -> str:
    if decisao in ("confirmada", "corrigida"):
        return "positiva"
    if decisao == "rejeitada":
        return "negativa"
    return "duvida"


def calcular_relatorio_benchmark(con, cli=None, rodada: str = RODADA_PADRAO,
                                 seed: int = SEMENTE_PADRAO, consultar_europepmc: bool = True, log=print) -> dict:
    """Reúne a amostra, os votos de curadores registrados e o casamento de texto automático. Não altera nada no banco
    além de `amostra_benchmark` (na primeira execução da rodada) e do PMCID das referências consultadas."""
    info_amostra = amostrar_benchmark(con, rodada=rodada, seed=seed)

    linhas = con.execute(
        """
        SELECT ab.afirmacao_id, ab.estrato, a.tipo, a.fonte_id, a.estado, a.procedencia_declarada, a.nivel_evidencia,
               m.nome AS mol_nome, m.tipo AS mol_tipo, m.smiles, m.inchikey, m.classe_quimica AS mol_classe,
               t.nome AS taxon_nome, t.genero AS taxon_genero, t.familia AS taxon_familia, t.id AS taxon_id,
               al.nome AS alvo_nome
        FROM amostra_benchmark ab
        JOIN afirmacao a ON a.id = ab.afirmacao_id
        JOIN molecula m ON m.id = a.molecula_id
        LEFT JOIN taxon t ON t.id = a.taxon_id
        LEFT JOIN alvo al ON al.id = a.alvo_id
        WHERE ab.rodada = ?
        ORDER BY ab.estrato, ab.afirmacao_id
        """,
        (rodada,),
    ).fetchall()

    af_ids = [r["afirmacao_id"] for r in linhas]
    refs_por_af: dict[int, list[dict]] = {}
    refs_unicas: dict[int, dict] = {}
    if af_ids:
        marcas = ",".join("?" * len(af_ids))
        for r in con.execute(
            f"SELECT ar.afirmacao_id, rf.* FROM afirmacao_referencia ar "
            f"JOIN referencia rf ON rf.id = ar.referencia_id WHERE ar.afirmacao_id IN ({marcas}) ORDER BY rf.id",
            af_ids,
        ):
            d = dict(r)
            af_id = d.pop("afirmacao_id")
            refs_por_af.setdefault(af_id, []).append(d)
            refs_unicas[d["id"]] = d

    sins_por_taxon: dict[int, list[str]] = {}
    tax_ids = sorted({r["taxon_id"] for r in linhas if r["taxon_id"]})
    if tax_ids:
        marcas_t = ",".join("?" * len(tax_ids))
        for r in con.execute(f"SELECT taxon_id, nome FROM taxon_sinonimo WHERE taxon_id IN ({marcas_t}) "
                             f"AND IFNULL(status_gbif, '') NOT IN ('PROPARTE_SYNONYM','MISAPPLIED','DOUBTFUL')", tax_ids):
            sins_por_taxon.setdefault(r["taxon_id"], []).append(r["nome"])

    # A. Votos de curadores (pessoas) registrados em `verificacao` para esta rodada
    verifs_por_af: dict[int, dict[str, dict]] = {}
    for v in con.execute(
        "SELECT * FROM verificacao WHERE rodada_benchmark = ? AND papel_curador IS NOT NULL ORDER BY id",
        (rodada,),
    ):
        vd = dict(v)
        verifs_por_af.setdefault(vd["afirmacao_id"], {})[vd["papel_curador"]] = vd

    pares_humanos: list[tuple[str, str]] = []
    n_conf, n_rej, n_duv = 0, 0, 0
    subtipos_hum = Counter()
    for aid in af_ids:
        vp = verifs_por_af.get(aid, {})
        if "curador_1" in vp and "curador_2" in vp:
            c1 = _classe_humana(vp["curador_1"]["decisao"])
            c2 = _classe_humana(vp["curador_2"]["decisao"])
            pares_humanos.append((c1, c2))
            final_v = vp.get("adjudicador") or (vp["curador_1"] if c1 == c2 else None)
            if final_v:
                cf = _classe_humana(final_v["decisao"])
                if cf == "positiva":
                    n_conf += 1
                elif cf == "negativa":
                    n_rej += 1
                else:
                    n_duv += 1
                if final_v.get("subtipo_decisao"):
                    subtipos_hum[final_v["subtipo_decisao"]] += 1

    concordancia_humana = metricas_concordancia(
        pares_humanos, categorias=("positiva", "negativa", "duvida"), seed=seed
    )
    frac_conf = auditar.intervalo_wilson(n_conf, n_conf + n_rej) if (n_conf + n_rej) > 0 else (None, None, None)

    # B. Casamento de texto automático no título e no resumo (Europe PMC e metadados locais)
    epmc_map: dict[int, dict] = {}
    if consultar_europepmc and cli is not None and refs_unicas:
        epmc_map = _buscar_textos_europepmc(con, cli, list(refs_unicas.values()), log=log)

    por_estrato: dict[str, Counter] = {}
    acesso_cont = Counter()
    resultado_cont = Counter()
    criterio_a_cont, criterio_b_cont = Counter(), Counter()
    pares_canais: list[tuple[str, str]] = []

    for r in linhas:
        aid = r["afirmacao_id"]
        r_list = refs_por_af.get(aid, [])
        so_retratada = bool(r_list) and all(bool(x["retratada"]) for x in r_list)
        textos = [
            epmc_map.get(x["id"], {"titulo": x.get("titulo") or "", "resumo": "", "oa": bool(x.get("pmcid"))})
            for x in r_list
        ]
        av = _casar_texto({**dict(r), "tem_so_retratada": so_retratada}, textos, sins_por_taxon.get(r["taxon_id"], []))
        c_est = por_estrato.setdefault(r["estrato"], Counter())
        c_est["n"] += 1
        c_est[av["resultado"]] += 1
        if av["canal_composto"] is not None:
            c_est["com_texto"] += 1
            pares_canais.append((av["canal_organismo_ou_alvo"], av["canal_composto"]))
            criterio_a_cont[av["criterio_organismo_ou_alvo"] or "nenhum"] += 1
            criterio_b_cont[av["criterio_composto"] or "nenhum"] += 1
            if av["titulo_de_revisao"]:
                c_est["titulo_de_revisao"] += 1
        acesso_cont[av["acesso"]] += 1
        resultado_cont[av["resultado"]] += 1

    n_amostra = len(linhas)
    n_com_texto = len(pares_canais)
    n_dois = resultado_cont["mencao_nos_dois_canais"]
    n_um_ou_dois = n_dois + resultado_cont["mencao_em_um_canal"]
    p_dois, lo_dois, hi_dois = auditar.intervalo_wilson(n_dois, n_com_texto)
    p_algum, lo_algum, hi_algum = auditar.intervalo_wilson(n_um_ou_dois, n_com_texto)
    p_cob, lo_cob, hi_cob = auditar.intervalo_wilson(n_com_texto, n_amostra)
    associacao_canais = metricas_concordancia(pares_canais, categorias=(MENCAO, SEM_MENCAO), seed=seed)

    desc_map = {eid: d for eid, _, d, _ in ESTRATOS_ALVO}
    desc_map[ESTRATO_COMPLEMENTO] = "Complemento: afirmações elegíveis de qualquer base, para completar a amostra"
    estratos_detalhe = []
    for est, c_est in sorted(por_estrato.items()):
        n_tx = c_est["com_texto"]
        pr_e, lo_e, hi_e = auditar.intervalo_wilson(c_est["mencao_nos_dois_canais"], n_tx)
        estratos_detalhe.append({
            "estrato": est,
            "descricao": desc_map.get(est, est),
            "n_amostrado": c_est["n"],
            "n_com_titulo_e_resumo_abertos": n_tx,
            "n_mencao_nos_dois_canais": c_est["mencao_nos_dois_canais"],
            "n_mencao_em_um_canal": c_est["mencao_em_um_canal"],
            "n_mencao_em_nenhum_canal": c_est["mencao_em_nenhum_canal"],
            "n_sem_resumo_aberto": c_est["sem_resumo_aberto"],
            "n_titulo_de_revisao": c_est["titulo_de_revisao"],
            "fracao_com_mencao_nos_dois_canais": pr_e if n_tx > 0 else None,
            "ic95_wilson": [lo_e, hi_e] if n_tx > 0 else None,
        })

    return {
        "esquema": 2,
        "versao_plataforma": __version__,
        "gerado_em": agora(),
        "rodada": rodada,
        "semente_aleatoria": seed,
        "n_amostra": n_amostra,
        "amostra_por_estrato": info_amostra["por_estrato"],
        "nota": ("Documento interno. A seção `revisao_por_dois_curadores` traz votos de pessoas, registrados em `verificacao`. "
                 "A seção `casamento_de_texto_automatico` compara dois programas de busca de palavras no título e no resumo: "
                 "não são avaliadores, e os números dela não medem acerto das afirmações."),
        "revisao_por_dois_curadores": {
            "estado": (
                "concluida" if len(pares_humanos) >= n_amostra and n_amostra > 0
                else ("em_andamento" if pares_humanos else "sem_votos_registrados")
            ),
            "n_avaliados_curador_1": sum(1 for vp in verifs_por_af.values() if "curador_1" in vp),
            "n_avaliados_curador_2": sum(1 for vp in verifs_por_af.values() if "curador_2" in vp),
            "n_pares_completos": len(pares_humanos),
            "n_adjudicados": sum(1 for vp in verifs_por_af.values() if "adjudicador" in vp),
            "concordancia_entre_os_dois_curadores": concordancia_humana,
            "decisao_final": {
                "confirmadas": n_conf,
                "rejeitadas": n_rej,
                "em_duvida": n_duv,
                "fracao_confirmada": frac_conf[0],
                "ic95_wilson": [frac_conf[1], frac_conf[2]] if frac_conf[0] is not None else None,
                "subtipos_decisao": dict(subtipos_hum),
            },
        },
        "casamento_de_texto_automatico": {
            "n_amostra": n_amostra,
            "acesso_ao_texto": dict(acesso_cont),
            "com_titulo_e_resumo_abertos": {"n": n_com_texto, "fracao_da_amostra": p_cob, "ic95_wilson": [lo_cob, hi_cob]},
            "mencao_nos_dois_canais": {"n": n_dois, "de": n_com_texto, "fracao": p_dois, "ic95_wilson": [lo_dois, hi_dois]},
            "mencao_em_ao_menos_um_canal": {"n": n_um_ou_dois, "de": n_com_texto, "fracao": p_algum, "ic95_wilson": [lo_algum, hi_algum]},
            "criterio_do_canal_do_organismo_ou_alvo": dict(criterio_a_cont),
            "criterio_do_canal_do_composto": dict(criterio_b_cont),
            "associacao_entre_os_dois_canais_automaticos": associacao_canais,
            "resultados": dict(resultado_cont),
            "por_estrato": estratos_detalhe,
        },
    }


def _pct(valor):
    return "—" if valor is None else f"{valor * 100:.1f}%".replace(".", ",")


def gerar_markdown_validacao(rel: dict) -> str:
    """Markdown interno (`docs/dev/VALIDACAO_TECNICA.md`): diz o que foi comparado com o quê, e mais nada."""
    hum = rel["revisao_por_dois_curadores"]
    tx = rel["casamento_de_texto_automatico"]
    cob, dois, algum = tx["com_titulo_e_resumo_abertos"], tx["mencao_nos_dois_canais"], tx["mencao_em_ao_menos_um_canal"]
    assoc = tx["associacao_entre_os_dois_canais_automaticos"]
    desc = {eid: d for eid, _, d, _ in ESTRATOS_ALVO}
    desc[ESTRATO_COMPLEMENTO] = "Complemento: afirmações elegíveis de qualquer base, para completar a amostra"
    cota_de = cotas(N_PADRAO)

    L = [
        "# Validação por amostragem",
        "",
        "Documento de engenharia, gerado por `python -m bmb benchmark`. Uso interno: não faz parte do site nem dos pacotes de dados.",
        "",
        f"- Rodada: `{rel['rodada']}` (semente `{rel['semente_aleatoria']}`), {rel['n_amostra']} afirmações públicas com obra citável (DOI ou PMID).",
        f"- Gerado em {rel['gerado_em'][:19]}Z por `bmb {rel['versao_plataforma']}`.",
        "",
        "## 1. O que este documento compara",
        "",
        "Duas comparações diferentes sobre a mesma amostra:",
        "",
        "- **Revisão por dois curadores (seção 3).** Duas pessoas leem a publicação de cada afirmação sorteada, cada uma sem ver "
        "o voto da outra; uma terceira decide as divergências. A concordância entre avaliadores (κ de Cohen, AC1 de Gwet, PABAK) "
        "é calculada sobre os pares de votos dessas pessoas.",
        "- **Casamento de texto automático (seção 4).** Dois programas procuram palavras no título e no resumo das obras citadas. "
        "Não são avaliadores, não leem o artigo e não conferem a afirmação.",
        "",
        "Só a primeira diz algo sobre o acerto das afirmações. A segunda diz em quantos resumos as palavras procuradas aparecem.",
        "",
        "## 2. Amostra",
        "",
        "Sorteio com semente fixa entre as afirmações públicas que têm ao menos uma obra citável com DOI ou PMID. Cada estrato "
        "é definido pela base de origem, pelo tipo de afirmação e, onde a base as distingue, pela procedência declarada ou pelo "
        "nível de evidência. Estrato com menos afirmações que a cota é completado no estrato `complemento`.",
        "",
        "| Estrato | Definição | Cota em N = 360 | Sorteadas |",
        "| :--- | :--- | ---: | ---: |",
    ]
    for eid in [*(e[0] for e in ESTRATOS_ALVO), ESTRATO_COMPLEMENTO]:
        n_e = rel["amostra_por_estrato"].get(eid, 0)
        if eid == ESTRATO_COMPLEMENTO and not n_e:
            continue
        L.append(f"| `{eid}` | {desc[eid]} | {cota_de.get(eid, '—')} | {n_e} |")
    outros = sorted(k for k in rel["amostra_por_estrato"] if k not in desc)
    for eid in outros:                      # rodada sorteada por uma versão anterior deste módulo
        L.append(f"| `{eid}` | estrato de uma definição anterior | — | {rel['amostra_por_estrato'][eid]} |")

    L += [
        "",
        "## 3. Revisão por dois curadores",
        "",
        f"- Afirmações avaliadas pelo curador 1: {hum['n_avaliados_curador_1']}; pelo curador 2: {hum['n_avaliados_curador_2']}; "
        f"pares completos: {hum['n_pares_completos']}; adjudicadas: {hum['n_adjudicados']}.",
    ]
    if hum["n_pares_completos"] > 0:
        ch, df = hum["concordancia_entre_os_dois_curadores"], hum["decisao_final"]
        ic = ch["ic95_bootstrap"]
        L += [
            f"- Concordância bruta entre os dois curadores: {ch['concordancia_bruta']} (IC 95% por bootstrap: {ic.get('concordancia_bruta')}).",
            f"- κ de Cohen: {ch['kappa_cohen']} (IC 95%: {ic.get('kappa_cohen')}). AC1 de Gwet: {ch['gwet_ac1']} (IC 95%: {ic.get('gwet_ac1')}). "
            f"PABAK: {ch['pabak']}.",
            f"- Decisão final (voto concordante ou adjudicação): {df['confirmadas']} confirmadas, {df['rejeitadas']} rejeitadas, "
            f"{df['em_duvida']} em dúvida. Fração confirmada entre confirmadas e rejeitadas: {_pct(df['fracao_confirmada'])}"
            + (f" (IC 95% de Wilson: {_pct(df['ic95_wilson'][0])} a {_pct(df['ic95_wilson'][1])})." if df["ic95_wilson"] else "."),
            f"- Os números valem para as {hum['n_pares_completos']} afirmações com par completo, não para a amostra inteira.",
        ]
    else:
        L += [
            "- Nenhum voto de curador foi registrado nesta rodada. Não há, portanto, medida de concordância entre avaliadores "
            "nem estimativa de acerto das afirmações.",
            "- A amostra está em `amostra_benchmark`, pronta para a revisão em `python -m bmb servir --curadoria`.",
        ]

    L += [
        "",
        "## 4. Casamento de texto automático no título e no resumo",
        "",
        "O que cada programa procura, no título e no resumo que o Europe PMC traz para as obras citadas:",
        "",
        "- **Canal do organismo ou do alvo.** Afirmação ligada a organismo: o nome aceito do táxon, um sinônimo, o gênero ou a "
        "família. Bioatividade: qualquer palavra de quatro letras ou mais do nome do alvo. Efeito clínico: um termo clínico genérico "
        f"({', '.join(TERMOS_CLINICOS)}).",
        "- **Canal do composto.** O nome do composto; se não aparece, uma palavra de cinco letras ou mais da classe química; se não "
        "aparece, um termo genérico de química de produtos naturais ou de ensaio (lista `TERMOS_GENERICOS` em `bmb/benchmark.py`, "
        "que inclui palavras como «compound», «extract» e «activity»).",
        "",
        "O critério do gênero, o da família e o do termo genérico são frouxos: quase todo resumo de fitoquímica os satisfaz. "
        "Por isso a tabela de critérios abaixo importa mais que o total.",
        "",
        f"- Afirmações com título e resumo abertos: {cob['n']} de {tx['n_amostra']} ({_pct(cob['fracao_da_amostra'])}; "
        f"IC 95% de Wilson {_pct(cob['ic95_wilson'][0])} a {_pct(cob['ic95_wilson'][1])}). Só nelas há texto em que procurar.",
        f"- Com menção nos dois canais: {dois['n']} de {dois['de']} ({_pct(dois['fracao'])}; IC 95% {_pct(dois['ic95_wilson'][0])} a {_pct(dois['ic95_wilson'][1])}).",
        f"- Com menção em ao menos um canal: {algum['n']} de {algum['de']} ({_pct(algum['fracao'])}; IC 95% {_pct(algum['ic95_wilson'][0])} a {_pct(algum['ic95_wilson'][1])}).",
        f"- Acesso ao texto: {', '.join(f'{k}: {v}' for k, v in sorted(tx['acesso_ao_texto'].items())) or '—'}.",
        "",
        "| Canal | Critério que encontrou a menção | Afirmações |",
        "| :--- | :--- | ---: |",
    ]
    for canal, chave in (("organismo ou alvo", "criterio_do_canal_do_organismo_ou_alvo"), ("composto", "criterio_do_canal_do_composto")):
        for criterio, n in sorted(tx[chave].items(), key=lambda par: (-par[1], par[0])):
            L.append(f"| {canal} | `{criterio}` | {n} |")
    L += [
        "",
        "Associação entre os dois canais automáticos (as mesmas fórmulas de concordância, aplicadas a dois programas): "
        f"coincidência bruta {assoc['concordancia_bruta']}, κ de Cohen {assoc['kappa_cohen']}, AC1 de Gwet {assoc['gwet_ac1']}, "
        f"em {assoc['n_pares']} afirmações. Este número diz com que frequência as duas buscas dão o mesmo resultado no mesmo resumo. "
        "Os canais procuram coisas diferentes e nenhum deles é referência para o outro: não é concordância entre avaliadores "
        "nem medida de acerto.",
        "",
        "| Estrato | Sorteadas | Com título e resumo | Menção nos dois canais | Em um canal | Em nenhum | Sem resumo aberto | Fração com as duas menções (IC 95% de Wilson) |",
        "| :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for e in tx["por_estrato"]:
        fr = (f"{_pct(e['fracao_com_mencao_nos_dois_canais'])} ({_pct(e['ic95_wilson'][0])} a {_pct(e['ic95_wilson'][1])})"
              if e["fracao_com_mencao_nos_dois_canais"] is not None else "—")
        L.append(f"| `{e['estrato']}` | {e['n_amostrado']} | {e['n_com_titulo_e_resumo_abertos']} | {e['n_mencao_nos_dois_canais']} | "
                 f"{e['n_mencao_em_um_canal']} | {e['n_mencao_em_nenhum_canal']} | {e['n_sem_resumo_aberto']} | {fr} |")

    L += [
        "",
        "## 5. O que estes números não dizem",
        "",
        "1. Menção no resumo não confirma a afirmação: o resumo pode citar o organismo e o composto sem dizer que um foi isolado do outro.",
        "2. Ausência no resumo não refuta a afirmação: artigos de fitoquímica listam os compostos isolados nas tabelas do corpo do texto.",
        "3. Obra sem resumo aberto no Europe PMC não entra em nenhuma das frações da seção 4.",
        "4. A conferência que entra nos dados publicados é outra: a etapa `evidencias` (`bmb/literatura.py`) localiza, frase a frase, "
        "o organismo e o composto com verbo de isolamento, e grava o resultado em `afirmacao.nivel_evidencia`.",
        "",
    ]
    return "\n".join(L)


def executar_e_salvar(con, cli=None, pasta_dados: Path | None = None, caminho_md: Path | None = None,
                      rodada: str = RODADA_PADRAO, seed: int = SEMENTE_PADRAO,
                      consultar_europepmc: bool = True, log=print) -> dict:
    """Sorteia (ou recupera) a amostra, calcula as duas comparações e grava o JSON e o Markdown, ambos internos.

    Padrões: JSON em `config.SAIDA_DIR / "interno"` e Markdown em `docs/dev/VALIDACAO_TECNICA.md`. Nenhum dos dois
    vai para `app/dados` nem para pasta alguma do site.
    """
    pasta = Path(pasta_dados or (config.SAIDA_DIR / pacotes.PASTA_INTERNA))
    arq_md = Path(caminho_md or (config.PLATAFORMA / "docs" / "dev" / "VALIDACAO_TECNICA.md"))
    # Registro interno: nunca dentro do site nem de uma pasta de pacotes públicos (a que tem manifesto.json).
    site = config.APP_DIR.resolve()
    for destino in (pasta.resolve(), arq_md.resolve().parent):
        if destino == site or site in destino.parents or (destino / "manifesto.json").exists():
            raise SystemExit(f"{destino} é pasta do site ou de pacotes públicos; a validação por amostragem é registro "
                             f"interno e fica em {config.SAIDA_DIR / pacotes.PASTA_INTERNA}.")
    rel = calcular_relatorio_benchmark(
        con, cli=cli, rodada=rodada, seed=seed, consultar_europepmc=consultar_europepmc, log=log
    )
    pasta.mkdir(parents=True, exist_ok=True)
    arq_json = pasta / "benchmark_validacao.json"
    arq_json.write_text(json.dumps(rel, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")

    arq_md.parent.mkdir(parents=True, exist_ok=True)
    arq_md.write_text(gerar_markdown_validacao(rel), encoding="utf-8")
    log(f"✓ validação por amostragem ({rodada}): N={rel['n_amostra']} · JSON em {arq_json} · Markdown em {arq_md}")
    return rel
