-- BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
-- Migração 007: cobertura universal verificada de estruturas 3D (experimentais wwPDB/COD + predições AlphaFold/ESMFold + confôrmeros ETKDGv3)
-- e sinalizador explícito de disponibilidade de arquivo SDF 3D validado.

INSERT OR IGNORE INTO fonte (id, nome, url, licenca, licenca_url, descricao) VALUES
  ('cod', 'Crystallography Open Database (COD)', 'https://www.crystallography.net/cod/',
   'CC0 1.0', 'https://creativecommons.org/publicdomain/zero/1.0/',
   'Estruturas cristalográficas tridimensionais experimentais de pequenas moléculas e produtos naturais determinadas por difração de raios X e nêutrons de monocristal (domínio público CC0).'),
  ('esm_atlas', 'ESM Metagenomic Atlas — ESMFold v1 (Meta FAIR)', 'https://esmatlas.com',
   'CC BY 4.0', 'https://creativecommons.org/licenses/by/4.0/',
   'Predições computacionais atômicas de estrutura proteica por modelo de linguagem evolutiva ESMFold v1 com métrica pLDDT por resíduo, empregadas quando a sequência madura não consta no AlphaFold DB.');

ALTER TABLE estrutura_3d ADD COLUMN tem_sdf_3d INTEGER NOT NULL DEFAULT 0 CHECK (tem_sdf_3d IN (0, 1));

CREATE INDEX IF NOT EXISTS idx_est3d_mol_nat ON estrutura_3d(molecula_id, natureza);
