-- BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
-- Migração 002: a verificação humana passa a registrar também a avaliação do método do estudo, e a rejeição não
-- exige trecho (o curador pode rejeitar justamente por não achar a passagem). A tabela ainda está vazia na
-- 001, então é recriada sem perda de dados; migrações futuras com dados devem copiar as linhas.
DROP TABLE IF EXISTS verificacao;
CREATE TABLE verificacao (
  id                  INTEGER PRIMARY KEY,
  afirmacao_id        INTEGER NOT NULL REFERENCES afirmacao(id),
  referencia_id       INTEGER REFERENCES referencia(id),
  curador             TEXT NOT NULL CHECK (length(trim(curador)) >= 3),
  decisao             TEXT NOT NULL CHECK (decisao IN ('confirmada','corrigida','rejeitada','duvida')),
  passagem_conferida  TEXT,                    -- citação curta que o curador leu no artigo
  procedencia_material TEXT,                   -- o que o artigo declara; NULL = o artigo não declara
  voucher             TEXT,                    -- testemunho/depósito do material, se declarado
  sensibilidade       TEXT CHECK (sensibilidade IN ('sem_restricao','restrito','comunitario')),
  qualidade_experimental TEXT CHECK (qualidade_experimental IN ('atende','parcial','ausente')),
  nota                TEXT,
  em                  TEXT NOT NULL,
  CHECK (decisao IN ('duvida','rejeitada') OR (passagem_conferida IS NOT NULL AND length(trim(passagem_conferida)) >= 20)),
  CHECK (decisao <> 'rejeitada' OR (nota IS NOT NULL AND length(trim(nota)) >= 10))
);
CREATE INDEX ix_verificacao_afirmacao ON verificacao(afirmacao_id);
