-- BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
-- Migração 008: identidade taxonômica com autoria, conferência na literatura, regras de retenção,
-- procedência declarada separada do contexto de distribuição, agregação de bioatividade e integridade bibliográfica.
--
-- Só acrescenta colunas e tabelas (nenhuma tabela é recriada). Duas colunas antigas deixam de ser usadas e ficam
-- sempre NULL: `afirmacao.nivel_procedencia` e `taxon.escopo_biogeografico`. Elas misturavam o que uma fonte declara
-- sobre o material estudado com a distribuição conhecida da espécie; os dois conceitos passam a ter colunas próprias.

-- ───────────────────────── 1. Sinônimos: autoria, categoria e chave do uso no GBIF ─────────────────────────
ALTER TABLE taxon_sinonimo ADD COLUMN nome_completo TEXT;                       -- nome científico com autoria, como o backbone traz
ALTER TABLE taxon_sinonimo ADD COLUMN autoria TEXT;
ALTER TABLE taxon_sinonimo ADD COLUMN categoria TEXT;                           -- SPECIES, SUBSPECIES, VARIETY, FORM…
ALTER TABLE taxon_sinonimo ADD COLUMN status_gbif TEXT;                         -- SYNONYM, HETEROTYPIC_SYNONYM, PROPARTE_SYNONYM…
ALTER TABLE taxon_sinonimo ADD COLUMN gbif_key INTEGER;                         -- chave do uso (não a do aceito)
ALTER TABLE taxon_sinonimo ADD COLUMN consulta_id INTEGER REFERENCES consulta(id);
-- Nomes pelos quais registros de composto eram ligados a um táxon antes desta migração (sinônimos do GBIF sem autoria,
-- com infraespecíficos reduzidos ao binômio). Não servem mais para ligar nada: ficam para explicar, de forma
-- reprodutível, por que uma afirmação antiga foi retida.
CREATE TABLE IF NOT EXISTS taxon_sinonimo_legado (
  taxon_id INTEGER NOT NULL REFERENCES taxon(id),
  nome     TEXT NOT NULL,
  PRIMARY KEY (taxon_id, nome)
);
INSERT OR IGNORE INTO taxon_sinonimo_legado (taxon_id, nome)
  SELECT taxon_id, nome FROM taxon_sinonimo WHERE origem = 'gbif';
-- Universo taxonômico: sinônimos do checklist nacional com autoria e categoria ([{nome, autoria, categoria}])
ALTER TABLE universo_checklist ADD COLUMN sinonimos_autoria_json TEXT;

-- ───────────────────────── 2. Organismo como a fonte o nomeia, resolvido no backbone ─────────────────────────
-- Um registro de composto só é ligado a um táxon quando o organismo que a FONTE nomeia resolve, por identificador
-- ou por casamento estrito de nome, para a mesma espécie aceita. A decisão fica gravada, com a consulta que a sustenta.
CREATE TABLE IF NOT EXISTS organismo_fonte (
  id                   INTEGER PRIMARY KEY,
  fonte_id             TEXT NOT NULL REFERENCES fonte(id),
  nome_fonte           TEXT NOT NULL,                 -- exatamente como a fonte escreve (binômio ou infraespecífico, sem truncar)
  id_fonte             TEXT NOT NULL DEFAULT '',      -- identificador taxonômico que a própria fonte fornece ('' = nenhum)
  familia_fonte        TEXT,
  gbif_key             INTEGER,
  gbif_nome_completo   TEXT,
  gbif_autoria         TEXT,
  gbif_categoria       TEXT,
  gbif_status          TEXT,
  especie_aceita_key   INTEGER,
  especie_aceita_nome  TEXT,
  via                  TEXT NOT NULL CHECK (via IN ('identificador_da_fonte','nome_estrito','nome_aceito_identico','nao_resolvido')),
  taxon_id             INTEGER REFERENCES taxon(id),
  decisao              TEXT NOT NULL CHECK (decisao IN (
                         'aceito','aceito_mesmo_nome_e_autoria','homonimo_nao_resolvido','fora_do_escopo','nao_resolvido')),
  consulta_id          INTEGER REFERENCES consulta(id),
  resolvido_em         TEXT NOT NULL,
  UNIQUE (fonte_id, nome_fonte, id_fonte)
);
CREATE INDEX IF NOT EXISTS idx_orgfonte_taxon ON organismo_fonte(taxon_id);

-- ───────────────────────── 3. Afirmações ─────────────────────────
ALTER TABLE afirmacao ADD COLUMN organismo_na_fonte TEXT;                       -- nome(s) usado(s) pela fonte, separados por '; '
ALTER TABLE afirmacao ADD COLUMN nivel_evidencia TEXT NOT NULL DEFAULT 'base_curada'
  CHECK (nivel_evidencia IN ('curador','artigo_trecho','artigo_cita_organismo','base_curada'));
ALTER TABLE afirmacao ADD COLUMN conferencia_literatura TEXT
  CHECK (conferencia_literatura IN (
    'trecho_localizado',              -- frase do resumo ou do texto aberto cita organismo e composto, com verbo de isolamento
    'organismo_citado',               -- título, resumo ou texto aberto citam o organismo
    'so_composto_ou_genero_citado',   -- o texto lido cita o gênero ou o composto, não a espécie
    'so_titulo_sem_organismo',        -- só o título pôde ser lido, e ele não cita o organismo
    'sem_texto',                      -- nenhuma obra citada pôde ser lida (nem título)
    'texto_sem_mencao',               -- resumo ou texto lido não cita organismo, gênero nem composto
    'outra_especie_citada',           -- os títulos citam outra espécie do gênero, e nenhuma obra cita esta
    'nao_se_aplica'));
ALTER TABLE afirmacao ADD COLUMN passagem_origem TEXT
  CHECK (passagem_origem IN ('anotacao_uniprot','mecanismo_chembl','resumo','texto_completo_aberto','curador'));
ALTER TABLE afirmacao ADD COLUMN passagem_referencia_id INTEGER REFERENCES referencia(id);
ALTER TABLE afirmacao ADD COLUMN passagem_sha256 TEXT;
ALTER TABLE afirmacao ADD COLUMN regra_quarentena TEXT;
ALTER TABLE afirmacao ADD COLUMN quarentena_origem TEXT CHECK (quarentena_origem IN ('regra','curador'));
ALTER TABLE afirmacao ADD COLUMN procedencia_declarada TEXT
  CHECK (procedencia_declarada IN (
    'curador_artigo_amazonia',                 -- curador leu o artigo: coleta na Amazônia (único nível conferido por pessoa)
    'curador_artigo_fora_da_amazonia',
    'base_declara_amazonia_legal',             -- UF da Amazônia Legal declarada pela base de origem (não conferida no artigo)
    'base_declara_brasil_fora_da_amazonia_legal',
    'base_declara_pais_pan_amazonico',         -- só o país (BR sem UF, BO, CO, EC, GF, GY, PE, SR, VE): não situa a coleta na Amazônia
    'base_declara_exterior',
    'nao_declarada'));
ALTER TABLE afirmacao ADD COLUMN procedencia_artigo TEXT                        -- o que o texto aberto do artigo declara (trecho localizado)
  CHECK (procedencia_artigo IN ('amazonia_legal','pais_pan_amazonico','brasil_fora_da_amazonia_legal','exterior','ambiente_marinho'));
ALTER TABLE afirmacao ADD COLUMN procedencia_artigo_local TEXT;                 -- só país ISO-2 e UF: 'BR-AP', 'CN'
ALTER TABLE afirmacao ADD COLUMN procedencia_artigo_referencia_id INTEGER REFERENCES referencia(id);
ALTER TABLE afirmacao ADD COLUMN procedencia_artigo_sha256 TEXT;                -- hash da frase; a frase não é guardada
ALTER TABLE afirmacao ADD COLUMN medida_agregacao TEXT CHECK (medida_agregacao IN ('mediana','unica'));
ALTER TABLE afirmacao ADD COLUMN medida_n INTEGER;
ALTER TABLE afirmacao ADD COLUMN medida_n_documentos INTEGER;
ALTER TABLE afirmacao ADD COLUMN medida_min REAL;
ALTER TABLE afirmacao ADD COLUMN medida_max REAL;
ALTER TABLE afirmacao ADD COLUMN ensaio_tipo TEXT;
ALTER TABLE afirmacao ADD COLUMN contexto_ensaio TEXT;                          -- JSON: confiança, relação ensaio–alvo, variante
ALTER TABLE afirmacao ADD COLUMN fontes_regulatorias TEXT;                      -- JSON: rótulos e registros que o ChEMBL cita por indicação
CREATE INDEX IF NOT EXISTS idx_afirmacao_regra ON afirmacao(regra_quarentena);
CREATE INDEX IF NOT EXISTS idx_afirmacao_evidencia ON afirmacao(nivel_evidencia);

-- Medidas individuais do ChEMBL consideradas em cada agregado (usadas ou excluídas, com o motivo).
CREATE TABLE IF NOT EXISTS medida_bioatividade (
  id                   INTEGER PRIMARY KEY,
  activity_id          INTEGER NOT NULL UNIQUE,
  afirmacao_id         INTEGER REFERENCES afirmacao(id),
  molecula_id          INTEGER NOT NULL REFERENCES molecula(id),
  alvo_chembl_id       TEXT NOT NULL,
  tipo                 TEXT NOT NULL,
  relacao              TEXT,
  valor_nm             REAL,
  pchembl              REAL,
  documento_chembl_id  TEXT,
  ensaio_chembl_id     TEXT,
  ensaio_tipo          TEXT,
  usada                INTEGER NOT NULL CHECK (usada IN (0,1)),
  motivo_exclusao      TEXT,
  consulta_id          INTEGER NOT NULL REFERENCES consulta(id)
);
CREATE INDEX IF NOT EXISTS idx_medida_afirmacao ON medida_bioatividade(afirmacao_id);
CREATE INDEX IF NOT EXISTS idx_medida_grupo ON medida_bioatividade(molecula_id, alvo_chembl_id, tipo);

-- ───────────────────────── 4. Alvos: natureza explícita ─────────────────────────
ALTER TABLE alvo ADD COLUMN tipo_chembl TEXT;                                   -- SINGLE PROTEIN, CELL-LINE, ORGANISM…
ALTER TABLE alvo ADD COLUMN natureza TEXT
  CHECK (natureza IN ('proteina_unica','complexo_proteico','familia_proteica','linhagem_celular','organismo','tecido',
                      'fracao_subcelular','acido_nucleico','admet','nao_molecular','indeterminado'));

-- ───────────────────────── 5. Referências ─────────────────────────
ALTER TABLE referencia ADD COLUMN tipo_obra TEXT;                               -- journal-article, book-chapter, dataset, component…
ALTER TABLE referencia ADD COLUMN agencia_doi TEXT;                             -- Crossref, DataCite…
ALTER TABLE referencia ADD COLUMN doi_pmid_coerente INTEGER CHECK (doi_pmid_coerente IN (0,1));
ALTER TABLE referencia ADD COLUMN estado TEXT NOT NULL DEFAULT 'ativa' CHECK (estado IN ('ativa','quarentena'));
ALTER TABLE referencia ADD COLUMN regra_quarentena TEXT;
ALTER TABLE referencia ADD COLUMN motivo_quarentena TEXT;
ALTER TABLE referencia ADD COLUMN duplicata_de INTEGER REFERENCES referencia(id);
ALTER TABLE referencia ADD COLUMN texto_nivel TEXT CHECK (texto_nivel IN ('texto_completo_aberto','resumo','titulo','nenhum'));
ALTER TABLE referencia ADD COLUMN texto_fonte TEXT;                             -- pubmed, europepmc, crossref
ALTER TABLE referencia ADD COLUMN texto_sha256 TEXT;                            -- hash do texto lido; o texto não é guardado
ALTER TABLE referencia ADD COLUMN texto_consulta_id INTEGER REFERENCES consulta(id);
ALTER TABLE referencia ADD COLUMN texto_conferido_em TEXT;
CREATE INDEX IF NOT EXISTS idx_referencia_duplicata ON referencia(duplicata_de);

-- ───────────────────────── 6. Moléculas ─────────────────────────
ALTER TABLE molecula ADD COLUMN inchikey_conectividade TEXT;                    -- primeiro bloco do InChIKey: esqueleto 2D, sem estereoquímica
ALTER TABLE molecula ADD COLUMN massa_monoisotopica REAL;
ALTER TABLE molecula ADD COLUMN massa_media REAL;
ALTER TABLE molecula ADD COLUMN estereocentros INTEGER;
ALTER TABLE molecula ADD COLUMN estereocentros_indefinidos INTEGER;
ALTER TABLE molecula ADD COLUMN medidas_consulta_id INTEGER REFERENCES consulta(id);   -- lista completa de medidas do ChEMBL já lida
ALTER TABLE molecula ADD COLUMN restricao_ocorrencia TEXT
  CHECK (restricao_ocorrencia IN ('farmaco_ou_reagente_sintetico','controle_de_ensaio','contaminante_provavel','elemento_quimico'));
CREATE INDEX IF NOT EXISTS idx_molecula_conectividade ON molecula(inchikey_conectividade);
UPDATE molecula SET inchikey_conectividade = substr(inchikey, 1, 14) WHERE inchikey IS NOT NULL;

-- ───────────────────────── 7. Linhagens curadas ─────────────────────────
ALTER TABLE relacao_molecula ADD COLUMN chave TEXT;                             -- chave estável da entrada em semente/linhagens.toml
ALTER TABLE relacao_molecula ADD COLUMN regra_quarentena TEXT;
ALTER TABLE relacao_molecula ADD COLUMN motivo_quarentena TEXT;
ALTER TABLE relacao_molecula ADD COLUMN trecho TEXT;                            -- frase do texto publicado que confirma a relação
ALTER TABLE relacao_molecula ADD COLUMN trecho_fonte TEXT CHECK (trecho_fonte IN ('resumo_pubmed','texto_completo_europepmc'));
ALTER TABLE relacao_molecula ADD COLUMN trecho_sha256 TEXT;
ALTER TABLE relacao_molecula ADD COLUMN trecho_conferido_em TEXT;

-- ───────────────────────── 8. Táxon: contexto de distribuição (não é procedência de material) ─────────────────────────
ALTER TABLE taxon ADD COLUMN distribuicao_br TEXT
  CHECK (distribuicao_br IN (
    'endemica_do_brasil_restrita_ao_dominio_amazonia',   -- Flora e Funga do Brasil / CTFB
    'endemica_do_brasil_com_ocorrencia_na_amazonia',
    'registros_brasileiros_concentrados_na_amazonia_legal', -- metade ou mais dos registros brasileiros do GBIF, nas duas bases
    'registros_brasileiros_dispersos',
    'introduzida_ou_naturalizada',
    'fora_do_recorte',
    'indeterminada'));

-- ───────────────────────── 9. Catálogo das regras de retenção ─────────────────────────
CREATE TABLE IF NOT EXISTS regra_quarentena (
  codigo   TEXT PRIMARY KEY,
  escopo   TEXT NOT NULL CHECK (escopo IN ('afirmacao','referencia','relacao_molecula','midia')),
  grupo    TEXT NOT NULL,
  titulo   TEXT NOT NULL,
  modelo   TEXT NOT NULL
);

-- ───────────────────────── 10. Estado inicial coerente logo após a migração ─────────────────────────
-- A classificação completa é refeita por `bmb construir --etapas prontidao`; aqui só se evita deixar o banco migrado
-- com rótulos antigos. O que dependia da distribuição da espécie deixa de constar como procedência.
UPDATE afirmacao SET procedencia_declarada = CASE
    WHEN tipo NOT IN ('composto_em_organismo','funcao_toxina') THEN NULL
    WHEN uf_coleta_declarada IN ('AC','AM','AP','MA','MT','PA','RO','RR','TO') THEN 'base_declara_amazonia_legal'
    WHEN uf_coleta_declarada IS NOT NULL AND instr(uf_coleta_declarada, ',') = 0 THEN 'base_declara_brasil_fora_da_amazonia_legal'
    WHEN pais_coleta_declarado IN ('BR','BO','CO','EC','GF','GY','PE','SR','VE') THEN 'base_declara_pais_pan_amazonico'
    WHEN pais_coleta_declarado IS NOT NULL THEN 'base_declara_exterior'
    ELSE 'nao_declarada' END;
UPDATE afirmacao SET nivel_procedencia = NULL;
UPDATE taxon SET escopo_biogeografico = NULL;
UPDATE afirmacao SET quarentena_origem = 'regra' WHERE estado = 'quarentena' AND quarentena_origem IS NULL;
UPDATE afirmacao SET passagem_origem = 'anotacao_uniprot' WHERE tipo = 'funcao_toxina' AND passagem IS NOT NULL;
UPDATE afirmacao SET passagem_origem = 'mecanismo_chembl' WHERE tipo = 'efeito_clinico_documentado' AND passagem IS NOT NULL;

-- ───────────────────────── 11. Regras que cada afirmação dispara (base do estado de retenção) ─────────────────────────
-- Uma afirmação pode disparar várias regras; o estado público decorre da de maior precedência. Guardar todas
-- torna a retenção reprodutível: quando a condição deixa de valer, a linha some e a afirmação volta a `candidato`.
CREATE TABLE IF NOT EXISTS afirmacao_regra (
  afirmacao_id  INTEGER NOT NULL REFERENCES afirmacao(id),
  codigo        TEXT NOT NULL,
  detalhe       TEXT,                           -- JSON com os dados que preenchem o modelo do motivo
  detectada_em  TEXT NOT NULL,
  PRIMARY KEY (afirmacao_id, codigo)
);
CREATE INDEX IF NOT EXISTS idx_afirmacao_regra_codigo ON afirmacao_regra(codigo);
