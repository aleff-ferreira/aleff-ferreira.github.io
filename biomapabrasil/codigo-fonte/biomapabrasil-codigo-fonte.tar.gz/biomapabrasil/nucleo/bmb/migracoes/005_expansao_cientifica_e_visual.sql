-- BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
-- Migração 005: expansão científica multi-fonte (checklists nacionais com sinônimos, estratificação vertical
-- empírica da floresta, bioma Amazônia vs. Amazônia Legal e fronteira 44°W no Maranhão, NuBBE-DB, NPAtlas,
-- descritores físico-químicos RDKit e espaço químico determinístico, estruturas 3D experimentais/preditas,
-- vias biológicas Reactome, sub-bacias hidrográficas amazônicas e grade de lacunas rastreável no SQLite).

-- ── 1. Táxons: checklists nacionais, estratos florestais empíricos, recorte ecológico e contexto biocultural ──
ALTER TABLE taxon ADD COLUMN endemismo_br TEXT
  CHECK (endemismo_br IS NULL OR endemismo_br IN ('endemica','nao_endemica','indeterminado'));
ALTER TABLE taxon ADD COLUMN biomas_json TEXT;
ALTER TABLE taxon ADD COLUMN forma_vida TEXT;
ALTER TABLE taxon ADD COLUMN estrato_florestal TEXT
  CHECK (estrato_florestal IS NULL OR estrato_florestal IN (
    'emergente','dossel','sub_bosque','liana_epifita','solo_serrapilheira','aquatico_ripario'
  ));
ALTER TABLE taxon ADD COLUMN categoria_mma TEXT;
ALTER TABLE taxon ADD COLUMN checklist_fonte TEXT;
ALTER TABLE taxon ADD COLUMN checklist_consulta_id INTEGER REFERENCES consulta(id);
ALTER TABLE taxon ADD COLUMN n_bioma_amazonia INTEGER;
ALTER TABLE taxon ADD COLUMN n_ma_oeste44 INTEGER;
ALTER TABLE taxon ADD COLUMN bioma_consulta_id INTEGER REFERENCES consulta(id);
ALTER TABLE taxon ADD COLUMN contexto_biocultural TEXT;

-- ── 2. Moléculas: fontes brasileiras/fúngicas, descritores RDKit e coordenadas de espaço químico ──
ALTER TABLE molecula ADD COLUMN nubbe_id TEXT;
ALTER TABLE molecula ADD COLUMN npatlas_id TEXT;
ALTER TABLE molecula ADD COLUMN clogp REAL;
ALTER TABLE molecula ADD COLUMN tpsa REAL;
ALTER TABLE molecula ADD COLUMN fsp3 REAL;
ALTER TABLE molecula ADD COLUMN hbd INTEGER;
ALTER TABLE molecula ADD COLUMN hba INTEGER;
ALTER TABLE molecula ADD COLUMN qed REAL;
ALTER TABLE molecula ADD COLUMN np_likeness REAL;
ALTER TABLE molecula ADD COLUMN murcko_smiles TEXT;
ALTER TABLE molecula ADD COLUMN umap_x REAL;
ALTER TABLE molecula ADD COLUMN umap_y REAL;

-- ── 3. Afirmações, alvos e linhagem farmacológica: metadados adicionais sem violar o Princípio 2 ──
ALTER TABLE afirmacao ADD COLUMN uf_coleta_declarada TEXT;
ALTER TABLE afirmacao ADD COLUMN escopo_referencia TEXT
  CHECK (escopo_referencia IS NULL OR escopo_referencia IN ('especifica','entrada_geral'));

ALTER TABLE alvo ADD COLUMN alvo_consulta_id INTEGER REFERENCES consulta(id);

ALTER TABLE relacao_molecula ADD COLUMN consulta_id INTEGER REFERENCES consulta(id);

-- ── 4. Estruturas 3D: separação estrita entre experimental (PDB), predição (AlphaFold) e confôrmero (RDKit) ──
CREATE TABLE estrutura_3d (
  id                    INTEGER PRIMARY KEY,
  molecula_id           INTEGER REFERENCES molecula(id),
  alvo_id               INTEGER REFERENCES alvo(id),
  natureza              TEXT NOT NULL CHECK (natureza IN ('experimental','predicao_computacional','conformero_calculado')),
  fonte_id              TEXT NOT NULL REFERENCES fonte(id),
  codigo                TEXT NOT NULL,
  metodo                TEXT,
  resolucao_angstrom    REAL,
  plddt_medio           REAL,
  energia_kcal_mol      REAL,
  n_atomos_ou_residuos  INTEGER,
  n_pontes_dissulfeto   INTEGER NOT NULL DEFAULT 0,
  arquivo_geometria     TEXT,
  geometria_sha256      TEXT,
  consulta_id           INTEGER REFERENCES consulta(id),
  CHECK (molecula_id IS NOT NULL OR alvo_id IS NOT NULL)
);

CREATE UNIQUE INDEX ux_estrutura_3d
  ON estrutura_3d (fonte_id, codigo, IFNULL(molecula_id, 0), IFNULL(alvo_id, 0));
CREATE INDEX ix_estrutura_3d_mol ON estrutura_3d(molecula_id);
CREATE INDEX ix_estrutura_3d_alvo ON estrutura_3d(alvo_id);

-- ── 5. Vias biológicas humanas (Reactome) ligadas a alvos moleculares ──
CREATE TABLE via_biologica (
  id            INTEGER PRIMARY KEY,
  reactome_id   TEXT NOT NULL UNIQUE,
  nome          TEXT NOT NULL,
  especie       TEXT NOT NULL DEFAULT 'Homo sapiens',
  doi           TEXT,
  consulta_id   INTEGER NOT NULL REFERENCES consulta(id)
);

CREATE TABLE alvo_via (
  alvo_id       INTEGER NOT NULL REFERENCES alvo(id),
  via_id        INTEGER NOT NULL REFERENCES via_biologica(id),
  consulta_id   INTEGER NOT NULL REFERENCES consulta(id),
  PRIMARY KEY (alvo_id, via_id)
);

-- ── 6. Sub-bacias hidrográficas amazônicas e ocorrências agregadas por bacia ──
CREATE TABLE bacia_hidrografica (
  id            TEXT PRIMARY KEY,
  nome          TEXT NOT NULL,
  rio_principal TEXT NOT NULL,
  area_km2      REAL NOT NULL CHECK (area_km2 > 0),
  poligono_wkt  TEXT NOT NULL,
  cor_hex       TEXT,
  consulta_id   INTEGER REFERENCES consulta(id)
);

CREATE TABLE ocorrencia_bacia (
  taxon_id      INTEGER NOT NULL REFERENCES taxon(id),
  bacia_id      TEXT NOT NULL REFERENCES bacia_hidrografica(id),
  n             INTEGER NOT NULL CHECK (n >= 0),
  consulta_id   INTEGER NOT NULL REFERENCES consulta(id),
  PRIMARY KEY (taxon_id, bacia_id)
);
CREATE INDEX ix_ocorrencia_bacia_bacia ON ocorrencia_bacia(bacia_id);

-- ── 7. Grade espacial de lacunas de amostragem e pressão antrópica (0,5°), 100% rastreável no SQLite ──
CREATE TABLE celula_lacuna (
  id                    INTEGER PRIMARY KEY,
  lon                   REAL NOT NULL,
  lat                   REAL NOT NULL,
  passo_graus           REAL NOT NULL DEFAULT 0.5,
  x_mapa                REAL NOT NULL,
  y_mapa                REAL NOT NULL,
  w_mapa                REAL NOT NULL,
  h_mapa                REAL NOT NULL,
  area_km2              REAL NOT NULL CHECK (area_km2 > 0),
  n_ocorrencias_gbif    INTEGER NOT NULL CHECK (n_ocorrencias_gbif >= 0),
  densidade_km2         REAL NOT NULL CHECK (densidade_km2 >= 0),
  bacia_id              TEXT REFERENCES bacia_hidrografica(id),
  pressao_desmatamento  REAL CHECK (pressao_desmatamento IS NULL OR (pressao_desmatamento >= 0 AND pressao_desmatamento <= 1)),
  cobertura_protegida   REAL CHECK (cobertura_protegida IS NULL OR (cobertura_protegida >= 0 AND cobertura_protegida <= 1)),
  prioridade_bivariada  TEXT,
  gbif_consulta_id      INTEGER NOT NULL REFERENCES consulta(id),
  pressao_consulta_id   INTEGER REFERENCES consulta(id),
  UNIQUE (lon, lat, passo_graus)
);
