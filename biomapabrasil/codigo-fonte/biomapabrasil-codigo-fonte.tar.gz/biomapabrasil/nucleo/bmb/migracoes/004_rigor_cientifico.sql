-- BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
-- Migração 004: metadados explícitos de rigor científico (origem de estabelecimento em checklists nacionais,
-- país de registro e quarentena rastreável de imagens, alertas estruturais PAINS, distinção entre fármaco
-- de metabólito secundário e metabólito primário/insumo farmacêutico em fase 4, e precursores controlados).

ALTER TABLE taxon ADD COLUMN origem_estabelecimento TEXT
  CHECK (origem_estabelecimento IS NULL OR origem_estabelecimento IN ('nativa','introduzida','indeterminada'));

ALTER TABLE midia ADD COLUMN pais TEXT;
ALTER TABLE midia ADD COLUMN estado TEXT NOT NULL DEFAULT 'ativo'
  CHECK (estado IN ('ativo','quarentena'));
ALTER TABLE midia ADD COLUMN motivo_quarentena TEXT;

ALTER TABLE molecula ADD COLUMN alerta_pains TEXT;
ALTER TABLE molecula ADD COLUMN categoria_clinica TEXT
  CHECK (categoria_clinica IS NULL OR categoria_clinica IN ('farmaco_secundario','metabolito_ou_insumo'));
ALTER TABLE molecula ADD COLUMN controle_regulatorio TEXT;
