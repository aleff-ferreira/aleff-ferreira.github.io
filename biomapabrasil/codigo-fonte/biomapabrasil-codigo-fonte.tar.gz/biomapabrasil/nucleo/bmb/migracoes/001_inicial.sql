-- BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
-- Esquema inicial. Regras do projeto que viram restrição do banco:
--   1. todo número e toda afirmação aponta uma consulta (fonte + URL + data);
--   2. ausência é NULL declarado, nunca zero silencioso (contagens têm consulta_id);
--   3. imagem só com licença CC0 ou CC BY;
--   4. a afirmação clínica só existe para fármaco aprovado, e descreve o fármaco, não o organismo.

CREATE TABLE fonte (
  id          TEXT PRIMARY KEY,
  nome        TEXT NOT NULL,
  url         TEXT NOT NULL,
  licenca     TEXT NOT NULL,
  licenca_url TEXT,
  descricao   TEXT
);

-- Proveniência de cada chamada externa: de onde veio, quando, e o que voltou.
CREATE TABLE consulta (
  id            INTEGER PRIMARY KEY,
  fonte_id      TEXT NOT NULL REFERENCES fonte(id),
  url           TEXT NOT NULL,
  consultado_em TEXT NOT NULL,                 -- ISO 8601, UTC; data da consulta ORIGINAL, mesmo se veio do cache
  status        INTEGER NOT NULL,
  bytes         INTEGER NOT NULL,
  sha256        TEXT NOT NULL,
  versao_fonte  TEXT,
  UNIQUE (url, sha256)
);

CREATE TABLE territorio (
  id             TEXT PRIMARY KEY,             -- 'BR', 'UF:13'
  tipo           TEXT NOT NULL CHECK (tipo IN ('pais','regiao','uf','municipio','bioma','celula')),
  codigo         TEXT,
  sigla          TEXT,
  nome           TEXT NOT NULL,
  pai_id         TEXT REFERENCES territorio(id),
  amazonia_legal INTEGER NOT NULL DEFAULT 0 CHECK (amazonia_legal IN (0,1)),
  area_km2       REAL,
  consulta_id    INTEGER REFERENCES consulta(id)
);

CREATE TABLE taxon (
  id              INTEGER PRIMARY KEY,
  gbif_key        INTEGER NOT NULL UNIQUE,     -- chave do uso ACEITO no backbone do GBIF
  nome            TEXT NOT NULL,               -- nome científico aceito (canônico)
  autoria         TEXT,
  rank            TEXT,
  reino           TEXT, filo TEXT, classe TEXT, ordem TEXT, familia TEXT, genero TEXT,
  grupo           TEXT NOT NULL CHECK (grupo IN ('planta','animal_peconhento','fungo','outro')),
  nomes_populares TEXT,                        -- JSON: [{"nome": "...", "idioma": "por"}]
  gbif_correspondencia TEXT,                   -- EXACT | FUZZY | ...  (como o nome da semente casou)
  gbif_confianca  INTEGER,
  uniprot_taxid   INTEGER,
  n_br            INTEGER,                     -- NULL = não consultado (nunca zero silencioso)
  n_al            INTEGER,
  n_br_com_uf     INTEGER,                     -- registros brasileiros com UF atribuída (base da fração)
  fracao_al_com_uf REAL,                       -- n_al / n_br_com_uf     (base 1: só registros com UF)
  fracao_al_total  REAL,                       -- n_al / n_br            (base 2: todos os registros do Brasil)
  predominio_al   TEXT CHECK (predominio_al IN ('predominante','nao_predominante','indeterminado')),
  ocorr_consulta_id INTEGER REFERENCES consulta(id),
  iucn            TEXT,
  iucn_consulta_id INTEGER REFERENCES consulta(id),
  no_recorte      INTEGER NOT NULL DEFAULT 0 CHECK (no_recorte IN (0,1)),
  motivo_recorte  TEXT NOT NULL,               -- por que está dentro ou fora do recorte, com os números
  origem_inclusao TEXT NOT NULL,
  -- Cobertura das fontes de moléculas, declarada: NULL = fonte não consultada; 0 = consultada e sem resultado.
  compostos_fonte     INTEGER,                 -- compostos que o LOTUS relaciona ao táxon, com publicação
  compostos_incluidos INTEGER,                 -- quantos a plataforma incluiu (teto por táxon, declarado)
  lotus_consulta_id   INTEGER REFERENCES consulta(id),
  toxinas_fonte       INTEGER,                 -- toxinas revisadas do Tox-Prot para o organismo
  uniprot_consulta_id INTEGER REFERENCES consulta(id),
  criado_em       TEXT NOT NULL,
  CHECK ((n_br IS NULL) = (ocorr_consulta_id IS NULL)),
  CHECK ((compostos_fonte IS NULL) = (lotus_consulta_id IS NULL)),
  CHECK ((toxinas_fonte IS NULL) = (uniprot_consulta_id IS NULL))
);

CREATE TABLE taxon_sinonimo (
  taxon_id INTEGER NOT NULL REFERENCES taxon(id),
  nome     TEXT NOT NULL,
  origem   TEXT NOT NULL,
  PRIMARY KEY (taxon_id, nome)
);

-- Distribuição agregada por UF: nunca coordenada individual.
CREATE TABLE ocorrencia_uf (
  taxon_id    INTEGER NOT NULL REFERENCES taxon(id),
  uf_sigla    TEXT NOT NULL,
  n           INTEGER NOT NULL CHECK (n >= 0),
  consulta_id INTEGER NOT NULL REFERENCES consulta(id),
  PRIMARY KEY (taxon_id, uf_sigla)
);

CREATE TABLE midia (
  id              INTEGER PRIMARY KEY,
  taxon_id        INTEGER NOT NULL REFERENCES taxon(id),
  url             TEXT NOT NULL,
  pagina          TEXT,
  licenca         TEXT NOT NULL CHECK (licenca IN ('CC0','CC BY')),
  autor           TEXT,
  instituicao     TEXT,
  gbif_ocorrencia TEXT,
  base_registro   TEXT,
  arquivo         TEXT,                        -- miniatura local (caminho relativo); NULL = ainda não baixada
  arquivo_sha256  TEXT,
  largura         INTEGER,
  altura          INTEGER,
  consulta_id     INTEGER NOT NULL REFERENCES consulta(id),
  UNIQUE (taxon_id, url)
);

CREATE TABLE molecula (
  id               INTEGER PRIMARY KEY,
  tipo             TEXT NOT NULL CHECK (tipo IN ('pequena_molecula','peptideo','proteina')),
  nome             TEXT NOT NULL,
  inchikey         TEXT UNIQUE,
  smiles           TEXT,
  formula          TEXT,
  massa            REAL,
  uniprot_acc      TEXT UNIQUE,
  comprimento_aa   INTEGER,
  familia          TEXT,
  pdb_ids          TEXT,                       -- JSON: ["1ABC", ...]
  pubchem_cid      INTEGER,
  chembl_id        TEXT,
  lotus_id         TEXT,
  classe_quimica   TEXT,
  nome_na_fonte    TEXT,                       -- nome como a fonte primária (LOTUS) o traz, se diferir do nome exibido
  nome_divergente  INTEGER NOT NULL DEFAULT 0 CHECK (nome_divergente IN (0,1)),
  pubchem_consulta_id INTEGER REFERENCES consulta(id),
  max_fase_clinica REAL,                       -- ChEMBL: 4 = aprovado; NULL = sem fase informada
  fase_consulta_id INTEGER REFERENCES consulta(id),   -- consulta ao ChEMBL (feita mesmo quando não há registro)
  fase_retirado    INTEGER CHECK (fase_retirado IN (0,1)),  -- fármaco retirado do mercado, segundo o ChEMBL
  atividades_consulta_id INTEGER REFERENCES consulta(id),  -- consulta às atividades (feita mesmo sem resultado)
  desenho          TEXT,                       -- caminho relativo do SVG da estrutura
  CHECK (inchikey IS NOT NULL OR uniprot_acc IS NOT NULL),
  CHECK (max_fase_clinica IS NULL OR fase_consulta_id IS NOT NULL)
);

CREATE TABLE alvo (
  id          INTEGER PRIMARY KEY,
  nome        TEXT NOT NULL,
  chembl_id   TEXT UNIQUE,
  uniprot_acc TEXT,
  organismo   TEXT,
  tipo        TEXT
);

CREATE TABLE referencia (
  id          INTEGER PRIMARY KEY,
  doi         TEXT UNIQUE,
  pmid        TEXT UNIQUE,
  pmcid       TEXT,
  titulo      TEXT,
  autores     TEXT,                            -- JSON
  revista     TEXT,
  ano         INTEGER,
  resolvida   INTEGER NOT NULL DEFAULT 0 CHECK (resolvida IN (0,1)),  -- 0 = só o identificador
  retratada   INTEGER NOT NULL DEFAULT 0 CHECK (retratada IN (0,1)),
  aviso       TEXT,                            -- ex.: 'expressao_de_preocupacao'
  consulta_id INTEGER REFERENCES consulta(id),
  CHECK (doi IS NOT NULL OR pmid IS NOT NULL)
);

CREATE TABLE afirmacao (
  id                   INTEGER PRIMARY KEY,
  tipo                 TEXT NOT NULL CHECK (tipo IN
                         ('composto_em_organismo','funcao_toxina','atividade_biologica','efeito_clinico_documentado')),
  taxon_id             INTEGER REFERENCES taxon(id),
  molecula_id          INTEGER NOT NULL REFERENCES molecula(id),
  alvo_id              INTEGER REFERENCES alvo(id),
  texto                TEXT NOT NULL,          -- enunciado por modelo fixo, sem juízo de eficácia
  passagem             TEXT,                   -- trecho da fonte que sustenta; NULL = fonte não traz
  metodo               TEXT,
  sistema_experimental TEXT,
  medida_tipo          TEXT,
  medida_relacao       TEXT,
  medida_valor         REAL,
  medida_unidade       TEXT,
  procedencia_material TEXT,                   -- NULL = a fonte NÃO declara (ausência declarada)
  origem               TEXT NOT NULL,          -- ex.: 'uniprot:P0CC17'
  fonte_id             TEXT NOT NULL REFERENCES fonte(id),
  consulta_id          INTEGER NOT NULL REFERENCES consulta(id),
  estado               TEXT NOT NULL DEFAULT 'candidato'
                         CHECK (estado IN ('candidato','em_revisao','verificado','quarentena','rejeitado')),
  classe_acesso        TEXT NOT NULL DEFAULT 'publico'
                         CHECK (classe_acesso IN ('publico','restrito','comunitario')),
  motivo_quarentena    TEXT,
  criado_em            TEXT NOT NULL,
  atualizado_em        TEXT NOT NULL,
  CHECK (tipo = 'atividade_biologica' OR alvo_id IS NULL OR tipo = 'funcao_toxina'),
  CHECK (tipo = 'composto_em_organismo' OR tipo = 'funcao_toxina' OR taxon_id IS NULL),
  CHECK (tipo <> 'efeito_clinico_documentado' OR taxon_id IS NULL),
  CHECK (tipo NOT IN ('composto_em_organismo','funcao_toxina') OR taxon_id IS NOT NULL),
  CHECK (estado <> 'quarentena' OR motivo_quarentena IS NOT NULL)
);

CREATE TABLE afirmacao_referencia (
  afirmacao_id  INTEGER NOT NULL REFERENCES afirmacao(id),
  referencia_id INTEGER NOT NULL REFERENCES referencia(id),
  papel         TEXT NOT NULL DEFAULT 'sustenta',
  PRIMARY KEY (afirmacao_id, referencia_id)
);

-- Perfil de prontidão da evidência: sete dimensões independentes. O índice mede completude
-- para reutilização; NÃO é nota de eficácia biológica.
CREATE TABLE prontidao (
  afirmacao_id           INTEGER PRIMARY KEY REFERENCES afirmacao(id),
  identidade_biologica   TEXT NOT NULL CHECK (identidade_biologica   IN ('atende','parcial','ausente','nao_avaliado','nao_se_aplica')),
  procedencia            TEXT NOT NULL CHECK (procedencia            IN ('atende','parcial','ausente','nao_avaliado','nao_se_aplica')),
  identidade_quimica     TEXT NOT NULL CHECK (identidade_quimica     IN ('atende','parcial','ausente','nao_avaliado','nao_se_aplica')),
  qualidade_experimental TEXT NOT NULL CHECK (qualidade_experimental IN ('atende','parcial','ausente','nao_avaliado','nao_se_aplica')),
  rastreabilidade        TEXT NOT NULL CHECK (rastreabilidade        IN ('atende','parcial','ausente','nao_avaliado','nao_se_aplica')),
  reutilizacao           TEXT NOT NULL CHECK (reutilizacao           IN ('atende','parcial','ausente','nao_avaliado','nao_se_aplica')),
  sensibilidade          TEXT NOT NULL CHECK (sensibilidade          IN ('atende','parcial','ausente','nao_avaliado','nao_se_aplica')),
  indice                 REAL NOT NULL CHECK (indice >= 0 AND indice <= 1),
  notas                  TEXT
);

CREATE TABLE evento_proveniencia (
  id          INTEGER PRIMARY KEY,
  entidade    TEXT NOT NULL,
  entidade_id INTEGER NOT NULL,
  atividade   TEXT NOT NULL,                   -- extracao | reconciliacao | verificacao | publicacao | correcao | quarentena
  agente      TEXT NOT NULL,                   -- 'software:bmb 0.1.0' ou identificação do curador
  em          TEXT NOT NULL,
  detalhe     TEXT
);

-- Verificação humana: o curador confere a passagem na publicação primária. Só ela leva uma afirmação a 'verificado'.
CREATE TABLE verificacao (
  id                  INTEGER PRIMARY KEY,
  afirmacao_id        INTEGER NOT NULL REFERENCES afirmacao(id),
  referencia_id       INTEGER REFERENCES referencia(id),
  curador             TEXT NOT NULL,
  decisao             TEXT NOT NULL CHECK (decisao IN ('confirmada','corrigida','rejeitada','duvida')),
  passagem_conferida  TEXT,                    -- trecho do artigo que o curador leu (NULL só em 'duvida')
  procedencia_material TEXT,                   -- o que o artigo declara; NULL = o artigo não declara
  voucher             TEXT,                    -- testemunho/depósito do material, se declarado
  sensibilidade       TEXT CHECK (sensibilidade IN ('sem_restricao','restrito','comunitario')),
  nota                TEXT,
  em                  TEXT NOT NULL,
  CHECK (decisao = 'duvida' OR passagem_conferida IS NOT NULL)
);

-- Relação entre moléculas documentada na literatura (ex.: peptídeo de veneno que inspirou um fármaco).
CREATE TABLE relacao_molecula (
  id            INTEGER PRIMARY KEY,
  origem_id     INTEGER NOT NULL REFERENCES molecula(id),
  destino_id    INTEGER NOT NULL REFERENCES molecula(id),
  tipo          TEXT NOT NULL CHECK (tipo IN ('inspirou','derivado_de','mesmo_composto')),
  texto         TEXT NOT NULL,
  referencia_id INTEGER NOT NULL REFERENCES referencia(id),
  estado        TEXT NOT NULL DEFAULT 'candidato'
                  CHECK (estado IN ('candidato','em_revisao','verificado','quarentena','rejeitado')),
  UNIQUE (origem_id, destino_id, tipo),
  CHECK (origem_id <> destino_id)
);

-- Registro das etapas do pipeline (retomável e auditável).
CREATE TABLE etapa (
  nome          TEXT PRIMARY KEY,
  iniciada_em   TEXT NOT NULL,
  concluida_em  TEXT,
  resumo        TEXT                           -- JSON com contagens e exclusões
);

-- Uma afirmação é única pela sua origem: a reconstrução do banco atualiza em vez de duplicar.
CREATE UNIQUE INDEX ux_afirmacao_origem
  ON afirmacao (tipo, IFNULL(taxon_id, 0), molecula_id, IFNULL(alvo_id, 0), origem);

CREATE INDEX ix_afirmacao_taxon ON afirmacao(taxon_id);
CREATE INDEX ix_afirmacao_molecula ON afirmacao(molecula_id);
CREATE INDEX ix_afirmacao_estado ON afirmacao(estado);
CREATE INDEX ix_ocorrencia_taxon ON ocorrencia_uf(taxon_id);
CREATE INDEX ix_evento_entidade ON evento_proveniencia(entidade, entidade_id);

-- Busca de texto completo sobre táxons, nomes populares e moléculas.
CREATE VIRTUAL TABLE busca USING fts5(tipo, ref_id UNINDEXED, texto, tokenize='unicode61 remove_diacritics 2');
