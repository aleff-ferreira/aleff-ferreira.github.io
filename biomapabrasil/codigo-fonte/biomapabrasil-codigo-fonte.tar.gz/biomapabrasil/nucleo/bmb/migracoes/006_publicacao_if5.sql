-- BioMapaBrasil v3.0.0 — Migração 006: Escala de bioma (checklists nacionais DwC-A),
-- classificação biogeográfica explícita (T1–T5), geodésia oficial e benchmark duplo-cego (N >= 360).

-- 1. Universo taxonômico amazônico completo (Flora e Funga do Brasil JBRJ + CTFB Fauna DwC-A)
CREATE TABLE IF NOT EXISTS universo_checklist (
  id                       INTEGER PRIMARY KEY,
  fonte                    TEXT NOT NULL CHECK (fonte IN ('jbrj_flora_funga','ctfb_fauna')),
  taxon_id_fonte           TEXT NOT NULL,
  nome_aceito              TEXT NOT NULL,
  autoria                  TEXT,
  reino                    TEXT NOT NULL,
  filo                     TEXT,
  classe                   TEXT,
  ordem                    TEXT,
  familia                  TEXT,
  genero                   TEXT,
  grupo_bmb                TEXT NOT NULL CHECK (grupo_bmb IN ('planta','fungo','animal_peconhento','animal_outro','outro')),
  status_origem_br         TEXT,
  endemismo_br             TEXT,
  dominios_fitogeograficos TEXT,
  ufs_distribuicao         TEXT,
  bioma_amazonia_declarado INTEGER NOT NULL DEFAULT 0 CHECK (bioma_amazonia_declarado IN (0,1)),
  forma_vida               TEXT,
  substrato_habitat        TEXT,
  sinonimos_json           TEXT,
  tem_quimica_aberta       INTEGER NOT NULL DEFAULT 0 CHECK (tem_quimica_aberta IN (0,1)),
  taxon_id_bmb             INTEGER REFERENCES taxon(id),
  consulta_id              INTEGER NOT NULL REFERENCES consulta(id),
  UNIQUE (fonte, taxon_id_fonte)
);
CREATE INDEX IF NOT EXISTS idx_uc_nome ON universo_checklist(nome_aceito);
CREATE INDEX IF NOT EXISTS idx_uc_amazonia ON universo_checklist(bioma_amazonia_declarado, grupo_bmb, tem_quimica_aberta);

-- 2. Métricas por fonte química, escopo biogeográfico e contagem exata na Amazônia Legal (polígono IBGE)
ALTER TABLE taxon ADD COLUMN compostos_lotus INTEGER;
ALTER TABLE taxon ADD COLUMN compostos_nubbe INTEGER;
ALTER TABLE taxon ADD COLUMN compostos_npatlas INTEGER;
ALTER TABLE taxon ADD COLUMN escopo_biogeografico TEXT
  CHECK (escopo_biogeografico IN (
    'endemica_amazonia_br',
    'endemica_brasil_com_amazonia',
    'nativa_pan_amazonica_neotropical',
    'nativa_ampla_pantropical',
    'introduzida_ou_naturalizada',
    'marginal_extra_amazonica',
    'indeterminado'
  ));
ALTER TABLE taxon ADD COLUMN n_al_exato INTEGER;

-- 3. Classificação explícita de procedência geográfica (T1–T5) por afirmação organismo–molécula
--    Nota: afirmacao.procedencia_material permanece estritamente NULL até leitura humana de artigo
--    primário (invariante P2.procedencia_inventada). A inferência e a leitura estruturada de base ficam em nivel_procedencia.
ALTER TABLE afirmacao ADD COLUMN nivel_procedencia TEXT
  CHECK (nivel_procedencia IN (
    'T1_voucher_amazonia_verificado',
    'T2a_declarada_amazonia_base',
    'T2b_declarada_brasil_extra_amazonia',
    'T3a_endemica_amazonia_br',
    'T3b_nativa_pan_amazonica',
    'T4_pantropical_ou_global_indeterminada',
    'T5_extra_amazonica_confirmada'
  ));
ALTER TABLE afirmacao ADD COLUMN pais_coleta_declarado TEXT;
ALTER TABLE afirmacao ADD COLUMN localidade_declarada TEXT;
ALTER TABLE afirmacao ADD COLUMN voucher_declarado_base TEXT;
ALTER TABLE afirmacao ADD COLUMN validacao_manual_fonte INTEGER CHECK (validacao_manual_fonte IN (0,1));

CREATE INDEX IF NOT EXISTS idx_afirmacao_procedencia ON afirmacao(nivel_procedencia);

-- Padronização da chave de origem do LOTUS antes da reingestão do dump congelado Zenodo
UPDATE afirmacao
SET origem = 'lotus:' || (SELECT m.inchikey FROM molecula m WHERE m.id = afirmacao.molecula_id)
WHERE fonte_id = 'lotus'
  AND tipo = 'composto_em_organismo'
  AND (origem IS NULL OR origem NOT LIKE 'lotus:%')
  AND EXISTS (SELECT 1 FROM molecula m WHERE m.id = afirmacao.molecula_id AND m.inchikey IS NOT NULL)
  AND NOT EXISTS (
    SELECT 1 FROM afirmacao a2
    WHERE a2.id <> afirmacao.id
      AND a2.tipo = afirmacao.tipo
      AND IFNULL(a2.taxon_id, 0) = IFNULL(afirmacao.taxon_id, 0)
      AND a2.molecula_id = afirmacao.molecula_id
      AND IFNULL(a2.alvo_id, 0) = IFNULL(afirmacao.alvo_id, 0)
      AND a2.origem = 'lotus:' || (SELECT m.inchikey FROM molecula m WHERE m.id = afirmacao.molecula_id)
  );

-- 4. Infraestrutura de validação técnica estratificada e revisão duplo-cega (κ de Cohen / AC1 de Gwet)
CREATE TABLE IF NOT EXISTS amostra_benchmark (
  id                INTEGER PRIMARY KEY,
  rodada            TEXT NOT NULL,
  afirmacao_id      INTEGER NOT NULL REFERENCES afirmacao(id),
  estrato           TEXT NOT NULL,
  semente_aleatoria INTEGER NOT NULL,
  amostrado_em      TEXT NOT NULL,
  UNIQUE (rodada, afirmacao_id)
);
CREATE INDEX IF NOT EXISTS idx_benchmark_rodada ON amostra_benchmark(rodada, estrato);

ALTER TABLE verificacao ADD COLUMN rodada_benchmark TEXT;
ALTER TABLE verificacao ADD COLUMN papel_curador TEXT
  CHECK (papel_curador IN ('curador_1','curador_2','adjudicador'));
ALTER TABLE verificacao ADD COLUMN subtipo_decisao TEXT
  CHECK (subtipo_decisao IN (
    'isolamento_primario_confirmado',
    'ensaio_primario_confirmado',
    'citacao_secundaria_ou_revisao',
    'erro_taxonomico_ou_sinonimo',
    'erro_quimico_ou_estrutura',
    'material_extra_amazonico',
    'sintetico_ou_derivado_nao_natural',
    'texto_insuficiente'
  ));
ALTER TABLE verificacao ADD COLUMN acesso_texto TEXT
  CHECK (acesso_texto IN ('texto_completo_aberto','texto_completo_assinatura','apenas_resumo','indisponivel'));
ALTER TABLE verificacao ADD COLUMN escopo_geografico_lido TEXT
  CHECK (escopo_geografico_lido IN ('amazonia_br','pan_amazonia','brasil_extra_amazonia','exterior_nao_amazonico','nao_declarado'));
