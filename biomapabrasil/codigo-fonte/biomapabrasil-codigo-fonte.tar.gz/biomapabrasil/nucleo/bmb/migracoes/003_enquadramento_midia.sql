-- BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
-- Migração 003: ponto focal de saliência (foco_x, foco_y em %) e nota de enquadramento (0..1) em cada imagem.
-- Garante que entradas atuais e futuras ordenem a melhor fotografia em 1.jpg e centralizem miniaturas no organismo.

ALTER TABLE midia ADD COLUMN foco_x REAL CHECK (foco_x IS NULL OR (foco_x >= 0 AND foco_x <= 100));
ALTER TABLE midia ADD COLUMN foco_y REAL CHECK (foco_y IS NULL OR (foco_y >= 0 AND foco_y <= 100));
ALTER TABLE midia ADD COLUMN nota_enquadramento REAL CHECK (nota_enquadramento IS NULL OR (nota_enquadramento >= 0 AND nota_enquadramento <= 1));
