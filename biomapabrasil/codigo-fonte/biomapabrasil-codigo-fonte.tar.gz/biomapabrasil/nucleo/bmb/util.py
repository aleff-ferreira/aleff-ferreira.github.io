# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Funções pequenas e puras usadas por todo o pacote."""
import datetime
import json
import re
import unicodedata


def agora():
    """Instante atual em UTC, ISO 8601, sem frações de segundo."""
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")


def sem_acento(texto):
    decomposto = unicodedata.normalize("NFD", texto or "")
    return "".join(c for c in decomposto if unicodedata.category(c) != "Mn")


def chave_nome(texto):
    """Forma de comparação de nomes: minúsculas, sem acento, só letras e dígitos."""
    return re.sub(r"[^a-z0-9]", "", sem_acento(texto).lower())


def json_compacto(obj):
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"), sort_keys=False)


def plural(n, singular, plural_):
    return singular if n == 1 else plural_


def milhar(n):
    """Inteiro com ponto como separador de milhar (padrão brasileiro)."""
    return f"{n:,}".replace(",", ".")


def numero_legivel(valor):
    """Número de medida em forma curta, sem notação científica nem ruído de ponto flutuante (vírgula decimal)."""
    if valor is None:
        return "—"
    if valor == 0:
        return "0"
    a = abs(valor)
    if a >= 1000:
        return milhar(round(valor))
    if a >= 0.01:
        return f"{valor:.3g}".replace(".", ",")
    return f"{valor:.2e}".replace(".", ",")
