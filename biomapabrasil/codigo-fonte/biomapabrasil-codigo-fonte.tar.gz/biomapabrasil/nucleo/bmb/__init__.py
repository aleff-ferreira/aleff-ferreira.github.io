# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Núcleo de dados do BioMapaBrasil.

Constrói, valida e exporta a base de afirmações verificáveis sobre organismos amazônicos e seus
bioativos. Cada número e cada afirmação carrega fonte, licença e data de consulta.
"""
__version__ = "4.2.0"
