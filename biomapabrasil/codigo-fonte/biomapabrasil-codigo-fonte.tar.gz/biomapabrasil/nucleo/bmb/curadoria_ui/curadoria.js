// BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
// Curadoria: fila de afirmações, leitura da publicação e registro assinado da verificação.
// O token da sessão vem do endereço (#token=...) impresso no terminal ao iniciar o servidor.
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const $ = (s, r = document) => r.querySelector(s);

let token = '';
try {
  const m = location.hash.match(/token=([\w-]+)/);
  if (m) { token = m[1]; sessionStorage.setItem('bmb-cur-token', token); history.replaceState(null, '', location.pathname); }
  else token = sessionStorage.getItem('bmb-cur-token') || '';
} catch { /* sem armazenamento: o token fica só nesta carga */ }

const TIPOS = { composto_em_organismo: 'Composto em organismo', funcao_toxina: 'Função de toxina', atividade_biologica: 'Atividade medida', efeito_clinico_documentado: 'Efeito clínico' };
const PRED = { predominante: 'metade ou mais dos registros brasileiros na Amazônia Legal', nao_predominante: 'registros brasileiros em várias regiões', indeterminado: 'concentração dos registros indeterminada' };
let atual = null, itens = [];

function anunciar(msg) { const v = $('#vivo'); v.textContent = ''; setTimeout(() => { v.textContent = msg; }, 50); }

async function api(caminho, opcoes = {}) {
  const r = await fetch(caminho, { ...opcoes, headers: { 'X-BMB-Token': token, 'Content-Type': 'application/json', ...(opcoes.headers || {}) } });
  const corpo = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(corpo.erro || corpo.detail || `Erro ${r.status}`);
  return corpo;
}

async function estatisticas() {
  try {
    const e = await api('api/estatisticas');
    const p = e.por_estado;
    const regras = Object.entries(e.retidas_por_regra || {}).map(([k, n]) => `${k}: ${n}`).join(' · ');
    $('#estat').textContent = `${p.candidato || 0} de base curada · ${p.em_revisao || 0} em revisão · ${p.verificado || 0} verificadas · ${p.rejeitado || 0} rejeitadas · ${p.quarentena || 0} em quarentena`;
    $('#estat').title = regras ? `Em quarentena, por regra — ${regras}` : '';
  } catch (e) { $('#estat').textContent = ''; }
}

async function carregarFila() {
  const qs = new URLSearchParams({ estado: $('#f-estado').value, limite: 60 });
  if ($('#f-tipo').value) qs.set('tipo', $('#f-tipo').value);
  if ($('#f-papel').value) qs.set('papel_curador', $('#f-papel').value);
  if ($('#f-rodada').value.trim()) qs.set('rodada_benchmark', $('#f-rodada').value.trim());
  if ($('#f-q').value.trim()) qs.set('q', $('#f-q').value.trim());
  try {
    const f = await api(`api/fila?${qs}`);
    itens = f.itens;
    $('#fila-info').textContent = `${f.total} ${f.total === 1 ? 'afirmação' : 'afirmações'}${f.total > itens.length ? `, mostrando as ${itens.length} de maior prioridade` : ''}.`;
    $('#fila').innerHTML = itens.map((i) => `<li><button type="button" class="fila-item" data-id="${i.id}" ${atual === i.id ? 'aria-current="true"' : ''}>
      <span class="t">${esc(i.molecula)}</span>
      <span class="s">${esc(TIPOS[i.tipo] || i.tipo)}${i.taxon ? ` · <em>${esc(i.taxon)}</em> (${esc(PRED[i.predominio] || '')})` : ''} · ${i.n_refs} ${i.n_refs === 1 ? 'publicação' : 'publicações'}</span></button></li>`).join('')
      || '<li class="vazio-estado">Nada na fila com estes filtros.</li>';
  } catch (e) {
    $('#fila-info').textContent = '';
    $('#fila').innerHTML = `<li class="cur-msg erro" role="alert">${esc(e.message)}. Abra a curadoria pelo endereço com #token=… impresso no terminal.</li>`;
  }
}

function refHtml(r) {
  const aut = (r.autores || []).slice(0, 3).join('; ');
  return `<div class="cur-ref" data-ref-box="${r.id}"><span><strong>${esc(r.titulo || 'Título não resolvido')}</strong></span>
    <span class="s">${esc(aut)}${aut ? ' · ' : ''}${esc(r.revista || '')}${r.ano ? ` · ${r.ano}` : ''}${r.retratada ? ' · <strong style="color:var(--argila)">RETRATADA</strong>' : ''}</span>
    <span style="display:flex;gap:.6rem;flex-wrap:wrap;align-items:center">
      ${r.url ? `<a href="${esc(r.url)}" target="_blank" rel="noopener noreferrer">Abrir o artigo (${esc(r.doi ? 'DOI ' + r.doi : 'PMID ' + r.pmid)})</a>` : ''}
      ${(r.doi || r.pmid) ? `<button type="button" class="btn sec" style="padding:.2rem .55rem;font-size:.78rem" data-epmc="${r.id}">Pré-buscar resumo / OA (Europe PMC)</button>` : ''}
    </span>
    <div class="epmc-res" id="epmc-${r.id}"></div></div>`;
}

async function abrir(id) {
  atual = id;
  document.querySelectorAll('.fila-item').forEach((b) => b.toggleAttribute('aria-current', Number(b.dataset.id) === id));
  const alvo = $('#conteudo');
  alvo.innerHTML = '<p class="carregando">Carregando…</p>';
  try {
    const papel = $('#f-papel').value;
    const qsDet = papel ? `?papel_curador=${encodeURIComponent(papel)}` : '';
    const d = await api(`api/afirmacao/${id}${qsDet}`);
    const a = d.afirmacao, m = d.molecula, t = d.taxon, rot = d.rotulos || {};
    const retida = a.estado === 'quarentena';
    alvo.innerHTML = `
      <p><span class="badge ind">${esc(TIPOS[a.tipo] || a.tipo)}</span> <span class="badge ${a.estado === 'verificado' ? 'verif' : 'auto'}">${esc(a.estado)}</span>
        ${rot.evidencia ? `<span class="badge ind">${esc(rot.evidencia)}</span>` : ''}
        ${d.cegamento_ativo ? `<span class="badge verif">revisão independente (${esc(papel)}): o voto do outro curador não aparece</span>` : ''}
        ${d.prontidao ? `<span class="badge ind">prontidão ${d.prontidao.indice}</span>` : ''}</p>
      ${retida ? `<div class="cur-msg erro" role="note"><strong>Retida${a.regra_quarentena ? ` pela regra ${esc(a.regra_quarentena)}` : (a.quarentena_origem === 'curador' ? ' por decisão de curador' : '')}.</strong> ${esc(a.motivo_quarentena || '')}
        ${(d.regras_disparadas || []).length > 1 ? `<br><span class="s">Regras que este registro dispara: ${d.regras_disparadas.map((r) => `${esc(r.codigo)}${r.titulo ? ` (${esc(r.titulo)})` : ''}`).join('; ')}</span>` : ''}</div>` : ''}
      <h3 style="margin:.4rem 0">${esc(m.nome)}</h3>
      <p class="fonte-linha">${m.inchikey ? `InChIKey <span class="mono">${esc(m.inchikey)}</span> · ` : ''}${m.uniprot_acc ? `UniProt ${esc(m.uniprot_acc)} · ` : ''}${m.formula ? esc(m.formula) : ''}</p>
      ${t ? `<p>Organismo: <strong><em>${esc(t.nome)}</em></strong>${a.organismo_na_fonte && a.organismo_na_fonte !== t.nome ? ` · na fonte: <em>${esc(a.organismo_na_fonte)}</em>` : ''} (${esc(rot.distribuicao_br || PRED[t.predominio_al] || '')})</p>
        <p class="fonte-linha">${esc(rot.procedencia || 'Procedência do material ainda não classificada.')}${a.uf_coleta_declarada ? ` UF: ${esc(a.uf_coleta_declarada)}.` : ''}${rot.procedencia_artigo ? ` ${esc(rot.procedencia_artigo)}${a.procedencia_artigo_local ? ` (${esc(a.procedencia_artigo_local)})` : ''}.` : ''}</p>` : '<p class="fonte-linha">Afirmação sobre a molécula isolada, sem organismo.</p>'}
      ${d.alvo ? `<p>Alvo: <strong>${esc(d.alvo.nome)}</strong>${d.alvo.organismo ? ` (${esc(d.alvo.organismo)})` : ''}${d.alvo.natureza && d.alvo.natureza !== 'proteina_unica' ? ` · natureza: ${esc(d.alvo.natureza.replace(/_/g, ' '))}` : ''} · ${esc(a.medida_tipo || '')} ${esc(a.medida_relacao || '')} ${a.medida_valor ?? ''} ${esc(a.medida_unidade || '')}${a.medida_agregacao === 'mediana' ? ` (mediana de ${a.medida_n} medidas em ${a.medida_n_documentos} ${a.medida_n_documentos === 1 ? 'publicação' : 'publicações'}; de ${a.medida_min} a ${a.medida_max} nM)` : (a.medida_agregacao === 'unica' ? ' (uma medida)' : '')}</p>` : ''}
      <p><strong>Enunciado da plataforma:</strong> ${esc(a.texto)}</p>
      ${a.passagem ? `<blockquote class="passagem cur-passagem-maquina">${esc(a.passagem)}<cite>${esc({ curador: 'Trecho conferido por curador', resumo: 'Frase localizada automaticamente no resumo', texto_completo_aberto: 'Frase localizada automaticamente no texto aberto', anotacao_uniprot: 'Anotação do UniProt', mecanismo_chembl: 'Mecanismo registrado no ChEMBL' }[a.passagem_origem] || 'Passagem como veio da base')}</cite></blockquote>` : `<p class="fonte-linha">${a.passagem_origem ? 'Uma frase foi localizada automaticamente na obra citada; o texto não é guardado.' : 'A fonte não traz passagem do artigo (ausência declarada).'}</p>`}
      <h4>Publicações indicadas pela fonte</h4>${d.referencias.map(refHtml).join('') || '<p>Nenhuma.</p>'}
      ${d.verificacoes.length ? `<h4>Verificações anteriores</h4>${d.verificacoes.map((v) => `<div class="cur-ref"><span><strong>${esc(v.decisao)}</strong> por ${esc(v.curador)} em ${esc(v.em.slice(0, 10))}</span>${v.passagem_conferida ? `<span class="s">“${esc(v.passagem_conferida)}”</span>` : ''}${v.nota ? `<span class="s">${esc(v.nota)}</span>` : ''}</div>`).join('')}` : ''}
      ${retida ? '<p class="fonte-linha">Registro retido não recebe verificação: resolva antes o motivo da retenção.</p>' : ''}
      <form id="form" class="cur-form" novalidate ${retida ? 'hidden' : ''}>
        <label>Seu nome (a verificação é assinada)<input type="text" id="c-curador" required minlength="3" autocomplete="name"></label>
        <label>Publicação que você leu<select id="c-ref">${d.referencias.map((r) => `<option value="${r.id}">${esc((r.titulo || r.doi || r.pmid || '').slice(0, 90))}</option>`).join('')}</select></label>
        <fieldset><legend>Decisão</legend>
          <label><input type="radio" name="decisao" value="confirmada"> Confirmada: o artigo sustenta a afirmação como está</label>
          <label><input type="radio" name="decisao" value="corrigida"> Corrigida: sustenta, com ressalva que descrevo na nota</label>
          <label><input type="radio" name="decisao" value="duvida" checked> Em dúvida: preciso de mais leitura</label>
          <label><input type="radio" name="decisao" value="rejeitada"> Rejeitada: o artigo não sustenta (explico na nota)</label></fieldset>
        <label>Trecho do artigo que você leu <span class="ajuda">Citação curta (20 a 600 caracteres), copiada do artigo. Obrigatório para confirmar ou corrigir. Cole a frase que sustenta a afirmação; se ela citar município, comunidade, unidade de conservação ou coordenada, corte esse pedaço.</span>
          <textarea id="c-passagem" maxlength="600"></textarea></label>
        <label>Procedência do material, como o artigo declara <span class="ajuda">Só «País» ou «País: UF», por exemplo «Brasil: AM» ou «Peru». Município, coordenada e nome de comunidade não são registrados. Deixe em branco se o artigo NÃO declara: a ausência fica registrada, nunca é preenchida por dedução.</span>
          <input type="text" id="c-proc" maxlength="40" placeholder="Brasil: AM"></label>
        <label>Testemunho (voucher) ou depósito do material <span class="ajuda">Só o código de coleção: sigla e número (ex.: INPA 22410), se o artigo declara.</span><input type="text" id="c-voucher" maxlength="80"></label>
        <label>Escopo geográfico lido no artigo <select id="c-escopo-geo"><option value="">—</option><option value="amazonia_br">Amazônia brasileira</option><option value="pan_amazonia">Pan-Amazônia (outros países)</option><option value="brasil_extra_amazonia">Brasil fora da Amazônia</option><option value="exterior_nao_amazonico">Exterior fora da Pan-Amazônia</option><option value="nao_declarado">Não declarado no texto</option></select></label>
        <label>Acesso ao texto primário <select id="c-acesso-txt"><option value="">—</option><option value="texto_completo_aberto">Texto completo aberto (OA / PMC)</option><option value="texto_completo_assinatura">Texto completo institucional</option><option value="apenas_resumo">Apenas resumo (abstract)</option><option value="indisponivel">Indisponível</option></select></label>
        <label>Subtipo da decisão (validação por amostragem) <select id="c-subtipo"><option value="">—</option><option value="isolamento_primario_confirmado">Isolamento primário confirmado</option><option value="ensaio_primario_confirmado">Ensaio primário confirmado</option><option value="citacao_secundaria_ou_revisao">Citação secundária / revisão</option><option value="erro_taxonomico_ou_sinonimo">Erro taxonômico / sinônimo</option><option value="erro_quimico_ou_estrutura">Erro químico / estrutura</option><option value="material_extra_amazonico">Material extra-amazônico</option><option value="sintetico_ou_derivado_nao_natural">Sintético / derivado não natural</option><option value="texto_insuficiente">Texto insuficiente</option></select></label>
        <label>Sensibilidade do dado <span class="ajuda">Obrigatório para confirmar ou corrigir. “Comunitário” e “restrito” mantêm o registro fora da exibição pública detalhada.</span>
          <select id="c-sens"><option value="">—</option><option value="sem_restricao">Sem restrição</option><option value="restrito">Restrito (localidade ou espécie sensível)</option><option value="comunitario">Comunitário (conhecimento tradicional associado)</option></select></label>
        <label>Qualidade experimental, pelo método descrito <span class="ajuda">Atende: método e identificação do composto bem descritos (ex.: espectros). Parcial: descritos de forma incompleta.</span>
          <select id="c-qual"><option value="">Não avaliar</option><option value="atende">Atende</option><option value="parcial">Parcial</option><option value="ausente">Ausente</option></select></label>
        <label>Nota <span class="ajuda">Obrigatória ao rejeitar (mínimo de 10 caracteres).</span><textarea id="c-nota" style="min-height:4rem"></textarea></label>
        <div><button type="submit" class="btn">Registrar verificação</button>
          <button type="button" class="btn sec" id="c-quarentena">Mandar para quarentena…</button></div>
        <div id="msg" role="status"></div>
      </form>`;
    try { $('#c-curador').value = localStorage.getItem('bmb-curador') || ''; } catch { /* ignorado */ }
    $('#form').addEventListener('submit', (e) => { e.preventDefault(); enviar(id); });
    $('#c-quarentena').addEventListener('click', () => quarentena(id));
    alvo.querySelectorAll('[data-epmc]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const rid = Number(btn.dataset.epmc);
        const box = $(`#epmc-${rid}`);
        box.innerHTML = '<span class="s">Consultando Europe PMC…</span>';
        try {
          const res = await api(`api/referencia/${rid}/europepmc`);
          if (!res.encontrado) { box.innerHTML = '<span class="s">Não indexado no Europe PMC.</span>'; return; }
          box.innerHTML = `<div class="s" style="margin-top:.35rem;padding:.45rem;border-left:2px solid var(--folha)">
            <strong>${res.acesso_aberto ? 'Open Access' : 'Acesso restrito / resumo'}</strong>${res.pmcid ? ` · ${esc(res.pmcid)}` : ''}${res.licenca ? ` (${esc(res.licenca)})` : ''}
            ${res.url_texto_completo ? ` · <a href="${esc(res.url_texto_completo)}" target="_blank" rel="noopener noreferrer">Texto completo PMC</a>` : ''}
            ${res.url_pdf_oa ? ` · <a href="${esc(res.url_pdf_oa)}" target="_blank" rel="noopener noreferrer">PDF Open Access</a>` : ''}
            ${res.resumo ? `<p style="margin:.35rem 0 0">${esc(res.resumo)}</p>` : '<p style="margin:.35rem 0 0">Sem resumo disponível no Europe PMC.</p>'}
            ${res.trecho_oa ? `<details style="margin-top:.35rem"><summary style="cursor:pointer;font-weight:600">Trecho inicial do corpo XML (PMC Open Access)</summary><p style="margin:.3rem 0 0">${esc(res.trecho_oa)}…</p></details>` : ''}
          </div>`;
        } catch (err) { box.innerHTML = `<span class="s" style="color:var(--argila)">${esc(err.message)}</span>`; }
      });
    });
    $('#detalhe').focus({ preventScroll: true });
    anunciar(`Aberta a afirmação sobre ${m.nome}`);
  } catch (e) { alvo.innerHTML = `<div class="cur-msg erro" role="alert">${esc(e.message)}</div>`; }
}

function mensagem(tipo, texto) { $('#msg').innerHTML = `<p class="cur-msg ${tipo}">${esc(texto)}</p>`; anunciar(texto); }

async function enviar(id) {
  const corpo = {
    afirmacao_id: id, curador: $('#c-curador').value, decisao: document.querySelector('input[name="decisao"]:checked').value,
    papel_curador: $('#f-papel').value || null, rodada_benchmark: $('#f-rodada').value.trim() || null,
    subtipo_decisao: $('#c-subtipo').value || null, acesso_texto: $('#c-acesso-txt').value || null,
    escopo_geografico_lido: $('#c-escopo-geo').value || null,
    referencia_id: $('#c-ref').value ? Number($('#c-ref').value) : null, passagem_conferida: $('#c-passagem').value,
    procedencia_material: $('#c-proc').value, voucher: $('#c-voucher').value, sensibilidade: $('#c-sens').value || null,
    qualidade_experimental: $('#c-qual').value || null, nota: $('#c-nota').value,
  };
  try {
    try { localStorage.setItem('bmb-curador', corpo.curador); } catch { /* ignorado */ }
    const r = await api('api/verificar', { method: 'POST', body: JSON.stringify(corpo) });
    mensagem('ok', `Registrado. Novo estado: ${r.estado}. Índice de prontidão: ${r.indice}.`);
    await Promise.all([carregarFila(), estatisticas()]);
  } catch (e) { mensagem('erro', e.message); }
}

async function quarentena(id) {
  const motivo = prompt('Motivo da quarentena (mínimo de 10 caracteres). A afirmação sai da exibição pública, com o motivo registrado:');
  if (!motivo) return;
  try {
    await api('api/quarentena', { method: 'POST', body: JSON.stringify({ afirmacao_id: id, curador: $('#c-curador').value, motivo }) });
    mensagem('ok', 'Afirmação enviada para quarentena.');
    await Promise.all([carregarFila(), estatisticas()]);
  } catch (e) { mensagem('erro', e.message); }
}

$('#fila').addEventListener('click', (e) => { const b = e.target.closest('[data-id]'); if (b) abrir(Number(b.dataset.id)); });
['f-estado', 'f-tipo', 'f-papel'].forEach((i) => $(`#${i}`).addEventListener('change', () => { carregarFila(); if (atual) abrir(atual); }));
let adiar;
['f-q', 'f-rodada'].forEach((i) => $(`#${i}`).addEventListener('input', () => { clearTimeout(adiar); adiar = setTimeout(carregarFila, 250); }));
$('#filtros').addEventListener('submit', (e) => e.preventDefault());
carregarFila(); estatisticas();
