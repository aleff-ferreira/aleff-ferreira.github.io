# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Rigor quimioinformático, alertas estruturais PAINS, estereoquímica e triagem regulatória por InChIKey.

Mantém toda verificação química ancorada na estrutura (SMILES -> RDKit Mol -> Standard InChIKey de 27
caracteres e bloco de conectividade de 14 caracteres), nunca apenas em nomes triviais.
"""
import re
from pathlib import Path

_CATALOGO_PAINS = None

# Blocos de conectividade InChIKey (14 caracteres, calculados via RDKit MolToInchiKey) de substâncias
# proscritas / entorpecentes / psicotrópicas sob a Portaria SVS/MS nº 344/1998 (Listas A1, A2, E, F1, F2).
BLOCOS_PROSCRITOS_OU_ESTRITOS_344 = {
    "DMULVCHRPCFFGV": ("F2", "DMT (N,N-dimetiltriptamina)"),
    "ZSTKHSQDNIGFLM": ("F2", "5-MeO-DMT"),
    "VTTONGPRPXSUTJ": ("F2", "Bufotenina"),
    "BXNJHAXVSOCGBA": ("E/F2", "Harmina"),
    "RERZNCLIYCABFS": ("E/F2", "Harmalina"),
    "ZXLDQJLIBNPEFJ": ("E/F2", "Tetraidroarmina"),
    "ZPUCINDJVBIVPJ": ("F1", "Cocaína"),
    "PHMBVCPLDPDESM": ("D1/F1", "Ecgonina"),
    "CYQFCXCEBYINGO": ("F2", "Delta-9-THC"),
    "QVDSEJDULKLHCG": ("F2", "Psilocibina"),
    "SPCIYGNTAMCTRO": ("F2", "Psilocina"),
    "RHCSKNNOAZULRK": ("F2", "Mescalina"),
    "BQJCRHHNABKAKU": ("A1", "Morfina"),
    "OROGSEYTTFOCAN": ("A2", "Codeína"),
    "WGASWGVWFWLTOW": ("F2", "Ibogaína"),
    "SHXWCVYOXRDMCX": ("F2", "MDMA"),
    "YCGNOPKWQXVFFQ": ("E", "Salvinorina A"),
}

# Blocos de conectividade InChIKey (14 caracteres, verificados via RDKit) de precursores químicos sujeitos a
# controle (Listas D1/D2 da Portaria SVS/MS nº 344/1998 e controle da Polícia Federal). A ocorrência natural
# em óleos essenciais vegetais é legítima na literatura fitoquímica, mas exige nota regulatória transparente.
PRECURSORES_PORTARIA_344 = {
    "ZMQAAUBTXCXRIC": (
        "Portaria SVS/MS nº 344/1998 — Lista D2 / Polícia Federal: insumo químico precursor sujeito a controle "
        "(safrol). A nota refere-se à substância química isolada, não ao táxon biológico."
    ),
    "VHVOLFRBFDOUSH": (
        "Portaria SVS/MS nº 344/1998 — Lista D1: precursor químico sujeito a controle especial "
        "(isossafrol). A nota refere-se à substância química isolada, não ao táxon biológico."
    ),
    "SATCULPHIDQDRE": (
        "Portaria SVS/MS nº 344/1998 — Lista D1: precursor químico sujeito a controle especial (piperonal)."
    ),
    "USFDJHKKKWEELI": (
        "Portaria SVS/MS nº 344/1998 — Lista D1: precursor químico sujeito a controle especial (ácido lisérgico)."
    ),
    "KWGRBVOPPLSCSI": (
        "Portaria SVS/MS nº 344/1998 — Lista D1: precursor químico sujeito a controle especial (efedrina/pseudoefedrina)."
    ),
}

# Blocos de conectividade InChIKey (14 caracteres) de metabólitos primários ubíquos, vitaminas, hormônios
# endógenos ou insumos/excipientes farmacêuticos simples que atingem max_phase = 4 no ChEMBL, mas NÃO constituem
# metabólitos secundários especializados (como alcaloides, cumarinas ou terpenoides farmacológicos).
_FASE4_UBIQUOS = None


def blocos_fase4_ubiquos(caminho=None):
    """Blocos de conectividade das moléculas em fase 4 que são metabólitos ubíquos, nutrientes, hormônios endógenos,
    minerais ou insumos (lista curada em `semente/fase4_metabolitos_e_insumos.toml`)."""
    global _FASE4_UBIQUOS
    if _FASE4_UBIQUOS is None or caminho is not None:
        import tomllib
        from . import config
        arq = caminho or (config.SEMENTE_DIR / "fase4_metabolitos_e_insumos.toml")
        if not Path(arq).exists():                # instalação sem a pasta de semente (só consulta): nada a classificar
            return frozenset()
        with open(arq, "rb") as f:
            lista = tomllib.load(f).get("substancia", [])
        blocos = frozenset(x["conectividade"].strip().upper() for x in lista if x.get("conectividade"))
        if caminho is not None:
            return blocos
        _FASE4_UBIQUOS = blocos
    return _FASE4_UBIQUOS


_PREFIXO_ESTEREO = re.compile(
    r"^(?P<pref>\(\+\)-|\(-\)-|\(±\)-|\(\+/-\)-|ent-|epi-|(?:\([0-9]*[RSEZ],\s*)*\([0-9]*[RSEZ]\)-|"
    r"alpha-|beta-|α-|β-|cis-|trans-|d-|l-)(?P<resto>.+)$",
    re.IGNORECASE,
)


def limpar_nome_quimico(nome):
    """Remove caracteres substitutos Unicode (U+FFFD) e espaços redundantes de nomes vindos das fontes."""
    if not nome:
        return nome
    limpo = nome.replace("\ufffd", "").strip(" -_,;")
    limpo = re.sub(r"\s+", " ", limpo)
    return limpo or nome.strip()


def preservar_estereo_no_nome(nome_fonte, titulo_pubchem):
    """Evita que um título genérico/racêmico do PubChem apague o prefixo estereoquímico explícito do LOTUS."""
    nf = limpar_nome_quimico(nome_fonte)
    tp = limpar_nome_quimico(titulo_pubchem)
    if not tp:
        return nf
    if not nf:
        return tp
    m = _PREFIXO_ESTEREO.match(nf)
    if not m:
        return tp
    pref = m.group("pref")
    if _PREFIXO_ESTEREO.match(tp) or any(s in tp for s in ("(+)", "(-)", "(R)", "(S)", "ent-", "alpha-", "beta-")):
        return tp
    pref_norm = pref.lower() if pref.lower() in ("ent-", "epi-", "cis-", "trans-", "alpha-", "beta-") else pref
    resto_low = m.group("resto").lower().strip()
    tp_low = tp.lower().strip()
    equivalentes = (
        ("catechol" in resto_low and "catechin" in tp_low)
        or ("epicatechol" in resto_low and "epicatechin" in tp_low)
        or ("kaur-" in resto_low and "kaurenoic" in tp_low)
        or ("pimaradiene" in resto_low and "sandaracopimaradiene" in tp_low)
        or ("copaene" in resto_low and "ylangene" in tp_low)
    )
    if resto_low == tp_low or resto_low.replace("-", "") == tp_low.replace("-", "") or equivalentes:
        return f"{pref_norm}{tp}"
    return tp


def conferir_inchikey(smiles, inchikey_esperado):
    """Confere se `MolFromSmiles(smiles)` gera exatamente o Standard InChIKey de 27 caracteres esperado."""
    if not smiles or not inchikey_esperado:
        return False, None
    from rdkit import Chem, RDLogger
    RDLogger.DisableLog("rdApp.*")
    try:
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return False, None
        calc = Chem.MolToInchiKey(mol)
        return calc == inchikey_esperado, calc
    finally:
        RDLogger.EnableLog("rdApp.*")


def _catalogo_pains():
    global _CATALOGO_PAINS
    if _CATALOGO_PAINS is None:
        from rdkit.Chem import FilterCatalog
        params = FilterCatalog.FilterCatalogParams()
        params.AddCatalog(FilterCatalog.FilterCatalogParams.FilterCatalogs.PAINS_A)
        params.AddCatalog(FilterCatalog.FilterCatalogParams.FilterCatalogs.PAINS_B)
        params.AddCatalog(FilterCatalog.FilterCatalogParams.FilterCatalogs.PAINS_C)
        _CATALOGO_PAINS = FilterCatalog.FilterCatalog(params)
    return _CATALOGO_PAINS


def alertas_pains(smiles):
    """Lista os nomes dos alertas estruturais PAINS (Baell & Holloway, 2010) acionados pelo SMILES."""
    if not smiles:
        return []
    from rdkit import Chem, RDLogger
    RDLogger.DisableLog("rdApp.*")
    try:
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return []
        cat = _catalogo_pains()
        return [e.GetDescription() for e in cat.GetMatches(mol)]
    finally:
        RDLogger.EnableLog("rdApp.*")


def controle_portaria_344(inchikey):
    """Devolve nota regulatória para precursores controlados (Listas D1/D2) ou None."""
    if not inchikey or len(inchikey) < 14:
        return None
    return PRECURSORES_PORTARIA_344.get(inchikey[:14])


def substancia_proscrita_344(inchikey):
    """Devolve `(lista, nome)` se o bloco InChIKey pertencer às listas estritas/proscritas da Portaria 344."""
    if not inchikey or len(inchikey) < 14:
        return None
    return BLOCOS_PROSCRITOS_OU_ESTRITOS_344.get(inchikey[:14])


def classificar_fase4(inchikey, classe_quimica=None):
    """Classifica molécula em fase 4 como `'metabolito_ou_insumo'` (lista curada) ou `'farmaco_secundario'`.

    A classe química não decide: «Amino acids and Peptides › Penicillins» é um antibiótico, não um aminoácido.
    `classe_quimica` permanece na assinatura por compatibilidade.
    """
    if (inchikey or "")[:14] in blocos_fase4_ubiquos():
        return "metabolito_ou_insumo"
    return "farmaco_secundario"


def descritores_de_identidade(smiles):
    """Massas e estereocentros a partir do SMILES: dict ou None quando o SMILES não é legível.

    `massa_monoisotopica` (isótopos mais abundantes; a que um espectrômetro de massas mede) e `massa_media` (pesos
    atômicos padrão) são grandezas diferentes e ficam em colunas diferentes.
    """
    if not smiles:
        return None
    from rdkit import Chem, RDLogger
    from rdkit.Chem import Descriptors
    RDLogger.DisableLog("rdApp.*")
    try:
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return None
        centros = Chem.FindMolChiralCenters(mol, includeUnassigned=True, useLegacyImplementation=False)
        return {"massa_monoisotopica": round(float(Descriptors.ExactMolWt(mol)), 4),
                "massa_media": round(float(Descriptors.MolWt(mol)), 3),
                "estereocentros": len(centros), "estereocentros_indefinidos": sum(1 for _, r in centros if r == "?")}
    finally:
        RDLogger.EnableLog("rdApp.*")


def normalizar_estruturas(con):
    """Preenche, para toda pequena molécula, o bloco de conectividade do InChIKey, as duas massas e a contagem de
    estereocentros. `massa` passa a ser sempre a monoisotópica (antes misturava as duas, conforme a fonte)."""
    con.execute("UPDATE molecula SET inchikey_conectividade=substr(inchikey,1,14) WHERE inchikey IS NOT NULL "
                "AND (inchikey_conectividade IS NULL OR inchikey_conectividade != substr(inchikey,1,14))")
    n = 0
    for m in con.execute("SELECT id, smiles FROM molecula WHERE tipo='pequena_molecula' AND smiles IS NOT NULL "
                         "AND massa_monoisotopica IS NULL").fetchall():
        d = descritores_de_identidade(m["smiles"])
        if d:
            con.execute("UPDATE molecula SET massa_monoisotopica=?, massa_media=?, estereocentros=?, estereocentros_indefinidos=?, "
                        "massa=? WHERE id=?", (d["massa_monoisotopica"], d["massa_media"], d["estereocentros"],
                                               d["estereocentros_indefinidos"], d["massa_monoisotopica"], m["id"]))
            n += 1
    return {"moleculas_normalizadas": n,
            "inchikeys": con.execute("SELECT COUNT(*) FROM molecula WHERE inchikey IS NOT NULL").fetchone()[0],
            "conectividades_2d": con.execute("SELECT COUNT(DISTINCT inchikey_conectividade) FROM molecula WHERE inchikey IS NOT NULL").fetchone()[0]}
