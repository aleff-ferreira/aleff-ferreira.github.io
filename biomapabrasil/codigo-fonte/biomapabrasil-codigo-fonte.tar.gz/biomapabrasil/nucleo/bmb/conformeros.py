"""Ensembles de pequenas moléculas com identidade verificada no arquivo distribuído."""
import hashlib
import json
import math
import os
import tempfile
import zlib
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
from zipfile import BadZipFile
from pathlib import Path
from functools import lru_cache

try:
    from rdkit import Chem, rdBase
    from rdkit.Chem import AllChem, rdCIPLabeler, rdMolAlign, rdMolDescriptors
except ModuleNotFoundError:  # consulta somente leitura na biblioteca padrão (ex.: server.py)
    Chem = rdBase = AllChem = rdCIPLabeler = rdMolAlign = rdMolDescriptors = None

SEED = 20261111
AMOSTRAS = 12
MAX_CONFORMEROS = 6
RMS_MIN = 0.40
FORMATO = "ensemble-sdf-v1"
METODO = "ETKDGv3 (energia MMFF94s)"
REFERENCIAS = ["10.1021/acs.jcim.5b00654", "10.1021/acs.jcim.0c00025", "10.1002/(SICI)1096-987X(199605)17:5/6<490::AID-JCC1>3.0.CO;2-P"]


def verificar(smiles, inchikey):
    if not smiles or not inchikey:
        return None, "identidade_ausente"
    mol = Chem.MolFromSmiles(smiles)
    if mol is None or Chem.MolToInchiKey(mol) != inchikey:
        return None, "identidade_divergente"
    if len(Chem.GetMolFrags(mol)) != 1:
        return None, "multicomponente"
    zs = {a.GetAtomicNum() for a in mol.GetAtoms()}
    if 6 not in zs or zs - {1, 6, 7, 8, 9, 15, 16, 17, 35, 53} or any(a.GetNumRadicalElectrons() for a in mol.GetAtoms()):
        return None, "elementos_ou_radical"
    if not 3 <= mol.GetNumHeavyAtoms() <= 50 or rdMolDescriptors.CalcNumRotatableBonds(mol) > 10:
        return None, "tamanho_ou_flexibilidade"
    if any(len(r) > 8 for r in mol.GetRingInfo().AtomRings()):
        return None, "macrociclo"
    if mol.GetStereoGroups() or any(s.specified != Chem.StereoSpecified.Specified for s in Chem.FindPotentialStereo(mol)):
        return None, "estereoquimica_indefinida"
    if not AllChem.MMFFHasAllMoleculeParams(Chem.AddHs(mol)):
        return None, "sem_parametros_mmff"
    return mol, None


@lru_cache(maxsize=16384)
def limitacao(smiles, inchikey):
    if Chem is None:
        return "sem_pose_publicada"
    with rdBase.BlockLogs():
        return verificar(smiles, inchikey)[1] or "sem_pose_publicada"


def amostrar(grafo, minimizar=False, tempo_fragmento=0):
    """Gera e seleciona candidatos usando apenas o grafo. Nenhuma pose de referência entra aqui."""
    mol = Chem.AddHs(grafo)
    mol.RemoveAllConformers()
    ps = AllChem.ETKDGv3()
    ps.randomSeed = SEED
    ps.enforceChirality = True
    ps.useSmallRingTorsions = True
    ps.pruneRmsThresh = 0.25
    ps.maxIterations = 120
    if hasattr(ps, "timeout"):
        ps.timeout = tempo_fragmento
    elif tempo_fragmento:
        raise ValueError("Esta versão do RDKit não suporta limite por fragmento.")
    ps.numThreads = 1
    AllChem.EmbedMultipleConfs(mol, numConfs=AMOSTRAS, params=ps)
    ids = [conf.GetId() for conf in mol.GetConformers()]
    candidatos = []
    props = AllChem.MMFFGetMoleculeProperties(mol, mmffVariant="MMFF94s")
    for cid in ids:
        campo = AllChem.MMFFGetMoleculeForceField(mol, props, confId=cid)
        if not campo or (minimizar and campo.Minimize(maxIts=500) != 0):
            continue
        energia = campo.CalcEnergy()
        if math.isfinite(energia):
            candidatos.append((energia, cid))
    pesados = Chem.RemoveHs(mol)
    selecionados = []
    for energia, cid in sorted(candidatos):
        if all(rdMolAlign.GetBestAlignmentTransform(pesados, pesados, prbCid=cid, refCid=outro, maxMatches=512)[0] >= RMS_MIN
               for _, outro in selecionados):
            selecionados.append((energia, cid))
            if len(selecionados) == MAX_CONFORMEROS:
                break
    return mol, selecionados


def mesma_identidade(sdf, smiles, chave):
    mol = Chem.MolFromMolBlock(sdf, removeHs=False)
    if mol is None or not mol.GetConformer().Is3D():
        return False
    Chem.AssignStereochemistryFrom3D(mol, replaceExistingTags=True)
    pesado = Chem.RemoveHs(mol)
    return Chem.MolToSmiles(pesado) == smiles and Chem.MolToInchiKey(pesado) == chave


@lru_cache(maxsize=768)
def _conferir_arquivo(arquivo, mtime, tamanho, sha, smiles, chave, mid, fragmento):
    from .conectores.estruturas3d import gerar_sdf_3d, json_canonico_bytes
    from .exportar.ensembles import ler_membro
    try:
        corpo = ler_membro(arquivo, fragmento) if arquivo.suffix == ".zip" else arquivo.read_bytes()
        raw = json.loads(corpo)
        if fragmento and arquivo.suffix != ".zip":
            raw = raw[fragmento]
            corpo = json_canonico_bytes(raw)
        if hashlib.sha256(corpo).hexdigest() != sha:
            return False
        if raw.get("fmt") == FORMATO:
            if raw.get("id") != mid or raw.get("ik") != chave or not raw.get("conformeros"):
                return False
            if raw.get("smiles_sha256") == hashlib.sha256((smiles or "").encode()).hexdigest() or Chem is None:
                return None
            grafo = Chem.MolFromSmiles(smiles) if smiles else None
            return None if grafo is not None and raw.get("smiles") == Chem.MolToSmiles(grafo) else False
        if Chem is None:
            return None
        with rdBase.BlockLogs():
            grafo = Chem.MolFromSmiles(smiles) if smiles else None
            sdf = gerar_sdf_3d(raw)
            if grafo is None or not mesma_identidade(sdf, Chem.MolToSmiles(grafo), chave):
                return False
            mol = Chem.MolFromMolBlock(sdf, removeHs=False)
            Chem.AssignStereochemistryFrom3D(mol, replaceExistingTags=True)
            rdCIPLabeler.AssignCIPLabels(mol)
            def cip(obj):
                return obj.GetProp("_CIPCode") if obj.HasProp("_CIPCode") else None
            return {"atomos": [[a.GetFormalCharge(), a.GetIsAromatic(), cip(a)] for a in mol.GetAtoms()],
                    "ligacoes": [[b.GetIsAromatic(), cip(b), b.IsInRing()] for b in mol.GetBonds()]}
    except (OSError, BadZipFile, EOFError, zlib.error, KeyError, ValueError, TypeError, IndexError, RuntimeError):
        return False


def validar_arquivo(estrutura, molecula, pastas):
    """False retém arquivo incompatível. O legado verificado também recebe atribuições para o inspetor."""
    ref = (estrutura["arquivo_geometria"] or "").removeprefix("dados/")
    if molecula["tipo"] != "pequena_molecula":
        return None
    if not ref:
        return False
    rel, _, fragmento = ref.partition("#")
    if Path(rel).is_absolute() or ".." in Path(rel).parts:
        return False
    from .exportar.ensembles import localizar
    for pasta in pastas:
        arq = Path(pasta) / rel
        membro = fragmento
        if not arq.is_file():
            pacote = localizar(pasta, rel)
            if pacote:
                arq, membro = pacote
        if arq.is_file():
            st = arq.stat()
            return _conferir_arquivo(arq, st.st_mtime_ns, st.st_size, estrutura["geometria_sha256"],
                                    molecula["smiles"], molecula["inchikey"], estrutura["molecula_id"], membro)
    return False


def gerar(tarefa, *, minimizar=False, tempo_fragmento=0):
    mid, nome, smiles, ik, formula = tarefa
    with rdBase.BlockLogs():
        grafo, motivo = verificar(smiles, ik)
        if motivo:
            return None, motivo
        canonico = Chem.MolToSmiles(grafo)
        mol, candidatos = amostrar(grafo, minimizar, tempo_fragmento)
        metodo = "ETKDGv3 / MMFF94s" if minimizar else METODO
        mol.SetProp("_Name", f"BioMapaBrasil {mid}")
        conformeros = []
        for energia, cid in candidatos:
            bloco = Chem.MolToMolBlock(mol, confId=cid)
            if not mesma_identidade(bloco, canonico, ik):
                continue
            numero = len(conformeros) + 1
            props = {"INCHIKEY": ik, "NATUREZA_EPISTEMICA": "conformero_calculado", "SOURCE_DATABASE": "rdkit_local",
                     "METHOD": metodo, "RDKIT_VERSION": rdBase.rdkitVersion, "RANDOM_SEED": SEED, "CONFORMER": numero,
                     "COORDINATE_UNIT": "angstrom", "MMFF94S_ENERGY_KCAL_MOL": f"{energia:.6f}"}
            sdf = bloco + "".join(f">  <{k}>\n{v}\n\n" for k, v in props.items()) + "$$$$\n"
            conformeros.append({"sdf": sdf, "energia": round(energia, 6)})
        if not conformeros:
            return None, "sem_conformero_validado"
        # Descritores do grafo de entrada. A conformação calculada nunca define a identidade do catálogo.
        Chem.AssignStereochemistry(mol, cleanIt=True, force=True)
        rdCIPLabeler.AssignCIPLabels(mol)
        carga_mol = Chem.Mol(mol)
        AllChem.ComputeGasteigerCharges(carga_mol)
        atomos = []
        for at in mol.GetAtoms():
            idx = at.GetIdx()
            carga = carga_mol.GetAtomWithIdx(idx).GetDoubleProp("_GasteigerCharge")
            atomos.append([at.GetSymbol(), at.GetFormalCharge(), at.GetIsAromatic(), at.GetProp("_CIPCode") if at.HasProp("_CIPCode") else None, at.GetIsotope(),
                           round(carga, 6) if math.isfinite(carga) else None])
        kek = Chem.Mol(mol)
        Chem.Kekulize(kek)
        ligacoes = []
        for bd in mol.GetBonds():
            ez = bd.GetProp("_CIPCode") if bd.HasProp("_CIPCode") else None
            ligacoes.append([bd.GetBeginAtomIdx(), bd.GetEndAtomIdx(), int(kek.GetBondWithIdx(bd.GetIdx()).GetBondTypeAsDouble()),
                             bd.GetIsAromatic(), ez, bd.IsInRing()])
        return {"fmt": FORMATO, "id": mid, "ik": ik, "nome": nome, "form": formula, "nat": "conformero_calculado",
                "fonte": "rdkit_local", "cod": f"ensemble-{mid}", "met": metodo, "smiles": canonico, "rdkit": rdBase.rdkitVersion,
                "seed": SEED, "tentativas": AMOSTRAS, "timeout_s": tempo_fragmento, "smiles_sha256": hashlib.sha256(smiles.encode()).hexdigest(), "rms_min_angstrom": RMS_MIN, "max_conformeros": MAX_CONFORMEROS,
                "referencias": REFERENCIAS, "atomos": atomos, "ligacoes": ligacoes, "conformeros": conformeros}, None


def _processar(tarefa, tempo_fragmento):
    try:
        return gerar(tarefa, tempo_fragmento=tempo_fragmento)
    except (ValueError, RuntimeError, OverflowError):
        return None, "falha_rdkit"


def preencher_ausentes(con, pasta, *, limite=None, processos=3, ids=None, tempo_fragmento=0, log=print):
    from .conectores.estruturas3d import _registrar_consulta_rdkit, _upsert_estrutura, json_canonico_bytes
    from .exportar.pacotes import SQL_MOLECULAS_PUBLICAS

    from . import config
    pasta = Path(pasta)
    pastas = (pasta, config.APP_DIR / "dados")
    if processos < 1 or tempo_fragmento < 0 or (limite is not None and limite < 0):
        raise ValueError("Limites inválidos para o cálculo de confôrmeros.")
    existentes = {}
    for row in con.execute(f"""SELECT e.*, m.tipo, m.smiles, m.inchikey FROM estrutura_3d e
                            JOIN molecula m ON e.molecula_id=m.id WHERE m.tipo='pequena_molecula'
                            AND m.id IN ({SQL_MOLECULAS_PUBLICAS})"""):
        existentes.setdefault(row["molecula_id"], {})[row["id"]] = validar_arquivo(row, row, pastas) is not False
    sql = f"""SELECT m.id, m.nome, m.smiles, m.inchikey, m.formula FROM molecula m
              WHERE m.tipo='pequena_molecula' AND m.id IN ({SQL_MOLECULAS_PUBLICAS}) ORDER BY m.id"""
    tarefas = [tuple(r) for r in con.execute(sql) if not any(existentes.get(r["id"], {}).values())]
    if ids is not None:
        escolhidos = set(ids)
        tarefas = [t for t in tarefas if t[0] in escolhidos]
    tarefas.sort(key=lambda t: t[0] in existentes)
    if limite is not None:
        tarefas = tarefas[:limite]
    (pasta / "estruturas3d").mkdir(parents=True, exist_ok=True)
    totais = Counter()
    with ProcessPoolExecutor(max_workers=processos) as pool:
        futuros = (pool.submit(_processar, t, tempo_fragmento) for t in tarefas)
        for i, futuro in enumerate(as_completed(futuros), 1):
            geom, motivo = futuro.result()
            if motivo:
                totais[motivo] += 1
            else:
                mid = geom["id"]
                corpo = json_canonico_bytes(geom)
                sha = hashlib.sha256(corpo).hexdigest()
                arq = f"estruturas3d/ens_{mid}_{sha[:16]}.json"
                # Um leitor só pode encontrar o registro depois que todo o arquivo foi instalado.
                with con:
                    con.execute("BEGIN IMMEDIATE")
                    atual = con.execute("SELECT tipo, smiles, inchikey FROM molecula WHERE id=?", (mid,)).fetchone()
                    if not atual or atual["inchikey"] != geom["ik"] or hashlib.sha256((atual["smiles"] or "").encode()).hexdigest() != geom["smiles_sha256"]:
                        totais["identidade_alterada"] += 1
                        continue
                    registros = con.execute("SELECT * FROM estrutura_3d WHERE molecula_id=?", (mid,))
                    if any(validar_arquivo(r, atual, pastas) is not False for r in registros):
                        totais["ja_existente"] += 1
                        continue
                    with tempfile.NamedTemporaryFile(dir=(pasta / arq).parent, delete=False) as tmp:
                        tmp.write(corpo)
                    os.replace(tmp.name, pasta / arq)
                    cid = _registrar_consulta_rdkit(con, f"rdkit://ensemble/{mid}/{sha}", corpo)
                    _upsert_estrutura(con, molecula_id=mid, natureza=geom["nat"], fonte_id=geom["fonte"], codigo=geom["cod"],
                                      metodo=geom["met"], energia=geom["conformeros"][0]["energia"], n_elem=len(geom["atomos"]),
                                      arquivo=arq, sha256=sha, consulta_id=cid, tem_sdf_3d=1)
                totais["gerados"] += 1
            if i % 500 == 0:
                log(f"{i}/{len(tarefas)} · {dict(totais)}")
    log(json.dumps(totais, ensure_ascii=False, sort_keys=True))
    return dict(totais)
