# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Orçamento de desempenho: confere se o site cabe na meta do dono (400 kbps, 400 ms, Android de entrada).

Mede o que o navegador baixa para mostrar o mapa pela primeira vez e o tamanho dos pacotes que se abrem
depois, com compressão gzip (nível 6, parecido com o de uma hospedagem estática comum; brotli faz melhor).
O tempo estimado soma a transferência a 400 kbps com 400 ms por viagem, supondo seis conexões paralelas.
"""
import gzip
import json
from pathlib import Path

from . import config

KBPS = 400
RTT = 0.4
PARALELAS = 6
# limites em KB comprimidos
ORCAMENTO = {"inicial": 170, "pacote_taxon": 45, "pacote_molecula": 20, "indice_moleculas": 160}
SEGUNDOS_PRIMEIRA_TELA = 8.0


def _gz(caminho):
    return len(gzip.compress(Path(caminho).read_bytes(), compresslevel=6))


def medir(app_dir=None):
    app = Path(app_dir or config.APP_DIR)
    dados = app / "dados"
    arq_idx_boot = (dados / "indice_mapa.json") if (dados / "indice_mapa.json").exists() else (dados / "indice.json")
    inicial = [app / "index.html", app / "css" / "app.css", *sorted((app / "js").glob("*.js")),
               app / "js" / "viz" / "terreno_gl.js", app / "manifest.webmanifest",
               dados / "manifesto.json", arq_idx_boot, dados / "geo" / "ufs.json", dados / "geo" / "relevo_pequeno.webp"]
    inicial = [p for p in inicial if p.exists()]
    # o relevo é WebP (já comprimido): gzip não ajuda; os demais são texto
    tam = {p.relative_to(app).as_posix(): (p.stat().st_size if p.suffix == ".webp" else _gz(p)) for p in inicial}
    total_inicial = sum(tam.values())
    maior = lambda pasta: max(((_gz(p), p.name) for p in (dados / pasta).glob("*.json")), default=(0, "-"))
    taxon = maior("taxa")
    mol = maior("moleculas")
    if mol[0] == 0 and (dados / "moleculas_lotes").exists():
        melhor_b, melhor_k = 0, "-"
        for p in sorted((dados / "moleculas_lotes").glob("*.json")):
            lote = json.loads(p.read_text(encoding="utf-8"))
            for mid, obj in lote.items():
                raw = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
                if len(raw) > melhor_b * 2:
                    gz_b = len(gzip.compress(raw, compresslevel=6))
                    if gz_b > melhor_b:
                        melhor_b, melhor_k = gz_b, f"lote:{p.name}#{mid}"
        mol = (melhor_b, melhor_k)
    idx_mols = _gz(dados / "moleculas_indice.json") if (dados / "moleculas_indice.json").exists() else 0
    n_arquivos = sum(1 for p in app.rglob("*") if p.is_file()) if app.exists() else 0
    bytes_dados = sum(p.stat().st_size for p in dados.rglob("*") if p.is_file()) if dados.exists() else 0
    segundos = total_inicial * 8 / (KBPS * 1000) + RTT * (1 + len(inicial) / PARALELAS)
    return {"inicial": tam, "total_inicial": total_inicial, "pacote_taxon": taxon, "pacote_molecula": mol,
            "indice_moleculas": idx_mols, "segundos_primeira_tela": segundos,
            "n_arquivos_app": n_arquivos, "bytes_dados": bytes_dados}


def relatorio(app_dir=None, imprimir=print):
    m = medir(app_dir)
    kb = lambda b: b / 1024
    imprimir(f"Orçamento de desempenho (gzip, {KBPS} kbps, {RTT * 1000:.0f} ms)")
    for nome, b in sorted(m["inicial"].items(), key=lambda x: -x[1]):
        imprimir(f"  {kb(b):7.1f} KB  {nome}")
    falhas = []
    linhas = [
        ("primeira tela (HTML, CSS, JS, índice, estados, relevo pequeno)", kb(m["total_inicial"]), ORCAMENTO["inicial"]),
        (f"maior pacote de táxon ({m['pacote_taxon'][1]})", kb(m["pacote_taxon"][0]), ORCAMENTO["pacote_taxon"]),
        (f"maior pacote de molécula ({m['pacote_molecula'][1]})", kb(m["pacote_molecula"][0]), ORCAMENTO["pacote_molecula"]),
        ("índice de moléculas (carregado só na busca)", kb(m["indice_moleculas"]), ORCAMENTO["indice_moleculas"]),
    ]
    imprimir("")
    for rotulo, valor, limite in linhas:
        ok = valor <= limite
        imprimir(f"  {'✓' if ok else '✗'} {valor:7.1f} KB de {limite} KB  {rotulo}")
        if not ok:
            falhas.append(rotulo)
    ok_t = m["segundos_primeira_tela"] <= SEGUNDOS_PRIMEIRA_TELA
    imprimir(f"  {'✓' if ok_t else '✗'} primeira tela estimada em {m['segundos_primeira_tela']:.1f} s (limite {SEGUNDOS_PRIMEIRA_TELA:.0f} s)")
    if not ok_t:
        falhas.append("tempo da primeira tela")
    ok_arq = m["n_arquivos_app"] <= 4500
    imprimir(f"  {'✓' if ok_arq else '✗'} arquivos totais em app/: {m['n_arquivos_app']} (limite GitHub Pages: 4500)")
    if not ok_arq:
        falhas.append("contagem de arquivos em app/")
    mb_dados = m["bytes_dados"] / (1024 * 1024)
    ok_mb = mb_dados <= 350.0
    imprimir(f"  {'✓' if ok_mb else '✗'} volume total em app/dados/: {mb_dados:.1f} MB (limite: 350,0 MB)")
    if not ok_mb:
        falhas.append("volume em app/dados/")
    return m, falhas
