# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Projeção da plataforma: Mercator no quadro do Brasil continental, idêntica ao protótipo.

Validada contra os bboxes das UFs do protótipo (AM x=4.8 y=77.4; erro < 0,3%).
"""
import math

LONMIN = -73.9904
LONMAX = -34.7930
LATMAX = 5.2718
K = 1000.0 / (LONMAX - LONMIN)          # 25.5118 px/grau
W = 1000.0
H = 1050.1

def mercdeg(lat):
    return math.degrees(math.log(math.tan(math.pi / 4 + math.radians(lat) / 2)))

_M0 = mercdeg(LATMAX)

def proj(lon, lat):
    """WGS84 -> espaço do mapa (0..1000 x 0..1050.1)."""
    return ((lon - LONMIN) * K, (_M0 - mercdeg(lat)) * K)

def inv(x, y):
    lon = x / K + LONMIN
    m = _M0 - y / K
    lat = math.degrees(2 * math.atan(math.exp(math.radians(m))) - math.pi / 2)
    return (lon, lat)

if __name__ == "__main__":
    # validação rápida contra o bbox do Amazonas no protótipo
    x, y = proj(-73.7995, 2.2450)
    print(f"AM oeste/norte projetado: x={x:.1f} (esperado ~4.8), y={y:.1f} (esperado ~77.4)")
