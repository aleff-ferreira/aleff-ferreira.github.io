# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Cliente HTTP do pipeline: cache em disco, cortesia por servidor e proveniência de cada consulta.

Princípio 1 do projeto: todo número tem fonte consultável e data de consulta. Por isso toda resposta
volta com um `consulta_id`, e a data guardada é a da consulta ORIGINAL, mesmo quando a resposta sai
do cache numa execução posterior.
"""
import datetime
import gzip
import hashlib
import json
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlencode, urlparse

import httpx

from . import config


# Assinatura de um arquivo gzip (bytes 1f 8b).
GZIP_MAGICO = bytes((0x1F, 0x8B))

class ErroDeFonte(RuntimeError):
    """A fonte respondeu com erro que não se resolve repetindo."""


@dataclass
class Resposta:
    url: str
    status: int
    dados: object            # JSON já decodificado, ou texto
    bytes: int
    sha256: str
    consultado_em: str
    do_cache: bool
    fonte: str
    versao_fonte: str | None = None
    consulta_id: int | None = None
    cabecalhos: dict = field(default_factory=dict)

    @property
    def ok(self):
        return 200 <= self.status < 300


def agora_utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")


class Cliente:
    def __init__(self, con=None, cache_dir=None, offline=False, trabalhadores=4):
        self.con = con
        self.cache_dir = Path(cache_dir or config.CACHE_DIR)
        self.offline = offline
        self.trabalhadores = trabalhadores
        self._trava = threading.Lock()
        self._ultimo = {}
        self._http = httpx.Client(
            headers={"User-Agent": config.USER_AGENT, "Accept-Encoding": "gzip"},
            timeout=httpx.Timeout(120.0, connect=25.0), follow_redirects=True)
        self.estatisticas = {"rede": 0, "cache": 0, "falhas": 0}

    # ───────────────────────── cache ─────────────────────────
    @staticmethod
    def _url_final(url, params):
        if not params:
            return url
        itens = params.items() if isinstance(params, dict) else params
        pares = sorted((k, str(v)) for k, v in itens if v is not None)
        return url + ("&" if "?" in url else "?") + urlencode(pares)

    def _arquivos(self, url, accept):
        chave = hashlib.sha256(f"{url}\n{accept}".encode()).hexdigest()
        host = urlparse(url).netloc.replace(":", "_")
        base = self.cache_dir / host / chave[:2]
        return base / f"{chave}.meta.json", base / f"{chave}.corpo.gz"

    def _ler_cache(self, url, accept):
        meta_p, corpo_p = self._arquivos(url, accept)
        if not (meta_p.exists() and corpo_p.exists()):
            return None
        meta = json.loads(meta_p.read_text(encoding="utf-8"))
        return meta, gzip.decompress(corpo_p.read_bytes())

    def _gravar_cache(self, url, accept, meta, corpo):
        meta_p, corpo_p = self._arquivos(url, accept)
        meta_p.parent.mkdir(parents=True, exist_ok=True)
        corpo_p.write_bytes(gzip.compress(corpo, compresslevel=6))
        meta_p.write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")

    # ───────────────────────── cortesia ─────────────────────────
    def _esperar_vez(self, host):
        intervalo = config.INTERVALO_HOST.get(host, config.INTERVALO_PADRAO)
        with self._trava:
            agora = time.monotonic()
            vaga = max(agora, self._ultimo.get(host, 0.0) + intervalo)
            self._ultimo[host] = vaga
        if vaga > agora:
            time.sleep(vaga - agora)

    # ───────────────────────── busca ─────────────────────────
    def _buscar(self, url, params=None, fonte="gbif", accept="application/json", como_json=True,
                cabecalho_versao=None, tentativas=5, aceitar_404=True, usar_cache=True, metodo="GET", como_bytes=False):
        url = self._url_final(url, params)
        chave_cache = f"{metodo}:{url}" if metodo != "GET" else url
        if usar_cache:
            hit = self._ler_cache(chave_cache, accept)
            if hit:
                meta, corpo = hit
                self.estatisticas["cache"] += 1
                return self._montar(url, meta["status"], corpo, meta["consultado_em"], True, fonte, como_json,
                                    meta.get("versao_fonte"), meta.get("cabecalhos", {}), como_bytes=como_bytes)
        if self.offline:
            raise ErroDeFonte(f"modo offline e sem cache para {url}")
        host = urlparse(url).netloc
        ultimo_erro = None
        for tentativa in range(tentativas):
            self._esperar_vez(host)
            try:
                r = self._http.request(metodo, url, headers={"Accept": accept})
            except (httpx.TimeoutException, httpx.TransportError) as e:
                ultimo_erro = f"{type(e).__name__}: {e}"
                time.sleep(min(2 ** tentativa, 30))
                continue
            if r.status_code == 429 or r.status_code >= 500:
                ultimo_erro = f"HTTP {r.status_code}"
                espera = r.headers.get("Retry-After")
                time.sleep(min(float(espera), 60) if espera and espera.isdigit() else min(2 ** (tentativa + 1), 45))
                continue
            if r.status_code == 404 and aceitar_404:
                pass
            elif r.status_code >= 400:
                self.estatisticas["falhas"] += 1
                raise ErroDeFonte(f"HTTP {r.status_code} em {url}")
            corpo = self._desembrulhar(r.content)
            versao = r.headers.get(cabecalho_versao) if cabecalho_versao else None
            meta = {"status": r.status_code, "consultado_em": agora_utc(), "versao_fonte": versao,
                    "cabecalhos": {k: v for k, v in r.headers.items()
                                   if k.lower() in ("x-total-results", "x-uniprot-release", "last-modified", "content-type")}}
            if r.status_code != 404 or aceitar_404:
                self._gravar_cache(chave_cache, accept, meta, corpo)
            self.estatisticas["rede"] += 1
            return self._montar(url, r.status_code, corpo, meta["consultado_em"], False, fonte, como_json,
                                versao, meta["cabecalhos"], como_bytes=como_bytes)
        self.estatisticas["falhas"] += 1
        raise ErroDeFonte(f"esgotadas as tentativas em {url}: {ultimo_erro}")

    @staticmethod
    def _desembrulhar(corpo):
        """O UniProt responde com Content-Encoding: gzip sobre um corpo que já é gzip: sobra uma camada
        depois que o httpx decodifica a primeira. Descomprime enquanto o corpo ainda começar com a
        assinatura gzip (1f 8b), com teto de 3 camadas."""
        for _ in range(3):
            if corpo[:2] != GZIP_MAGICO:
                break
            try:
                corpo = gzip.decompress(corpo)
            except (OSError, EOFError):
                break
        return corpo

    @staticmethod
    def _montar(url, status, corpo, quando, do_cache, fonte, como_json, versao, cabecalhos, como_bytes=False):
        sha = hashlib.sha256(corpo).hexdigest()
        if como_bytes:
            dados = corpo
        elif como_json and corpo[:1] in (b"{", b"["):
            dados = json.loads(corpo.decode("utf-8"))
        else:
            dados = corpo.decode("utf-8", errors="replace")
        return Resposta(url=url, status=status, dados=dados, bytes=len(corpo), sha256=sha,
                        consultado_em=quando, do_cache=do_cache, fonte=fonte, versao_fonte=versao,
                        cabecalhos=cabecalhos)

    # ───────────────────────── proveniência ─────────────────────────
    def registrar(self, resp):
        """Grava a consulta no banco e devolve o id. Idempotente por (url, sha256)."""
        if resp.consulta_id is not None or self.con is None:
            return resp.consulta_id
        self.con.execute(
            "INSERT OR IGNORE INTO consulta (fonte_id, url, consultado_em, status, bytes, sha256, versao_fonte) "
            "VALUES (?,?,?,?,?,?,?)",
            (resp.fonte, resp.url, resp.consultado_em, resp.status, resp.bytes, resp.sha256, resp.versao_fonte))
        resp.consulta_id = self.con.execute(
            "SELECT id FROM consulta WHERE url=? AND sha256=?", (resp.url, resp.sha256)).fetchone()[0]
        return resp.consulta_id

    # ───────────────────────── API pública ─────────────────────────
    def get(self, url, params=None, fonte="gbif", **kw):
        resp = self._buscar(url, params, fonte, **kw)
        self.registrar(resp)
        return resp

    def post(self, url, params=None, fonte="gbif", **kw):
        resp = self._buscar(url, params, fonte, metodo="POST", **kw)
        self.registrar(resp)
        return resp

    def get_varios(self, pedidos, fonte="gbif", ignorar_erros=False, **kw):
        """pedidos: lista de (url, params). Busca em paralelo limitado; registra na ordem, no fio principal."""
        def _um(p):
            try:
                return self._buscar(p[0], p[1], fonte, **kw)
            except ErroDeFonte:
                if ignorar_erros:
                    return None
                raise

        with ThreadPoolExecutor(max_workers=self.trabalhadores) as ex:
            respostas = list(ex.map(_um, pedidos))
        for r in respostas:
            if r is not None:
                self.registrar(r)
        return respostas

    def baixar(self, url, fonte="gbif", max_bytes=8_000_000, tentativas=2):
        """Baixa um arquivo de imagem SEM guardá-lo no cache em disco (ocuparia gigabytes). A consulta
        (URL, data, tamanho, hash) é registrada; `dados` volta em bytes. Recusa tipo não-imagem e excesso."""
        if self.offline:
            raise ErroDeFonte(f"modo offline: não baixa {url}")
        host = urlparse(url).netloc
        ultimo_erro = None
        for tentativa in range(tentativas):
            self._esperar_vez(host)
            try:
                with self._http.stream("GET", url, headers={"Accept": "image/*"}) as r:
                    if r.status_code >= 400:
                        raise ErroDeFonte(f"HTTP {r.status_code} em {url}")
                    tipo = r.headers.get("content-type", "")
                    if not tipo.startswith("image/"):
                        raise ErroDeFonte(f"tipo inesperado ({tipo or 'ausente'}) em {url}")
                    partes, total = [], 0
                    for bloco in r.iter_bytes():
                        total += len(bloco)
                        if total > max_bytes:
                            raise ErroDeFonte(f"arquivo acima de {max_bytes} bytes em {url}")
                        partes.append(bloco)
                    corpo, status = b"".join(partes), r.status_code
            except (httpx.TimeoutException, httpx.TransportError) as e:
                ultimo_erro = f"{type(e).__name__}: {e}"
                time.sleep(min(2 ** tentativa, 10))
                continue
            resp = Resposta(url=url, status=status, dados=corpo, bytes=len(corpo), sha256=hashlib.sha256(corpo).hexdigest(),
                            consultado_em=agora_utc(), do_cache=False, fonte=fonte)
            self.registrar(resp)
            self.estatisticas["rede"] += 1
            return resp
        self.estatisticas["falhas"] += 1
        raise ErroDeFonte(f"esgotadas as tentativas em {url}: {ultimo_erro}")

    def fechar(self):
        self._http.close()
