# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Mídia: miniaturas das imagens licenciadas, enquadramento por saliência e desenho das estruturas químicas.

Imagens (Princípio 3): só entram fotos com licença CC0 ou CC BY legível por máquina, com autor e
página de origem. A miniatura (720 px máx., JPEG progressivo) serve a meta de desempenho (400 kbps);
o arquivo original nunca é redistribuído, e a atribuição vai junto em todo uso. Cada imagem recebe
um ponto focal óptico `(foco_x, foco_y)` e uma `nota_enquadramento` para promover automaticamente a
fotografia mais bem composta a `1.jpg` (capa do dossiê e miniatura nas listas) em entradas atuais e futuras.

Estruturas: desenhadas localmente com RDKit a partir do SMILES, em preto e branco (nada depende de
cor) e com `currentColor`, para que o tema claro ou escuro do site governe o traço.
"""
import hashlib
import io
import math
import re
from pathlib import Path

from . import config
from .conectores import gbif, wikimedia_reflora
from .http import ErroDeFonte

MINIATURA_LADO_MAX = 640
MINIATURA_QUALIDADE = 72
IMAGENS_POR_TAXON = 3
LIMITE_GALERIA_COMPLETA = 80
CANDIDATAS_POR_TAXON = 6


# ═══════════════════════════ estruturas químicas ═══════════════════════════
_RE_ESTILO_PADRAO = re.compile(
    r";?(?:stroke-linecap:butt|stroke-linejoin:miter|stroke-opacity:1|fill-opacity:1|stroke-miterlimit:10)\b"
)
_RE_PATH_RDKIT = re.compile(r"<path d='(M[^']*)' (class='bmb\d+'|fill='currentColor')\s*/>\s*")
_RE_CHAIN_POLY = re.compile(r"L([0-9.]+,[0-9.]+)M\1L")


def desenhar_estrutura(smiles, nome, largura=320, altura=240):
    """SVG da estrutura 2D, ou None se o SMILES não for válido."""
    from rdkit import Chem
    from rdkit.Chem.Draw import rdMolDraw2D
    mol = Chem.MolFromSmiles(smiles) if smiles else None
    if mol is None:
        return None
    d = rdMolDraw2D.MolDraw2DSVG(largura, altura)
    o = d.drawOptions()
    o.clearBackground = False
    o.useBWAtomPalette()
    o.bondLineWidth = 1.6
    o.padding = 0.07
    d.DrawMolecule(mol)
    d.FinishDrawing()
    svg = d.GetDrawingText()
    svg = svg.replace("#000000", "currentColor")
    rotulo = (nome or "composto").replace("&", "e").replace("<", "").replace(">", "").replace('"', "'")[:140]
    # acessibilidade: o SVG é uma imagem com nome
    svg = re.sub(r"<svg ", f'<svg role="img" aria-label="Estrutura química de {rotulo}" ', svg, count=1)
    # remove o cabeçalho XML (o SVG vai inline na página)
    svg = re.sub(r"<\?xml[^>]*\?>\s*", "", svg)
    return compactar_svg(svg)


def compactar_svg(svg):
    """Encolhe o SVG do RDKit sem mudar o desenho: tira o cabeçalho verboso e as classes de átomo e ligação,
    troca o `style` repetido em cada traço por poucas classes (`bmb*`) e funde `<path>` consecutivos da mesma classe."""
    svg = re.sub(r"\s+xmlns:rdkit='[^']*'|\s+xmlns:xlink='[^']*'|\s+xml:space='preserve'|\s+version='1.1'|\s+baseProfile='full'", "", svg)
    svg = re.sub(r"\s+width='[0-9.]+px'\s+height='[0-9.]+px'", "", svg)        # o tamanho vem do CSS; o viewBox fica
    svg = svg.replace("<!-- END OF HEADER -->", "")
    svg = re.sub(r" class='[^']*'", "", svg)
    estilos = {}

    def troca(m):
        corpo = _RE_ESTILO_PADRAO.sub("", m.group(1)).strip(";")
        if corpo not in estilos:
            estilos[corpo] = f"bmb{len(estilos)}"
        return f" class='{estilos[corpo]}'"

    svg = re.sub(r" style='([^']*)'", troca, svg)
    regras = "".join(f".{c}{{{e}}}" for e, c in estilos.items())
    if regras:
        svg = svg.replace(">", f"><style>{regras}</style>", 1)                    # o primeiro '>' fecha a abertura de <svg>
    svg = re.sub(r"\s{2,}", " ", svg).replace(">\n<", "><").replace("> <", "><").strip()
    def _emitir_path(attr_p, ds_p):
        d_join = "".join(ds_p)
        ant = None
        while ant != d_join:
            ant = d_join
            d_join = _RE_CHAIN_POLY.sub(r"L\1L", d_join)
        return f"<path {attr_p} d='{d_join}'/>"

    # Se todos os filhos do <svg> após </style> forem <path> do RDKit, agrupa globalmente por atributo
    # mantendo os glifos de átomos (`fill='currentColor'`) sempre no topo da pilha visual.
    partes, pos, attr_atual, ds_atuais = [], 0, None, []
    for m in _RE_PATH_RDKIT.finditer(svg):
        if m.start() != pos:
            if attr_atual:
                partes.append(_emitir_path(attr_atual, ds_atuais))
                attr_atual, ds_atuais = None, []
            partes.append(svg[pos:m.start()])
        dd = re.sub(r"\s*([MLQCZ,])\s*", r"\1", m.group(1)).strip()
        dd = re.sub(r"\s+", " ", dd)
        at = m.group(2)
        if at == attr_atual:
            ds_atuais.append(dd)
        else:
            if attr_atual:
                partes.append(_emitir_path(attr_atual, ds_atuais))
            attr_atual, ds_atuais = at, [dd]
        pos = m.end()
    if attr_atual:
        partes.append(_emitir_path(attr_atual, ds_atuais))
    partes.append(svg[pos:])
    saida = "".join(partes).strip()

    # Funde também grupos não-adjacentes da mesma classe bmbX (preservando glifos fill='currentColor' ao final)
    re_emitido = re.compile(r"<path (class='bmb\d+'|fill='currentColor') d='([^']*)'/>")
    if "</style>" in saida and saida.endswith("</svg>"):
        cab, corpo_svg = saida.split("</style>", 1)
        interior = corpo_svg[:-6]
        restante = re_emitido.sub("", interior).strip()
        if not restante:
            ordem_attrs: list[str] = []
            por_attr: dict[str, list[str]] = {}
            for me in re_emitido.finditer(interior):
                ak, dv = me.group(1), me.group(2)
                if ak not in por_attr:
                    ordem_attrs.append(ak)
                    por_attr[ak] = []
                por_attr[ak].append(dv)
            # Garante `fill='currentColor'` por último (acima de ligações e cunhas)
            ordem_attrs.sort(key=lambda x: 1 if x.startswith("fill=") else 0)
            fundidos = [_emitir_path(ak, por_attr[ak]) for ak in ordem_attrs]
            saida = f"{cab}</style>{''.join(fundidos)}</svg>"
    return saida


def desenhar_todas(con, log):
    import json
    import shutil
    pasta_lotes = config.SAIDA_DIR / "estruturas_lotes"
    if pasta_lotes.exists():
        shutil.rmtree(pasta_lotes)
    pasta_lotes.mkdir(parents=True, exist_ok=True)
    pasta_legado = config.SAIDA_DIR / "estruturas"
    if pasta_legado.exists():
        shutil.rmtree(pasta_legado)
    mols = con.execute("SELECT id, nome, inchikey, smiles FROM molecula WHERE tipo='pequena_molecula' AND smiles IS NOT NULL ORDER BY id").fetchall()
    n = invalidas = 0
    lotes = {f"{b:02x}": {} for b in range(256)}
    atualizacoes = []
    for m in mols:
        svg = desenhar_estrutura(m["smiles"], m["nome"])
        if svg is None:
            invalidas += 1
            continue
        ik = m["inchikey"]
        bucket = hashlib.sha1(ik.encode("ascii")).hexdigest()[:2]
        lotes[bucket][ik] = svg
        atualizacoes.append((f"estruturas_lotes/{bucket}.json#{ik}", m["id"]))
        n += 1
        if n % 2500 == 0:
            log(f"    {n}/{len(mols)} estruturas")
    for bucket, d in lotes.items():
        if d:
            (pasta_lotes / f"{bucket}.json").write_text(
                json.dumps(d, ensure_ascii=False, separators=(",", ":"), sort_keys=True),
                encoding="utf-8",
            )
    if atualizacoes:
        con.executemany("UPDATE molecula SET desenho=? WHERE id=?", atualizacoes)
    con.commit()
    log(f"  estruturas desenhadas em 256 lotes: {n}; SMILES inválidos: {invalidas}")
    return {"desenhadas": n, "invalidas": invalidas, "lotes": sum(1 for d in lotes.values() if d)}


# ═══════════════════════════ enquadramento e imagens ═══════════════════════════
def _variante_media(url):
    """O iNaturalist serve variantes dimensionadas; `large` (1024 px) evita baixar originais enormes
    sem degradar fotos verticais como `medium` (500 px)."""
    return re.sub(r"/original\.(jpe?g|png)$", r"/large.\1", url, flags=re.IGNORECASE)


def _tem_barra_captura(lum, g):
    """Detecta barras retas artificiais (capturas de tela de celular com faixas pretas/brancas e degrau abrupto)."""
    # Varredura horizontal (topo e base)
    for intervalo in (range(3, g // 4), range(g - 4, g - g // 4, -1)):
        faixa_plana = 0
        passo = 1 if intervalo.step > 0 else -1
        for y in intervalo:
            uniformes = degrau = 0
            y_adj = y + passo
            for x in range(g):
                l0 = lum[y * g + x]
                l1 = lum[y_adj * g + x]
                if l0 < 8 or l0 > 249:
                    uniformes += 1
                if abs(l1 - l0) >= 14:
                    degrau += 1
            if uniformes >= int(g * 0.88):
                faixa_plana += 1
                if faixa_plana >= 3 and degrau >= int(g * 0.72):
                    return True
            else:
                break
    # Varredura vertical (laterais esquerda e direita)
    for intervalo in (range(3, g // 4), range(g - 4, g - g // 4, -1)):
        faixa_plana = 0
        passo = 1 if intervalo.step > 0 else -1
        for x in intervalo:
            uniformes = degrau = 0
            x_adj = x + passo
            for y in range(g):
                l0 = lum[y * g + x]
                l1 = lum[y * g + x_adj]
                if l0 < 8 or l0 > 249:
                    uniformes += 1
                if abs(l1 - l0) >= 14:
                    degrau += 1
            if uniformes >= int(g * 0.88):
                faixa_plana += 1
                if faixa_plana >= 3 and degrau >= int(g * 0.72):
                    return True
            else:
                break
    return False


def analisar_enquadramento(im):
    """Calcula o ponto focal óptico `(foco_x, foco_y)` em % (0..100) e a `nota` de composição (0..1).

    Combina energia de nitidez multi-escala (regiões em foco óptico superam bokeh desfocado),
    contraste cromático em relação ao perímetro da imagem e penalização de áreas estouradas,
    sombras totalmente vazias, tiras excessivamente estreitas e barras de captura de tela.
    """
    from PIL import Image, ImageFilter
    w, h = im.size
    if w <= 0 or h <= 0:
        return {"foco_x": 50.0, "foco_y": 46.0, "nota": 0.5, "barra_artificial": False}
    g = 96
    peq = im.convert("RGB").resize((g, g), Image.Resampling.BILINEAR)
    l_im = peq.convert("L")
    b2 = l_im.filter(ImageFilter.BoxBlur(2))
    b5 = l_im.filter(ImageFilter.BoxBlur(5))
    rgb = peq.tobytes()
    lum = l_im.tobytes()
    bl2 = b2.tobytes()
    bl5 = b5.tobytes()

    borda_rg, borda_by = [], []
    for y in range(g):
        for x in range(g):
            if x < 6 or x >= g - 6 or y < 6 or y >= g - 6:
                idx = (y * g + x) * 3
                r, gr, b = rgb[idx], rgb[idx + 1], rgb[idx + 2]
                borda_rg.append(r - gr)
                borda_by.append(0.5 * (r + gr) - b)
    borda_rg.sort()
    borda_by.sort()
    m_rg = borda_rg[len(borda_rg) // 2] if borda_rg else 0.0
    m_by = borda_by[len(borda_by) // 2] if borda_by else 0.0

    barra_art = _tem_barra_captura(lum, g)
    sal = [0.0] * (g * g)
    det_vals = [0.0] * (g * g)
    escuras = estouradas = marca_borda = 0

    for y in range(g):
        ny = (y + 0.5) / g
        for x in range(g):
            nx = (x + 0.5) / g
            i = y * g + x
            idx = i * 3
            r, gr, b = rgb[idx], rgb[idx + 1], rgb[idx + 2]
            l_val = lum[i]
            sat = max(r, gr, b) - min(r, gr, b)
            if l_val < 14:
                escuras += 1
            elif l_val > 248 and sat < 14:
                estouradas += 1
            det = abs(l_val - bl2[i]) + 0.55 * abs(l_val - bl5[i])
            if (y < int(g * 0.11) or y >= int(g * 0.86)) and l_val > 228 and sat < 22 and abs(l_val - bl2[i]) > 38:
                marca_borda += 1
            croma = math.hypot((r - gr) - m_rg, (0.5 * (r + gr) - b) - m_by)
            prior = 0.76 + 0.24 * math.exp(-((nx - 0.50) ** 2 + (ny - 0.44) ** 2) / 0.24)
            peso = 1.0
            if l_val < 14 or (l_val > 248 and sat < 14):
                peso *= 0.06
            if x < 4 or x >= g - 4 or y < 4 or y >= g - 4:
                peso *= 0.35
            sal[i] = ((det + 0.8) ** 1.42) * (1.0 + 0.011 * croma) * prior * peso
            det_vals[i] = det

    ordenado = sorted(sal)
    p80 = ordenado[int(len(ordenado) * 0.80)]
    sx = sy = sw = det_top = n_top = 0.0
    if p80 > 1e-3 and (ordenado[-1] - ordenado[0]) > 1e-2:
        for y in range(g):
            for x in range(g):
                i = y * g + x
                s = sal[i]
                if s >= p80:
                    wt = max(1e-4, s - p80 * 0.85) ** 1.3
                    sx += (x + 0.5) / g * 100.0 * wt
                    sy += (y + 0.5) / g * 100.0 * wt
                    sw += wt
                    det_top += det_vals[i]
                    n_top += 1
    fx = max(14.0, min(86.0, sx / sw)) if sw > 0 else 50.0
    fy = max(14.0, min(86.0, sy / sw)) if sw > 0 else 46.0

    prop = w / max(h, 1)
    if 0.80 <= prop <= 1.85:
        s_prop = 1.0
    elif 0.62 <= prop < 0.80:
        s_prop = 0.72 + (prop - 0.62) / 0.18 * 0.28
    elif prop < 0.62:
        s_prop = max(0.32, (prop / 0.62) * 0.68)
    else:
        s_prop = max(0.45, 1.0 - (prop - 1.85) * 0.35)

    s_res = min(1.0, min(w, h) / 380.0)
    tot = g * g
    nit_media = (det_top / max(n_top, 1)) if n_top > 0 else 0.0
    # Fotografias macro noturnas legítimas (herpetofauna/artrópodes com flash em mata) têm fundo escuro natural,
    # mas sujeito nítido em primeiro plano: não devem ser rebaixadas atrás de carcaças diurnas em estrada.
    limiar_escuro = 0.64 if (nit_media >= 11.5 and n_top >= 0.06 * tot and prop >= 0.72) else 0.22
    vazio = max(0.0, escuras / tot - limiar_escuro) + max(0.0, estouradas / tot - 0.22)
    s_exp = max(0.25, 1.0 - vazio * 1.15)
    s_nit = min(1.0, nit_media / 14.0) if n_top > 0 else 0.35
    dist = math.hypot((fx - 50.0) / 50.0, (fy - 46.0) / 50.0)
    s_comp = max(0.55, 1.0 - max(0.0, dist - 0.22) * 0.55)
    nota = 0.34 * s_prop + 0.20 * s_res + 0.22 * s_exp + 0.14 * s_nit + 0.10 * s_comp
    marca_dagua = (marca_borda / max(1, int(tot * 0.25))) >= 0.068
    if barra_art:
        nota *= 0.68
    if marca_dagua:
        nota *= 0.62
    return {"foco_x": round(fx, 1), "foco_y": round(fy, 1), "nota": round(max(0.0, min(1.0, nota)), 3),
            "barra_artificial": barra_art, "marca_dagua": marca_dagua}


def _processar_imagem(bytes_):
    """Gera a miniatura JPEG progressiva e analisa o enquadramento em uma única leitura."""
    from PIL import Image, ImageOps
    with Image.open(io.BytesIO(bytes_)) as im:
        im = ImageOps.exif_transpose(im)
        if im.mode not in ("RGB", "L"):
            im = im.convert("RGB")
        im.thumbnail((MINIATURA_LADO_MAX, MINIATURA_LADO_MAX), Image.Resampling.LANCZOS)
        rgb = im.convert("RGB")
        enq = analisar_enquadramento(rgb)
        saida = io.BytesIO()
        rgb.save(saida, "JPEG", quality=MINIATURA_QUALIDADE, optimize=True, progressive=True)
        return saida.getvalue(), rgb.width, rgb.height, enq


def _miniatura(bytes_):
    dados, w, h, _ = _processar_imagem(bytes_)
    return dados, w, h


def _ordenar_e_gravar_taxon(con, taxon_id, gbif_key, pasta_base, max_arquivos=None):
    """Ordena as imagens baixadas de um táxon por `nota_enquadramento` decrescente para que `1.jpg`
    seja sempre a fotografia mais nítida e bem enquadrada."""
    linhas = [dict(r) for r in con.execute(
        "SELECT * FROM midia WHERE taxon_id=? AND estado='ativo' AND arquivo IS NOT NULL ORDER BY id", (taxon_id,)).fetchall()]
    if not linhas:
        return 0
    pasta_raiz = Path(pasta_base)
    carregadas = []
    for r in linhas:
        caminho = pasta_raiz.parent / r["arquivo"] if r["arquivo"].startswith("imagens/") else pasta_raiz / r["arquivo"]
        if not caminho.exists():
            continue
        bruto = caminho.read_bytes()
        if r.get("foco_x") is None or r.get("foco_y") is None or r.get("nota_enquadramento") is None:
            from PIL import Image
            with Image.open(io.BytesIO(bruto)) as im:
                enq = analisar_enquadramento(im)
            r["foco_x"], r["foco_y"], r["nota_enquadramento"] = enq["foco_x"], enq["foco_y"], enq["nota"]
            r["largura"], r["altura"] = im.width, im.height
        carregadas.append((r, bruto))
    if not carregadas:
        return 0

    carregadas.sort(key=lambda par: (-(par[0].get("nota_enquadramento") or 0.0), par[0]["id"]))
    mantidas = carregadas[:max_arquivos] if max_arquivos else carregadas
    excedentes = carregadas[max_arquivos:] if max_arquivos else []
    pasta_taxon = pasta_raiz / str(gbif_key)
    pasta_taxon.mkdir(parents=True, exist_ok=True)
    # Remove arquivos excedentes (p.ex. 3.jpg antigo quando uma imagem foi para quarentena ou fora da cota de galeria)
    for antigo in pasta_taxon.glob("*.jpg"):
        antigo.unlink(missing_ok=True)
    for idx, (r, bruto) in enumerate(mantidas, start=1):
        arq = pasta_taxon / f"{idx}.jpg"
        arq.write_bytes(bruto)
        sha = hashlib.sha256(bruto).hexdigest()
        rel = f"imagens/{gbif_key}/{idx}.jpg"
        con.execute(
            "UPDATE midia SET arquivo=?, arquivo_sha256=?, largura=?, altura=?, foco_x=?, foco_y=?, nota_enquadramento=? WHERE id=?",
            (rel, sha, r["largura"], r["altura"], r["foco_x"], r["foco_y"], r["nota_enquadramento"], r["id"]))
    for r, _ in excedentes:
        con.execute("UPDATE midia SET arquivo=NULL, arquivo_sha256=NULL WHERE id=?", (r["id"],))
    return len(mantidas)


def reavaliar_imagens(con, pasta_imagens=None, log=print):
    """Analisa foco e composição de todas as imagens locais já registradas e promove a melhor a `1.jpg`."""
    if pasta_imagens is None:
        padrao = config.SAIDA_DIR / "imagens"
        pasta_imagens = padrao if padrao.exists() else (config.APP_DIR / "dados" / "imagens")
    pasta_imagens = Path(pasta_imagens)
    if not pasta_imagens.exists():
        return {"taxons": 0, "imagens": 0}
    taxa = con.execute(
        "SELECT DISTINCT t.id, t.gbif_key FROM taxon t JOIN midia m ON m.taxon_id=t.id WHERE m.arquivo IS NOT NULL ORDER BY t.id"
    ).fetchall()
    n_img = 0
    for t in taxa:
        n_img += _ordenar_e_gravar_taxon(con, t["id"], t["gbif_key"], pasta_imagens)
    con.commit()
    log(f"  enquadramento reavaliado: {n_img} imagens em {len(taxa)} táxons")
    return {"taxons": len(taxa), "imagens": n_img}


def baixar_imagens(con, cli, log, limite_novos_dwca=260):
    pasta_base = config.SAIDA_DIR / "imagens"
    taxa = con.execute(
        "SELECT id, gbif_key, nome, origem_inclusao, "
        "(COALESCE(compostos_incluidos, 0) + COALESCE(toxinas_fonte, 0)) AS n_mols, COALESCE(n_al, 0) AS n_al "
        "FROM taxon WHERE no_recorte=1 "
        "ORDER BY CASE WHEN origem_inclusao LIKE 'catalogo_nacional%' THEN 1 ELSE 0 END ASC, n_mols DESC, n_al DESC, nome ASC"
    ).fetchall()
    n_taxa = n_baixadas = n_falhas = n_sem = n_dwca_com_img = 0
    for idx_t, t in enumerate(taxa):
        eh_dwca = str(t["origem_inclusao"] or "").startswith("catalogo_nacional")
        meta_taxon = IMAGENS_POR_TAXON if (not eh_dwca and idx_t < LIMITE_GALERIA_COMPLETA) else 1
        ja = con.execute("SELECT COUNT(*) FROM midia WHERE taxon_id=? AND estado='ativo' AND arquivo IS NOT NULL", (t["id"],)).fetchone()[0]
        if ja >= meta_taxon:
            _ordenar_e_gravar_taxon(con, t["id"], t["gbif_key"], pasta_base, max_arquivos=meta_taxon)
            if eh_dwca:
                n_dwca_com_img += 1
            continue
        if eh_dwca and n_dwca_com_img >= limite_novos_dwca:
            continue
        try:
            candidatas = gbif.imagens(cli, t["gbif_key"], 3 if eh_dwca else CANDIDATAS_POR_TAXON)
        except ErroDeFonte:
            candidatas = []
        if len(candidatas) < meta_taxon:
            sins = [r["nome"] for r in con.execute("SELECT nome FROM taxon_sinonimo WHERE taxon_id=?", (t["id"],)).fetchall()]
            extras = wikimedia_reflora.imagens_commons(cli, [t["nome"]] + sins[:2], meta_taxon - len(candidatas) + 2)
            urls_ja = {c["url"] for c in candidatas}
            for ex in extras:
                if ex["url"] not in urls_ja:
                    candidatas.append(ex)
                    urls_ja.add(ex["url"])
        if not candidatas:
            n_sem += 1
            continue
        n_taxa += 1
        pasta = pasta_base / str(t["gbif_key"])
        pasta.mkdir(parents=True, exist_ok=True)
        novas = []
        faltam = meta_taxon - ja
        for c in candidatas:
            existente = con.execute("SELECT id, arquivo, estado FROM midia WHERE taxon_id=? AND url=?", (t["id"], c["url"])).fetchone()
            if existente and (existente["arquivo"] or existente["estado"] == "quarentena"):
                continue
            try:
                fonte_dl = "wikimedia_commons" if c.get("base_registro") == "WIKIMEDIA_COMMONS" else "gbif"
                r = cli.baixar(_variante_media(c["url"]), fonte_dl)
                miniatura, w, h, enq = _processar_imagem(r.dados)
            except (ErroDeFonte, OSError, ValueError) as exc:
                n_falhas += 1
                log(f"    ✗ {t['nome']}: {str(exc)[:110]}")
                continue
            novas.append((enq["nota"], c, existente, miniatura, w, h, enq))
            boas = sum(1 for item in novas if item[0] >= 0.82 and not item[6]["barra_artificial"])
            if boas >= faltam and len(novas) >= faltam + (0 if eh_dwca else 1):
                break

        novas.sort(key=lambda item: -item[0])
        ordem = ja
        for _, c, existente, miniatura, w, h, enq in novas[:faltam]:
            arq = pasta / f"{ordem + 1}.jpg"
            arq.write_bytes(miniatura)
            sha = hashlib.sha256(miniatura).hexdigest()
            rel = f"imagens/{t['gbif_key']}/{ordem + 1}.jpg"
            if existente:
                con.execute(
                    "UPDATE midia SET arquivo=?, arquivo_sha256=?, largura=?, altura=?, foco_x=?, foco_y=?, nota_enquadramento=?, pais=COALESCE(?, pais) WHERE id=?",
                    (rel, sha, w, h, enq["foco_x"], enq["foco_y"], enq["nota"], c.get("pais"), existente["id"]))
            else:
                con.execute(
                    "INSERT INTO midia (taxon_id, url, pagina, licenca, autor, instituicao, gbif_ocorrencia, base_registro, "
                    "arquivo, arquivo_sha256, largura, altura, foco_x, foco_y, nota_enquadramento, pais, consulta_id) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (t["id"], c["url"], c["pagina"], c["licenca"], c["autor"], c["instituicao"], c["gbif_ocorrencia"],
                     c["base_registro"], rel, sha, w, h, enq["foco_x"], enq["foco_y"], enq["nota"], c.get("pais"), c["consulta_id"]))
            ordem += 1
            n_baixadas += 1
        if eh_dwca and novas:
            n_dwca_com_img += 1
        _ordenar_e_gravar_taxon(con, t["id"], t["gbif_key"], pasta_base, max_arquivos=meta_taxon)
        con.commit()
        if n_taxa % 20 == 0:
            log(f"    {n_taxa} táxons com imagem · {n_baixadas} miniaturas")
    con.commit()
    log(f"  imagens: {n_baixadas} miniaturas em {n_taxa} táxons; sem imagem licenciada: {n_sem}; falhas: {n_falhas}")
    return {"miniaturas": n_baixadas, "taxons_com_imagem": n_taxa, "taxons_sem_imagem_licenciada": n_sem, "falhas": n_falhas}


def executar(con, cli, log=print, imagens=True, estruturas=True, so_reavaliar=False):
    resumo = {}
    if so_reavaliar:
        log("▸ reavaliação óptica de enquadramento das imagens locais")
        resumo["enquadramento"] = reavaliar_imagens(con, log=log)
        return resumo
    if estruturas:
        log("▸ estruturas químicas (RDKit)")
        resumo["estruturas"] = desenhar_todas(con, log)
    if imagens:
        log("▸ imagens licenciadas (CC0 / CC BY)")
        resumo["imagens"] = baixar_imagens(con, cli, log)
    return resumo
