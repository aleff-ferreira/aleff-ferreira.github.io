# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Descritores físico-químicos RDKit, esqueletos de Murcko, NP-likeness e espaço químico determinístico.

Calcula para cada pequena molécula:
  * `cLogP`, `TPSA`, `Fsp3`, `HBD`, `HBA`, `QED` (Bickerton et al., 2012) e `MurckoScaffold` (Bemis & Murcko, 1996);
  * escore de semelhança a produto natural (`NP-likeness`, Ertl et al., 2008 via RDKit Contrib ou aproximação analítica);
  * projeção 2D determinística (`umap_x`, `umap_y`, `seed=20261111`) sobre impressões digitais circulares Morgan ECFP4
    (`2048` bits, raio 2, similaridade de Tanimoto) com inicialização espectral laplaciana e refinamento UMAP atrativo/repulsivo;
  * árvore geradora mínima (TMAP; Probst & Reymond, 2020) conectando vizinhos estruturais mais próximos.
"""
from pathlib import Path
import numpy as np

SEMENTE_ESPACO = 20261111
_NPSCORER = "nao_inicializado"


def _obter_npscorer():
    global _NPSCORER
    if _NPSCORER != "nao_inicializado":
        return _NPSCORER
    try:
        import sys
        from rdkit import RDConfig
        pasta = Path(RDConfig.RDContribDir) / "NP_Score"
        if (pasta / "npscorer.py").exists():
            if str(pasta) not in sys.path:
                sys.path.insert(0, str(pasta))
            import npscorer  # type: ignore
            _NPSCORER = (npscorer, npscorer.readNPModel())
            return _NPSCORER
    except Exception:
        pass
    _NPSCORER = None
    return None


def _np_likeness_analitico(mol, fsp3):
    """Fallback estrutural calibrado nas feições de Ertl et al. (2008) caso RDKit Contrib não esteja presente."""
    from rdkit.Chem import rdMolDescriptors
    n_pesados = max(mol.GetNumHeavyAtoms(), 1)
    quirais = len(rdMolDescriptors.CalcChiralCenters(mol, includeUnassigned=True))
    espiro = rdMolDescriptors.CalcNumSpiroAtoms(mol)
    ponte = rdMolDescriptors.CalcNumBridgeheadAtoms(mol)
    aneis_alif = rdMolDescriptors.CalcNumAliphaticRings(mol)
    oxigenios = sum(1 for a in mol.GetAtoms() if a.GetAtomicNum() == 8)
    nitro_halog_s = sum(1 for a in mol.GetAtoms() if a.GetAtomicNum() in (9, 16, 17, 35, 53))
    aromaticos_n = sum(1 for a in mol.GetAtoms() if a.GetAtomicNum() == 7 and a.GetIsAromatic())
    score = (
        -0.85
        + 1.75 * float(fsp3)
        + 2.8 * min(quirais / n_pesados, 0.35)
        + 0.22 * min(aneis_alif, 5)
        + 0.35 * min(espiro + ponte, 3)
        + 1.4 * min(oxigenios / n_pesados, 0.40)
        - 0.45 * min(nitro_halog_s, 4)
        - 0.28 * min(aromaticos_n, 4)
    )
    return round(float(max(-3.5, min(3.5, score))), 3)


def calcular_descritores_rdkit(smiles):
    """Calcula descritores físico-químicos e esqueleto de Bemis-Murcko a partir de um SMILES."""
    if not smiles:
        return None
    from rdkit import Chem, RDLogger
    from rdkit.Chem import Descriptors, QED, rdMolDescriptors
    from rdkit.Chem.Scaffolds import MurckoScaffold

    RDLogger.DisableLog("rdApp.*")
    try:
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return None
        clogp = round(float(Descriptors.MolLogP(mol)), 3)
        tpsa = round(float(rdMolDescriptors.CalcTPSA(mol)), 2)
        fsp3 = round(float(rdMolDescriptors.CalcFractionCSP3(mol)), 3)
        hbd = int(rdMolDescriptors.CalcNumHBD(mol))
        hba = int(rdMolDescriptors.CalcNumHBA(mol))
        qed_val = round(float(QED.qed(mol)), 3)

        nps = _obter_npscorer()
        if nps is not None:
            np_val = round(float(nps[0].scoreMol(mol, nps[1])), 3)
        else:
            np_val = _np_likeness_analitico(mol, fsp3)

        murcko = None
        try:
            scaf = MurckoScaffold.GetScaffoldForMol(mol)
            if scaf is not None and scaf.GetNumHeavyAtoms() >= 3:
                murcko = Chem.MolToSmiles(scaf, isomericSmiles=False)
        except Exception:
            murcko = None

        return {
            "clogp": clogp,
            "tpsa": tpsa,
            "fsp3": fsp3,
            "hbd": hbd,
            "hba": hba,
            "qed": qed_val,
            "np_likeness": np_val,
            "murcko_smiles": murcko,
        }
    finally:
        RDLogger.EnableLog("rdApp.*")


def _construir_grafo_tanimoto(moleculas, k_vizinhos=14):
    """Constrói grafo k-NN simétrico (ECFP4 Tanimoto), conecta componentes e gera a árvore geradora mínima (TMAP)."""
    from rdkit import Chem, DataStructs, RDLogger
    from rdkit.Chem import rdFingerprintGenerator
    from scipy import sparse
    from scipy.sparse.csgraph import connected_components, minimum_spanning_tree

    RDLogger.DisableLog("rdApp.*")
    ids, fps = [], []
    try:
        gen = rdFingerprintGenerator.GetMorganGenerator(radius=2, fpSize=2048)
        for mid, smi in moleculas:
            if not smi:
                continue
            mol = Chem.MolFromSmiles(smi)
            if mol is None:
                continue
            ids.append(int(mid))
            fps.append(gen.GetFingerprint(mol))
    finally:
        RDLogger.EnableLog("rdApp.*")

    n = len(ids)
    if n < 2:
        return ids, None, []

    k = min(k_vizinhos, n - 1)
    linhas_w, cols_w, sims_w = [], [], []
    linhas_d, cols_d, dists_d = [], [], []

    # 1. Grafo k-NN exato de similaridade de Tanimoto em C++ via BulkTanimotoSimilarity
    for i in range(n):
        sims = np.asarray(DataStructs.BulkTanimotoSimilarity(fps[i], fps), dtype=np.float32)
        sims[i] = -1.0
        idx_top = np.argpartition(-sims, k)[:k]
        idx_top = idx_top[np.argsort(-sims[idx_top])]
        for j in idx_top:
            s = float(max(0.0, sims[j]))
            linhas_w.append(i)
            cols_w.append(int(j))
            sims_w.append(max(s, 0.02))
            linhas_d.append(i)
            cols_d.append(int(j))
            dists_d.append(max(1e-4, 1.0 - s))

    # Garante conectividade global ligando componentes conexos pelo par de maior Tanimoto
    W = sparse.csr_matrix((sims_w, (linhas_w, cols_w)), shape=(n, n), dtype=np.float32)
    W = W.maximum(W.T)
    D_sym = sparse.coo_matrix((
        np.concatenate([dists_d, dists_d]),
        (np.concatenate([linhas_d, cols_d]), np.concatenate([cols_d, linhas_d]))
    ), shape=(n, n), dtype=np.float32).tocsr()

    n_comp, rotulos = connected_components(W, directed=False)
    if n_comp > 1:
        # Ordena componentes do maior para o menor e encontra a ponte real de maior Tanimoto entre componentes
        ordem_comp = sorted(range(n_comp), key=lambda c: -int(np.sum(rotulos == c)))
        membros_acumulados = list(np.where(rotulos == ordem_comp[0])[0].astype(int))
        extra_r, extra_c, extra_w, extra_d = [], [], [], []
        for ci in ordem_comp[1:]:
            idxs_ci = np.where(rotulos == ci)[0].astype(int)
            # Amostra determinística de até 24 membros do componente menor contra todos os já conectados
            passo_am = max(1, len(idxs_ci) // 24)
            cand_ci = idxs_ci[::passo_am][:24]
            fps_alvo = [fps[m] for m in membros_acumulados]
            melhor_s, melhor_u, melhor_v = -1.0, int(idxs_ci[0]), int(membros_acumulados[0])
            for u_cand in cand_ci:
                sims_c = DataStructs.BulkTanimotoSimilarity(fps[int(u_cand)], fps_alvo)
                j_best = int(np.argmax(sims_c))
                if sims_c[j_best] > melhor_s:
                    melhor_s = float(sims_c[j_best])
                    melhor_u = int(u_cand)
                    melhor_v = int(membros_acumulados[j_best])
            s_ponte = float(max(0.01, melhor_s))
            extra_r.extend([melhor_u, melhor_v])
            extra_c.extend([melhor_v, melhor_u])
            extra_w.extend([s_ponte, s_ponte])
            extra_d.extend([1.0 - s_ponte, 1.0 - s_ponte])
            membros_acumulados.extend(int(x) for x in idxs_ci)
        W = (W + sparse.csr_matrix((extra_w, (extra_r, extra_c)), shape=(n, n), dtype=np.float32)).tocsr()
        D_sym = (D_sym + sparse.csr_matrix((extra_d, (extra_r, extra_c)), shape=(n, n), dtype=np.float32)).tocsr()

    # 2. TMAP: Árvore Geradora Mínima sobre distância de Tanimoto
    mst = minimum_spanning_tree(D_sym).tocoo()
    arestas_tmap = []
    for u, v, d in zip(mst.row, mst.col, mst.data):
        if int(u) != int(v):
            sim = round(float(max(0.0, min(1.0, 1.0 - d))), 3)
            arestas_tmap.append((ids[int(u)], ids[int(v)], sim))

    return ids, W, arestas_tmap


def projetar_espaco_e_tmap(moleculas, k_vizinhos=14, epocas=160, semente=SEMENTE_ESPACO):
    """Recebe lista de `(id, smiles)` e devolve `(coords_por_id, arestas_tmap)`.

    `coords_por_id`: `{mol_id: (x, y)}` em `[-1, 1]`, 100% determinístico (`semente=20261111`).
    `arestas_tmap`: lista de `(id_a, id_b, similaridade_tanimoto)` formando a árvore geradora mínima (TMAP).
    """
    from scipy import sparse
    from scipy.sparse.linalg import eigsh

    ids, W, arestas_tmap = _construir_grafo_tanimoto(moleculas, k_vizinhos=k_vizinhos)
    n = len(ids)
    if n == 0:
        return {}, []
    if n == 1:
        return {ids[0]: (0.0, 0.0)}, []

    # 3. Inicialização espectral determinística do Laplaciano normalizado + refinamento UMAP
    rng = np.random.default_rng(semente)
    graus = np.asarray(W.sum(axis=1)).ravel()
    inv_raiz = 1.0 / np.sqrt(np.maximum(graus, 1e-8))
    D_inv = sparse.diags(inv_raiz)
    L_norm = sparse.eye(n, dtype=np.float32) - (D_inv @ W @ D_inv)

    try:
        if n >= 6:
            v0 = rng.standard_normal(n).astype(np.float32)
            vals, vecs = eigsh(L_norm, k=3, which="SM", v0=v0, tol=1e-3, maxiter=400)
            ordem = np.argsort(vals)
            Y = vecs[:, ordem[1:3]].astype(np.float32)
            # Fixa orientação canônica de sinal dos autovetores para determinismo estrito entre plataformas
            for col in range(2):
                imax = int(np.argmax(np.abs(Y[:, col])))
                if Y[imax, col] < 0:
                    Y[:, col] = -Y[:, col]
        else:
            raise ValueError("n pequeno")
    except Exception:
        ang = np.linspace(0, 2 * np.pi, n, endpoint=False, dtype=np.float32)
        Y = np.stack([np.cos(ang), np.sin(ang)], axis=1)

    desvio = np.std(Y, axis=0, keepdims=True)
    Y = (Y / np.maximum(desvio, 1e-6)) * 2.2 + rng.normal(0.0, 0.03, size=Y.shape).astype(np.float32)

    coo = W.tocoo()
    mask_pos = coo.row < coo.col
    src = coo.row[mask_pos].astype(np.int32)
    dst = coo.col[mask_pos].astype(np.int32)
    pesos = np.power(np.clip(coo.data[mask_pos], 0.02, 1.0), 0.75).astype(np.float32)

    a_umap, b_umap = 1.58, 0.90
    n_arestas = len(src)
    lote = min(16384, max(512, n_arestas))
    epocas_efetivas = min(epocas, 110) if n > 5000 else epocas

    for ep in range(epocas_efetivas):
        lr = float(1.0 * (1.0 - ep / epocas_efetivas) + 0.04)
        perm = rng.permutation(n_arestas)
        for ini in range(0, n_arestas, lote):
            fatia = perm[ini:ini + lote]
            u = src[fatia]
            v = dst[fatia]
            w = pesos[fatia][:, None]

            # Força atrativa nos pares k-NN similares
            diff = Y[u] - Y[v]
            dist2 = np.sum(diff * diff, axis=1, keepdims=True) + 1e-4
            grad_atr = (-2.0 * a_umap * b_umap * np.power(dist2, b_umap - 1.0) / (1.0 + a_umap * np.power(dist2, b_umap))) * w * diff
            grad_atr = np.clip(grad_atr, -4.0, 4.0) * lr * 0.45
            np.add.at(Y, u, grad_atr)
            np.add.at(Y, v, -grad_atr)

            # Amostragem negativa repulsiva (3 negativos por aresta)
            for _ in range(3):
                neg = rng.integers(0, n, size=len(u), dtype=np.int32)
                diff_n = Y[u] - Y[neg]
                dist2_n = np.sum(diff_n * diff_n, axis=1, keepdims=True) + 0.05
                grad_rep = (2.0 * b_umap / ((0.12 + dist2_n) * (1.0 + a_umap * np.power(dist2_n, b_umap)))) * diff_n
                grad_rep = np.clip(grad_rep, -4.0, 4.0) * lr * 0.14
                np.add.at(Y, u, grad_rep)

    # Normalização robusta centrada no percentil 1..99 com leve compressão tangente hiperbólica nos extremos
    centro = np.median(Y, axis=0, keepdims=True)
    Y = Y - centro
    escala = np.percentile(np.abs(Y), 98.5, axis=0, keepdims=True)
    Y = Y / np.maximum(escala, 1e-5)
    Y = np.tanh(Y * 1.15) / float(np.tanh(1.15))
    Y = np.clip(Y, -1.0, 1.0)

    coords = {ids[i]: (round(float(Y[i, 0]), 5), round(float(Y[i, 1]), 5)) for i in range(n)}
    return coords, arestas_tmap


def atualizar_banco(con, log=print):
    """Preenche descritores RDKit faltantes e recalcula o espaço químico determinístico das pequenas moléculas."""
    pendentes = con.execute(
        "SELECT id, smiles FROM molecula WHERE tipo='pequena_molecula' AND smiles IS NOT NULL AND clogp IS NULL"
    ).fetchall()
    if pendentes:
        log(f"  RDKit descritores + Murcko: {len(pendentes)} moléculas…")
        for i, m in enumerate(pendentes, 1):
            desc = calcular_descritores_rdkit(m["smiles"])
            if desc:
                con.execute(
                    "UPDATE molecula SET clogp=?, tpsa=?, fsp3=?, hbd=?, hba=?, qed=?, np_likeness=?, murcko_smiles=? WHERE id=?",
                    (desc["clogp"], desc["tpsa"], desc["fsp3"], desc["hbd"], desc["hba"],
                     desc["qed"], desc["np_likeness"], desc["murcko_smiles"], m["id"]),
                )
            if i % 1000 == 0:
                con.commit()
        con.commit()

    todas = con.execute(
        "SELECT id, smiles FROM molecula WHERE tipo='pequena_molecula' AND smiles IS NOT NULL ORDER BY id"
    ).fetchall()
    log(f"  Espaço químico Morgan ECFP4 + TMAP: projetando {len(todas)} moléculas (seed={SEMENTE_ESPACO})…")
    coords, arestas_tmap = projetar_espaco_e_tmap([(r["id"], r["smiles"]) for r in todas])
    con.executemany(
        "UPDATE molecula SET umap_x=?, umap_y=? WHERE id=?",
        [(xy[0], xy[1], mid) for mid, xy in coords.items()],
    )
    con.commit()
    return {"moleculas_projetadas": len(coords), "arestas_tmap": len(arestas_tmap), "arestas": arestas_tmap}


def calcular_arestas_tmap(con, destino_json=None, k_vizinhos=14):
    """Recalcula apenas a árvore geradora mínima (TMAP) das pequenas moléculas e, opcionalmente, grava JSON compacto."""
    import json
    from pathlib import Path

    todas = con.execute(
        "SELECT id, smiles FROM molecula WHERE tipo='pequena_molecula' AND smiles IS NOT NULL ORDER BY id"
    ).fetchall()
    _, _, arestas_tmap = _construir_grafo_tanimoto([(r["id"], r["smiles"]) for r in todas], k_vizinhos=k_vizinhos)
    if destino_json:
        dest = Path(destino_json)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(json.dumps([list(e) for e in arestas_tmap], ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    return arestas_tmap
