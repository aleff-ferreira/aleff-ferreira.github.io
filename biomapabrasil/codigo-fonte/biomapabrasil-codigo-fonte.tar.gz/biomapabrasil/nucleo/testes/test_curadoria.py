# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
import pytest

from bmb import config, curadoria, validar


def test_semente_verificacoes_curador_valida_e_sem_localidade_fina():
    import tomllib

    arq = config.SEMENTE_DIR / "verificacoes_curador.toml"
    assert arq.is_file()
    entradas = tomllib.loads(arq.read_text(encoding="utf-8")).get("verificacao", [])
    assert len(entradas) >= 30
    for ent in entradas:
        assert ent["curador"] and len(ent["curador"]) >= 3
        assert ent["decisao"] in curadoria.DECISOES
        assert ent["sensibilidade"] in curadoria.SENSIBILIDADES
        passagem = ent["passagem_conferida"]
        assert 20 <= len(passagem) <= curadoria.LIMITE_TRECHO
        assert curadoria.localidade_fina(passagem) is None, passagem
        assert not validar.PALAVRAS_EFICACIA.search(passagem), passagem


def test_aplicar_semente_verificacoes_idempotente(mini, tmp_path):
    con = mini.con
    semente = tmp_path / "verificacoes.toml"
    semente.write_text('''
[[verificacao]]
taxon_gbif_key = 100
molecula_inchikey = "RYYVLZVUVIJVGH-UHFFFAOYSA-N"
fonte_id = "lotus"
doi = "10.1000/abc"
curador = "Curadoria Teste"
decisao = "confirmada"
sensibilidade = "sem_restricao"
qualidade_experimental = "atende"
subtipo_decisao = "isolamento_primario_confirmado"
acesso_texto = "apenas_resumo"
escopo_geografico_lido = "nao_declarado"
passagem_conferida = "Caffeine was isolated and identified cleanly from the seeds extract."
nota = "Conferência de teste."
''', encoding="utf-8")

    r1 = curadoria.aplicar_semente_verificacoes(con, caminho=semente, log=lambda *_: None)
    assert r1 == {"aplicadas": 1, "ja_existentes": 0, "ignoradas": 0}
    af = con.execute("SELECT estado, nivel_evidencia, passagem_origem FROM afirmacao WHERE id=?", (mini.af_composto,)).fetchone()
    assert tuple(af) == ("verificado", "curador", "curador")

    # Segunda execução é 100% idempotente
    r2 = curadoria.aplicar_semente_verificacoes(con, caminho=semente, log=lambda *_: None)
    assert r2 == {"aplicadas": 0, "ja_existentes": 1, "ignoradas": 0}
    assert con.execute("SELECT COUNT(*) FROM verificacao WHERE afirmacao_id=?", (mini.af_composto,)).fetchone()[0] == 1


def test_aplicar_semente_recusa_localidade_fina(mini, tmp_path):
    con = mini.con
    semente = tmp_path / "verif_local.toml"
    semente.write_text('''
[[verificacao]]
taxon_gbif_key = 100
molecula_inchikey = "RYYVLZVUVIJVGH-UHFFFAOYSA-N"
fonte_id = "lotus"
doi = "10.1000/abc"
curador = "Curadoria Teste"
decisao = "confirmada"
sensibilidade = "sem_restricao"
passagem_conferida = "Caffeine was collected in Manaus Municipality at 3°06' S."
''', encoding="utf-8")
    with pytest.raises(curadoria.ErroDeLocalidade):
        curadoria.aplicar_semente_verificacoes(con, caminho=semente, log=lambda *_: None)
