# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
import pytest

from bmb import config, curadoria, validar


def test_semente_verificacoes_curador_valida_e_sem_localidade_fina():
    import tomllib

    arq = config.SEMENTE_DIR / "verificacoes_curador.toml"
    assert arq.is_file()
    entradas = tomllib.loads(arq.read_text(encoding="utf-8")).get("verificacao", [])
    assert len(entradas) >= 30
    for ent in entradas:
        assert ent["curador"] and len(ent["curador"]) >= 3
        assert ent["decisao"] in curadoria.DECISOES
        assert ent["sensibilidade"] in curadoria.SENSIBILIDADES
        passagem = ent["passagem_conferida"]
        assert 20 <= len(passagem) <= curadoria.LIMITE_TRECHO
        assert curadoria.localidade_fina(passagem) is None, passagem
        assert not validar.PALAVRAS_EFICACIA.search(passagem), passagem


def test_aplicar_semente_verificacoes_idempotente(mini, tmp_path):
    con = mini.con
    semente = tmp_path / "verificacoes.toml"
    semente.write_text('''
[[verificacao]]
taxon_gbif_key = 100
molecula_inchikey = "RYYVLZVUVIJVGH-UHFFFAOYSA-N"
fonte_id = "lotus"
doi = "10.1000/abc"
curador = "Curadoria Teste"
decisao = "confirmada"
sensibilidade = "sem_restricao"
qualidade_experimental = "atende"
subtipo_decisao = "isolamento_primario_confirmado"
acesso_texto = "apenas_resumo"
escopo_geografico_lido = "nao_declarado"
passagem_conferida = "Caffeine was isolated and identified cleanly from the seeds extract."
nota = "Conferência de teste."
''', encoding="utf-8")

    r1 = curadoria.aplicar_semente_verificacoes(con, caminho=semente, log=lambda *_: None)
    assert r1 == {"aplicadas": 1, "ja_existentes": 0, "ignoradas": 0}
    af = con.execute("SELECT estado, nivel_evidencia, passagem_origem FROM afirmacao WHERE id=?", (mini.af_composto,)).fetchone()
    assert tuple(af) == ("verificado", "curador", "curador")

    # Segunda execução é 100% idempotente
    r2 = curadoria.aplicar_semente_verificacoes(con, caminho=semente, log=lambda *_: None)
    assert r2 == {"aplicadas": 0, "ja_existentes": 1, "ignoradas": 0}
    assert con.execute("SELECT COUNT(*) FROM verificacao WHERE afirmacao_id=?", (mini.af_composto,)).fetchone()[0] == 1


def test_aplicar_semente_recusa_localidade_fina(mini, tmp_path):
    con = mini.con
    semente = tmp_path / "verif_local.toml"
    semente.write_text('''
[[verificacao]]
taxon_gbif_key = 100
molecula_inchikey = "RYYVLZVUVIJVGH-UHFFFAOYSA-N"
fonte_id = "lotus"
doi = "10.1000/abc"
curador = "Curadoria Teste"
decisao = "confirmada"
sensibilidade = "sem_restricao"
passagem_conferida = "Caffeine was collected in Manaus Municipality at 3°06' S."
''', encoding="utf-8")
    with pytest.raises(curadoria.ErroDeLocalidade):
        curadoria.aplicar_semente_verificacoes(con, caminho=semente, log=lambda *_: None)


def test_aplicar_semente_sincroniza_edicao_e_remocao_sem_apagar_voto_humano(mini, tmp_path):
    con = mini.con
    semente = tmp_path / "verif_sync.toml"
    semente.write_text('''
[[verificacao]]
taxon_gbif_key = 100
molecula_inchikey = "RYYVLZVUVIJVGH-UHFFFAOYSA-N"
fonte_id = "lotus"
doi = "10.1000/abc"
curador = "Curadoria Científica BioMapaBrasil"
decisao = "confirmada"
sensibilidade = "sem_restricao"
qualidade_experimental = "atende"
subtipo_decisao = "isolamento_primario_confirmado"
acesso_texto = "texto_completo_aberto"
escopo_geografico_lido = "amazonia_br"
procedencia_material = "Brasil: TO"
voucher = "IAC 50629"
passagem_conferida = "Caffeine was isolated from the bark extract collected in northern Brazil."
nota = "Primeira versão."
''', encoding="utf-8")
    r1 = curadoria.aplicar_semente_verificacoes(con, caminho=semente, log=lambda *_: None, sincronizar_remocoes=True)
    assert r1["aplicadas"] == 1
    af1 = con.execute("SELECT estado, procedencia_declarada, procedencia_material FROM afirmacao WHERE id=?", (mini.af_composto,)).fetchone()
    assert tuple(af1) == ("verificado", "curador_artigo_amazonia", "Brasil: TO")

    # Atualização declarativa (ex.: rebaixar escopo geográfico de resumo ambíguo para nao_declarado)
    semente.write_text('''
[[verificacao]]
taxon_gbif_key = 100
molecula_inchikey = "RYYVLZVUVIJVGH-UHFFFAOYSA-N"
fonte_id = "lotus"
doi = "10.1000/abc"
curador = "Curadoria Científica BioMapaBrasil"
decisao = "confirmada"
sensibilidade = "sem_restricao"
qualidade_experimental = "atende"
subtipo_decisao = "isolamento_primario_confirmado"
acesso_texto = "apenas_resumo"
escopo_geografico_lido = "nao_declarado"
passagem_conferida = "Caffeine was isolated and characterized by NMR from the seed extract."
nota = "Versão revisada."
''', encoding="utf-8")
    r2 = curadoria.aplicar_semente_verificacoes(con, caminho=semente, log=lambda *_: None, sincronizar_remocoes=True)
    assert r2["aplicadas"] == 1
    af2 = con.execute("SELECT estado, procedencia_declarada, procedencia_material, passagem FROM afirmacao WHERE id=?", (mini.af_composto,)).fetchone()
    assert tuple(af2) == ("verificado", "nao_declarada", None, "Caffeine was isolated and characterized by NMR from the seed extract.")
    assert con.execute("SELECT COUNT(*) FROM verificacao WHERE afirmacao_id=?", (mini.af_composto,)).fetchone()[0] == 1

    # Remoção declarativa reverte afirmação para candidato
    semente.write_text("", encoding="utf-8")
    r3 = curadoria.aplicar_semente_verificacoes(con, caminho=semente, log=lambda *_: None, sincronizar_remocoes=True)
    assert r3.get("removidas") == 1
    af3 = con.execute("SELECT estado, nivel_evidencia, passagem FROM afirmacao WHERE id=?", (mini.af_composto,)).fetchone()
    assert tuple(af3) == ("candidato", "base_curada", None)
