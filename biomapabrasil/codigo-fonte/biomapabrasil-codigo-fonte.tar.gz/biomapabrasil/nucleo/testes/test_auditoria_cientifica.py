# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Testes de regressão da auditoria científica e das guardas permanentes de rigor (WS1–WS7)."""
from PIL import Image, ImageDraw
import pytest

from bmb import auditar, construir, midia, prontidao, quimica, texto, validar
from bmb.conectores import chembl, gbif, npatlas_coconut, pubchem, referencias
from bmb.exportar import pacotes
from conftest import _afirmacao, _molecula, resposta


def test_pubchem_prefere_smiles_isomerico_a_conectividade():
    r = resposta({
        "PropertyTable": {
            "Properties": [{
                "CID": 989,
                "Title": "Pilocarpine",
                "MolecularFormula": "C11H16N2O2",
                "MolecularWeight": "208.26",
                "SMILES": "CC[C@H]1[C@@H](COC1=O)Cc2cncn2C",
                "ConnectivitySMILES": "CCC1C(COC1=O)Cc2cncn2C",
            }]
        }
    })
    p = pubchem.interpretar(r)
    assert "@H" in p["smiles"] and "@@H" in p["smiles"]


def test_gbif_sinonimos_exclui_proparte_e_duvidosos():
    class Cli:
        def get(self, *a, **k):
            return resposta({
                "results": [
                    {"canonicalName": "Justicia pectoralis", "taxonomicStatus": "HOMOTYPIC_SYNONYM"},
                    {"canonicalName": "Justicia procumbens", "taxonomicStatus": "HOMOTYPIC_SYNONYM", "origin": "EX_AUTHOR_SYNONYM"},
                    {"canonicalName": "Justicia procumbens", "taxonomicStatus": "PROPARTE_SYNONYM", "origin": "SOURCE"},
                    {"canonicalName": "Dianthera duvidosa", "taxonomicStatus": "DOUBTFUL"},
                    {"canonicalName": "Dianthera errada", "taxonomicStatus": "MISAPPLIED"},
                ]
            })

    sins = gbif.sinonimos(Cli(), 3173174)
    assert sins == ["Justicia pectoralis"]


def test_gbif_imagens_exclui_especimes_mortos_e_cativos():
    class Cli:
        def get(self, *a, **k):
            return resposta({
                "results": [
                    {
                        "key": 1, "countryCode": "BR", "vitality": "dead", "basisOfRecord": "HUMAN_OBSERVATION",
                        "media": [{"type": "StillImage", "identifier": "https://x/1.jpg", "license": "CC0", "creator": "A"}],
                    },
                    {
                        "key": 2, "countryCode": "BR", "occurrenceRemarks": "Serpente atropelada na BR-174",
                        "basisOfRecord": "HUMAN_OBSERVATION",
                        "media": [{"type": "StillImage", "identifier": "https://x/2.jpg", "license": "CC0", "creator": "B"}],
                    },
                    {
                        "key": 3, "countryCode": "GF", "vitality": "alive", "basisOfRecord": "HUMAN_OBSERVATION",
                        "media": [{"type": "StillImage", "identifier": "https://x/3.jpg", "license": "CC BY 4.0", "creator": "C"}],
                    },
                ]
            })

    imgs = gbif.imagens(Cli(), 2444433)
    assert len(imgs) == 1 and imgs[0]["gbif_ocorrencia"] == "3" and imgs[0]["pais"] == "GF"


def test_chembl_exclui_non_protein_target_e_mecanismo_unknown():
    assert "non-protein target" in chembl.ALVOS_SEM_ATRIBUICAO
    assert "molecular identity unknown" in chembl.ALVOS_SEM_ATRIBUICAO

    class Cli:
        def get(self, url, *a, **k):
            if "mechanism" in url:
                return resposta({"mechanisms": [{"mechanism_of_action": "Unknown", "action_type": None}]})
            return resposta({"drug_indications": [{"efo_term": "edema", "max_phase_for_ind": "4.0"}]})

    cl = chembl.clinico(Cli(), "CHEMBL689")
    assert cl["mecanismos"] == [] and cl["indicacoes"][0]["termo"] == "edema"
    enunc = texto.enunciado_clinico("Mannitol", cl["indicacoes"], cl["mecanismos"], categoria_clinica="metabolito_ou_insumo")
    assert "Unknown" not in enunc and "insumo farmacêutico ou metabólito ubíquo" in enunc


def test_enunciado_clinico_explicita_retirada_e_validador_bloqueia_omissao(mini):
    enunc_ret = texto.enunciado_clinico("Emetine", [{"termo": "amebíase"}], [], retirado=True)
    assert "retirada de mercado" in enunc_ret

    con = mini.con
    con.execute("UPDATE molecula SET fase_retirado=1 WHERE id=?", (mini.molecula,))
    con.execute("UPDATE afirmacao SET texto='«Cafeína» é fármaco aprovado (fase 4 no ChEMBL).' WHERE id=?", (mini.af_clinico,))
    erros = {e["id"] for e in validar.validar(con)["erros"]}
    assert "P4.clinico_retirado_sem_aviso" in erros

    con.execute("UPDATE afirmacao SET texto=? WHERE id=?", (enunc_ret, mini.af_clinico))
    erros2 = {e["id"] for e in validar.validar(con)["erros"]}
    assert "P4.clinico_retirado_sem_aviso" not in erros2


def test_quimica_inchikey_pains_estereo_e_portaria_344():
    ok, ik = quimica.conferir_inchikey("Cn1cnc2c1c(=O)n(C)c(=O)n2C", "RYYVLZVUVIJVGH-UHFFFAOYSA-N")
    assert ok and ik == "RYYVLZVUVIJVGH-UHFFFAOYSA-N"
    # Quercetina (catecol) aciona PAINS; cafeína não
    assert len(quimica.alertas_pains("O=c1c(O)c(-c2ccc(O)c(O)c2)oc2cc(O)cc(O)c12")) >= 1
    assert quimica.alertas_pains("Cn1cnc2c1c(=O)n(C)c(=O)n2C") == []
    # Teofilina (ZFXYFBGIUFBOJW) NÃO é proscrita; DMT (DMULVCHRPCFFGV) é; Safrol é precursor Lista D2
    assert quimica.substancia_proscrita_344("ZFXYFBGIUFBOJW-UHFFFAOYSA-N") is None
    assert quimica.substancia_proscrita_344("DMULVCHRPCFFGV-UHFFFAOYSA-N")[0] == "F2"
    assert "Lista D2" in quimica.controle_portaria_344("ZMQAAUBTXCXRIC-UHFFFAOYSA-N")
    # Preservação de estereoquímica no título
    assert quimica.preservar_estereo_no_nome("ent-epicatechin", "Epicatechin") == "ent-Epicatechin"
    assert quimica.preservar_estereo_no_nome("(+)-catechol", "Catechin") == "(+)-Catechin"
    assert quimica.limpar_nome_quimico("\ufffd-d-galactopyranoside, ethyl") == "d-galactopyranoside, ethyl"


def test_crossref_detecta_errata_ou_corrigenda():
    err = referencias.interpretar_crossref(
        resposta({"message": {"title": ["Erratum to 'Lignans from Virola'"], "issued": {"date-parts": [[2004]]}}})
    )
    assert err["retratada"] is False and err["aviso"] == "errata_ou_corrigenda"


def test_enquadramento_nao_penaliza_macro_noturno_nitido():
    im = Image.new("RGB", (640, 480), (4, 5, 4))
    dr = ImageDraw.Draw(im)
    for k in range(10, 145, 5):
        dr.ellipse((320 - k, 230 - k // 2, 320 + k, 230 + k // 2), outline=(228, 188, 76), width=2)
    enq = midia.analisar_enquadramento(im)
    assert enq["nota"] >= 0.88 and not enq["marca_dagua"]


def test_auditar_intervalo_wilson_e_execucao_completa(mini, tmp_path):
    p, lo, hi = auditar.intervalo_wilson(65, 65)
    assert p == 1.0 and 0.94 < lo < 0.95 and hi == 1.0

    con = mini.con
    con.execute("INSERT OR REPLACE INTO ocorrencia_uf (taxon_id, uf_sigla, n, consulta_id) VALUES (?,?,?,?), (?,?,?,?)",
                (mini.taxon, "AM", 60, mini.consulta_gbif, mini.taxon, "SP", 20, mini.consulta_gbif))
    con.execute("UPDATE molecula SET smiles='Cn1cnc2c1c(=O)n(C)c(=O)n2C', categoria_clinica='farmaco_secundario' WHERE id=?",
                (mini.molecula,))
    prontidao.recalcular_todas(con)
    construir.etapa_busca(con, lambda *_: None)
    destino = tmp_path / "dados"
    pacotes.exportar_tudo(con, destino, log=lambda *_: None)

    res = auditar.executar_auditoria(con, pasta_dados=destino, rapido=False)
    assert res["ok"] is True
    assert "ws8_expansao_e_3d" in res["eixos"]
    assert all(b["ok"] for b in res["eixos"].values())


def test_npatlas_conector_especie_lineana_e_rdkit():
    assert npatlas_coconut.nome_do_fungo("Fungus", "Ganoderma", "lucidum") == "Ganoderma lucidum"
    assert npatlas_coconut.nome_do_fungo("Fungus", "Ganoderma", "sp. BCC 123") is None
    assert npatlas_coconut.nome_do_fungo("Fungus", "Ganoderma", "cf. lucidum") is None
    assert npatlas_coconut.nome_do_fungo("Bacterium", "Streptomyces", "coelicolor") is None
    # variedade fica no nome; código de linhagem não faz parte dele
    assert npatlas_coconut.nome_do_fungo("Fungus", "Aspergillus", "flavus var. oryzae") == "Aspergillus flavus var. oryzae"
    assert npatlas_coconut.nome_do_fungo("Fungus", "Penicillium", "citrinum NRRL 5907") == "Penicillium citrinum"

    tsv = (
        "npaid\tcompound_name\tcompound_smiles\torigin_type\tgenus\torigin_species\t"
        "original_reference_author_list\toriginal_reference_year\toriginal_reference_doi\t"
        "original_reference_pmid\toriginal_reference_title\toriginal_journal_title\n"
        "NPA000106\tGanoderic acid T\tCC(=O)OC1CC2CCC3C(C2(C)CC1)CCC4(C)C3=CCC4C(C)CCC(=O)O\t"
        "Fungus\tGanoderma\tlucidum\tLi, A.; Silva, B.\t2020\t10.1021/np2020\t\tTriterpenoids\tJ. Nat. Prod.\n"
        "NPA000999\tStrain compound\tCCO\tFungus\tGanoderma\tsp.\tLi, A.\t2020\t10.1021/np999\t\tStrain\tJNP\n"
    )

    class CliNP:
        def get(self, *a, **k):
            return resposta(tsv, consulta_id=77)

        def get_varios(self, pedidos, *a, **k):
            return [
                resposta({"data": {"pathway_results": ["Terpenoids"], "superclass_results": ["Triterpenoids"]}}, consulta_id=78)
                for _ in pedidos
            ]

    comps, cid = npatlas_coconut.compostos_do_fungo(CliNP(), ["Ganoderma lucidum"])
    assert cid == 77
    assert len(comps) == 1
    assert comps[0]["npatlas_id"] == "NPA000106"
    assert len(comps[0]["inchikey"]) == 27
    assert comps[0]["classe"] == "Terpenoids › Triterpenoids"


def test_quarentena_portaria_344_e_doi_inexistente(mini):
    con = mini.con
    # 1) Portaria 344: Harmine (Lista F2) entra em quarentena rastreável sem apagar registro
    mid_harm = _molecula(con, "Harmine", inchikey="BXNJHAXVSOCGBA-UHFFFAOYSA-N")
    aid_harm = _afirmacao(con, "composto_em_organismo", mid_harm, mini.consulta_lotus, taxon_id=mini.taxon,
                          origem="lotus:LTS_HARM", fonte="lotus", organismo_na_fonte="Carapa guianensis",
                          texto="Em «Paullinia cupana» foi relatado «Harmine» em 1 publicação.")
    con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (aid_harm, mini.ref))
    nq344 = construir.quarentenar_portaria_344(con)
    assert nq344 == 1
    est = con.execute("SELECT estado, motivo_quarentena FROM afirmacao WHERE id=?", (aid_harm,)).fetchone()
    assert est["estado"] == "quarentena" and "Portaria SVS/MS" in est["motivo_quarentena"]

    # 2) DOI consultado e inexistente (resolvida=0, consulta_id preenchido) entra em quarentena e não gera aviso ativo
    con.execute("INSERT INTO referencia (doi, resolvida, consulta_id) VALUES ('10.1016/inexistente-999', 0, ?)",
                (mini.consulta_lotus,))
    rid_404 = con.execute("SELECT id FROM referencia WHERE doi='10.1016/inexistente-999'").fetchone()["id"]
    aid_404 = _afirmacao(con, "composto_em_organismo", mini.molecula, mini.consulta_lotus, taxon_id=mini.taxon,
                         origem="nubbe:NuBBE_999", fonte="lotus", organismo_na_fonte="Carapa guianensis",
                         texto="Em «Paullinia cupana» foi relatado «Cafeína» em 1 publicação.")
    con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (aid_404, rid_404))
    from bmb import bibliografia, quarentena
    assert bibliografia.declarar_regras_de_afirmacao(con).get("REF-INEXISTENTE") == 1
    quarentena.aplicar_estados(con)
    linha = con.execute("SELECT estado, regra_quarentena FROM afirmacao WHERE id=?", (aid_404,)).fetchone()
    assert (linha["estado"], linha["regra_quarentena"]) == ("quarentena", "REF-INEXISTENTE")
    prontidao.recalcular_todas(con)
    val = validar.validar(con)
    assert val["erros"] == []
    assert "E.referencia_nao_resolvida" not in {a["id"] for a in val["avisos"]}
