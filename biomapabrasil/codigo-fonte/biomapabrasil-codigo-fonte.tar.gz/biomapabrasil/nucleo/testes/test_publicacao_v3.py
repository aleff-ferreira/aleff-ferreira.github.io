# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Testes de publicação: procedência declarada e distribuição, geodésia EPSG:5880,
curadoria duplo-cega, métricas κ/AC1/PABAK, universo de checklists, lotes 00..ff e limpeza de licenças."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

import pytest
from shapely.geometry import box
from shapely import wkt as shp_wkt
from starlette.testclient import TestClient

from bmb import api, benchmark, config, curadoria, midia, procedencia, prontidao, quarentena
from bmb.conectores import geometrias_oficiais as go
from bmb.exportar import pacotes
from conftest import AGORA, _afirmacao, _consulta, _molecula, _taxon


# ─────────────────────────── WS3: Procedência T1–T5 & Escopo Biogeográfico ───────────────────────────

def test_procedencia_declarada_distribuicao_da_especie_e_leitura_de_curador(con):
    """Três perguntas, três colunas: o que se declara da coleta, onde a espécie ocorre, o que um curador leu."""
    cid = _consulta(con, "gbif", "https://api.gbif.org/v1/occ", "1")
    cid_l = _consulta(con, "lotus", "https://zenodo.org/records/19360665", "2")
    cid_n = _consulta(con, "nubbe", "https://nubbe.iq.unesp.br/api", "3")
    cid_c = _consulta(con, "chembl", "https://www.ebi.ac.uk/chembl/api", "4")

    def taxon(gbif, nome, **campos):
        tid = _taxon(con, gbif=gbif, nome=nome, consulta_id=cid)
        con.execute("UPDATE taxon SET " + ", ".join(f"{k}=?" for k in campos) + " WHERE id=?", (*campos.values(), tid))
        return tid

    t_end = taxon(1001, "Victoria amazonica", origem_estabelecimento="nativa", endemismo_br="endemica",
                  biomas_json=json.dumps(["Amazônia"]), predominio_al="predominante")
    t_pan = taxon(1002, "Bertholletia excelsa", origem_estabelecimento="nativa", endemismo_br="nao_endemica",
                  biomas_json=json.dumps(["Amazônia"]), predominio_al="predominante")
    t_amp = taxon(1003, "Lantana camara", origem_estabelecimento="nativa", endemismo_br="nao_endemica",
                  biomas_json=json.dumps(["Amazônia", "Cerrado", "Mata Atlântica", "Caatinga"]), predominio_al="nao_predominante")
    t_int = taxon(1004, "Mangifera indica", origem_estabelecimento="introduzida", endemismo_br="nao_endemica",
                  biomas_json=json.dumps(["Amazônia", "Mata Atlântica"]), predominio_al="nao_predominante")

    mid = _molecula(con, "Quercetina", "REFJWTPEDVJJIY-UHFFFAOYSA-N")
    con.execute("INSERT INTO referencia (doi, titulo, ano, resolvida, consulta_id) VALUES ('10.1000/p1','Artigo P1',2022,1,?)", (cid_l,))
    rid = con.execute("SELECT id FROM referencia WHERE doi='10.1000/p1'").fetchone()[0]

    af_end = _afirmacao(con, "composto_em_organismo", mid, cid_l, taxon_id=t_end, origem="lotus:end")
    af_pan = _afirmacao(con, "composto_em_organismo", mid, cid_l, taxon_id=t_pan, origem="lotus:pan")
    af_amp = _afirmacao(con, "composto_em_organismo", mid, cid_l, taxon_id=t_amp, origem="lotus:amp")
    af_am = _afirmacao(con, "composto_em_organismo", mid, cid_n, taxon_id=t_amp, origem="nubbe:am", fonte="nubbe", uf_coleta_declarada="AM, PA")
    af_sp = _afirmacao(con, "composto_em_organismo", mid, cid_n, taxon_id=t_pan, origem="nubbe:sp", fonte="nubbe", uf_coleta_declarada="SP")
    af_mista = _afirmacao(con, "composto_em_organismo", mid, cid_n, taxon_id=t_amp, origem="nubbe:mista", fonte="nubbe", uf_coleta_declarada="AM, SP")
    af_guiana = _afirmacao(con, "composto_em_organismo", mid, cid_l, taxon_id=t_pan, origem="ena:gf", pais_coleta_declarado="GF")
    af_india = _afirmacao(con, "composto_em_organismo", mid, cid_l, taxon_id=t_pan, origem="ena:in", pais_coleta_declarado="IN")
    con.execute("INSERT INTO alvo (nome, chembl_id) VALUES ('Alvo X', 'CHEMBL999')")
    alvo_id = con.execute("SELECT id FROM alvo WHERE chembl_id='CHEMBL999'").fetchone()[0]
    af_ativ = _afirmacao(con, "atividade_biologica", mid, cid_c, alvo_id=alvo_id, origem="chembl:ativ:99", fonte="chembl",
                         medida_tipo="IC50", medida_relacao="=", medida_valor=50.0, medida_unidade="nM")
    for aid in (af_end, af_pan, af_amp, af_am, af_sp, af_mista, af_guiana, af_india):
        con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (aid, rid))

    res = procedencia.recalcular_procedencia_banco(con)
    con.commit()

    def dist(tid):
        return con.execute("SELECT distribuicao_br FROM taxon WHERE id=?", (tid,)).fetchone()[0]

    def decl(aid):
        return con.execute("SELECT procedencia_declarada FROM afirmacao WHERE id=?", (aid,)).fetchone()[0]

    assert dist(t_end) == "endemica_do_brasil_restrita_ao_dominio_amazonia"
    assert dist(t_pan) == "registros_brasileiros_concentrados_na_amazonia_legal"
    assert dist(t_amp) == "registros_brasileiros_dispersos"
    assert dist(t_int) == "introduzida_ou_naturalizada"
    # espécie endêmica da Amazônia ou de registros concentrados nela: a afirmação NÃO herda procedência
    assert decl(af_end) == decl(af_pan) == decl(af_amp) == "nao_declarada"
    assert decl(af_am) == "base_declara_amazonia_legal"
    assert decl(af_sp) == "base_declara_brasil_fora_da_amazonia_legal"
    assert decl(af_mista) == "base_declara_pais_pan_amazonico"         # UFs dos dois lados: só o país é certo
    assert decl(af_guiana) == "base_declara_pais_pan_amazonico"        # país não situa a coleta na Amazônia
    assert decl(af_india) == "base_declara_exterior"
    assert decl(af_ativ) is None
    # as colunas antigas ficam vazias; nada automático preenche procedência do material
    assert con.execute("SELECT COUNT(*) FROM afirmacao WHERE nivel_procedencia IS NOT NULL OR procedencia_material IS NOT NULL").fetchone()[0] == 0
    assert con.execute("SELECT COUNT(*) FROM taxon WHERE escopo_biogeografico IS NOT NULL").fetchone()[0] == 0
    assert sum(res["distribuicao_taxons"].values()) == 4

    base = {"referencia_id": rid, "curador": "Dra. Ana Curadora", "decisao": "confirmada", "sensibilidade": "sem_restricao"}
    # localidade mais fina que UF não é aceita nem do curador
    with pytest.raises(curadoria.ErroCuradoria):
        curadoria.verificar(con, {**base, "afirmacao_id": af_amp, "escopo_geografico_lido": "amazonia_br",
                                  "passagem_conferida": "Leaves were collected and a voucher was deposited (INPA 22410).",
                                  "procedencia_material": "Reserva Ducke, Manaus, Amazonas, Brasil"})
    # leitura de curador com coleta amazônica: único caminho para procedência verificada em fonte primária
    curadoria.verificar(con, {**base, "afirmacao_id": af_amp, "escopo_geografico_lido": "amazonia_br",
                              "passagem_conferida": "Leaves were collected and a voucher was deposited (INPA 22410).",
                              "procedencia_material": "Brasil: AM", "voucher": "INPA 22410"})
    procedencia.recalcular_procedencia_banco(con)
    linha = con.execute("SELECT procedencia_declarada, estado, nivel_evidencia, nivel_procedencia FROM afirmacao WHERE id=?", (af_amp,)).fetchone()
    assert tuple(linha) == ("curador_artigo_amazonia", "verificado", "curador", None)
    assert decl(af_amp) in procedencia.PROCEDENCIA_PRIMARIA_VERIFICADA and decl(af_am) not in procedencia.PROCEDENCIA_PRIMARIA_VERIFICADA
    # leitura de curador com coleta em outro estado: vale a leitura, não a distribuição da espécie
    curadoria.verificar(con, {**base, "afirmacao_id": af_pan, "escopo_geografico_lido": "brasil_extra_amazonia",
                              "passagem_conferida": "Cultivated specimens were used for the isolation (UEC 9981).",
                              "procedencia_material": "Brasil: SP"})
    procedencia.recalcular_procedencia_banco(con)
    assert decl(af_pan) == "curador_artigo_fora_da_amazonia"
    # coleta fora da Amazônia confirmada pelo curador: a afirmação sai do público, com a leitura preservada
    quarentena.aplicar_estados(con)
    linha = con.execute("SELECT estado, regra_quarentena, quarentena_origem FROM afirmacao WHERE id=?", (af_pan,)).fetchone()
    assert tuple(linha) == ("quarentena", "PROV-FORA-DA-AMAZONIA", "regra")
    assert con.execute("SELECT COUNT(*) FROM verificacao WHERE afirmacao_id=?", (af_pan,)).fetchone()[0] == 1


# ─────────────────────────── WS4: Geodésia EPSG:5880 & União Topológica ───────────────────────────

def test_geodesia_epsg5880_e_protecao_sem_dupla_contagem():
    # Quadrado de 1° × 1° centrado no equador em Manaus (-60°, 0°): área teórica GRS80 ~ 12.309 km²
    quad_eq = box(-60.5, -0.5, -59.5, 0.5)
    area_grs80 = go.area_geodesica_km2(quad_eq)
    area_5880 = go.projetar_epsg5880(quad_eq).area / 1e6
    assert 12240.0 <= area_grs80 <= 12380.0
    assert abs(area_5880 - area_grs80) / area_grs80 < 0.008

    # Sobreposição total entre UC (CNUC) e TI (FUNAI) na mesma célula de 0,5° nunca ultrapassa 1,0
    uc_5880 = go.projetar_epsg5880(box(-60.5, -3.5, -59.5, -2.5))
    ti_5880 = go.projetar_epsg5880(box(-60.5, -3.5, -59.5, -2.5))
    ind = go.IndiceProtecaoVetorial([uc_5880, ti_5880], [1, 2])
    assert ind.fracao_protegida_celula(-60.0, -3.0, passo=0.5) == 1.0

    # Cobertura parcial exata de metade longitudinal da célula (~0,50) mesmo duplicada em 3 polígonos sobrepostos
    meia_1 = go.projetar_epsg5880(box(-60.25, -3.25, -60.0, -2.75))
    meia_2 = go.projetar_epsg5880(box(-60.25, -3.25, -60.0, -2.75))
    ind_meia = go.IndiceProtecaoVetorial([meia_1, meia_2], [1])
    frac = ind_meia.fracao_protegida_celula(-60.0, -3.0, passo=0.5)
    assert 0.49 <= frac <= 0.51

    # Limites oficiais semente: WKTs válidos, compactos (<= 1.800 chars) e áreas amazônicas coerentes com IBGE
    lim = go.carregar_limites_oficiais()
    assert 4_000_000 <= lim["bioma_amazonia"]["area_km2"] <= 4_400_000
    assert 4_850_000 <= lim["amazonia_legal"]["area_km2"] <= 5_200_000
    assert len(lim["bacias"]) == 9
    for chave_wkt in [lim["bioma_amazonia"]["wkt_gbif"], lim["amazonia_legal"]["wkt_gbif"], *(b["wkt_gbif"] for b in lim["bacias"])]:
        assert len(chave_wkt) <= 1800
        geom = shp_wkt.loads(chave_wkt)
        assert geom.is_valid and not geom.is_empty


# ─────────────────────────── WS2: Dupla Curadoria Cega & Métricas IAA ───────────────────────────

def test_dupla_curadoria_cega_consenso_e_adjudicacao(mini):
    con = mini.con
    aid = mini.af_composto
    rid = mini.ref

    # Curador 1 confirma -> fica em_revisao até Curador 2 votar
    r1 = curadoria.verificar(con, {
        "afirmacao_id": aid,
        "referencia_id": rid,
        "curador": "Curador Um",
        "papel_curador": "curador_1",
        "rodada_benchmark": "rodada_teste",
        "decisao": "confirmada",
        "passagem_conferida": "Caffeine was isolated and characterized by 1H/13C NMR from leaves.",
        "sensibilidade": "sem_restricao",
    })
    assert r1["estado"] == "em_revisao"

    # Cegamento: Curador 2 consultando detalhe NÃO vê o voto nem a passagem do Curador 1
    det_c2 = curadoria.detalhe(con, aid, papel_curador="curador_2")
    assert det_c2["cegamento_ativo"] is True
    assert det_c2["verificacoes"] == []
    # Já Curador 1 vê apenas o próprio voto, e adjudicador vê todos
    assert len(curadoria.detalhe(con, aid, papel_curador="curador_1")["verificacoes"]) == 1
    assert len(curadoria.detalhe(con, aid, papel_curador="adjudicador")["verificacoes"]) == 1

    # Fila da rodada_benchmark esconde de curador_1 o item já avaliado por ele, mas mostra a curador_2
    assert curadoria.fila(con, estado="todos", rodada_benchmark="rodada_teste", papel_curador="curador_1")["total"] == 0

    # Caso de discordância: se em outra afirmação curador_1 confirma e curador_2 rejeita -> permanece em_revisao até adjudicador
    aid2 = _afirmacao(con, "composto_em_organismo", mini.molecula, mini.consulta_lotus, taxon_id=mini.taxon, origem="lotus:disc")
    con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (aid2, rid))
    con.commit()

    curadoria.verificar(con, {
        "afirmacao_id": aid2, "referencia_id": rid, "curador": "Curador Um", "papel_curador": "curador_1",
        "rodada_benchmark": "rodada_teste", "decisao": "confirmada",
        "passagem_conferida": "Compound reported in table 1 of the supplementary material.",
        "sensibilidade": "sem_restricao",
    })
    r_disc = curadoria.verificar(con, {
        "afirmacao_id": aid2, "referencia_id": rid, "curador": "Curador Dois", "papel_curador": "curador_2",
        "rodada_benchmark": "rodada_teste", "decisao": "rejeitada",
        "nota": "Artigo de revisão secundária sem isolamento experimental primário.",
    })
    assert r_disc["estado"] == "em_revisao"

    # Adjudicador resolve a divergência
    r_adj = curadoria.verificar(con, {
        "afirmacao_id": aid2, "referencia_id": rid, "curador": "Adjudicador Sênior", "papel_curador": "adjudicador",
        "rodada_benchmark": "rodada_teste", "decisao": "rejeitada",
        "nota": "Adjudicação confirma citação apenas secundária sem isolamento.",
    })
    assert r_adj["estado"] == "rejeitado"

    # Consenso positivo em `aid`: Curador 2 confirma independentemente -> promove a `verificado`
    r2 = curadoria.verificar(con, {
        "afirmacao_id": aid, "referencia_id": rid, "curador": "Curador Dois", "papel_curador": "curador_2",
        "rodada_benchmark": "rodada_teste", "decisao": "confirmada",
        "passagem_conferida": "Isolated crystalline caffeine (12 mg) identified from dried leaves.",
        "sensibilidade": "sem_restricao",
    })
    assert r2["estado"] == "verificado"


def test_metricas_concordancia_paradoxo_kappa_gwet_ac1_e_vazio():
    # Entrada vazia
    vazio = benchmark.metricas_concordancia([])
    assert vazio["n_pares"] == 0 and vazio["kappa_cohen"] is None and vazio["gwet_ac1"] is None

    # Concordância perfeita
    perf = benchmark.metricas_concordancia([("positiva", "positiva")] * 15 + [("negativa", "negativa")] * 5, n_bootstrap=200)
    assert perf["concordancia_bruta"] == 1.0
    assert perf["kappa_cohen"] == 1.0
    assert perf["gwet_ac1"] == 1.0
    assert perf["pabak"] == 1.0

    # Paradoxo clássico de alta prevalência (Feinstein & Cicchetti 1990):
    # 94 (+,+), 1 (-,-), 2 (+,-), 3 (-,+) -> concordância bruta = 95%, porém κ cai ~0.26 enquanto AC1 ~0.94 e PABAK = 0.90
    pares_paradoxo = (
        [("positiva", "positiva")] * 94
        + [("negativa", "negativa")] * 1
        + [("positiva", "negativa")] * 2
        + [("negativa", "positiva")] * 3
    )
    m = benchmark.metricas_concordancia(pares_paradoxo, categorias=("positiva", "negativa"), n_bootstrap=500, seed=42)
    assert m["concordancia_bruta"] == 0.95
    assert m["pabak"] == 0.90
    assert 0.24 <= m["kappa_cohen"] <= 0.29
    assert 0.93 <= m["gwet_ac1"] <= 0.96
    lo_ac1, hi_ac1 = m["ic95_bootstrap"]["gwet_ac1"]
    assert 0.85 <= lo_ac1 <= m["gwet_ac1"] <= hi_ac1 <= 1.0


def test_amostragem_benchmark_deterministica_e_nao_altera_estado(mini):
    con = mini.con
    con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (mini.af_atividade, mini.ref))
    con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (mini.af_clinico, mini.ref))
    prontidao.recalcular_todas(con)
    con.commit()

    s1 = benchmark.amostrar_benchmark(con, rodada="r_det", seed=20261115, n_total=10, recriar=True)
    ids1 = [r[0] for r in con.execute("SELECT afirmacao_id FROM amostra_benchmark WHERE rodada='r_det' ORDER BY id")]
    s2 = benchmark.amostrar_benchmark(con, rodada="r_det", seed=20261115, n_total=10, recriar=True)
    ids2 = [r[0] for r in con.execute("SELECT afirmacao_id FROM amostra_benchmark WHERE rodada='r_det' ORDER BY id")]
    assert ids1 == ids2 and s1["n_amostra"] == s2["n_amostra"] == 3
    # Princípio 3: amostragem nunca cria verificações sintéticas nem promove candidato a verificado
    assert con.execute("SELECT COUNT(*) FROM verificacao").fetchone()[0] == 0
    assert con.execute("SELECT COUNT(*) FROM afirmacao WHERE estado='verificado'").fetchone()[0] == 0


# ─────────────────────────── WS1 & WS5: Lotes Hex, Universo Checklist & API v3 ───────────────────────────

def test_exportacao_lotes_indice_mapa_universo_e_api_v3(mini, tmp_path):
    con = mini.con
    con.execute(
        "INSERT INTO universo_checklist (fonte, taxon_id_fonte, nome_aceito, reino, familia, genero, grupo_bmb, "
        "status_origem_br, endemismo_br, bioma_amazonia_declarado, tem_quimica_aberta, taxon_id_bmb, consulta_id) "
        "VALUES ('jbrj_flora_funga','FB100','Carapa guianensis','Plantae','Meliaceae','Carapa','planta','nativa','nao_endemica',1,1,?,?)",
        (mini.taxon, mini.consulta_gbif),
    )
    con.execute(
        "INSERT INTO universo_checklist (fonte, taxon_id_fonte, nome_aceito, reino, familia, genero, grupo_bmb, "
        "status_origem_br, endemismo_br, bioma_amazonia_declarado, tem_quimica_aberta, consulta_id) "
        "VALUES ('jbrj_flora_funga','FB101','Especie inexplorada','Plantae','Fabaceae','Inga','planta','nativa','endemica',1,0,?)",
        (mini.consulta_gbif,),
    )
    con.execute("UPDATE molecula SET smiles='CN1C=NC2=C1C(=O)N(C(=O)N2C)C' WHERE id=?", (mini.molecula,))
    prontidao.recalcular_todas(con)
    con.commit()

    midia.desenhar_todas(con, lambda *_: None)
    ik = "RYYVLZVUVIJVGH-UHFFFAOYSA-N"
    bucket_svg = hashlib.sha1(ik.encode("ascii")).hexdigest()[:2]
    lote_svg = config.SAIDA_DIR / "estruturas_lotes" / f"{bucket_svg}.json"
    assert lote_svg.exists()
    assert ik in json.loads(lote_svg.read_text(encoding="utf-8"))

    dest = tmp_path / "dados_out"
    manif = pacotes.exportar_tudo(con, dest, log=lambda *_: None)

    assert (dest / "indice_mapa.json").exists()
    ix_m = json.loads((dest / "indice_mapa.json").read_text(encoding="utf-8"))
    assert ix_m["esquema"] == 2 and "dados" in ix_m and "ufs" in ix_m
    mol_ix = json.loads((dest / "moleculas_indice.json").read_text(encoding="utf-8"))
    assert mol_ix["esquema"] == 2 and "dados" in mol_ix
    lote_mol = dest / "moleculas_lotes" / f"{mini.molecula & 0xff:02x}.json"
    assert lote_mol.exists()
    assert str(mini.molecula) in json.loads(lote_mol.read_text(encoding="utf-8"))
    assert (dest / "tabelas" / "universo_checklist_amazonia.csv").exists()

    assert manif["universo_checklist"]["especies_aceitas_bioma_amazonia"] == 2
    assert manif["universo_checklist"]["sem_quimica_aberta_dark_matter"] == 1
    assert "governanca_sisgen" in manif

    db_arq = Path(con.execute("PRAGMA database_list").fetchone()[2])
    app_asgi = api.criar_app(caminho_db=db_arq, app_dir=tmp_path)
    with TestClient(app_asgi) as client:
        ru = client.get("/api/universo")
        assert ru.status_code == 200
        assert ru.json()["especies_aceitas_bioma_amazonia"] == 2
        assert ru.json()["sem_quimica_aberta_dark_matter"] == 1

        # a validação por amostragem e o livro de retenções são registros internos: fora da API pública
        assert client.get("/api/benchmark").status_code == 404
        assert client.get("/api/quarentena").status_code == 404
        caminhos = client.get("/api/openapi.json").json()["paths"]
        assert "/api/benchmark" not in caminhos and "/api/quarentena" not in caminhos

        # a procedência é filtrada pelo que a fonte declara; o filtro antigo por distribuição é recusado
        rt = client.get("/api/taxa?procedencia=nao_declarada")
        assert rt.status_code == 200
        assert rt.json()["total"] == 1
        assert client.get("/api/taxa?procedencia=base_declara_amazonia_legal").json()["total"] == 0
        assert client.get("/api/taxa?nivel_procedencia=T1").status_code == 400
        assert client.get("/api/taxa?procedencia=amazonica_estrita").status_code == 400

    # com a curadoria ligada (uso local), as duas rotas existem e exigem o token da sessão
    app_interno = api.criar_app(caminho_db=db_arq, app_dir=tmp_path, curadoria_ativa=True, token="segredo-de-teste")
    with TestClient(app_interno) as interno:
        assert interno.get("/api/benchmark").status_code in (401, 403)
        rb = interno.get("/api/benchmark", headers={"X-BMB-Token": "segredo-de-teste"})
        assert rb.status_code == 200 and isinstance(rb.json(), dict)


def test_arvore_plataforma_sem_coordenadas_pontuais_nem_midia_by_nc():
    import subprocess
    raiz_plat = Path(__file__).resolve().parents[2]
    assert not (raiz_plat / "web").exists(), "Diretório legado web/ (com pontos CC BY-NC) não deve existir em v3.0"
    assert not (raiz_plat / "prototipo").exists(), "Diretório legado prototipo/ (Sentinel CC BY-NC-SA) não deve existir em v3.0"

    padrao_coord_json = re.compile(r'"(?:decimalLatitude|decimalLongitude)"\s*:\s*-?\d+\.\d{3,}')
    violacoes = []
    candidatos: list[Path] = []
    if (raiz_plat / ".git").exists():
        proc = subprocess.run(["git", "-C", str(raiz_plat), "ls-files"], capture_output=True, text=True, check=False)
        if proc.returncode == 0:
            candidatos.extend(raiz_plat / ln.strip() for ln in proc.stdout.splitlines() if ln.strip())
    for sub in ("app", "docs"):
        pasta = raiz_plat / sub
        if pasta.exists():
            candidatos.extend(p for p in pasta.rglob("*") if p.is_file())

    vistos: set[Path] = set()
    for arq in candidatos:
        arq_res = arq.resolve()
        if arq_res in vistos or not arq.is_file():
            continue
        vistos.add(arq_res)
        rel = arq.relative_to(raiz_plat).as_posix()
        if rel.startswith("nucleo/testes/"):
            continue
        if arq.suffix.lower() not in {".js", ".html", ".css", ".json", ".geojson"}:
            continue
        if arq.stat().st_size > 5 * 1024 * 1024:
            continue
        txt = arq.read_text(encoding="utf-8", errors="ignore")
        if padrao_coord_json.search(txt):
            violacoes.append(f"coordenada_pontual:{rel}")
        if '"licenca":"CC BY-NC' in txt or '"licenca": "CC BY-NC' in txt or "CC BY-NC-SA" in txt:
            violacoes.append(f"licenca_by_nc_ativa:{rel}")
    assert not violacoes, f"Violações encontradas: {violacoes}"


def test_guarda_inchikey_27chars_e_compactacao_svg(con):
    from bmb import construir
    # SMILES divergente do InChIKey de 27 chars -> armazenado com smiles=None (Princípio 2)
    mid_div = construir.upsert_molecula_pequena(con, {
        "nome": "Fosfina errada",
        "inchikey": "OAICVXFJPJFONN-UHFFFAOYSA-N",
        "smiles": "P",
        "formula": "P",
        "massa": 30.97,
    })
    assert con.execute("SELECT smiles FROM molecula WHERE id=?", (mid_div,)).fetchone()[0] is None

    # SMILES congruente com InChIKey de 27 chars -> preservado e desenhado com paths fundidos
    mid_ok = construir.upsert_molecula_pequena(con, {
        "nome": "Cafeína",
        "inchikey": "RYYVLZVUVIJVGH-UHFFFAOYSA-N",
        "smiles": "CN1C=NC2=C1C(=O)N(C(=O)N2C)C",
        "formula": "C8H10N4O2",
        "massa": 194.19,
    })
    assert con.execute("SELECT smiles FROM molecula WHERE id=?", (mid_ok,)).fetchone()[0] is not None
    svg = midia.desenhar_estrutura("CN1C=NC2=C1C(=O)N(C(=O)N2C)C", "Cafeína")
    assert svg is not None and svg.startswith("<svg ") and "stroke-linecap:butt" not in svg
    assert svg.count("<path ") <= 8


def test_etapa_toxinas_enriquece_procedencia_ena_via_chave_embl(con, monkeypatch):
    from types import SimpleNamespace
    from bmb import construir
    from bmb.conectores import ena, uniprot

    cid_g = _consulta(con, "gbif", "https://api.gbif.org/v1/occ", "g1")
    cid_u = _consulta(con, "uniprot", "https://rest.uniprot.org/uniprotkb/stream", "u1")
    cid_e = _consulta(con, "ena", "https://www.ebi.ac.uk/ena/portal/api/search", "e1")
    tid = _taxon(con, gbif=7771, nome="Bothrops atrox", grupo="animal_peconhento", consulta_id=cid_g)
    con.execute("UPDATE taxon SET uniprot_taxid=8725, no_recorte=1, predominio_al='predominante' WHERE id=?", (tid,))

    monkeypatch.setattr(uniprot, "organismos_toxprot", lambda cli: ([{"taxid": 8725, "cientifico": "Bothrops atrox", "n": 1}], cid_u))
    monkeypatch.setattr(
        uniprot,
        "toxinas_do_organismo",
        lambda cli, taxid: (
            [{
                "acc": "P0DM59",
                "nome": "BatxLAAO",
                "organismo": "Bothrops atrox",
                "sequencia": "MNVFFMFSLLFLAALGQG",
                "comprimento": 18,
                "massa": 2012.4,
                "familia": "L-amino-acid oxidase family",
                "funcao": "Catalyzes oxidative deamination and induces platelet aggregation.",
                "experimental": True,
                "pmids_funcao": ["24613490"],
                "chaves_ref_entrada": ["24613490"],
                "referencias": {"24613490": {"pmid": "24613490", "doi": "10.1016/j.toxicon.2014.02.015", "titulo": "BatxLAAO", "ano": 2014}},
                "embl": ["KC820798"],
                "pdb": [],
            }],
            SimpleNamespace(consulta_id=cid_u),
        ),
    )
    monkeypatch.setattr(
        ena,
        "buscar_procedencia_embl_em_lote",
        lambda cli, acessos: {"KC820798": {"pais": "BR", "uf": "AM", "voucher": "INPA-H 31022", "consulta_id": cid_e}}
        if "KC820798" in acessos else {},
    )

    construir.etapa_toxinas(con, SimpleNamespace(), lambda *_: None)
    procedencia.recalcular_procedencia_banco(con)
    row = con.execute(
        "SELECT pais_coleta_declarado, uf_coleta_declarada, voucher_declarado_base, procedencia_declarada, nivel_procedencia "
        "FROM afirmacao WHERE origem='uniprot:P0DM59'"
    ).fetchone()
    assert dict(row) == {
        "pais_coleta_declarado": "BR",
        "uf_coleta_declarada": "AM",
        "voucher_declarado_base": "INPA-H 31022",
        "procedencia_declarada": "base_declara_amazonia_legal",      # declarada pelo ENA; não é leitura do artigo
        "nivel_procedencia": None,
    }


def test_prebuscar_europepmc_extrai_xml_oa_e_pdf_sem_erro_formato(mini):
    from types import SimpleNamespace
    con = mini.con
    chamadas = []

    class _CliFalso:
        def get(self, url, params=None, *, fonte, como_json=True, accept="application/json", tentativas=4):
            chamadas.append((url, como_json, accept, fonte))
            if "search" in url:
                return SimpleNamespace(
                    consulta_id=mini.consulta_lotus,
                    dados={
                        "resultList": {
                            "result": [{
                                "title": "Isolation of limonoids from Carapa guianensis collected in Amazonas",
                                "abstractText": "Gedunin was isolated from seeds collected in Manaus.",
                                "pmcid": "PMC9876543",
                                "isOpenAccess": "Y",
                                "license": "cc by",
                                "pubYear": "2023",
                                "journalInfo": {"journal": {"title": "Journal of Natural Products"}},
                                "fullTextUrlList": {"fullTextUrl": [{"availabilityCode": "OA", "documentStyle": "pdf", "url": "https://europepmc.org/articles/PMC9876543?pdf=render"}]},
                            }]
                        }
                    },
                )
            assert como_json is False and accept == "application/xml"
            return SimpleNamespace(
                consulta_id=mini.consulta_lotus,
                dados="<article><body><sec><title>Plant Material</title><p>Seeds collected at Reserva Ducke, Manaus (INPA 11223).</p></sec></body></article>",
            )

    res = curadoria.prebuscar_europepmc(con, _CliFalso(), mini.ref)
    assert res["encontrado"] is True
    assert res["acesso_aberto"] is True
    assert res["url_pdf_oa"] == "https://europepmc.org/articles/PMC9876543?pdf=render"
    assert "Reserva Ducke, Manaus (INPA 11223)" in (res["trecho_oa"] or "")
    assert len(chamadas) == 2


def test_dupla_curadoria_cega_fila_default_divergencia_e_protecao_benchmark(mini):
    con = mini.con
    aid = mini.af_composto
    rid = mini.ref
    prontidao.recalcular_todas(con)
    benchmark.amostrar_benchmark(con, rodada="r_guard", seed=20261115, n_total=5, recriar=True)

    # 1. Bloqueia verificação sem papel_curador em item pertencente a amostra_benchmark
    with pytest.raises(curadoria.ErroCuradoria, match="amostra estratificada de benchmark"):
        curadoria.verificar(con, {
            "afirmacao_id": aid,
            "referencia_id": rid,
            "curador": "Curador Avulso",
            "decisao": "confirmada",
            "passagem_conferida": "Isolated compound characterized by NMR spectroscopy in Manaus.",
            "sensibilidade": "sem_restricao",
        })

    # 2. Curador 1 vota confirmada + restrito -> item vai para em_revisao e classe_acesso sobe para restrito,
    # mas continua visível na fila padrão ('candidato') de Curador 2 mascarado como 'candidato'!
    curadoria.verificar(con, {
        "afirmacao_id": aid,
        "referencia_id": rid,
        "curador": "Curador Um",
        "papel_curador": "curador_1",
        "rodada_benchmark": "r_guard",
        "decisao": "confirmada",
        "passagem_conferida": "Collected near protected area with sensitive locality details.",
        "sensibilidade": "restrito",
    })
    assert con.execute("SELECT classe_acesso FROM afirmacao WHERE id=?", (aid,)).fetchone()[0] == "restrito"

    fila_c2 = curadoria.fila(con, estado="candidato", rodada_benchmark="r_guard", papel_curador="curador_2")
    assert fila_c2["total"] == 1 and fila_c2["itens"][0]["estado"] == "candidato"
    det_c2 = curadoria.detalhe(con, aid, papel_curador="curador_2")
    assert det_c2["afirmacao"]["estado"] == "candidato"

    # 3. Curador 2 vota 'corrigida' + 'sem_restricao': divergência de decisão/sensibilidade exige adjudicador
    r2 = curadoria.verificar(con, {
        "afirmacao_id": aid,
        "referencia_id": rid,
        "curador": "Curador Dois",
        "papel_curador": "curador_2",
        "rodada_benchmark": "r_guard",
        "decisao": "corrigida",
        "passagem_conferida": "Compound structure corrected to stereoisomer 3-beta by X-ray crystallography.",
        "sensibilidade": "sem_restricao",
    })
    assert r2["estado"] == "em_revisao"
    # Sensibilidade restrita nunca é rebaixada silenciosamente
    assert con.execute("SELECT classe_acesso FROM afirmacao WHERE id=?", (aid,)).fetchone()[0] == "restrito"


def test_galaxia_quantizada_int16_delta_ufs_e_dockerfile_integro(mini, tmp_path):
    con = mini.con      # a fixture já traz contagens por UF coerentes com os totais do táxon (AM 60, SP 20)
    con.execute("UPDATE molecula SET smiles='CN1C=NC2=C1C(=O)N(C(=O)N2C)C', umap_x=0.41234, umap_y=-0.78912 WHERE id=?", (mini.molecula,))
    prontidao.recalcular_todas(con)
    con.commit()
    dest = tmp_path / "out_q"
    pacotes.exportar_tudo(con, dest, log=lambda *_: None)

    gx = json.loads((dest / "viz" / "galaxia.json").read_text(encoding="utf-8"))
    assert gx["quantizacao_xy"] == "int16" and gx["escala_xy"] == 10000
    ix_x, ix_y, ix_cls = gx["colunas"].index("x"), gx["colunas"].index("y"), gx["colunas"].index("classe")
    assert gx["linhas"][0][ix_x] == 4123 and gx["linhas"][0][ix_y] == -7891
    assert isinstance(gx["linhas"][0][ix_cls], int) and len(gx["dicionario_classes"]) >= 1

    ix_m = json.loads((dest / "indice_mapa.json").read_text(encoding="utf-8"))
    assert ix_m["ufs_formato"] == "bitmask_27"
    assert "AM" in ix_m["ufs"] and ix_m["dados"]["uf_mask"][0] > 0

    raiz_plat = Path(__file__).resolve().parents[2]
    dockerfile = (raiz_plat / "Dockerfile").read_text(encoding="utf-8")
    assert "nucleo/README.md" in dockerfile and "nucleo/MANIFEST.in" in dockerfile
    for p_rel in ("nucleo/pyproject.toml", "nucleo/README.md", "nucleo/MANIFEST.in", "nucleo/servir.py"):
        assert (raiz_plat / p_rel).is_file(), f"Arquivo exigido pelo Dockerfile ausente: {p_rel}"
