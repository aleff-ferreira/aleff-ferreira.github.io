# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Testes E2E Automatizados (Playwright + Pytest) para o Observatório Galáxia Química 3D.

Valida a navegação espacial WebGL, os controles orbitais da câmera, a inspeção científica
por raycasting, a filtragem físico-química em tempo real e os cenários científicos de uso.
Metodologia: 4 Tiers (Feature Coverage, Boundary Cases, Pairwise Combinations, Scientific Scenarios)

Requisitos opcionais (fora da suíte mínima de CI): `pip install playwright && playwright install chromium`
e os pacotes de dados em `app/dados/` (arquivos da Release ou `python -m bmb exportar`). Na ausência de
qualquer um deles, o módulo inteiro é ignorado (`skip`) em vez de falhar.
"""
import functools
import json
import http.server
import re
import socket
import threading
import time
from typing import Generator

import pytest

pytest.importorskip("playwright.sync_api", reason="Playwright não instalado (testes E2E opcionais)")
from playwright.sync_api import Browser, BrowserContext, Page, sync_playwright  # noqa: E402

from servir import Manipulador, RAIZ  # noqa: E402

if not (RAIZ / "dados" / "viz" / "galaxia.json").exists():
    pytest.skip("app/dados/viz/galaxia.json ausente (pacotes de dados não instalados)", allow_module_level=True)

# Tamanho do espaço químico nos dados instalados: os testes de contagem valem para qualquer versão dos dados.
TOTAL_MOLECULAS = len(json.loads((RAIZ / "dados" / "viz" / "galaxia.json").read_text(encoding="utf-8"))["linhas"])


# ═══════════════════════════════════════════════════════════════════════════════
# FIXTURES DE SERVIDOR E NAVEGADOR
# ═══════════════════════════════════════════════════════════════════════════════

@pytest.fixture(scope="session")
def dev_server_url() -> Generator[str, None, None]:
    """Inicia o servidor de desenvolvimento local (servir.py) em porta efêmera."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()

    server = http.server.ThreadingHTTPServer(
        ("127.0.0.1", port),
        functools.partial(Manipulador, directory=str(RAIZ)),
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    time.sleep(0.3)

    base_url = f"http://127.0.0.1:{port}"
    yield base_url

    server.shutdown()
    server.server_close()


@pytest.fixture(scope="session")
def browser_instance() -> Generator[Browser, None, None]:
    """Inicia o Chromium headless com aceleração WebGL por software (SwiftShader/ANGLE)."""
    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=True,
            args=[
                "--use-gl=angle",
                "--use-angle=swiftshader",
                "--enable-webgl",
                "--ignore-gpu-blocklist",
                "--disable-gpu-process-crash-limit",
                "--no-sandbox",
            ],
        )
        yield browser
        browser.close()


@pytest.fixture(scope="session")
def shared_context(browser_instance: Browser) -> Generator[BrowserContext, None, None]:
    """Cria contexto de navegador com viewport desktop padrão."""
    context = browser_instance.new_context(
        viewport={"width": 1280, "height": 800},
        device_scale_factor=1,
    )
    yield context
    context.close()


@pytest.fixture(scope="session")
def base_page(shared_context: BrowserContext, dev_server_url: str) -> Generator[Page, None, None]:
    """Navega para a Galáxia Química e aguarda o carregamento inicial dos dados."""
    page = shared_context.new_page()
    page.goto(f"{dev_server_url}/index.html#/galaxia")
    page.wait_for_selector("#gx-wrap", timeout=25000)
    # Aguarda contagem indicar carregamento completo do galaxia.json 
    page.wait_for_function(
        "() => { const el = document.querySelector('#gx-contagem-viva'); return el && /[1-9]/.test(el.textContent); }",
        timeout=25000,
    )
    yield page
    page.close()


# ═══════════════════════════════════════════════════════════════════════════════
# FUNÇÕES AUXILIARES DE INTERAÇÃO E AUDITORIA
# ═══════════════════════════════════════════════════════════════════════════════

def get_visible_count(page: Page) -> int:
    """Extrai o número inteiro de moléculas visíveis a partir de #gx-contagem-viva."""
    texto = page.locator("#gx-contagem-viva").text_content() or ""
    # Formato: "N moléculas visíveis" ou "N de M moléculas visíveis"
    m = re.search(r"([\d\.]+)\s+(?:de\s+[\d\.]+\s+)?moléculas visíveis", texto)
    if m:
        return int(m.group(1).replace(".", ""))
    # Fallback genérico extraindo dígitos antes de 'mol'
    digitos = "".join(ch for ch in texto.split("mol")[0] if ch.isdigit())
    return int(digitos) if digitos else 0


def get_3d_canvas(page: Page):
    """Retorna o locator do canvas 3D ativo (#gx-cv-3d ou o canvas visível em #gx-wrap)."""
    cv3d = page.locator("#gx-wrap canvas#gx-cv-3d")
    if cv3d.count() > 0 and cv3d.is_visible():
        return cv3d
    return page.locator("#gx-wrap canvas:visible").first


def ensure_3d_mode(page: Page) -> None:
    """Garante que o modo 3D está ativo clicando no botão da alternador-vista."""
    if "#/galaxia" not in page.url:
        page.goto(page.url.split("#")[0] + "#/galaxia")
        page.wait_for_selector("#gx-wrap", timeout=15000)
        page.wait_for_function(
            "() => { const el = document.querySelector('#gx-contagem-viva'); return el && /[1-9]/.test(el.textContent); }",
            timeout=15000,
        )
    btn_3d = page.locator('.alternador-vista button[data-gx-vista="3d"]')
    if btn_3d.count() > 0 and btn_3d.get_attribute("aria-pressed") != "true":
        btn_3d.click()
        page.wait_for_timeout(100)


def get_webgl_status(page: Page) -> dict:
    """Retorna metadados do contexto WebGL montado dentro de #gx-wrap."""
    return page.evaluate("""() => {
        const wrap = document.querySelector('#gx-wrap');
        if (!wrap) return { found: false, error: 'no #gx-wrap' };
        const canvases = Array.from(wrap.querySelectorAll('canvas'));
        for (const cv of canvases) {
            const isVisible = cv.offsetWidth > 0 && cv.offsetHeight > 0 && cv.style.display !== 'none' && !cv.hidden;
            if (isVisible) {
                const gl2 = cv.getContext('webgl2');
                const gl1 = cv.getContext('webgl') || cv.getContext('experimental-webgl');
                const gl = gl2 || gl1;
                if (gl) {
                    return {
                        found: true,
                        id: cv.id,
                        isWebGL2: !!gl2,
                        isContextLost: gl.isContextLost ? gl.isContextLost() : false,
                        renderer: gl.getParameter(gl.RENDERER),
                        version: gl.getParameter(gl.VERSION),
                        canvasWidth: cv.width,
                        canvasHeight: cv.height,
                        clientWidth: cv.clientWidth,
                        clientHeight: cv.clientHeight
                    };
                }
            }
        }
        return { found: false, error: 'no visible canvas with webgl context' };
    }""")


def simulate_orbit_drag(page: Page, dx: int = 80, dy: int = 40) -> None:
    """Simula arrasto orbital com botão esquerdo do mouse sobre o canvas 3D."""
    cv = get_3d_canvas(page)
    box = cv.bounding_box()
    assert box is not None, "Canvas não encontrado para arrasto orbital"
    cx = box["x"] + box["width"] / 2
    cy = box["y"] + box["height"] / 2
    page.mouse.move(cx, cy)
    page.mouse.down(button="left")
    page.mouse.move(cx + dx, cy + dy, steps=5)
    page.mouse.up(button="left")
    page.wait_for_timeout(100)


def simulate_pan_drag(page: Page, dx: int = 60, dy: int = 30) -> None:
    """Simula translação (pan) com Shift+botão esquerdo sobre o canvas 3D."""
    cv = get_3d_canvas(page)
    box = cv.bounding_box()
    assert box is not None, "Canvas não encontrado para translação"
    cx = box["x"] + box["width"] / 2
    cy = box["y"] + box["height"] / 2
    page.keyboard.down("Shift")
    page.mouse.move(cx, cy)
    page.mouse.down(button="left")
    page.mouse.move(cx + dx, cy + dy, steps=5)
    page.mouse.up(button="left")
    page.keyboard.up("Shift")
    page.wait_for_timeout(100)


def simulate_wheel_zoom(page: Page, delta_y: int = -300) -> None:
    """Simula zoom via rotação da roda do mouse (dolly zoom) sobre o canvas 3D."""
    cv = get_3d_canvas(page)
    box = cv.bounding_box()
    assert box is not None, "Canvas não encontrado para zoom por roda"
    cx = box["x"] + box["width"] / 2
    cy = box["y"] + box["height"] / 2
    page.mouse.move(cx, cy)
    page.mouse.wheel(0, delta_y)
    page.wait_for_timeout(100)


def hover_center_node(page: Page, offset_x: int = 0, offset_y: int = 0) -> None:
    """Move o ponteiro para a área de nós para engatilhar o tooltip de inspeção."""
    cv = get_3d_canvas(page)
    box = cv.bounding_box()
    assert box is not None, "Canvas não encontrado para hover"
    cx = box["x"] + box["width"] / 2
    cy = box["y"] + box["height"] / 2

    if offset_x != 0 or offset_y != 0:
        page.mouse.move(cx + offset_x, cy + offset_y)
        page.wait_for_timeout(100)
        return

    # Procura um nó navegando pelo cluster em grade rápida até acionar o tooltip
    for dy in [-100, -60, -20, 20, 60, 100]:
        for dx in [-100, -60, -20, 20, 60, 100]:
            page.mouse.move(cx + dx, cy + dy)
            page.wait_for_timeout(35)
            vis = page.evaluate("""() => {
                const d = document.querySelector('#gx-dica');
                return d && !d.hidden && d.textContent.trim().length > 0;
            }""")
            if vis:
                return


def set_slider_value(page: Page, slider_id: str, value: str) -> None:
    """Ajusta o valor de um slider de faixa via DOM e despacha o evento 'input'."""
    page.evaluate(f"""() => {{
        const el = document.querySelector('#{slider_id}');
        if (el) {{
            el.value = '{value}';
            el.dispatchEvent(new Event('input', {{ bubbles: true }}));
        }}
    }}""")
    page.wait_for_timeout(80)


def set_z_elevation_mode(page: Page, mode: str) -> bool:
    """Alterna o eixo de elevação Z ('fsp3', 'clogp', 'mw', 'domo')."""
    # 1. Tenta dropdown select (#gx-sel-z ou similar)
    sel = page.locator("#gx-sel-z, #gx-eixo-z, select[data-gx-eixo-z]")
    if sel.count() > 0 and sel.is_visible():
        sel.select_option(mode)
        sel.dispatch_event("change")
        page.wait_for_timeout(100)
        return True

    # 2. Tenta botão com atributo de dados
    btn = page.locator(f'[data-gx-eixo-z="{mode}"]')
    if btn.count() > 0 and btn.is_visible():
        btn.click()
        page.wait_for_timeout(100)
        return True

    # 3. Invoca API do motor diretamente caso exposta na instância
    return page.evaluate("""(m) => {
        if (window.__gx3d && typeof window.__gx3d.definirEixoZ === 'function') {
            window.__gx3d.definirEixoZ(m);
            return true;
        }
        const wrap = document.querySelector('#gx-wrap');
        if (wrap && wrap.__gx3d && typeof wrap.__gx3d.definirEixoZ === 'function') {
            wrap.__gx3d.definirEixoZ(m);
            return true;
        }
        return false;
    }""", mode)


def reset_filters_and_camera(page: Page) -> None:
    """Redefine todos os filtros do painel lateral e a câmera para o estado inicial."""
    ensure_3d_mode(page)

    # Limpa busca textual
    page.evaluate("""() => {
        const q = document.querySelector('#gx-q');
        if (q && q.value) {
            q.value = '';
            q.dispatchEvent(new Event('input', { bubbles: true }));
        }
    }""")

    # Desmarca o filtro de coleta amazônica declarada
    coleta = page.locator("#gx-coleta")
    if coleta.count() > 0 and coleta.is_checked():
        coleta.uncheck()

    # Redefine sliders
    set_slider_value(page, "gx-mw", "1200")
    set_slider_value(page, "gx-lp", "10")
    set_slider_value(page, "gx-tp", "350")
    set_slider_value(page, "gx-f3", "0")

    # Restaura lente cromática padrão (classe)
    btn_lente = page.locator('.chips button[data-gx-lente="classe"]')
    if btn_lente.count() > 0 and btn_lente.get_attribute("aria-pressed") != "true":
        btn_lente.click()

    # Restaura esqueleto para "Todos"
    btn_scaf = page.locator('[data-gx-scaf="-1"]')
    if btn_scaf.count() > 0 and btn_scaf.get_attribute("aria-pressed") != "true":
        btn_scaf.click()

    # Restaura câmera via botão de reset
    btn_reset = page.locator('[data-gx-reset], [data-gx-reset="1"]')
    if btn_reset.count() > 0 and btn_reset.is_visible():
        btn_reset.click()

    # Garante que filamentos TMAP estão ligados
    btn_tmap = page.locator("#gx-btn-tmap")
    if btn_tmap.count() > 0 and btn_tmap.get_attribute("aria-pressed") != "true":
        btn_tmap.click()

    # Limpa estado de hover
    cv = get_3d_canvas(page)
    if cv.count() > 0 and cv.is_visible():
        cv.dispatch_event("pointerleave")
    page.wait_for_timeout(80)


@pytest.fixture(autouse=True)
def clean_state(base_page: Page):
    """Fixture de reset automático executada antes de cada caso de teste."""
    reset_filters_and_camera(base_page)
    yield


# ═══════════════════════════════════════════════════════════════════════════════
# TIER 1: FEATURE COVERAGE (25 TEST CASES)
# ═══════════════════════════════════════════════════════════════════════════════

class TestTier1FeatureCoverage:
    """Verifica a cobertura de requisitos essenciais para as 5 funcionalidades do projeto."""

    # ── Feature 1: Visualizador 3D e Alternador de Vistas ───────────────────────

    def test_t1_f1_01_3d_toggle_button_exists_in_view_switcher(self, base_page: Page):
        """O alternador de vistas deve conter o botão específico para ativar o Espaço 3D."""
        btn_3d = base_page.locator('.alternador-vista button[data-gx-vista="3d"]')
        assert btn_3d.count() == 1, "Botão [data-gx-vista='3d'] deve estar presente no .alternador-vista"
        texto = btn_3d.text_content() or ""
        assert "3D" in texto or "3d" in texto.lower(), f"Texto do botão deve mencionar 3D: '{texto}'"

    def test_t1_f1_02_3d_mode_activation_and_aria_pressed(self, base_page: Page):
        """Ao clicar no botão 3D, aria-pressed deve tornar-se true e o palco 3D deve ficar ativo."""
        btn_3d = base_page.locator('.alternador-vista button[data-gx-vista="3d"]')
        btn_3d.click()
        assert btn_3d.get_attribute("aria-pressed") == "true", "Botão 3D deve ter aria-pressed='true'"
        btn_2d = base_page.locator('.alternador-vista button[data-gx-vista="canvas"]')
        assert btn_2d.get_attribute("aria-pressed") == "false", "Botão 2D deve ter aria-pressed='false'"
        btn_tab = base_page.locator('.alternador-vista button[data-gx-vista="tabela"]')
        assert btn_tab.get_attribute("aria-pressed") == "false", "Botão Tabela deve ter aria-pressed='false'"

    def test_t1_f1_03_webgl_canvas_mounts_in_wrap_with_valid_context(self, base_page: Page):
        """O canvas WebGL deve estar montado dentro de #gx-wrap com contexto WebGL válido."""
        ensure_3d_mode(base_page)
        info = get_webgl_status(base_page)
        assert info.get("found") is True, f"Nenhum canvas com contexto WebGL ativo encontrado: {info}"
        assert info.get("isContextLost") is False, "O contexto WebGL não pode estar perdido"
        assert info.get("canvasWidth", 0) > 0, "Largura do canvas WebGL deve ser maior que zero"
        assert info.get("canvasHeight", 0) > 0, "Altura do canvas WebGL deve ser maior que zero"

    def test_t1_f1_04_initial_molecule_count_displays_dataset_total(self, base_page: Page):
        """A contagem inicial de moléculas no HUD deve refletir a totalidade do conjunto instalado."""
        ensure_3d_mode(base_page)
        count = get_visible_count(base_page)
        assert count == TOTAL_MOLECULAS, f"Contagem inicial esperada: {TOTAL_MOLECULAS}; obtido: {count}"

    def test_t1_f1_05_floating_controls_and_hud_accessible_in_3d(self, base_page: Page):
        """Os controles flutuantes de aproximação, afastamento, reset e TMAP devem estar visíveis."""
        ensure_3d_mode(base_page)
        assert base_page.locator("#gx-contagem-viva").is_visible(), "Contagem viva deve estar visível"
        assert base_page.locator('[data-gx-z="1.35"]').is_visible(), "Botão de aproximar (+) deve estar visível"
        assert base_page.locator('[data-gx-z="0.74"]').is_visible(), "Botão de afastar (-) deve estar visível"
        assert base_page.locator('[data-gx-reset]').is_visible(), "Botão de resetar câmera (0) deve estar visível"
        assert base_page.locator("#gx-btn-tmap").is_visible(), "Botão de filamentos TMAP deve estar visível"

    # ── Feature 2: Controles de Câmera 3D (Órbita, Pan, Zoom, Reset) ───────────

    def test_t1_f2_01_mouse_drag_orbits_camera(self, base_page: Page):
        """Arrastar com o botão esquerdo deve atualizar os ângulos orbitais da câmera 3D."""
        ensure_3d_mode(base_page)
        simulate_orbit_drag(base_page, dx=120, dy=60)
        info = get_webgl_status(base_page)
        assert info.get("found") is True, "WebGL deve continuar ativo após rotação da câmera"

    def test_t1_f2_02_mouse_wheel_dolly_zoom(self, base_page: Page):
        """A rotação da roda do mouse deve executar dolly zoom no espaço 3D."""
        ensure_3d_mode(base_page)
        simulate_wheel_zoom(base_page, delta_y=-350)
        simulate_wheel_zoom(base_page, delta_y=350)
        info = get_webgl_status(base_page)
        assert info.get("found") is True, "WebGL deve responder ao evento wheel sem falhas"

    def test_t1_f2_03_floating_zoom_buttons_step_camera(self, base_page: Page):
        """Clicar nos botões flutuantes '+' e '−' deve alterar a aproximação da câmera."""
        ensure_3d_mode(base_page)
        base_page.locator('[data-gx-z="1.35"]').click()
        base_page.wait_for_timeout(80)
        base_page.locator('[data-gx-z="0.74"]').click()
        base_page.wait_for_timeout(80)
        assert get_3d_canvas(base_page).is_visible()

    def test_t1_f2_04_reset_button_restores_canonical_perspective(self, base_page: Page):
        """Clicar no botão '0' (reset) deve restaurar a câmera para a perspectiva canônica."""
        ensure_3d_mode(base_page)
        simulate_orbit_drag(base_page, dx=200, dy=100)
        simulate_wheel_zoom(base_page, delta_y=-500)
        base_page.locator('[data-gx-reset]').click()
        base_page.wait_for_timeout(150)
        info = get_webgl_status(base_page)
        assert info.get("found") is True

    def test_t1_f2_05_keyboard_navigation_controls_camera(self, base_page: Page):
        """As teclas direcionais e '+', '-', '0' devem controlar a câmera quando o canvas tem foco."""
        ensure_3d_mode(base_page)
        cv = get_3d_canvas(base_page)
        cv.focus()
        base_page.keyboard.press("ArrowLeft")
        base_page.keyboard.press("ArrowUp")
        base_page.keyboard.press("+")
        base_page.keyboard.press("-")
        base_page.keyboard.press("0")
        base_page.wait_for_timeout(100)
        assert cv.is_visible()

    # ── Feature 3: Inspeção Científica e Tooltip com Estrutura 2D ───────────────

    def test_t1_f3_01_molecule_hover_displays_tooltip(self, base_page: Page):
        """Mover o cursor sobre um ponto do espaço químico deve exibir o tooltip #gx-dica."""
        ensure_3d_mode(base_page)
        hover_center_node(base_page)
        dica = base_page.locator("#gx-dica")
        assert dica.count() == 1, "Elemento #gx-dica deve existir no DOM"
        visivel = base_page.evaluate("""() => {
            const d = document.querySelector('#gx-dica');
            return d && !d.hidden && window.getComputedStyle(d).display !== 'none';
        }""")
        assert visivel, "#gx-dica deve estar visível ao pairar sobre molécula"

    def test_t1_f3_02_tooltip_displays_chemical_metadata_and_properties(self, base_page: Page):
        """O tooltip deve conter nome da molécula, classe e propriedades físico-químicas."""
        ensure_3d_mode(base_page)
        hover_center_node(base_page)
        texto = base_page.locator("#gx-dica").text_content() or ""
        assert len(texto) > 10, "Tooltip deve conter texto descritivo da molécula"
        assert any(k in texto for k in ["cLogP", "Fsp³", "Fsp3", "Da", "NP"]), f"Metadados ausentes no tooltip: '{texto}'"

    def test_t1_f3_03_tooltip_contains_2d_svg_structure_preview(self, base_page: Page):
        """O tooltip deve incorporar a estrutura química 2D (tag img vinculada a SVG)."""
        ensure_3d_mode(base_page)
        hover_center_node(base_page)
        img = base_page.locator("#gx-dica img")
        assert img.count() >= 1, "Tooltip deve conter elemento img para a representação bidimensional"

    def test_t1_f3_04_moving_pointer_away_hides_tooltip(self, base_page: Page):
        """Ao afastar o cursor para fora do canvas, o tooltip #gx-dica deve ser ocultado."""
        ensure_3d_mode(base_page)
        hover_center_node(base_page)
        cv = get_3d_canvas(base_page)
        cv.dispatch_event("pointerleave")
        base_page.wait_for_timeout(100)
        oculto = base_page.evaluate("""() => {
            const d = document.querySelector('#gx-dica');
            return !d || d.hidden || window.getComputedStyle(d).display === 'none';
        }""")
        assert oculto, "Tooltip deve ser ocultado quando o cursor deixa a área dos nós"

    def test_t1_f3_05_clicking_molecule_navigates_to_dossier(self, base_page: Page):
        """Clicar em uma molécula sob foco deve alterar a rota para #/molecula/<id>."""
        ensure_3d_mode(base_page)
        hover_center_node(base_page)
        cv = get_3d_canvas(base_page)
        cv.click()
        base_page.wait_for_timeout(300)
        url_atual = base_page.url
        assert "#/molecula/" in url_atual, f"A rota deveria ter navegado para um dossiê de molécula: {url_atual}"
        base_page.goto(url_atual.split("#")[0] + "#/galaxia")
        base_page.wait_for_selector("#gx-wrap", timeout=15000)
        ensure_3d_mode(base_page)

    # ── Feature 4: Filtragem Interativa, Lentes Cromáticas e Sliders ───────────

    def test_t1_f4_01_chromatic_lens_switching_updates_legend_and_render(self, base_page: Page):
        """Alternar lentes cromáticas deve atualizar a legenda e o esquema de cores dos pontos."""
        ensure_3d_mode(base_page)
        for lente in ["procedencia", "potencia", "npl", "fase", "pains", "classe"]:
            btn = base_page.locator(f'.chips button[data-gx-lente="{lente}"]')
            btn.click()
            assert btn.get_attribute("aria-pressed") == "true", f"Lente {lente} deve estar ativa"
            legenda = base_page.locator("#gx-legenda").text_content() or ""
            assert len(legenda) > 0, f"Legenda não deve estar vazia para a lente {lente}"

    def test_t1_f4_02_search_query_filters_galaxy_and_updates_live_counter(self, base_page: Page):
        """Buscar por termo químico ('Quercetin') deve reduzir a contagem viva de nós visíveis."""
        ensure_3d_mode(base_page)
        base_page.locator("#gx-q").fill("Quercetin")
        base_page.locator("#gx-q").dispatch_event("input")
        base_page.wait_for_timeout(150)
        cont = get_visible_count(base_page)
        assert 0 < cont < TOTAL_MOLECULAS, f"A busca por Quercetin deve filtrar o espaço químico: obtido {cont}"

    def test_t1_f4_03_mw_slider_filters_molecules_by_mass(self, base_page: Page):
        """Ajustar o slider de massa molecular máxima (MW) deve restringir as moléculas exibidas."""
        ensure_3d_mode(base_page)
        set_slider_value(base_page, "gx-mw", "400")
        assert "400" in (base_page.locator("#gx-mw-v").text_content() or "")
        cont = get_visible_count(base_page)
        assert 0 < cont < TOTAL_MOLECULAS, f"Filtro de MW <= 400 deve diminuir moléculas: obtido {cont}"

    def test_t1_f4_04_fsp3_slider_filters_molecules_by_saturation(self, base_page: Page):
        """Ajustar o slider de saturação 3D (Fsp3 mínimo) deve restringir o espaço a nós saturados."""
        ensure_3d_mode(base_page)
        set_slider_value(base_page, "gx-f3", "0.4")
        assert "0,4" in (base_page.locator("#gx-f3-v").text_content() or "") or "0.4" in (base_page.locator("#gx-f3-v").text_content() or "")
        cont = get_visible_count(base_page)
        assert 0 < cont < TOTAL_MOLECULAS, f"Filtro Fsp3 >= 0.4 deve restringir o espaço: obtido {cont}"

    def test_t1_f4_05_bemis_murcko_scaffold_chips_filter_galaxy(self, base_page: Page):
        """Selecionar um chip de esqueleto de Bemis–Murcko deve isolar a família estrutural."""
        ensure_3d_mode(base_page)
        chips = base_page.locator('[data-gx-scaf]:not([data-gx-scaf="-1"])')
        assert chips.count() > 0, "Chips de esqueletos de Bemis–Murcko devem estar presentes"
        primeiro_chip = chips.first
        primeiro_chip.click()
        assert primeiro_chip.get_attribute("aria-pressed") == "true"
        cont = get_visible_count(base_page)
        assert 0 < cont < TOTAL_MOLECULAS, f"Seleção de scaffold deve isolar subconjunto: obtido {cont}"

    # ── Feature 5: Performance, Elevação Z e Aderência a CSP ──────────────────

    def test_t1_f5_01_zero_csp_violations_and_clean_console(self, base_page: Page):
        """O carregamento e execução do visualizador 3D não podem gerar violações de CSP ou erros JS."""
        erros_console = []
        base_page.on("console", lambda msg: erros_console.append(msg.text) if msg.type in ["error"] and "favicon" not in msg.text else None)
        ensure_3d_mode(base_page)
        simulate_orbit_drag(base_page, 50, 50)
        assert not any("Content-Security-Policy" in err or "eval" in err for err in erros_console), \
            f"Violações de CSP detectadas no console: {erros_console}"

    def test_t1_f5_02_tmap_filament_toggle_controls_edge_visibility(self, base_page: Page):
        """O botão #gx-btn-tmap deve alternar o estado dos filamentos TMAP com aria-pressed."""
        ensure_3d_mode(base_page)
        btn_tmap = base_page.locator("#gx-btn-tmap")
        btn_tmap.click()
        assert btn_tmap.get_attribute("aria-pressed") == "false"
        btn_tmap.click()
        assert btn_tmap.get_attribute("aria-pressed") == "true"

    def test_t1_f5_03_z_axis_elevation_selector_mode_switching(self, base_page: Page):
        """Deve ser possível comutar o modo de elevação Z entre saturação, lipofilia, massa e domo."""
        ensure_3d_mode(base_page)
        for modo in ["fsp3", "clogp", "mw", "domo"]:
            sucesso = set_z_elevation_mode(base_page, modo)
            assert sucesso, f"Falha ao alternar eixo Z para modo '{modo}'"
        set_z_elevation_mode(base_page, "fsp3")

    def test_t1_f5_04_canvas_resizes_responsively_on_container_change(self, base_page: Page):
        """O canvas WebGL deve redimensionar seu buffer quando o container tem tamanho alterado."""
        ensure_3d_mode(base_page)
        w_inicial = base_page.evaluate("() => document.querySelector('#gx-cv-3d')?.width")
        base_page.set_viewport_size({"width": 500, "height": 600})
        base_page.wait_for_function("w => document.querySelector('#gx-cv-3d')?.width !== w", arg=w_inicial, timeout=5000)
        w_final = base_page.evaluate("() => document.querySelector('#gx-cv-3d')?.width")
        assert w_final < w_inicial, f"Largura do canvas deveria ter diminuído: inicial {w_inicial}, final {w_final}"
        base_page.set_viewport_size({"width": 1280, "height": 800})
        base_page.wait_for_function("w => document.querySelector('#gx-cv-3d')?.width !== w", arg=w_final, timeout=5000)

    def test_t1_f5_05_webgl_context_loss_event_registered(self, base_page: Page):
        """O canvas WebGL deve suportar ciclo de vida e tratamento de perda de contexto."""
        ensure_3d_mode(base_page)
        tem_suporte = base_page.evaluate("""() => {
            const cv = document.querySelector('#gx-cv-3d') || document.querySelector('#gx-wrap canvas');
            return cv && typeof cv.addEventListener === 'function';
        }""")
        assert tem_suporte, "Canvas WebGL deve permitir registro de listeners de contexto"


# ═══════════════════════════════════════════════════════════════════════════════
# TIER 2: BOUNDARY & CORNER CASES (25 TEST CASES)
# ═══════════════════════════════════════════════════════════════════════════════

class TestTier2BoundaryAndEdgeCases:
    """Verifica condições de fronteira, entradas extremas e robustez a falhas de estado."""

    # ── Feature 1 Boundaries ───────────────────────────────────────────────────

    def test_t2_f1_01_rapid_view_switching_3d_2d_table(self, base_page: Page):
        """Alternar rapidamente entre 3D, 2D e Tabela não deve causar erro ou travar o motor."""
        vistas = ["3d", "canvas", "tabela", "3d", "canvas", "3d"]
        for v in vistas:
            base_page.locator(f'.alternador-vista button[data-gx-vista="{v}"]').click()
            base_page.wait_for_timeout(50)
        btn_3d = base_page.locator('.alternador-vista button[data-gx-vista="3d"]')
        assert btn_3d.get_attribute("aria-pressed") == "true"
        info = get_webgl_status(base_page)
        assert info.get("found") is True

    def test_t2_f1_02_extreme_mobile_viewport_320x480(self, base_page: Page):
        """Em viewport móvel extremo (320x480), o canvas 3D deve inicializar sem transbordamento."""
        base_page.set_viewport_size({"width": 320, "height": 480})
        base_page.wait_for_timeout(200)
        ensure_3d_mode(base_page)
        info = get_webgl_status(base_page)
        assert info.get("found") is True
        assert info.get("canvasWidth", 0) > 0
        base_page.set_viewport_size({"width": 1280, "height": 800})
        base_page.wait_for_timeout(200)

    def test_t2_f1_03_ultra_wide_4k_viewport_3840x2160(self, base_page: Page):
        """Em resolução 4K (3840x2160), o clamp de DPR deve evitar estouro de memória da GPU."""
        base_page.set_viewport_size({"width": 3840, "height": 2160})
        base_page.wait_for_timeout(200)
        ensure_3d_mode(base_page)
        info = get_webgl_status(base_page)
        assert info.get("found") is True
        base_page.set_viewport_size({"width": 1280, "height": 800})
        base_page.wait_for_timeout(200)

    def test_t2_f1_04_tab_visibility_change_and_animation_lifecycle(self, base_page: Page):
        """Simular aba oculta via document.visibilitychange deve desacelerar/pausar o loop de render."""
        ensure_3d_mode(base_page)
        base_page.evaluate("""() => {
            Object.defineProperty(document, 'hidden', { value: true, configurable: true });
            document.dispatchEvent(new Event('visibilitychange'));
        }""")
        base_page.wait_for_timeout(100)
        base_page.evaluate("""() => {
            Object.defineProperty(document, 'hidden', { value: false, configurable: true });
            document.dispatchEvent(new Event('visibilitychange'));
        }""")
        base_page.wait_for_timeout(100)
        info = get_webgl_status(base_page)
        assert info.get("found") is True

    def test_t2_f1_05_reduced_motion_preference_honored(self, base_page: Page):
        """Configurar preferência de movimento reduzido deve suspender transições de inércia."""
        base_page.evaluate("() => { document.documentElement.dataset.movimento = 'pausado'; }")
        ensure_3d_mode(base_page)
        simulate_orbit_drag(base_page, 50, 50)
        base_page.evaluate("() => { delete document.documentElement.dataset.movimento; }")
        info = get_webgl_status(base_page)
        assert info.get("found") is True

    # ── Feature 2 Boundaries ───────────────────────────────────────────────────

    def test_t2_f2_01_drag_below_threshold_does_not_pan_or_orbit(self, base_page: Page):
        """Movimentos de ponteiro inferiores ao limiar de arrasto (<= 3px) não devem mover a cena."""
        ensure_3d_mode(base_page)
        cv = get_3d_canvas(base_page)
        box = cv.bounding_box()
        assert box is not None
        cx, cy = box["x"] + box["width"] / 2, box["y"] + box["height"] / 2
        base_page.mouse.move(cx, cy)
        base_page.mouse.down()
        base_page.mouse.move(cx + 2, cy + 2)
        base_page.mouse.up()
        info = get_webgl_status(base_page)
        assert info.get("found") is True

    def test_t2_f2_02_extreme_zoom_in_clamping(self, base_page: Page):
        """Aplicar zoom excessivo com delta muito negativo deve ser contido pelo clamp superior."""
        ensure_3d_mode(base_page)
        for _ in range(5):
            simulate_wheel_zoom(base_page, delta_y=-1000)
        info = get_webgl_status(base_page)
        assert info.get("found") is True

    def test_t2_f2_03_extreme_zoom_out_clamping(self, base_page: Page):
        """Aplicar afastamento excessivo deve ser contido pelo clamp inferior para não inverter cena."""
        ensure_3d_mode(base_page)
        for _ in range(5):
            simulate_wheel_zoom(base_page, delta_y=1000)
        info = get_webgl_status(base_page)
        assert info.get("found") is True

    def test_t2_f2_04_pan_boundary_limits_prevent_disappearance(self, base_page: Page):
        """Transladar a galáxia para fora da tela e acionar reset deve recuperá-la imediatamente."""
        ensure_3d_mode(base_page)
        simulate_pan_drag(base_page, dx=800, dy=600)
        base_page.locator('[data-gx-reset]').click()
        base_page.wait_for_timeout(100)
        info = get_webgl_status(base_page)
        assert info.get("found") is True

    def test_t2_f2_05_rapid_conflicting_keyboard_inputs(self, base_page: Page):
        """Pressões simultâneas e conflitantes de teclas direcionais não devem gerar exceções."""
        ensure_3d_mode(base_page)
        cv = get_3d_canvas(base_page)
        cv.focus()
        for k in ["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "+", "-", "0"]:
            base_page.keyboard.press(k)
        info = get_webgl_status(base_page)
        assert info.get("found") is True

    # ── Feature 3 Boundaries ───────────────────────────────────────────────────

    def test_t2_f3_01_hover_near_viewport_edges_keeps_tooltip_on_screen(self, base_page: Page):
        """Hover em nós situados na borda do canvas deve manter o tooltip contido na área visível."""
        ensure_3d_mode(base_page)
        cv = get_3d_canvas(base_page)
        box = cv.bounding_box()
        assert box is not None
        base_page.mouse.move(box["x"] + box["width"] - 20, box["y"] + box["height"] - 20)
        base_page.wait_for_timeout(100)
        left = base_page.evaluate("() => parseFloat(document.querySelector('#gx-dica')?.style.left || '0')")
        assert left <= box["width"], "Posição left do tooltip não deve extrapolar largura"

    def test_t2_f3_02_rapid_pointer_movement_across_nodes(self, base_page: Page):
        """Varrer o ponteiro rapidamente sobre a cena deve atualizar o tooltip sem corrupção."""
        ensure_3d_mode(base_page)
        cv = get_3d_canvas(base_page)
        box = cv.bounding_box()
        assert box is not None
        for i in range(10):
            base_page.mouse.move(box["x"] + 100 + i * 20, box["y"] + 150 + i * 10)
        base_page.wait_for_timeout(100)
        assert cv.is_visible()

    def test_t2_f3_03_molecule_without_structure_svg_graceful_render(self, base_page: Page):
        """O tooltip deve renderizar perfeitamente mesmo que uma molécula não possua representação SVG."""
        ensure_3d_mode(base_page)
        hover_center_node(base_page)
        dica = base_page.locator("#gx-dica")
        assert dica.is_visible()

    def test_t2_f3_04_pointer_leave_canvas_clears_selection_state(self, base_page: Page):
        """Quando o cursor sai do canvas, o índice de foco interno deve ser limpo."""
        ensure_3d_mode(base_page)
        hover_center_node(base_page)
        cv = get_3d_canvas(base_page)
        cv.dispatch_event("pointerleave")
        base_page.wait_for_timeout(100)
        oculto = base_page.evaluate("() => document.querySelector('#gx-dica')?.hidden")
        assert oculto is True

    def test_t2_f3_05_click_on_empty_space_does_not_navigate(self, base_page: Page):
        """Clicar em uma região vazia do espaço 3D (sem nó) não deve disparar navegação."""
        ensure_3d_mode(base_page)
        cv = get_3d_canvas(base_page)
        box = cv.bounding_box()
        assert box is not None
        cv.dispatch_event("pointerleave")
        base_page.wait_for_timeout(50)
        base_page.mouse.click(box["x"] + 15, box["y"] + 15)
        base_page.wait_for_timeout(200)
        assert base_page.url.endswith("#/galaxia"), f"Não deveria navegar: {base_page.url}"

    # ── Feature 4 Boundaries ───────────────────────────────────────────────────

    def test_t2_f4_01_search_query_with_no_matches_displays_zero_visivel(self, base_page: Page):
        """Buscar por termo inexistente deve resultar em exatamente 0 moléculas visíveis."""
        ensure_3d_mode(base_page)
        base_page.locator("#gx-q").fill("XYZTERMO_TOTALMENTE_INEXISTENTE_999")
        base_page.locator("#gx-q").dispatch_event("input")
        base_page.wait_for_timeout(150)
        cont = get_visible_count(base_page)
        assert cont == 0, f"Deveria exibir 0 moléculas: obtido {cont}"

    def test_t2_f4_02_search_query_with_regex_metacharacters(self, base_page: Page):
        """Buscar metacaracteres de regex (ex: '.*+?^${}()|[]\\') não deve quebrar o filtro."""
        ensure_3d_mode(base_page)
        base_page.locator("#gx-q").fill(".*+?^${}()|[]\\")
        base_page.locator("#gx-q").dispatch_event("input")
        base_page.wait_for_timeout(150)
        cont = get_visible_count(base_page)
        assert cont >= 0, "Filtro deve processar busca com caracteres especiais sem erro"

    def test_t2_f4_03_sliders_at_absolute_minimum_boundaries(self, base_page: Page):
        """Ajustar todos os sliders para seus valores mínimos absolutos deve produzir contagem coerente."""
        ensure_3d_mode(base_page)
        set_slider_value(base_page, "gx-mw", "120")
        set_slider_value(base_page, "gx-lp", "-2")
        set_slider_value(base_page, "gx-tp", "20")
        set_slider_value(base_page, "gx-f3", "0.95")
        cont = get_visible_count(base_page)
        assert 0 <= cont < TOTAL_MOLECULAS

    def test_t2_f4_04_sliders_at_absolute_maximum_boundaries(self, base_page: Page):
        """Ajustar todos os sliders para valores máximos deve exibir todas as moléculas."""
        ensure_3d_mode(base_page)
        set_slider_value(base_page, "gx-mw", "1200")
        set_slider_value(base_page, "gx-lp", "10")
        set_slider_value(base_page, "gx-tp", "350")
        set_slider_value(base_page, "gx-f3", "0")
        cont = get_visible_count(base_page)
        assert cont == TOTAL_MOLECULAS

    def test_t2_f4_05_scaffold_reset_chip_restores_unfiltered_count(self, base_page: Page):
        """Selecionar um scaffold e depois clicar em 'Todos' ([data-gx-scaf='-1']) restaura o dataset."""
        ensure_3d_mode(base_page)
        chip = base_page.locator('[data-gx-scaf]:not([data-gx-scaf="-1"])').first
        chip.click()
        base_page.wait_for_timeout(80)
        assert get_visible_count(base_page) < TOTAL_MOLECULAS
        base_page.locator('[data-gx-scaf="-1"]').click()
        base_page.wait_for_timeout(80)
        assert get_visible_count(base_page) == TOTAL_MOLECULAS

    # ── Feature 5 Boundaries ───────────────────────────────────────────────────

    def test_t2_f5_01_coleta_declarada_checkbox_filter_boundary_toggle(self, base_page: Page):
        """Marcar e desmarcar o filtro de coleta amazônica declarada deve alternar os nós."""
        ensure_3d_mode(base_page)
        coleta = base_page.locator("#gx-coleta")
        coleta.check()
        base_page.wait_for_timeout(100)
        cont_restrito = get_visible_count(base_page)
        assert 0 < cont_restrito < TOTAL_MOLECULAS
        coleta.uncheck()
        base_page.wait_for_timeout(100)
        assert get_visible_count(base_page) == TOTAL_MOLECULAS

    def test_t2_f5_02_csv_export_with_active_filters_invoked(self, base_page: Page):
        """Clicar no botão de download CSV com filtros ativos deve disparar o download sem travar."""
        ensure_3d_mode(base_page)
        set_slider_value(base_page, "gx-mw", "400")
        base_page.locator("#gx-csv").click()
        base_page.wait_for_timeout(100)
        assert get_3d_canvas(base_page).is_visible()

    def test_t2_f5_03_all_chromatic_lenses_rapid_cycling(self, base_page: Page):
        """Alternar em sucessão rápida por todas as lentes cromáticas não deve desestabilizar o shader."""
        ensure_3d_mode(base_page)
        lentes = ["classe", "procedencia", "potencia", "npl", "fase", "pains"]
        for lente in lentes:
            base_page.locator(f'[data-gx-lente="{lente}"]').click()
            base_page.wait_for_timeout(40)
        info = get_webgl_status(base_page)
        assert info.get("found") is True

    def test_t2_f5_04_switching_z_axis_during_camera_movement(self, base_page: Page):
        """Alternar a elevação Z durante uma transição de câmera deve preservar o estado dos buffers."""
        ensure_3d_mode(base_page)
        simulate_orbit_drag(base_page, 60, 40)
        set_z_elevation_mode(base_page, "clogp")
        simulate_orbit_drag(base_page, -40, -30)
        set_z_elevation_mode(base_page, "fsp3")
        info = get_webgl_status(base_page)
        assert info.get("found") is True

    def test_t2_f5_05_webgl_canvas_dpi_scaling_clamped_to_2(self, base_page: Page):
        """A escala de DPI do canvas WebGL deve ser clamped a no máximo 2 para evitar saturação de fillrate."""
        ensure_3d_mode(base_page)
        res = base_page.evaluate("""() => {
            const cv = document.querySelector('#gx-cv-3d') || document.querySelector('#gx-wrap canvas');
            const dpr = Math.min(window.devicePixelRatio || 1, 2);
            return {
                cvWidth: cv.width,
                clientWidth: cv.clientWidth,
                expectedMax: Math.round(cv.clientWidth * 2 + 10)
            };
        }""")
        assert res["cvWidth"] <= res["expectedMax"], "Resolução do canvas WebGL não deve exceder DPR 2"


# ═══════════════════════════════════════════════════════════════════════════════
# TIER 3: CROSS-FEATURE COMBINATIONS (10 TEST CASES)
# ═══════════════════════════════════════════════════════════════════════════════

class TestTier3CrossFeatureCombinations:
    """Verifica combinações pareadas de funcionalidades interagindo simultaneamente no espaço 3D."""

    def test_t3_c01_search_query_combined_with_mw_slider_in_3d(self, base_page: Page):
        """Combinação: Busca textual por 'Alkaloids' conjugada com teto de Massa Molecular <= 400."""
        ensure_3d_mode(base_page)
        base_page.locator("#gx-q").fill("Alkaloids")
        base_page.locator("#gx-q").dispatch_event("input")
        set_slider_value(base_page, "gx-mw", "400")
        cont = get_visible_count(base_page)
        assert 0 < cont < TOTAL_MOLECULAS, "Interseção busca + MW deve filtrar o espaço químico"

    def test_t3_c02_search_query_combined_with_fsp3_saturation_slider_in_3d(self, base_page: Page):
        """Combinação: Busca textual por 'Flavon' conjugada com corte de saturação Fsp3 >= 0.20."""
        ensure_3d_mode(base_page)
        base_page.locator("#gx-q").fill("Flavon")
        base_page.locator("#gx-q").dispatch_event("input")
        set_slider_value(base_page, "gx-f3", "0.2")
        cont = get_visible_count(base_page)
        assert 0 < cont < TOTAL_MOLECULAS

    def test_t3_c03_potency_lens_combined_with_declared_collection_filter(self, base_page: Page):
        """Combinação: Lente de Potência pChEMBL conjugada com o filtro de coleta amazônica declarada."""
        ensure_3d_mode(base_page)
        base_page.locator('.chips button[data-gx-lente="potencia"]').click()
        base_page.locator("#gx-coleta").check()
        base_page.wait_for_timeout(100)
        cont = get_visible_count(base_page)
        assert 0 < cont < TOTAL_MOLECULAS
        assert "pChEMBL" in (base_page.locator("#gx-legenda").text_content() or "")

    def test_t3_c04_bemis_murcko_scaffold_with_z_axis_elevation_switch(self, base_page: Page):
        """Combinação: Filtro de esqueleto de Bemis-Murcko conjugado com mudança de elevação para cLogP."""
        ensure_3d_mode(base_page)
        base_page.locator('[data-gx-scaf]:not([data-gx-scaf="-1"])').first.click()
        set_z_elevation_mode(base_page, "clogp")
        simulate_orbit_drag(base_page, 40, 40)
        info = get_webgl_status(base_page)
        assert info.get("found") is True

    def test_t3_c05_tmap_filaments_hidden_with_active_camera_orbit(self, base_page: Page):
        """Combinação: Ocultar filamentos TMAP mantendo apenas nuvem de pontos durante órbita 3D."""
        ensure_3d_mode(base_page)
        btn_tmap = base_page.locator("#gx-btn-tmap")
        btn_tmap.click()  # Desativa
        assert btn_tmap.get_attribute("aria-pressed") == "false"
        simulate_orbit_drag(base_page, 100, 50)
        info = get_webgl_status(base_page)
        assert info.get("found") is True

    def test_t3_c06_fsp3_elevation_mode_with_fsp3_filter_boundary(self, base_page: Page):
        """Combinação: Elevação Z orientada a Fsp3 conjugada com filtro de Fsp3 >= 0.50."""
        ensure_3d_mode(base_page)
        set_z_elevation_mode(base_page, "fsp3")
        set_slider_value(base_page, "gx-f3", "0.5")
        cont = get_visible_count(base_page)
        assert 0 < cont < TOTAL_MOLECULAS

    def test_t3_c07_pains_alert_lens_with_search_filter(self, base_page: Page):
        """Combinação: Lente de Alertas PAINS conjugada com busca textual por 'Terpen'."""
        ensure_3d_mode(base_page)
        base_page.locator('.chips button[data-gx-lente="pains"]').click()
        base_page.locator("#gx-q").fill("Terpen")
        base_page.locator("#gx-q").dispatch_event("input")
        cont = get_visible_count(base_page)
        assert 0 <= cont < TOTAL_MOLECULAS
        assert "PAINS" in (base_page.locator("#gx-legenda").text_content() or "")

    def test_t3_c08_high_zoom_inspection_with_hover_raycasting(self, base_page: Page):
        """Combinação: Câmera com aproximação máxima seguida de inspeção por hover nos nós centrais."""
        ensure_3d_mode(base_page)
        for _ in range(4):
            base_page.locator('[data-gx-z="1.35"]').click()
            base_page.wait_for_timeout(50)
        hover_center_node(base_page)
        dica = base_page.locator("#gx-dica")
        assert dica.is_visible()

    def test_t3_c09_viewport_transition_3d_to_table_filter_persistence_back_to_3d(self, base_page: Page):
        """Combinação: Aplicar filtro no 3D, alternar para tabela, conferir persistência e retornar ao 3D."""
        ensure_3d_mode(base_page)
        set_slider_value(base_page, "gx-mw", "400")
        cont_3d = get_visible_count(base_page)

        # Alterna para modo tabela
        base_page.locator('.alternador-vista button[data-gx-vista="tabela"]').click()
        base_page.wait_for_timeout(100)
        linhas_tabela = base_page.locator("#gx-tabela tbody tr").count()
        assert linhas_tabela > 0, "Tabela deve conter linhas populadas respeitando o filtro ativo"

        # Retorna para o 3D
        base_page.locator('.alternador-vista button[data-gx-vista="3d"]').click()
        base_page.wait_for_timeout(100)
        assert get_visible_count(base_page) == cont_3d, "Contagem 3D deve persistir após voltar da tabela"

    def test_t3_c10_mobile_viewport_with_touch_drag_and_floating_zoom(self, base_page: Page):
        """Combinação: Resolução móvel (375x667) conjugada com arrasto orbital e zoom por botões flutuantes."""
        base_page.set_viewport_size({"width": 375, "height": 667})
        base_page.wait_for_timeout(150)
        ensure_3d_mode(base_page)
        simulate_orbit_drag(base_page, 50, 30)
        base_page.locator('[data-gx-z="1.35"]').click()
        base_page.wait_for_timeout(100)
        info = get_webgl_status(base_page)
        assert info.get("found") is True
        base_page.set_viewport_size({"width": 1280, "height": 800})
        base_page.wait_for_timeout(150)


# ═══════════════════════════════════════════════════════════════════════════════
# TIER 4: REAL-WORLD APPLICATION SCENARIOS (5 SCIENTIFIC WORKLOADS)
# ═══════════════════════════════════════════════════════════════════════════════

class TestTier4RealWorldScenarios:
    """Valida jornadas completas de cientistas utilizando a plataforma para descoberta de fármacos."""

    def test_t4_s01_natural_product_discovery_pipeline(self, base_page: Page):
        """Cenário 1: Pipeline de Descoberta de Produtos Naturais Bioativos da Amazônia.
        Fluxo: Filtrar por coleta amazônica declarada -> Aplicar lente de Potência -> Restringir peso molecular
        druglike (MW <= 600) -> Inspecionar nós e conferir tooltip com estrutura 2D.
        """
        ensure_3d_mode(base_page)

        # 1. Restringe a táxons com procedência estrita da Amazônia Legal
        base_page.locator("#gx-coleta").check()
        base_page.wait_for_timeout(80)

        # 2. Ativa lente cromática de potência in vitro
        base_page.locator('.chips button[data-gx-lente="potencia"]').click()
        base_page.wait_for_timeout(80)

        # 3. Restringe peso molecular para janela clássica de pequenas moléculas
        set_slider_value(base_page, "gx-mw", "600")

        # 4. Inspeciona nó bioativo no espaço 3D
        hover_center_node(base_page)
        dica = base_page.locator("#gx-dica")
        assert dica.is_visible(), "Tooltip deve abrir no fluxo de descoberta"
        texto = dica.text_content() or ""
        assert "pChEMBL" in texto or "cLogP" in texto or "Fsp³" in texto

    def test_t4_s02_3d_structural_saturation_escape_from_flatland(self, base_page: Page):
        """Cenário 2: Análise de Saturação Tridimensional ('Escape from Flatland').
        Fluxo: Elevar coordenada Z por Fsp3 -> Filtrar Fsp3 >= 0.40 -> Orbitar câmera para vista oblíqua
        -> Verificar estratificação vertical das moléculas tridimensionais sobre heterociclos planos.
        """
        ensure_3d_mode(base_page)

        # 1. Configura elevação orientada a Fsp3
        set_z_elevation_mode(base_page, "fsp3")

        # 2. Filtra moléculas com elevada tridimensionalidade (Fsp3 >= 0.40)
        set_slider_value(base_page, "gx-f3", "0.4")
        cont_saturadas = get_visible_count(base_page)
        assert 0 < cont_saturadas < TOTAL_MOLECULAS

        # 3. Orbita a cena para perspectiva oblíqua de relevo
        simulate_orbit_drag(base_page, dx=140, dy=70)
        info = get_webgl_status(base_page)
        assert info.get("found") is True

    def test_t4_s03_chemotype_scaffold_screening_and_clustering(self, base_page: Page):
        """Cenário 3: Triagem de Quimiotipos e Esqueletos Centrais de Bemis–Murcko.
        Fluxo: Selecionar esqueleto mais abundante -> Verificar clusterização de anéis -> Ligar/desligar
        filamentos TMAP para auditar conectividade quimiotípica.
        """
        ensure_3d_mode(base_page)

        # 1. Seleciona primeiro scaffold molecular
        scaf_btn = base_page.locator('[data-gx-scaf]:not([data-gx-scaf="-1"])').first
        scaf_btn.click()
        base_page.wait_for_timeout(80)
        cont_scaf = get_visible_count(base_page)
        assert 0 < cont_scaf < TOTAL_MOLECULAS

        # 2. Alterna filamentos TMAP para verificar árvore geradora mínima
        btn_tmap = base_page.locator("#gx-btn-tmap")
        btn_tmap.click()
        assert btn_tmap.get_attribute("aria-pressed") == "false"
        btn_tmap.click()
        assert btn_tmap.get_attribute("aria-pressed") == "true"

    def test_t4_s04_lead_likeness_pharmacophore_multi_slider_sweep(self, base_page: Page):
        """Cenário 4: Varredura Multifatorial de Regras de Lipinski / Lead-Likeness.
        Fluxo: MW <= 500 Da, cLogP <= 5.0, TPSA <= 140 A², Fsp3 >= 0.20 simultaneamente
        -> Verificar resposta instantânea do HUD e estabilidade do buffer GPU.
        """
        ensure_3d_mode(base_page)

        set_slider_value(base_page, "gx-mw", "500")
        set_slider_value(base_page, "gx-lp", "5")
        set_slider_value(base_page, "gx-tp", "140")
        set_slider_value(base_page, "gx-f3", "0.2")

        cont_lipinski = get_visible_count(base_page)
        assert 0 < cont_lipinski < TOTAL_MOLECULAS
        info = get_webgl_status(base_page)
        assert info.get("found") is True

    def test_t4_s05_multi_modal_view_switching_and_context_resilience(self, base_page: Page):
        """Cenário 5: Resiliência Multimodal e Recuperação de Contexto do Observatório.
        Fluxo: Iniciar em 3D -> Aplicar filtros -> Migrar para 2D -> Migrar para Tabela ->
        Exportar CSV -> Retornar ao 3D -> Simular redimensionamento dinâmico da janela.
        """
        ensure_3d_mode(base_page)
        set_slider_value(base_page, "gx-mw", "400")
        base_page.locator('.chips button[data-gx-lente="npl"]').click()
        cont_original = get_visible_count(base_page)

        # 1. 3D -> 2D Nebulosa
        base_page.locator('.alternador-vista button[data-gx-vista="canvas"]').click()
        base_page.wait_for_timeout(80)
        assert base_page.locator("#gx-wrap canvas:visible").count() >= 1

        # 2. 2D -> Tabela
        base_page.locator('.alternador-vista button[data-gx-vista="tabela"]').click()
        base_page.wait_for_timeout(80)
        assert base_page.locator("#gx-tabela").is_visible()

        # 3. Tabela -> 3D
        base_page.locator('.alternador-vista button[data-gx-vista="3d"]').click()
        base_page.wait_for_timeout(100)
        assert get_visible_count(base_page) == cont_original

        # 4. Redimensionamento de janela
        base_page.set_viewport_size({"width": 1024, "height": 768})
        base_page.wait_for_timeout(150)
        info = get_webgl_status(base_page)
        assert info.get("found") is True
        base_page.set_viewport_size({"width": 1280, "height": 800})
        base_page.wait_for_timeout(150)
