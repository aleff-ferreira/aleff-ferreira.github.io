# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Verificações estáticas do site (sem navegador): o que a CSP, a acessibilidade e a navegação exigem do código,
e o que entra — e o que nunca entra — no artefato `_site/` montado por `scripts/preparar_pages.py`."""
import gzip
import importlib.util
import json
import re
import tarfile
from pathlib import Path
from types import SimpleNamespace

import pytest

APP = Path(__file__).resolve().parent.parent.parent / "app"
RAIZ = APP.parent
JS = sorted((APP / "js").glob("*.js"))
JS_VIZ = sorted((APP / "js" / "viz").glob("*.js"))
TODOS_JS = JS + JS_VIZ
HTML = (APP / "index.html").read_text(encoding="utf-8")
CSS = (APP / "css" / "app.css").read_text(encoding="utf-8")


def test_importacoes_dos_modulos_existem():
    for arq in TODOS_JS:
        texto = arq.read_text(encoding="utf-8")
        for destino in re.findall(r"from\s+'(\.\.?/[^']+)'", texto):
            assert (arq.parent / destino).resolve().exists(), f"{arq.name} importa {destino}, que não existe"
        for dinamico in re.findall(r"import\(\s*'(\.\.?/[^']+)'\s*\)", texto):
            assert (arq.parent / dinamico).resolve().exists(), f"{arq.name} importa dinamicamente {dinamico}, que não existe"


def test_sem_manipulador_inline_nem_javascript_url():
    """A CSP (script-src 'self') bloqueia onclick=, onsubmit= etc.; usar addEventListener."""
    fontes = [HTML] + [a.read_text(encoding="utf-8") for a in TODOS_JS] + [(APP.parent / "nucleo" / "bmb" / "curadoria_ui" / "index.html").read_text(encoding="utf-8")]
    for t in fontes:
        assert not re.search(r"\son[a-z]+\s*=\s*[\"']", t), "manipulador de evento inline encontrado"
        assert "javascript:" not in t.lower()


def test_html_tem_o_que_a_acessibilidade_exige():
    assert '<html lang="pt-BR">' in HTML
    assert 'id="principal"' in HTML and 'class="pular"' in HTML and 'role="status"' in HTML and "aria-live" in HTML
    assert '<meta name="viewport"' in HTML and "Content-Security-Policy" in HTML
    assert 'role="combobox"' in HTML and 'aria-controls="sugestoes"' in HTML
    assert '<nav class="menu"' in HTML and 'aria-label="Seções do site"' in HTML
    assert "<noscript>" in HTML                                             # sem JS, os dados abertos continuam acessíveis


def test_css_respeita_movimento_contraste_e_temas():
    assert "prefers-reduced-motion: reduce" in CSS and "prefers-color-scheme: dark" in CSS and 'data-tema="escuro"' in CSS
    assert "forced-colors" in CSS and ":focus-visible" in CSS and "[hidden] { display: none !important; }" in CSS
    assert "@import" not in CSS and "fonts.googleapis" not in CSS and "url(http" not in CSS      # sem recurso remoto (meta de 400 kbps)


def _luminancia(hexa):
    r, g, b = (int(hexa[i:i + 2], 16) / 255 for i in (1, 3, 5))
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def _contraste(a, b):
    la, lb = _luminancia(a), _luminancia(b)
    claro, escuro = max(la, lb), min(la, lb)
    return (claro + 0.05) / (escuro + 0.05)


def _tokens(bloco):
    return dict(re.findall(r"--([a-z0-9-]+):\s*(#[0-9a-fA-F]{6})", bloco))


def test_contraste_aa_dos_pares_de_texto_nos_dois_temas():
    claro = _tokens(CSS.split("@media (prefers-color-scheme: dark)")[0])
    escuro = _tokens(re.search(r':root\[data-tema="escuro"\] \{(.*?)\n\}', CSS, re.S).group(1))
    pares = [("ink", "bg"), ("ink", "surface"), ("ink2", "bg"), ("ink3", "bg"), ("ink3", "surface"), ("rio", "surface"), ("verde", "surface"),
             ("on-verde", "verde"), ("alerta-ink", "alerta-bg"), ("ok-ink", "ok-bg"), ("argila", "argila-claro"), ("topo-ink", "topo-bg"),
             ("topo-ink2", "topo-bg")]
    for nome, tema in (("claro", claro), ("escuro", escuro)):
        base = {**claro, **tema} if nome == "escuro" else tema
        for fg, bg in pares:
            if fg in base and bg in base:
                c = _contraste(base[fg], base[bg])
                assert c >= 4.5, f"tema {nome}: {fg} sobre {bg} tem contraste {c:.2f} (< 4,5)"


def test_icones_usados_existem_no_sprite():
    sprite = set(re.findall(r'id="i-([a-z]+)"', HTML))
    usados = set()
    for arq in TODOS_JS:
        t = arq.read_text(encoding="utf-8")
        usados |= set(re.findall(r"icone\('([a-z]+)'", t))
        usados |= set(re.findall(r"ic: '([a-z]+)'", t))
        usados |= set(re.findall(r"icone: '([a-z]+)'", t))
        usados |= set(re.findall(r"#i-([a-z]+)", t))
    usados |= set(re.findall(r'href="#i-([a-z]+)"', HTML))
    assert usados - sprite == set(), f"ícones usados e ausentes do sprite: {sorted(usados - sprite)}"


def test_links_do_menu_tem_rota():
    main = (APP / "js" / "main.js").read_text(encoding="utf-8")
    for destino in re.findall(r'<a href="#(/[a-z]*)" data-vista', HTML):
        chave = destino if destino == "/" else destino
        assert (f"'{chave}'" in main) or (chave == "/" and "caminho === '/'" in main), f"rota {destino} sem tratamento em main.js"


def test_manifesto_e_icones_do_pwa():
    m = json.loads((APP / "manifest.webmanifest").read_text(encoding="utf-8"))
    assert m["lang"] == "pt-BR" and m["display"] == "standalone"
    for i in m["icons"]:
        assert (APP / i["src"]).exists(), i["src"]


def test_service_worker_nao_guarda_terceiros_e_lista_o_esqueleto():
    sw = (APP / "sw.js").read_text(encoding="utf-8")
    assert "url.origin !== location.origin" in sw
    for arq in JS:
        assert f"'js/{arq.name}'" in sw, f"{arq.name} fora do esqueleto em cache"


def test_nenhum_dado_externo_e_carregado_pelo_site():
    for arq in TODOS_JS:
        t = arq.read_text(encoding="utf-8")
        for u in re.findall(r"fetch\(\s*['\"`](https?://[^'\"`]+)", t):
            pytest.fail(f"{arq.name} busca recurso externo: {u}")


def test_preloads_e_recursos_locais_do_html_existem():
    """Garante que nenhum <link rel='modulepreload'|'preload'|'stylesheet'|'icon'|'manifest'> aponte para 404."""
    for href in re.findall(r'<link\b[^>]*\bhref="([^"]+)"', HTML):
        if href.startswith(("http://", "https://", "#", "data:")):
            continue
        alvo = (APP / href).resolve()
        assert alvo.is_file(), f"index.html referencia {href}, que não existe em app/"


# ═══════════════════════════ o artefato _site/ ═══════════════════════════
def _script(nome):
    arq = RAIZ / "scripts" / f"{nome}.py"
    if not arq.is_file():
        pytest.skip(f"scripts/{nome}.py não está neste checkout")
    spec = importlib.util.spec_from_file_location(nome, arq)
    modulo = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modulo)
    return modulo


@pytest.fixture
def release(mini, tmp_path, monkeypatch):
    """Os dois arquivos de uma Release (pacote de dados e banco), feitos do banco mínimo, e o script de montagem."""
    from bmb import config, construir, orcamento, prontidao
    from bmb.exportar import pacotes

    construir.etapa_busca(mini.con, lambda *_: None)
    prontidao.recalcular_todas(mini.con)
    mini.con.commit()
    dados = tmp_path / "dados"
    pacotes.exportar_tudo(mini.con, dados, log=lambda *_: None)
    copia = tmp_path / "copia.sqlite"
    mini.con.execute(f"VACUUM INTO '{copia.as_posix()}'")
    gz = tmp_path / "biomapabrasil-sqlite-teste.gz"
    gz.write_bytes(gzip.compress(copia.read_bytes()))
    # um banco de trabalho no lugar de sempre: montar o site nunca pode tocar nele
    monkeypatch.setattr(config, "DB_PATH", tmp_path / "saida" / "biomapabrasil.sqlite")
    config.DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    config.DB_PATH.write_bytes(b"banco de trabalho, com o registro interno")
    # o orçamento de primeira tela é do front-end e tem medição própria; este teste trata do que entra em _site
    monkeypatch.setitem(orcamento.ORCAMENTO, "inicial", 10 ** 6)

    def empacotar(nome="biomapabrasil-app-dados-teste.tar.gz"):
        tar = tmp_path / nome
        with tarfile.open(tar, "w:gz") as tf:
            tf.add(dados, arcname=".")
        return tar

    return SimpleNamespace(dados=dados, gz=gz, empacotar=empacotar, script=_script("preparar_pages"), site=tmp_path / "_site",
                           banco=tmp_path / "saida" / "biomapabrasil.sqlite")


def test_site_montado_so_tem_o_que_e_publico(release):
    from bmb import api
    from bmb.exportar import pacotes

    codigo = release.script.main(["--dados-tar", str(release.empacotar()), "--sqlite-gz", str(release.gz), "--saida", str(release.site)])
    site = release.site
    assert codigo == 0
    for esperado in ("index.html", "css/app.css", "dados/manifesto.json", "dados/indice_mapa.json", "dados/tabelas/afirmacoes.csv",
                     "api/openapi.json", "api/docs/index.html", "api/taxa/index.json", "api/afirmacoes/index.json"):
        assert (site / esperado).is_file(), esperado
    # o que nunca entra: documentação do repositório, auditoria externa, código, banco e registros internos da construção
    for pasta in ("docs", "external_audit_2026-11-15", "nucleo", "scripts", "interno", "dados/interno"):
        assert not (site / pasta).exists(), pasta
    nomes = [p.relative_to(site).as_posix() for p in site.rglob("*") if p.is_file()]
    for padrao in (r"\.sqlite", r"(^|/)quarentena", r"(^|/)benchmark", r"(^|/)retencoes", r"nomes_rejeitados", r"VALIDACAO_TECNICA", r"CONTRATO_DE_DADOS"):
        assert [n for n in nomes if re.search(padrao, n)] == [], padrao
    # o banco da Release foi lido de um arquivo temporário: nada de banco no site, e o banco de trabalho ficou como estava
    assert release.banco.read_bytes() == b"banco de trabalho, com o registro interno"
    # instantâneos da API: só rotas públicas, e o OpenAPI não lista as internas
    assert not (site / "api" / "quarentena").exists() and not (site / "api" / "benchmark").exists()
    spec = json.loads((site / "api" / "openapi.json").read_text(encoding="utf-8"))
    assert set(spec["paths"]) == set(api.especificacao(False)["paths"])
    assert {f"/api/{r}" for r in release.script.ROTAS_DA_API} <= set(spec["paths"])
    docs = (site / "api" / "docs" / "index.html").read_text(encoding="utf-8")
    for texto_ in (docs, json.dumps(spec, ensure_ascii=False), (site / "api" / "index.json").read_text(encoding="utf-8")):
        assert "quarentena" not in texto_ and "benchmark" not in texto_
    assert 'href="../taxa/index.json"' in docs and 'href="/api/' not in docs
    assert pacotes.conferir_fronteira(site) == []
    # o conferidor que o CI roda sobre `_site` aprova o artefato inteiro: site, dados e instantâneos da API
    conferidor = _script("conferir_pacote_publico")
    assert conferidor.conferir(site) == []


def test_banco_da_release_nunca_e_gravado_por_cima_de_outro_nem_dentro_do_site(release, tmp_path):
    args = ["--dados-tar", str(release.empacotar()), "--sqlite-gz", str(release.gz), "--saida", str(release.site)]
    with pytest.raises(SystemExit, match="já existe"):                # o banco de trabalho é um arquivo que já existe
        release.script.main([*args, "--banco", str(release.banco)])
    with pytest.raises(SystemExit, match="dentro da saída"):
        release.script.main([*args, "--banco", str(release.site / "biomapabrasil.sqlite")])
    assert release.banco.read_bytes() == b"banco de trabalho, com o registro interno" and not release.site.exists()
    guardado = tmp_path / "da_release" / "biomapabrasil.sqlite"
    assert release.script.main([*args, "--banco", str(guardado)]) == 0
    assert guardado.is_file() and guardado.read_bytes()[:15] == b"SQLite format 3"
    assert [p for p in release.site.rglob("*") if ".sqlite" in p.name] == []


def test_site_recusa_pacote_de_dados_com_arquivo_interno(release):
    """Um pacote de dados antigo, com o livro de retenções dentro, não vira artefato publicável."""
    (release.dados / "quarentena.json").write_text('{"afirmacoes":[]}', encoding="utf-8")
    assert release.script.main(["--dados-tar", str(release.empacotar()), "--sqlite-gz", str(release.gz), "--saida", str(release.site)]) == 1
    (release.dados / "quarentena.json").unlink()
    (release.dados / "taxa" / "antigo.json").write_text('{"afirmacao":{"nivel_procedencia":"T3a_endemica_amazonia_br"}}', encoding="utf-8")
    assert release.script.main(["--dados-tar", str(release.empacotar()), "--sqlite-gz", str(release.gz), "--saida", str(release.site)]) == 1


def test_site_nao_e_montado_com_banco_invalido(release, mini):
    mini.con.execute("UPDATE afirmacao SET estado='verificado' WHERE id=?", (mini.af_composto,))      # sem verificação humana
    mini.con.commit()
    copia = release.gz.parent / "invalido.sqlite"
    mini.con.execute(f"VACUUM INTO '{copia.as_posix()}'")
    release.gz.write_bytes(gzip.compress(copia.read_bytes()))
    args = ["--dados-tar", str(release.empacotar()), "--sqlite-gz", str(release.gz), "--saida", str(release.site)]
    assert release.script.main(args) == 1 and not (release.site / "api").exists()


def test_saida_do_site_nao_pode_ser_o_repositorio_nem_pasta_interna(tmp_path):
    script = _script("preparar_pages")
    for ruim in (RAIZ, RAIZ.parent, RAIZ / "nucleo" / "saida" / "_site", RAIZ / "docs" / "site", RAIZ / "app"):
        with pytest.raises(SystemExit):
            script.conferir_saida(ruim)
    script.conferir_saida(RAIZ / "_site")
    script.conferir_saida(tmp_path / "_site")
    assert not {"quarentena", "benchmark"} & set(script.ROTAS_DA_API)

