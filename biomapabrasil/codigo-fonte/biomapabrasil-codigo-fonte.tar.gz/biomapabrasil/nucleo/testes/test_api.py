# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""API de consulta (somente leitura) e curadoria local (escrita protegida por token).

A API pública segue o mesmo contrato dos pacotes (`docs/dev/CONTRATO_DE_DADOS.md`): só registro público, nenhuma
contagem que inclua registro não publicado, e as rotas internas só existem com a curadoria ligada.
"""
import json

import pytest
from starlette.testclient import TestClient

from bmb import construir, procedencia, prontidao, quarentena, validar
from bmb.api import criar_app, especificacao
from conftest import AGORA, _afirmacao, _molecula

ROTAS_INTERNAS = ("/api/quarentena", "/api/benchmark")
PROIBIDAS = ("quarentena", "motivo_quarentena", "regra_quarentena", "nivel_procedencia", "escopo_biogeografico", "T3a", "T3b",
             "benchmark", "afirmacoes_em_quarentena", "amazonica_estrita", "localidade_declarada", "procedencia_material")


def _preparar(mini):
    construir.etapa_busca(mini.con, lambda *_: None)
    prontidao.recalcular_todas(mini.con)
    mini.con.commit()
    return mini.con.execute("PRAGMA database_list").fetchone()[2]


@pytest.fixture
def servidor(mini, tmp_path):
    """App com a API pública; o banco da fixture já foi preenchido e a busca indexada."""
    return criar_app(_preparar(mini), app_dir=tmp_path / "sem-site")


@pytest.fixture
def cliente(servidor):
    return TestClient(servidor)


@pytest.fixture
def curador(mini, tmp_path):
    app = criar_app(_preparar(mini), app_dir=tmp_path / "sem-site", curadoria_ativa=True, token="token-de-teste")
    return TestClient(app), {"X-BMB-Token": "token-de-teste"}


def _reter(mini):
    """Acrescenta ao banco mínimo uma molécula cuja única ocorrência está retida por regra, com uma medida em estado público."""
    con = mini.con
    quarentena.registrar_catalogo(con)
    mid = _molecula(con, "Retidina de teste", "AAAAAAAAAAAAAA-UHFFFAOYSA-N", chembl_id="CHEMBL900002")
    aid = _afirmacao(con, "composto_em_organismo", mid, mini.consulta_lotus, taxon_id=mini.taxon, origem="lotus:retida",
                     organismo_na_fonte="Carapa guianensis")
    con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (aid, mini.ref))
    quarentena.declarar(con, ("TAX-HOMONIMO",), {aid: {"TAX-HOMONIMO": {"organismo_fonte": "Carapa guianensis", "uso_fonte": "outro uso",
                                                                       "taxon": "Carapa guianensis", "autoria_taxon": "Aubl."}}})
    quarentena.aplicar_estados(con)
    orfa = _afirmacao(con, "atividade_biologica", mid, mini.consulta_chembl, alvo_id=mini.alvo, fonte="chembl",
                      origem="chembl:agregado:CHEMBL900002:CHEMBL226:Ki", medida_tipo="Ki", medida_relacao="=", medida_valor=77.0,
                      medida_unidade="nM", medida_agregacao="unica", medida_n=1, medida_n_documentos=1, medida_min=77.0, medida_max=77.0)
    con.commit()
    return mid, aid, orfa


# ═══════════════════════════ consulta pública ═══════════════════════════
def test_saude_e_documentacao(cliente):
    r = cliente.get("/api/saude").json()
    assert r["ok"] and r["taxons"] == 1 and r["moleculas"] == 1 and r["afirmacoes"] == 3
    spec = cliente.get("/api/openapi.json").json()
    assert spec["openapi"].startswith("3.") and "/api/taxa/{gbif}" in spec["paths"]
    assert "API de consulta" in cliente.get("/api/docs").text


def test_so_leitura_e_cors(cliente):
    assert cliente.post("/api/taxa").status_code == 405
    r = cliente.get("/api/taxa", headers={"Origin": "https://outro-site.example"})
    assert r.headers["access-control-allow-origin"] == "*" and "ETag" in r.headers and "max-age" in r.headers["cache-control"]


def test_lista_de_taxa_e_filtros(cliente):
    r = cliente.get("/api/taxa").json()
    assert r["total"] == 1 and r["itens"][0]["nome"] == "Carapa guianensis" and r["itens"][0]["predominio"] == "predominante"
    item = r["itens"][0]
    assert item["distribuicao_br"] in procedencia.ROTULOS_DISTRIBUICAO and item["coleta_amazonica_declarada"] is False
    assert "escopo_biogeografico" not in item and "tem_procedencia_estrita" not in item
    assert cliente.get("/api/taxa?q=carapa").json()["total"] == 1                # busca sem acento e com prefixo
    assert cliente.get("/api/taxa?q=zzzz").json()["total"] == 0
    assert cliente.get("/api/taxa?grupo=fungo").json()["total"] == 0
    assert cliente.get("/api/taxa?grupo=inventado").status_code == 400
    assert cliente.get("/api/taxa?limite=abc").status_code == 400
    assert cliente.get("/api/taxa?limite=100000").json()["limite"] == 200         # teto de página


def test_filtros_de_evidencia_procedencia_e_distribuicao(mini, tmp_path):
    con = mini.con
    con.execute("UPDATE afirmacao SET uf_coleta_declarada='AM', pais_coleta_declarado='BR' WHERE id=?", (mini.af_composto,))
    c = TestClient(criar_app(_preparar(mini), app_dir=tmp_path / "sem-site"))
    dist = con.execute("SELECT distribuicao_br FROM taxon").fetchone()[0]
    total = lambda url: c.get(url).json()["total"]
    # distribuição da espécie: contexto do táxon
    assert total(f"/api/taxa?distribuicao_br={dist}") == 1 and total("/api/taxa?distribuicao_br=fora_do_recorte") == 0
    assert total(f"/api/taxa?distribuicao_br=fora_do_recorte,{dist}") == 1
    # procedência declarada: código exato, e o atalho que reúne os dois códigos de coleta amazônica declarada
    assert total("/api/taxa?procedencia=base_declara_amazonia_legal") == 1 and total("/api/taxa?procedencia=curador_artigo_amazonia") == 0
    assert total("/api/taxa?coleta_amazonica_declarada=1") == 1 and total("/api/moleculas?coleta_amazonica_declarada=1") == 1
    assert total("/api/moleculas?procedencia=nao_declarada") == 0
    assert total("/api/afirmacoes?procedencia=base_declara_amazonia_legal") == 1 and total("/api/afirmacoes?coleta_amazonica_declarada=1") == 1
    assert total("/api/afirmacoes?procedencia=nao_declarada") == 0              # medida e efeito clínico não têm procedência
    # evidência: um nível ou vários
    assert total("/api/afirmacoes?evidencia=base_curada") == 3 and total("/api/afirmacoes?evidencia=curador") == 0
    assert total("/api/afirmacoes?evidencia=curador,artigo_trecho,base_curada") == 3
    assert total("/api/taxa?evidencia=base_curada") == 1 and total("/api/taxa?evidencia=artigo_trecho") == 0
    assert total("/api/taxa?evidencia=artigo_trecho&coleta_amazonica_declarada=1") == 0   # as condições valem para a mesma afirmação
    assert c.get("/api/taxa").json()["itens"][0]["coleta_amazonica_declarada"] is True
    # código fora do vocabulário e filtros que deixaram de existir: 400 com mensagem, nunca resultado sem filtro
    for url in ("/api/taxa?procedencia=amazonica_estrita", "/api/afirmacoes?evidencia=forte", "/api/taxa?distribuicao_br=amazonica",
                "/api/moleculas?coleta_amazonica_declarada=sim", "/api/taxa?escopo=endemica_amazonia_br",
                "/api/afirmacoes?nivel_procedencia=T1_voucher_amazonia_verificado", "/api/afirmacoes?molecula=abc"):
        r = c.get(url)
        assert r.status_code == 400 and r.json()["erro"], url
    assert "distribuicao_br" in c.get("/api/taxa?escopo=x").json()["erro"]


def test_perfil_do_taxon_traz_proveniencia(cliente):
    t = cliente.get("/api/taxa/100").json()
    assert t["nome"] == "Carapa guianensis" and t["recorte"]["dentro"] and t["consultas"][t["recorte"]["consulta"]]["fonte"] == "gbif"
    assert len(t["moleculas"]) == 1 and t["moleculas"][0]["afirmacao"]["estado"] == "candidato"
    assert t["moleculas"][0]["afirmacao"]["evidencia"] == "base_curada" and t["moleculas"][0]["afirmacao"]["procedencia"] == "nao_declarada"
    assert t["distribuicao_br"] in procedencia.ROTULOS_DISTRIBUICAO and t["cobertura"]["compostos"] == 1
    assert cliente.get("/api/taxa/999").status_code == 404
    assert cliente.get("/api/taxa/abc").status_code in (400, 404)


def test_perfil_da_molecula_separa_isolada_organismo_e_farmaco(cliente):
    m = cliente.get("/api/moleculas/1").json()
    assert m["clinico"]["tipo"] == "efeito_clinico_documentado" and m["atividades"][0]["medida"]["tipo"] == "IC50"
    assert m["atividades"][0]["medida"]["agregacao"] == "unica" and m["atividades"][0]["alvo"]["natureza"] == "proteina_unica"
    assert all(o["afirmacao"]["tipo"] == "composto_em_organismo" for o in m["ocorre_em"])
    assert m["conectividade"] == "RYYVLZVUVIJVGH" and m["n_mesma_conectividade"] == 1
    lista = cliente.get("/api/moleculas?aprovado=1&atividade=1").json()
    assert lista["total"] == 1 and lista["itens"][0]["aprovado"] and lista["itens"][0]["conectividade"] == "RYYVLZVUVIJVGH"


def test_afirmacoes_com_fonte_estado_e_prontidao(cliente):
    r = cliente.get("/api/afirmacoes?tipo=composto_em_organismo").json()
    assert r["total"] == 1
    a = r["itens"][0]
    assert a["estado"] == "candidato" and a["prontidao"]["identidade_quimica"] == "atende" and a["refs"] and a["consulta"] is not None
    assert a["evidencia"] == "base_curada" and a["procedencia"] == "nao_declarada"
    assert cliente.get("/api/afirmacoes?estado=quarentena").status_code == 400     # quarentena não sai pela via pública de afirmações
    # a mesma forma dos pacotes: a medida agregada e o alvo vêm na afirmação de bioatividade
    at = cliente.get("/api/afirmacoes?tipo=atividade_biologica").json()["itens"][0]
    assert at["medida"]["n"] == 1 and at["medida"]["n_publicacoes"] == 1 and at["alvo"]["chembl"] == "CHEMBL226" and at["ensaio_tipo"] == "B"
    cl = cliente.get("/api/afirmacoes?tipo=efeito_clinico_documentado").json()["itens"][0]
    assert cl["fontes_regulatorias"][0]["tipo"] == "DailyMed"


def test_busca_por_nome(cliente):
    r = cliente.get("/api/busca?q=caraP").json()
    assert [t["nome"] for t in r["taxa"]] == ["Carapa guianensis"]
    assert cliente.get("/api/busca?q=").status_code == 400


def test_limite_de_requisicoes_por_ip(servidor):
    c = TestClient(servidor)
    codigos = [c.get("/api/saude").status_code for _ in range(140)]
    assert 429 in codigos and codigos[0] == 200


# ═══════════════════════════ fronteira: o que a API pública não mostra ═══════════════════════════
def test_rotas_internas_nao_existem_sem_a_curadoria(cliente):
    for rota in ROTAS_INTERNAS:
        assert cliente.get(rota).status_code == 404, rota
        assert cliente.get(rota + "/").status_code == 404
    spec = cliente.get("/api/openapi.json").json()
    assert not any("quarentena" in c or "benchmark" in c for c in spec["paths"])
    assert set(spec["paths"]) == set(especificacao(False)["paths"])
    raiz = cliente.get("/api").json()
    assert not any("quarentena" in e or "benchmark" in e for e in raiz["endpoints"])
    for texto_ in (json.dumps(spec, ensure_ascii=False), json.dumps(raiz, ensure_ascii=False), cliente.get("/api/docs").text):
        assert not any(p in texto_ for p in PROIBIDAS), [p for p in PROIBIDAS if p in texto_]


def test_rotas_internas_com_a_curadoria_exigem_o_token(curador):
    c, h = curador
    spec = c.get("/api/openapi.json").json()
    for rota in ROTAS_INTERNAS:
        assert rota in spec["paths"]
        assert c.get(rota).status_code == 401
        assert c.get(rota, headers={"X-BMB-Token": "errado"}).status_code == 401
        assert c.get(rota, headers=h).status_code == 200
    # leitura de outra origem não passa: o cabeçalho do token não é liberado por CORS
    pre = c.options("/api/quarentena", headers={"Origin": "https://outro-site.example", "Access-Control-Request-Method": "GET",
                                                "Access-Control-Request-Headers": "x-bmb-token"})
    assert pre.status_code == 400


def test_nenhuma_rota_publica_mostra_registro_retido_nem_conta_com_ele(mini, tmp_path):
    mid, aid, orfa = _reter(mini)
    mini.con.execute("UPDATE afirmacao SET classe_acesso='restrito' WHERE id=?", (mini.af_clinico,))
    mini.con.execute("INSERT INTO territorio (id, tipo, codigo, sigla, nome, amazonia_legal) VALUES ('UF:13', 'uf', '13', 'AM', 'Amazonas', 1)")
    c = TestClient(criar_app(_preparar(mini), app_dir=tmp_path / "sem-site"))
    saude = c.get("/api/saude").json()
    # no banco há 5 afirmações e 2 moléculas; públicas são 2 afirmações (composto e medida da cafeína) e 1 molécula
    assert saude["afirmacoes"] == 2 and saude["moleculas"] == 1
    assert c.get("/api/afirmacoes").json()["total"] == 2
    assert {a["id"] for a in c.get("/api/afirmacoes").json()["itens"]} == {mini.af_composto, mini.af_atividade}
    assert c.get(f"/api/afirmacoes?molecula={mid}").json()["total"] == 0          # nem a medida da molécula sem ocorrência pública
    assert c.get(f"/api/moleculas/{mid}").status_code == 404 and c.get("/api/moleculas").json()["total"] == 1
    assert c.get("/api/busca?q=retidina").json()["moleculas"] == []
    assert [m["id"] for m in c.get("/api/taxa/100").json()["moleculas"]] == [mini.molecula]
    assert c.get(f"/api/moleculas/{mini.molecula}").json()["clinico"] is None      # efeito clínico de acesso restrito
    corpos = []
    for url in ("/api", "/api/saude", "/api/fontes", "/api/universo", "/api/taxa", "/api/taxa/100", "/api/moleculas",
                f"/api/moleculas/{mini.molecula}", "/api/afirmacoes", "/api/ufs/AM", "/api/bacias", "/api/lacunas", "/api/linhagens",
                "/api/vias", "/api/estruturas3d", "/api/busca?q=carapa", "/api/openapi.json", "/api/docs"):
        r = c.get(url)
        assert r.status_code == 200, url
        corpos.append((url, r.text))
    for url, corpo in corpos:
        achadas = [p for p in (*PROIBIDAS, "TAX-HOMONIMO", "Retidina", "outro uso", "AAAAAAAAAAAAAA") if p in corpo]
        assert achadas == [], (url, achadas)


def test_linhagem_retida_e_obra_retida_nao_saem_pela_api(mini, tmp_path):
    con = mini.con
    quarentena.registrar_catalogo(con)
    farmaco = _molecula(con, "Farmacotest", "DDDDDDDDDDDDDD-UHFFFAOYSA-N", chembl_id="CHEMBL900001", max_fase_clinica=4.0,
                        fase_consulta_id=mini.consulta_chembl)
    outro = _molecula(con, "Contraditina de teste", "EEEEEEEEEEEEEE-UHFFFAOYSA-N")
    con.execute("INSERT INTO relacao_molecula (origem_id, destino_id, tipo, texto, referencia_id, consulta_id, chave, trecho, trecho_fonte, "
                "trecho_sha256, trecho_conferido_em) VALUES (?,?,'inspirou','A cafeína foi o composto-líder do fármaco de teste.',?,?,"
                "'cafeina-farmacotest','Caffeine was the lead compound for the test drug.','resumo_pubmed',?,?)",
                (mini.molecula, farmaco, mini.ref, mini.consulta_chembl, "f" * 64, AGORA))
    con.execute("INSERT INTO relacao_molecula (origem_id, destino_id, tipo, texto, referencia_id, consulta_id, estado, regra_quarentena, "
                "motivo_quarentena) VALUES (?,?,'derivado_de','Relação não sustentada: teste.',?,?,'rejeitado','LIN-CONTRADITA','outra origem')",
                (mini.molecula, outro, mini.ref, mini.consulta_chembl))
    con.execute("INSERT INTO referencia (doi, titulo, resolvida, consulta_id) VALUES ('10.1000/retida','Obra retida de teste',0,?)", (mini.consulta_lotus,))
    retida = con.execute("SELECT id FROM referencia WHERE doi='10.1000/retida'").fetchone()[0]
    quarentena.reter_referencia(con, retida, "REF-DOI-INEXISTENTE", doi="10.1000/retida", resposta_handle="handle não encontrado")
    con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (mini.af_composto, retida))
    c = TestClient(criar_app(_preparar(mini), app_dir=tmp_path / "sem-site"))
    lin = c.get("/api/linhagens").json()
    assert lin["total"] == 1 and lin["linhagens"][0]["destino"]["nome"] == "Farmacotest"
    assert lin["linhagens"][0]["trecho"] == "Caffeine was the lead compound for the test drug." and lin["linhagens"][0]["trecho_fonte"] == "resumo_pubmed"
    assert c.get("/api/saude").json()["linhagens_bioinspiradas"] == 1
    assert c.get(f"/api/moleculas/{farmaco}").status_code == 200 and c.get(f"/api/moleculas/{outro}").status_code == 404
    afs = c.get("/api/afirmacoes?tipo=composto_em_organismo").json()
    assert [r["doi"] for r in afs["refs"]] == ["10.1000/abc"] and afs["itens"][0]["refs"] == [0]
    assert "10.1000/retida" not in c.get("/api/taxa/100").text and "Contraditina" not in c.get(f"/api/moleculas/{mini.molecula}").text


# ═══════════════════════════ curadoria local ═══════════════════════════
def test_curadoria_nao_existe_sem_a_opcao(cliente):
    assert cliente.get("/curadoria/api/fila").status_code == 404


def test_curadoria_exige_token(curador):
    c, _ = curador
    assert c.get("/curadoria/api/fila").status_code == 401
    assert c.get("/curadoria/api/fila", headers={"X-BMB-Token": "errado"}).status_code == 401
    assert c.post("/curadoria/api/verificar", json={}).status_code == 401


def test_fluxo_de_verificacao_pela_curadoria(curador, mini):
    c, h = curador
    fila = c.get("/curadoria/api/fila", headers=h).json()
    assert fila["total"] >= 1 and all(i["n_refs"] >= 1 for i in fila["itens"])
    af = next(i for i in fila["itens"] if i["tipo"] == "composto_em_organismo")
    assert af["nivel_evidencia"] == "base_curada" and "nivel_procedencia" not in af
    det = c.get(f"/curadoria/api/afirmacao/{af['id']}", headers=h).json()
    assert det["referencias"][0]["url"].startswith("https://doi.org/") and det["taxon"]["nome"] == "Carapa guianensis"
    assert det["rotulos"]["evidencia"] == "Transcrito de base curada" and "distribuicao_br" in det["taxon"]
    # entradas inválidas voltam com mensagem clara
    base = {"afirmacao_id": af["id"], "curador": "Curadora Teste", "decisao": "confirmada", "sensibilidade": "sem_restricao",
            "referencia_id": det["referencias"][0]["id"]}
    r = c.post("/curadoria/api/verificar", headers=h, json={**base, "passagem_conferida": "curto"})
    assert r.status_code == 422 and "trecho" in r.json()["erro"].lower()
    assert c.post("/curadoria/api/verificar", headers=h, json={**base, "curador": "ab", "passagem_conferida": "x" * 40}).status_code == 422
    assert c.post("/curadoria/api/verificar", headers=h, json={**base, "decisao": "talvez", "passagem_conferida": "x" * 40}).status_code == 422
    sem_sens = {k: v for k, v in base.items() if k != "sensibilidade"}
    assert c.post("/curadoria/api/verificar", headers=h, json={**sem_sens, "passagem_conferida": "x" * 40}).status_code == 422
    # decisão válida
    ok = c.post("/curadoria/api/verificar", headers=h, json={**base, "passagem_conferida": "The compound was isolated from the seed oil.",
                                                            "procedencia_material": "", "qualidade_experimental": "atende"})
    assert ok.status_code == 200 and ok.json()["estado"] == "verificado" and ok.json()["indice"] > 0.8
    linha = mini.con.execute("SELECT nivel_evidencia, passagem_origem, passagem_referencia_id, passagem_sha256, nivel_procedencia, "
                             "procedencia_declarada FROM afirmacao WHERE id=?", (af["id"],)).fetchone()
    assert (linha["nivel_evidencia"], linha["passagem_origem"], linha["passagem_referencia_id"]) == ("curador", "curador", base["referencia_id"])
    assert len(linha["passagem_sha256"]) == 64 and linha["nivel_procedencia"] is None and linha["procedencia_declarada"] == "nao_declarada"
    # a API pública enxerga a verificação: evidência «curador», trecho do curador e nenhuma procedência deduzida
    a = c.get("/api/afirmacoes?estado=verificado").json()["itens"][0]
    assert a["verificacao"]["curador"] == "Curadora Teste" and a["verificacao"]["escopo_geografico_lido"] is None
    assert "procedencia" not in a["verificacao"] and "passagem" not in a["verificacao"]
    assert a["evidencia"] == "curador" and a["passagem_origem"] == "curador" and a["procedencia"] == "nao_declarada"
    assert a["passagem"] == "The compound was isolated from the seed oil."
    assert c.get("/api/afirmacoes?evidencia=curador").json()["total"] == 1


def test_curadoria_so_registra_localidade_como_pais_e_uf(curador, mini):
    c, h = curador
    af = next(i for i in c.get("/curadoria/api/fila", headers=h).json()["itens"] if i["tipo"] == "composto_em_organismo")
    ref = c.get(f"/curadoria/api/afirmacao/{af['id']}", headers=h).json()["referencias"][0]["id"]
    base = {"afirmacao_id": af["id"], "curador": "Curadora Teste", "decisao": "confirmada", "sensibilidade": "sem_restricao",
            "referencia_id": ref, "passagem_conferida": "The compound was isolated from the seed oil.", "escopo_geografico_lido": "amazonia_br"}
    postar = lambda **campos: c.post("/curadoria/api/verificar", headers=h, json={**base, **campos})
    # município, comunidade, unidade de conservação, coordenada: 400, com a forma aceita na mensagem, e nada é gravado
    for texto_ in ("Reserva Ducke, Manaus, Amazonas, Brasil", "Manaus", "Brasil: Manaus", "Comunidade São João", "3°06'S 60°01'W",
                   "Brasil: AM, Tefé", "Amazonas"):
        r = postar(procedencia_material=texto_)
        assert r.status_code == 400 and "País: UF" in r.json()["erro"], texto_
    assert postar(procedencia_material="Peru: LO").status_code == 400            # UF só do Brasil
    r = postar(passagem_conferida="Leaves were collected at Reserva Ducke, near Manaus, and extracted with ethanol.")
    assert r.status_code == 400 and "Reserva Ducke" in r.json()["erro"]
    r = postar(passagem_conferida="Leaves were collected in the forest (3°06′S, 60°01′W) and extracted with ethanol.")
    assert r.status_code == 400 and "3°06′" in r.json()["erro"]
    r = postar(voucher="coletado em Tefé por J. Silva 123")
    assert r.status_code == 400 and "código de coleção" in r.json()["erro"]
    # país e UF que contradizem o escopo marcado: 422
    assert postar(procedencia_material="Brasil: SP").status_code == 422
    assert mini.con.execute("SELECT COUNT(*) FROM verificacao").fetchone()[0] == 0
    assert mini.con.execute("SELECT estado FROM afirmacao WHERE id=?", (af["id"],)).fetchone()[0] == "candidato"
    # a forma aceita
    r = postar(procedencia_material="brasil : am", voucher="INPA 22410")
    assert r.status_code == 200 and r.json()["estado"] == "verificado"
    v = mini.con.execute("SELECT procedencia_material, voucher, escopo_geografico_lido FROM verificacao").fetchone()
    assert tuple(v) == ("brasil: AM", "INPA 22410", "amazonia_br")
    assert mini.con.execute("SELECT procedencia_declarada FROM afirmacao WHERE id=?", (af["id"],)).fetchone()[0] == "curador_artigo_amazonia"
    a = c.get("/api/afirmacoes?estado=verificado").json()["itens"][0]
    assert a["procedencia"] == "curador_artigo_amazonia" and a["verificacao"]["escopo_geografico_lido"] == "amazonia_br"
    assert a["verificacao"]["voucher"] == "INPA 22410" and "brasil: AM" not in json.dumps(a, ensure_ascii=False)
    assert c.get("/api/taxa?coleta_amazonica_declarada=1").json()["total"] == 1


def test_sensibilidade_restrita_tira_a_afirmacao_da_exibicao_publica(curador):
    c, h = curador
    af = next(i for i in c.get("/curadoria/api/fila", headers=h).json()["itens"] if i["tipo"] == "composto_em_organismo")
    ref = c.get(f"/curadoria/api/afirmacao/{af['id']}", headers=h).json()["referencias"][0]["id"]
    r = c.post("/curadoria/api/verificar", headers=h, json={"afirmacao_id": af["id"], "curador": "Curadora Teste", "decisao": "confirmada",
                                                            "sensibilidade": "comunitario", "referencia_id": ref,
                                                            "passagem_conferida": "Collected with the community under protocol."})
    assert r.status_code == 200
    assert c.get("/api/afirmacoes?tipo=composto_em_organismo").json()["total"] == 0
    assert c.get("/api/taxa/100").json()["moleculas"] == []


def test_quarentena_pela_curadoria_registra_motivo_e_sai_do_publico(curador, mini):
    c, h = curador
    # a leitura pública já foi feita uma vez: a retenção tem de valer na consulta seguinte, sem reiniciar o servidor
    assert len(c.get("/api/taxa/100").json()["moleculas"]) == 1 and c.get("/api/saude").json()["afirmacoes"] == 3
    af = next(i for i in c.get("/curadoria/api/fila", headers=h).json()["itens"] if i["tipo"] == "composto_em_organismo")
    assert c.post("/curadoria/api/quarentena", headers=h, json={"afirmacao_id": af["id"], "curador": "Curadora Teste", "motivo": "curto"}).status_code == 422
    r = c.post("/curadoria/api/quarentena", headers=h, json={"afirmacao_id": af["id"], "curador": "Curadora Teste", "motivo": "Artigo com correção pendente."})
    assert r.status_code == 200
    linha = mini.con.execute("SELECT estado, quarentena_origem, regra_quarentena FROM afirmacao WHERE id=?", (af["id"],)).fetchone()
    assert tuple(linha) == ("quarentena", "curador", None)
    # A própria decisão já rederiva os estados: sem a ocorrência, a molécula fica sem registro publicado em organismo,
    # e a medida e o efeito clínico dela passam a retidos pela regra derivada. O banco continua válido.
    dependentes = {mini.af_atividade, mini.af_clinico}
    for aid in dependentes:
        dep = mini.con.execute("SELECT estado, quarentena_origem, regra_quarentena FROM afirmacao WHERE id=?", (aid,)).fetchone()
        assert tuple(dep) == ("quarentena", "regra", quarentena.REGRA_DERIVADA)
    assert validar.validar(mini.con)["erros"] == []
    # decisão de curador não é desfeita pelas regras automáticas, e rederivar de novo não muda nada
    resultado = quarentena.aplicar_estados(mini.con)
    mini.con.commit()
    assert resultado["retidas_agora"] == 0 and resultado["liberadas"] == 0
    linha = mini.con.execute("SELECT estado, quarentena_origem, regra_quarentena FROM afirmacao WHERE id=?", (af["id"],)).fetchone()
    assert tuple(linha) == ("quarentena", "curador", None)
    # o motivo está no livro interno (com token) e em nenhuma rota pública
    q = c.get("/api/quarentena", headers=h).json()
    assert any(i["id"] == af["id"] and i["motivo"] == "Artigo com correção pendente." and i["decidida_por"] == "curador" for i in q["afirmacoes"])
    assert {i["id"] for i in q["afirmacoes"] if i["regra"] == quarentena.REGRA_DERIVADA and i["decidida_por"] == "regra"} == dependentes
    assert q["afirmacoes_de_molecula_sem_registro_publico"] == []       # o estado já diz tudo: a lista defensiva fica vazia
    assert q["resumo"]["afirmacoes_por_regra"][quarentena.REGRA_DERIVADA] == 2
    # sem ocorrência pública, a molécula inteira deixa de ser pública: nem a medida nem o efeito clínico dela saem
    assert c.get("/api/taxa/100").json()["moleculas"] == [] and c.get("/api/saude").json()["afirmacoes"] == 0
    assert c.get("/api/afirmacoes").json()["total"] == 0 and c.get(f"/api/moleculas/{mini.molecula}").status_code == 404
    assert "correção pendente" not in c.get("/api/taxa/100").text
    fila = c.get("/curadoria/api/fila?estado=quarentena", headers=h).json()
    assert {i["id"] for i in fila["itens"]} == {af["id"], *dependentes}
    assert {i["id"]: i["regra_quarentena"] for i in fila["itens"]} == {af["id"]: None, **{aid: quarentena.REGRA_DERIVADA for aid in dependentes}}
    det = c.get(f"/curadoria/api/afirmacao/{af['id']}", headers=h).json()
    assert det["afirmacao"]["motivo_quarentena"] == "Artigo com correção pendente."      # a ferramenta de curadoria mostra o motivo


def test_endpoints_cientificos_v2_bacias_lacunas_linhagens_vias_estruturas3d(mini, tmp_path):
    con = mini.con
    cid_gbif = con.execute("SELECT id FROM consulta WHERE fonte_id='gbif' LIMIT 1").fetchone()[0]
    cid_chembl = con.execute("SELECT id FROM consulta WHERE fonte_id='chembl' LIMIT 1").fetchone()[0]
    ref_id = con.execute("SELECT id FROM referencia LIMIT 1").fetchone()[0]

    con.execute(
        "INSERT INTO bacia_hidrografica (id, nome, rio_principal, area_km2, poligono_wkt, cor_hex, consulta_id) "
        "VALUES ('negro', 'Bacia do Rio Negro', 'Rio Negro', 696000.0, 'POLYGON((-68 2,-60 2,-60 -3,-68 -3,-68 2))', '#38bdf8', ?)",
        (cid_gbif,),
    )
    con.execute(
        "INSERT INTO ocorrencia_bacia (taxon_id, bacia_id, n, consulta_id) VALUES (1, 'negro', 25, ?)",
        (cid_gbif,),
    )
    con.execute(
        "INSERT INTO celula_lacuna (lon, lat, passo_graus, x_mapa, y_mapa, w_mapa, h_mapa, area_km2, n_ocorrencias_gbif, "
        "densidade_km2, bacia_id, pressao_desmatamento, cobertura_protegida, prioridade_bivariada, gbif_consulta_id, pressao_consulta_id) "
        "VALUES (-62.0, -1.5, 0.5, 310.0, 140.0, 12.0, 12.0, 3080.0, 2, 0.00065, 'negro', 0.42, 0.15, 'G3_P3', ?, ?)",
        (cid_gbif, cid_gbif),
    )
    con.execute(
        "INSERT INTO molecula (id, tipo, nome, inchikey, chembl_id, max_fase_clinica, fase_consulta_id) "
        "VALUES (2, 'pequena_molecula', 'Farmaco Sintetico Derivado', 'ZZZZZZZZZZZZZZ-UHFFFAOYSA-N', 'CHEMBL999999', 4.0, ?)",
        (cid_chembl,),
    )
    con.execute(
        "INSERT INTO relacao_molecula (origem_id, destino_id, tipo, texto, referencia_id, consulta_id) "
        "VALUES (1, 2, 'inspirou', 'A gedunina isolada inspirou o desenho estrutural do análogo sintético.', ?, ?)",
        (ref_id, cid_chembl),
    )
    con.execute(
        "INSERT INTO via_biologica (id, reactome_id, nome, especie, doi, consulta_id) "
        "VALUES (1, 'R-HSA-9018678', 'Cellular response to heat stress', 'Homo sapiens', '10.3180/R-HSA-9018678.1', ?)",
        (cid_chembl,),
    )
    con.execute("INSERT INTO alvo_via (alvo_id, via_id, consulta_id) VALUES (1, 1, ?)", (cid_chembl,))
    # via de um alvo sem medida pública: não é listada
    con.execute("INSERT INTO alvo (id, nome, chembl_id, natureza) VALUES (2, 'Alvo sem medida pública', 'CHEMBL1', 'proteina_unica')")
    con.execute("INSERT INTO via_biologica (id, reactome_id, nome, especie, consulta_id) VALUES (2, 'R-HSA-1', 'Via de alvo sem medida', 'Homo sapiens', ?)", (cid_chembl,))
    con.execute("INSERT INTO alvo_via (alvo_id, via_id, consulta_id) VALUES (2, 2, ?)", (cid_chembl,))
    from bmb.conformeros import gerar
    import hashlib
    smi = "Cn1c(=O)c2c(ncn2C)n(C)c1=O"
    ik = con.execute("SELECT inchikey FROM molecula WHERE id=1").fetchone()[0]
    con.execute("UPDATE molecula SET smiles=? WHERE id=1", (smi,))
    geom, motivo = gerar((1, "Cafeína", smi, ik, None))
    assert motivo is None
    corpo = json.dumps(geom).encode()
    sha = hashlib.sha256(corpo).hexdigest()
    ref = f"estruturas3d/ens_1_{sha[:16]}.json"
    arq = tmp_path / "sem-site-v2" / "dados" / ref
    arq.parent.mkdir(parents=True)
    arq.write_bytes(corpo)
    con.execute(
        "INSERT INTO estrutura_3d (molecula_id, natureza, fonte_id, codigo, metodo, arquivo_geometria, geometria_sha256, consulta_id) "
        "VALUES (1, 'conformero_calculado', 'rdkit_local', 'ensemble-1', ?, ?, ?, ?)", (geom["met"], ref, sha, cid_chembl))
    construir.etapa_busca(con, lambda *_: None)
    prontidao.recalcular_todas(con)
    con.commit()

    caminho = con.execute("PRAGMA database_list").fetchone()[2]
    c = TestClient(criar_app(caminho, app_dir=tmp_path / "sem-site-v2"))

    spec = c.get("/api/openapi.json").json()
    for rota in ("/api/bacias", "/api/bacias/{id}", "/api/lacunas", "/api/linhagens", "/api/vias", "/api/estruturas3d"):
        assert rota in spec["paths"]

    s = c.get("/api/saude").json()
    assert s["bacias"] == 1 and s["celulas_lacuna"] == 1 and s["estruturas_3d"] == 1 and s["vias_reactome"] == 1 and s["linhagens_bioinspiradas"] == 1

    bacias_r = c.get("/api/bacias").json()
    assert bacias_r["total"] == 1 and bacias_r["bacias"][0]["id"] == "negro" and bacias_r["bacias"][0]["n_taxons_recorte"] == 1
    b_det = c.get("/api/bacias/negro").json()
    assert b_det["taxons"][0]["gbif"] == 100 and b_det["consulta"]["fonte"] == "gbif"
    assert c.get("/api/bacias/inexistente").status_code == 404
    assert c.get("/api/taxa?bacia=negro").json()["total"] == 1

    lac = c.get("/api/lacunas?bacia=negro&prioridade=G3_P3").json()
    assert lac["total"] == 1 and lac["itens"][0]["prioridade_bivariada"] == "G3_P3" and lac["consultas"]

    lin = c.get("/api/linhagens").json()
    assert lin["total"] == 1 and lin["linhagens"][0]["origem"]["id"] == 1 and lin["linhagens"][0]["destino"]["id"] == 2
    assert c.get("/api/moleculas/2").status_code == 200
    assert c.get("/api/moleculas?tem_3d=1").json()["total"] == 1

    vias_r = c.get("/api/vias?q=heat").json()
    assert vias_r["total"] == 1 and vias_r["itens"][0]["reactome_id"] == "R-HSA-9018678" and vias_r["itens"][0]["n_alvos"] == 1
    assert c.get("/api/vias").json()["total"] == 1

    e3d = c.get("/api/estruturas3d?natureza=conformero_calculado&molecula=1").json()
    assert e3d["total"] == 1 and e3d["itens"][0]["fonte"] == "rdkit_local"
    assert c.get("/api/estruturas3d/experimentais").json()["total"] == 0
    assert c.get("/api/estruturas3d/experimentais/index.json").status_code == 200
    assert c.get("/api/estruturas3d?molecula=abc").status_code == 400


def test_bacias_com_prefixo_bac_maiusculo_aceitam_slug_e_qualquer_caixa(mini, tmp_path):
    con = mini.con
    cid_gbif = con.execute("SELECT id FROM consulta WHERE fonte_id='gbif' LIMIT 1").fetchone()[0]
    con.execute(
        "INSERT INTO bacia_hidrografica (id, nome, rio_principal, area_km2, poligono_wkt, cor_hex, consulta_id) "
        "VALUES ('BAC:SOLIMOES', 'Bacia do Solimões', 'Rio Solimões', 910000.0, 'POLYGON((-70 0,-62 0,-62 -5,-70 -5,-70 0))', '#22d3ee', ?)",
        (cid_gbif,),
    )
    con.execute("INSERT INTO ocorrencia_bacia (taxon_id, bacia_id, n, consulta_id) VALUES (1, 'BAC:SOLIMOES', 40, ?)", (cid_gbif,))
    con.execute(
        "INSERT INTO celula_lacuna (lon, lat, passo_graus, x_mapa, y_mapa, w_mapa, h_mapa, area_km2, n_ocorrencias_gbif, "
        "densidade_km2, bacia_id, pressao_desmatamento, cobertura_protegida, prioridade_bivariada, gbif_consulta_id, pressao_consulta_id) "
        "VALUES (-65.0, -2.5, 0.5, 290.0, 160.0, 12.0, 12.0, 3080.0, 1, 0.00032, 'BAC:SOLIMOES', 0.30, 0.20, 'G3_P2', ?, ?)",
        (cid_gbif, cid_gbif),
    )
    c = TestClient(criar_app(_preparar(mini), app_dir=tmp_path / "sem-site-bac"))
    item = c.get("/api/bacias").json()["bacias"][0]
    assert item["id"] == "BAC:SOLIMOES" and item["slug"] == "solimoes"
    for variante in ("BAC:SOLIMOES", "bac:solimoes", "SOLIMOES", "solimoes"):
        r_det = c.get(f"/api/bacias/{variante}")
        assert r_det.status_code == 200 and r_det.json()["id"] == "BAC:SOLIMOES" and len(r_det.json()["taxons"]) == 1
        assert c.get(f"/api/taxa?bacia={variante}").json()["total"] == 1
        assert c.get(f"/api/lacunas?bacia={variante}").json()["total"] == 1
