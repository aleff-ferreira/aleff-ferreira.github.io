# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""A exportação publica só o que é público, com proveniência, e é reproduzível e verificável.

O contrato é `docs/dev/CONTRATO_DE_DADOS.md`. Além da forma de cada pacote, os testes conferem a fronteira pelo lado
negativo: registro retido, rejeitado ou de acesso restrito, obra retida ou duplicada, linhagem rejeitada, imagem
retida, texto livre de curador e qualquer identificador interno não aparecem em arquivo nenhum do destino.
"""
import csv
import hashlib
import importlib.util
import json
import zipfile
from pathlib import Path
from types import SimpleNamespace

import pytest

from bmb import config, curadoria, db, procedencia, prontidao, quarentena, texto, validar
from bmb.exportar import banco_publico, pacotes
from conftest import AGORA, _afirmacao, _consulta, _molecula

RAIZ = Path(__file__).resolve().parents[2]
# Cadeias que não podem constar em arquivo nenhum do pacote público.
PROIBIDAS = ("quarentena", "motivo_quarentena", "regra_quarentena", "nivel_procedencia", "escopo_biogeografico", "T3a", "T3b",
             "benchmark", "afirmacoes_em_quarentena", "localidade_declarada", "procedencia_material", "motivo_exclusao",
             "nomes_rejeitados", "retencoes")
BINARIOS = {".webp", ".jpg", ".jpeg", ".png"}


def _json(p):
    return json.loads(p.read_text(encoding="utf-8"))


def _csv(p):
    with open(p, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def _textos(pasta):
    """(caminho relativo, texto) de cada arquivo de texto da pasta, abrindo também o que está dentro de .zip."""
    for arq in sorted(p for p in pasta.rglob("*") if p.is_file()):
        rel = arq.relative_to(pasta).as_posix()
        if arq.suffix.lower() in BINARIOS:
            continue
        if arq.suffix.lower() == ".zip":
            with zipfile.ZipFile(arq) as z:
                for nome in z.namelist():
                    yield f"{rel}!{nome}", z.read(nome).decode("utf-8")
        else:
            yield rel, arq.read_text(encoding="utf-8")


def _ocorrencias(pasta, cadeias):
    return [(rel, c) for rel, txt in _textos(pasta) for c in cadeias if c in txt]


@pytest.fixture
def publico(mini, tmp_path):
    prontidao.recalcular_todas(mini.con)
    destino = tmp_path / "publico"
    pacotes.exportar_tudo(mini.con, destino, log=lambda *_: None)
    return destino


@pytest.fixture
def cenario(mini):
    """O banco mínimo mais um registro de cada espécie que NÃO pode sair, ao lado de registros públicos de cada tipo."""
    con = mini.con
    quarentena.registrar_catalogo(con)
    gbif = con.execute("SELECT gbif_key FROM taxon WHERE id=?", (mini.taxon,)).fetchone()[0]

    # obra retida (ligada à afirmação pública, ao lado da obra boa) e linha duplicada de outra obra
    con.execute("INSERT INTO referencia (doi, titulo, ano, resolvida, consulta_id) VALUES ('10.1000/retida','Obra retida de teste',2019,0,?)",
                (mini.consulta_lotus,))
    ref_retida = con.execute("SELECT id FROM referencia WHERE doi='10.1000/retida'").fetchone()[0]
    quarentena.reter_referencia(con, ref_retida, "REF-DOI-INEXISTENTE", doi="10.1000/retida", resposta_handle="handle não encontrado")
    con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (mini.af_composto, ref_retida))
    con.execute("INSERT INTO referencia (pmid, titulo, ano, resolvida, duplicata_de) VALUES ('999001','Linha duplicada de teste',2020,1,?)", (mini.ref,))

    # molécula cuja única ocorrência está retida por regra; a medida dela, em estado público, também não sai
    m_retida = _molecula(con, "Retidina de teste", "AAAAAAAAAAAAAA-UHFFFAOYSA-N", chembl_id="CHEMBL900002")
    af_retida = _afirmacao(con, "composto_em_organismo", m_retida, mini.consulta_lotus, taxon_id=mini.taxon, origem="lotus:retida",
                           organismo_na_fonte="Carapa guianensis", texto="«Retidina de teste» consta como relatado em Carapa guianensis.")
    con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (af_retida, mini.ref))
    quarentena.declarar(con, ("TAX-HOMONIMO",), {af_retida: {"TAX-HOMONIMO": {
        "organismo_fonte": "Carapa guianensis", "uso_fonte": "Carapa guianensis Homônimo", "taxon": "Carapa guianensis", "autoria_taxon": "Aubl."}}})
    af_orfa = _afirmacao(con, "atividade_biologica", m_retida, mini.consulta_chembl, alvo_id=mini.alvo,
                         origem="chembl:agregado:CHEMBL900002:CHEMBL226:Ki", fonte="chembl", medida_tipo="Ki", medida_relacao="=",
                         medida_valor=77.0, medida_unidade="nM", medida_agregacao="unica", medida_n=1, medida_n_documentos=1,
                         medida_min=77.0, medida_max=77.0, ensaio_tipo="B", texto="Medida de «Retidina de teste» sobre Receptor A1.")
    con.execute("INSERT INTO medida_bioatividade (activity_id, afirmacao_id, molecula_id, alvo_chembl_id, tipo, relacao, valor_nm, "
                "pchembl, usada, consulta_id) VALUES (2, ?, ?, 'CHEMBL226', 'Ki', '=', 77.0, 7.11, 1, ?)", (af_orfa, m_retida, mini.consulta_chembl))

    # afirmação rejeitada por curador e afirmação de acesso restrito
    m_rej = _molecula(con, "Rejeitadina de teste", "BBBBBBBBBBBBBB-UHFFFAOYSA-N")
    af_rej = _afirmacao(con, "composto_em_organismo", m_rej, mini.consulta_lotus, taxon_id=mini.taxon, origem="lotus:rej",
                        organismo_na_fonte="Carapa guianensis", estado="rejeitado")
    m_restr = _molecula(con, "Restritina de teste", "CCCCCCCCCCCCCC-UHFFFAOYSA-N")
    af_restr = _afirmacao(con, "composto_em_organismo", m_restr, mini.consulta_lotus, taxon_id=mini.taxon, origem="lotus:restr",
                          organismo_na_fonte="Carapa guianensis", classe_acesso="restrito")
    con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (af_restr, mini.ref))

    # linhagem pública (com a frase da obra) e linhagem rejeitada
    m_farmaco = _molecula(con, "Farmacotest", "DDDDDDDDDDDDDD-UHFFFAOYSA-N", chembl_id="CHEMBL900001", max_fase_clinica=4.0,
                          fase_consulta_id=mini.consulta_chembl)
    con.execute("INSERT INTO relacao_molecula (origem_id, destino_id, tipo, texto, referencia_id, consulta_id, chave, trecho, trecho_fonte, "
                "trecho_sha256, trecho_conferido_em) VALUES (?,?,'inspirou','A cafeína foi o composto-líder do fármaco de teste.',?,?,"
                "'cafeina-farmacotest','Caffeine was the lead compound for the test drug.','resumo_pubmed',?,?)",
                (mini.molecula, m_farmaco, mini.ref, mini.consulta_chembl, "f" * 64, AGORA))
    m_contradita = _molecula(con, "Contraditina de teste", "EEEEEEEEEEEEEE-UHFFFAOYSA-N")
    con.execute("INSERT INTO relacao_molecula (origem_id, destino_id, tipo, texto, referencia_id, consulta_id, chave, estado, regra_quarentena, "
                "motivo_quarentena) VALUES (?,?,'derivado_de','Relação não sustentada: origem sintética de teste.',?,?,'cafeina-contraditina',"
                "'rejeitado','LIN-CONTRADITA','A literatura de desenho indica outra origem (teste).')",
                (mini.molecula, m_contradita, mini.ref, mini.consulta_chembl))

    # fotografia ativa e fotografia retida, cujo arquivo antigo ainda está em disco
    pasta_img = config.SAIDA_DIR / "imagens" / str(gbif)
    pasta_img.mkdir(parents=True)
    (pasta_img / "1.jpg").write_bytes(b"miniatura ativa")
    (pasta_img / "2.jpg").write_bytes(b"miniatura de imagem retida")
    con.execute("INSERT INTO midia (taxon_id, url, pagina, licenca, autor, gbif_ocorrencia, arquivo, arquivo_sha256, largura, altura, consulta_id) "
                "VALUES (?, 'https://x.test/1.jpg', 'https://www.gbif.org/occurrence/1', 'CC BY', 'Autora Ativa', '1', ?, ?, 320, 240, ?)",
                (mini.taxon, f"imagens/{gbif}/1.jpg", hashlib.sha256(b"miniatura ativa").hexdigest(), mini.consulta_gbif))
    con.execute("INSERT INTO midia (taxon_id, url, pagina, licenca, autor, gbif_ocorrencia, consulta_id, estado, motivo_quarentena) "
                "VALUES (?, 'https://x.test/2.jpg', 'https://www.gbif.org/occurrence/2', 'CC BY', 'Autor Retido', '2', ?, 'quarentena', "
                "'Espécime morto na fotografia (teste).')", (mini.taxon, mini.consulta_gbif))

    # afirmação conferida por curador, com procedência registrada como país e UF
    m_verif = _molecula(con, "Verificadina de teste", "FFFFFFFFFFFFFF-UHFFFAOYSA-N")
    af_verif = _afirmacao(con, "composto_em_organismo", m_verif, mini.consulta_lotus, taxon_id=mini.taxon, origem="lotus:verif",
                          organismo_na_fonte="Carapa guianensis; Persoonia guareoides")
    con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (af_verif, mini.ref))
    quarentena.aplicar_estados(con)
    con.commit()
    curadoria.verificar(con, {"afirmacao_id": af_verif, "referencia_id": mini.ref, "curador": "Curadora Teste", "decisao": "confirmada",
                              "sensibilidade": "sem_restricao", "acesso_texto": "texto_completo_aberto",
                              "passagem_conferida": "Compound seven was isolated from the seed oil of Carapa guianensis.",
                              "procedencia_material": "Brasil: AM", "escopo_geografico_lido": "amazonia_br", "voucher": "INPA 22410"})
    prontidao.recalcular_todas(con)
    con.commit()
    return SimpleNamespace(**vars(mini), gbif=gbif, ref_retida=ref_retida, m_retida=m_retida, af_retida=af_retida, af_orfa=af_orfa,
                           m_rej=m_rej, af_rej=af_rej, m_restr=m_restr, af_restr=af_restr, m_farmaco=m_farmaco,
                           m_contradita=m_contradita, m_verif=m_verif, af_verif=af_verif)


@pytest.fixture
def publico_do_cenario(cenario, tmp_path):
    destino = tmp_path / "publico_do_cenario"
    # `forcar`: a fronteira tem de valer mesmo que o validador, que evolui à parte, aponte algo no banco de teste
    pacotes.exportar_tudo(cenario.con, destino, log=lambda *_: None, forcar=True)
    return destino


# ═══════════════════════════ forma dos pacotes ═══════════════════════════
def test_estrutura_dos_pacotes(publico, mini):
    for f in ("manifesto.json", "indice.json", "indice_mapa.json", "moleculas_indice.json", "inchikeys_indice.json",
              "sinonimos_indice.json", "territorios.json", "SHA256SUMS.txt"):
        assert (publico / f).exists(), f
    for f in ("quarentena.json", "benchmark_validacao.json", "nomes_rejeitados.json", "interno"):
        assert not (publico / f).exists(), f
    gbif = mini.con.execute("SELECT gbif_key FROM taxon").fetchone()[0]
    t = _json(publico / "taxa" / f"{gbif}.json")
    assert t["nome"] == "Carapa guianensis" and t["recorte"]["dentro"] and len(t["moleculas"]) == 1
    assert t["recorte"]["consulta"] is not None and t["consultas"][t["recorte"]["consulta"]]["fonte"] == "gbif"
    mol = _json(publico / "moleculas" / f"{mini.molecula}.json")
    assert mol["clinico"] and mol["atividades"] and mol["ocorre_em"]
    assert mol["clinico"]["prontidao"]["identidade_biologica"] == "nao_se_aplica"


def test_afirmacao_publica_traz_evidencia_procedencia_e_medida_agregada(publico, mini):
    mol = _json(publico / "moleculas" / f"{mini.molecula}.json")
    oc = mol["ocorre_em"][0]["afirmacao"]
    assert oc["tipo"] == "composto_em_organismo" and oc["evidencia"] == "base_curada" and oc["procedencia"] == "nao_declarada"
    assert "organismo_na_fonte" not in oc                                   # a fonte usa o nome aceito: nada a acrescentar
    assert "nivel_procedencia" not in oc and "procedencia_material" not in oc and "passagem_origem" not in oc
    at = mol["atividades"][0]
    assert at["evidencia"] == "base_curada" and "procedencia" not in at     # procedência só em afirmação ligada a organismo
    assert at["medida"] == {"tipo": "IC50", "valor": 12.0, "unidade": "nM", "agregacao": "unica", "n": 1, "n_publicacoes": 1,
                            "min": 12.0, "max": 12.0}
    assert at["ensaio_tipo"] == "B"
    assert at["alvo"]["nome"] == "Receptor A1" and at["alvo"]["natureza"] == "proteina_unica" and at["alvo"]["chembl"] == "CHEMBL226"
    assert mol["clinico"]["fontes_regulatorias"] == [{"tipo": "DailyMed", "id": "x", "url": "https://dailymed.nlm.nih.gov/x"}]
    # identidade química: estrutura com estereoquímica e esqueleto 2D
    assert mol["inchikey"] == "RYYVLZVUVIJVGH-UHFFFAOYSA-N" and mol["conectividade"] == "RYYVLZVUVIJVGH" and mol["n_mesma_conectividade"] == 1
    for campo in ("massa", "massa_monoisotopica", "massa_media", "estereocentros", "estereocentros_indefinidos"):
        assert campo in mol
    # forma compacta, dentro do pacote do táxon
    gbif = mini.con.execute("SELECT gbif_key FROM taxon").fetchone()[0]
    compacta = _json(publico / "taxa" / f"{gbif}.json")["moleculas"][0]["afirmacao"]
    assert compacta["evidencia"] == "base_curada" and compacta["procedencia"] == "nao_declarada" and "nivel_procedencia" not in compacta


def test_medida_com_relacao_diferente_de_igual_nunca_perde_a_relacao(mini, tmp_path):
    mini.con.execute("UPDATE afirmacao SET medida_relacao='>', medida_agregacao=NULL, medida_n=NULL, medida_n_documentos=NULL, "
                     "medida_min=NULL, medida_max=NULL WHERE id=?", (mini.af_atividade,))
    prontidao.recalcular_todas(mini.con)
    ctx = pacotes.Contexto(mini.con)
    m = ctx.con.execute("SELECT * FROM molecula WHERE id=?", (mini.molecula,)).fetchone()
    medida = pacotes.pacote_molecula(ctx, m)["atividades"][0]["medida"]
    assert medida["relacao"] == ">" and medida["agregacao"] is None and medida["n"] is None


def test_taxon_traz_distribuicao_cobertura_publica_e_sinonimos_com_autoria(mini, tmp_path):
    con = mini.con
    con.executemany("INSERT INTO taxon_sinonimo (taxon_id, nome, origem, autoria, categoria, status_gbif) VALUES (?,?,?,?,?,?)", [
        (mini.taxon, "Persoonia guareoides", "gbif", "Willd.", "SPECIES", "SYNONYM"),
        (mini.taxon, "Carapa latifolia", "gbif", None, None, "HETEROTYPIC_SYNONYM"),
        (mini.taxon, "Carapa parte", "gbif", "Fulano", "SPECIES", "PROPARTE_SYNONYM"),
        (mini.taxon, "Carapa malaplicada", "gbif", "Beltrano", "SPECIES", "MISAPPLIED"),
        (mini.taxon, "Carapa duvidosa", "gbif", None, "SPECIES", "DOUBTFUL"),
        (mini.taxon, "Carapa da semente", "semente", None, None, None),
        (mini.taxon, "Andiroba tree", "uniprot", None, None, None)])       # nome vernáculo vindo do UniProt
    prontidao.recalcular_todas(con)
    destino = tmp_path / "s"
    pacotes.exportar_tudo(con, destino, log=lambda *_: None)
    gbif = con.execute("SELECT gbif_key FROM taxon").fetchone()[0]
    t = _json(destino / "taxa" / f"{gbif}.json")
    # só o que o backbone registra como sinônimo: nomes de busca da semente e do UniProt não são sinônimos
    assert t["sinonimos"] == [{"nome": "Carapa latifolia"},
                              {"nome": "Persoonia guareoides", "autoria": "Willd.", "categoria": "SPECIES"}]
    assert _json(destino / "sinonimos_indice.json")["por_gbif"][str(gbif)] == ["Carapa latifolia", "Persoonia guareoides"]
    for excluido in ("Carapa parte", "Carapa malaplicada", "Carapa duvidosa", "Carapa da semente", "Andiroba tree"):
        assert _ocorrencias(destino, [excluido]) == []
    assert t["distribuicao_br"] in procedencia.ROTULOS_DISTRIBUICAO and "escopo_biogeografico" not in t and "escopo_biogeografico" not in t["recorte"]
    cob = t["cobertura"]
    assert (cob["compostos"], cob["compostos_lotus"], cob["compostos_nubbe"], cob["compostos_npatlas"]) == (1, 1, 0, 0)
    assert "compostos_fonte" not in cob and "compostos_incluidos" not in cob and cob["consulta_lotus"] is not None


def test_indice_de_taxa_e_compacto_e_coerente(publico):
    ix = _json(publico / "indice.json")
    assert ix["colunas"][:3] == ["id", "gbif", "nome"] and len(ix["linhas"]) == 1
    assert ix["colunas"][-2:] == ["distribuicao_br", "coleta_amazonica_declarada"]
    linha = dict(zip(ix["colunas"], ix["linhas"][0]))
    assert linha["recorte"] == 1 and linha["predominio"] == "p" and linha["moleculas"] == 1 and linha["aprovado"] == 1
    assert linha["coleta_amazonica_declarada"] == 0 and linha["distribuicao_br"] in procedencia.ROTULOS_DISTRIBUICAO
    assert (publico / "indice.json").stat().st_size < 4096
    assert _json(publico / "indice_mapa.json")["colunas"][-1] == "coleta_amazonica_declarada"
    mols = _json(publico / "moleculas_indice.json")
    assert "coleta_amazonica_declarada" in mols["colunas"] and mols["dados"]["coleta_amazonica_declarada"] == [0]
    assert "classe" in mols["colunas"] and "dicionario_classes" in mols and "formula" not in mols["colunas"]
    assert "bacias" in ix["colunas"] and "bacias" in ix["legenda"]
    iks = _json(publico / "inchikeys_indice.json")
    assert iks["esquema"] == 1 and len(iks["iks"]) == len(mols["dados"]["id"]) and len(iks["formulas"]) == len(mols["dados"]["id"])


def test_coleta_amazonica_declarada_diz_quem_declara(mini, tmp_path):
    """UF da Amazônia Legal declarada pela base marca o táxon e a molécula; a distribuição da espécie, sozinha, não."""
    con = mini.con
    assert pacotes.indice_taxa(pacotes.Contexto(con))["linhas"][0][-1] == 0
    con.execute("UPDATE afirmacao SET uf_coleta_declarada='AM', pais_coleta_declarado='BR', fonte_id='nubbe' WHERE id=?", (mini.af_composto,))
    prontidao.recalcular_todas(con)
    ctx = pacotes.Contexto(con)
    assert pacotes.indice_taxa(ctx)["linhas"][0][-1] == 1 and mini.molecula in ctx.mol_coleta_amazonica
    t = con.execute("SELECT * FROM taxon WHERE id=?", (mini.taxon,)).fetchone()
    af = pacotes.pacote_taxon(ctx, t)["moleculas"][0]["afirmacao"]
    assert (af["procedencia"], af["uf_coleta"], af["pais_coleta"]) == ("base_declara_amazonia_legal", "AM", "BR")
    assert ctx.contagens()["procedencia_declarada"]["base_declara_amazonia_legal"] == 1


# ═══════════════════════════ manifesto ═══════════════════════════
def test_manifesto_so_conta_o_que_e_publico_e_traz_os_rotulos(publico_do_cenario, cenario):
    m = _json(publico_do_cenario / "manifesto.json")
    c = m["contagens"]
    for extinta in ("afirmacoes_em_quarentena", "imagens_em_quarentena", "afirmacoes_procedencia_amazonica_estrita_t1_t3",
                    "afirmacoes_por_procedencia", "afirmacoes_com_acesso_restrito_nao_exibidas", "referencias_retratadas"):
        assert extinta not in c, extinta
    assert "benchmark_validacao" not in m
    # públicas: 1 composto do banco mínimo + 1 verificada, 1 atividade, 1 clínico (retida, rejeitada, restrita e órfã ficam de fora)
    assert c["afirmacoes_publicas"] == 4
    assert c["afirmacoes_por_tipo"] == {"composto_em_organismo": 2, "atividade_biologica": 1, "funcao_toxina": 0, "efeito_clinico_documentado": 1}
    assert c["afirmacoes_por_evidencia"] == {"curador": 1, "artigo_trecho": 0, "artigo_cita_organismo": 0, "base_curada": 3}
    assert c["afirmacoes_verificadas"] == 1
    assert c["procedencia_declarada"]["curador_artigo_amazonia"] == 1 and c["procedencia_declarada"]["nao_declarada"] == 1
    assert set(c["procedencia_declarada"]) == set(procedencia.ROTULOS_PROCEDENCIA)
    assert set(c["taxons_por_distribuicao"]) == set(procedencia.ROTULOS_DISTRIBUICAO) and sum(c["taxons_por_distribuicao"].values()) == 1
    # moléculas públicas: cafeína, a verificada e o fármaco da linhagem pública
    assert c["moleculas"] == 3 and c["moleculas_inchikey"] == 3 and c["conectividades_2d"] == 3
    assert c["pares_taxon_molecula"] == 2 and c["pares_taxon_molecula_em_mais_de_uma_base"] == 0
    assert c["linhagens_bioinspiradas"] == 1 and c["imagens"] == 1 and c["referencias"] == 1
    assert m["rotulos"] == {"evidencia": pacotes.ROTULOS_EVIDENCIA, "procedencia": procedencia.ROTULOS_PROCEDENCIA,
                            "procedencia_artigo": procedencia.ROTULOS_PROCEDENCIA_ARTIGO,
                            "distribuicao_br": procedencia.ROTULOS_DISTRIBUICAO, "natureza_alvo": texto.ROTULO_NATUREZA_ALVO}
    assert list(m["rotulos"]["evidencia"]) == ["curador", "artigo_trecho", "artigo_cita_organismo", "base_curada"]
    assert m["estados"]["candidato"] == "Registro de base curada; passagem da publicação ainda não lida por curador."
    assert [p["n"] for p in m["principios"]] == [1, 2, 3, 4, 5] and m["principios"][3]["titulo"] == "Associação documentada não é eficácia"
    assert m["politica_de_exclusao"]["texto"] and all(set(e) == {"nome", "motivo"} for e in m["politica_de_exclusao"]["especies"])
    # da construção, só o nome da etapa e a data
    assert all(set(e) == {"concluida_em"} for e in m["etapas"].values())


def test_etapas_do_manifesto_nao_levam_o_resumo_da_construcao(mini, tmp_path):
    con = mini.con
    con.execute("INSERT INTO etapa (nome, iniciada_em, concluida_em, resumo) VALUES ('compostos', ?, ?, ?)",
                (AGORA, AGORA, json.dumps({"regras_declaradas": {"TAX-HOMONIMO": 7}, "antigas_nao_reproduzidas": 12,
                                           "organismos_resolvidos": {"lotus:homonimo_nao_resolvido": 3}})))
    con.execute("INSERT INTO etapa (nome, iniciada_em, concluida_em, resumo) VALUES ('referencias', ?, NULL, NULL)", (AGORA,))
    prontidao.recalcular_todas(con)
    destino = tmp_path / "e"
    m = pacotes.exportar_tudo(con, destino, log=lambda *_: None)
    assert m["etapas"] == {"compostos": {"concluida_em": AGORA}}                 # etapa não concluída não é listada
    assert _ocorrencias(destino, ["antigas_nao_reproduzidas", "regras_declaradas", "TAX-HOMONIMO", "homonimo_nao_resolvido"]) == []


def test_metricas_sem_dupla_contagem(mini, tmp_path):
    """O mesmo par táxon–molécula em duas bases é um par; dois estereoisômeros são duas estruturas e um esqueleto 2D."""
    con = mini.con
    cid_nubbe = con.execute("INSERT INTO consulta (fonte_id, url, consultado_em, status, bytes, sha256) VALUES ('nubbe','https://nubbe.test/x',?,200,1,?)",
                            (AGORA, "d" * 64)).lastrowid
    con.execute("INSERT INTO organismo_fonte (fonte_id, nome_fonte, id_fonte, via, taxon_id, decisao, resolvido_em) "
                "VALUES ('nubbe', 'Carapa guianensis', '', 'nome_estrito', ?, 'aceito', ?)", (mini.taxon, AGORA))
    segunda = _afirmacao(con, "composto_em_organismo", mini.molecula, cid_nubbe, taxon_id=mini.taxon, origem="nubbe:1", fonte="nubbe",
                         organismo_na_fonte="Carapa guianensis", uf_coleta_declarada="PA", pais_coleta_declarado="BR")
    con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (segunda, mini.ref))
    isomero = _molecula(con, "Estereoisômero de teste", "RYYVLZVUVIJVGH-ABCDEFGHSA-N")
    terceira = _afirmacao(con, "composto_em_organismo", isomero, mini.consulta_lotus, taxon_id=mini.taxon, origem="lotus:iso",
                          organismo_na_fonte="Carapa guianensis")
    con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (terceira, mini.ref))
    prontidao.recalcular_todas(con)
    destino = tmp_path / "d"
    c = pacotes.exportar_tudo(con, destino, log=lambda *_: None)["contagens"]
    assert c["afirmacoes_por_tipo"]["composto_em_organismo"] == 3
    assert c["pares_taxon_molecula"] == 2 and c["pares_taxon_molecula_em_mais_de_uma_base"] == 1
    assert c["moleculas_inchikey"] == 2 and c["conectividades_2d"] == 1
    pac_iso = _json(destino / "moleculas" / f"{isomero}.json")
    assert pac_iso["n_mesma_conectividade"] == 2
    assert [x["id"] for x in pac_iso["mesma_conectividade"]] == [mini.molecula]
    gbif = con.execute("SELECT gbif_key FROM taxon").fetchone()[0]
    t = _json(destino / "taxa" / f"{gbif}.json")
    cafeina = next(x for x in t["moleculas"] if x["id"] == mini.molecula)
    # o par afirmado por LOTUS e NuBBE-DB aparece uma vez, com as duas bases; representa-o a afirmação com coleta amazônica declarada
    assert cafeina["fontes"] == ["lotus", "nubbe"] and cafeina["n_afirmacoes"] == 2 and cafeina["afirmacao"]["id"] == segunda
    assert cafeina["afirmacao"]["procedencia"] == "base_declara_amazonia_legal" and t["cobertura"]["compostos"] == 2
    assert (t["cobertura"]["compostos_lotus"], t["cobertura"]["compostos_nubbe"]) == (2, 1)


# ═══════════════════════════ fronteira: o que não sai ═══════════════════════════
def test_cenario_de_fronteira_e_um_banco_valido(cenario):
    assert [(e["id"], e["amostra"]) for e in validar.validar(cenario.con)["erros"]] == []


def test_nada_interno_em_arquivo_nenhum_do_destino(publico_do_cenario, cenario):
    assert _ocorrencias(publico_do_cenario, PROIBIDAS) == []
    # códigos de regra, motivos e o texto dos registros retidos
    internas = ["TAX-HOMONIMO", "REF-DOI-INEXISTENTE", "LIN-CONTRADITA", "Homônimo", "handle não encontrado", "Relação não sustentada",
                "A literatura de desenho indica outra origem", "Espécime morto na fotografia", "Autor Retido"]
    assert _ocorrencias(publico_do_cenario, internas) == []
    # os registros que não são públicos, por nome, identificador e obra
    ausentes = ["Retidina de teste", "AAAAAAAAAAAAAA", "CHEMBL900002", "Rejeitadina de teste", "BBBBBBBBBBBBBB", "Restritina de teste",
                "CCCCCCCCCCCCCC", "Contraditina de teste", "EEEEEEEEEEEEEE", "10.1000/retida", "Obra retida de teste",
                "Linha duplicada de teste", "x.test/2.jpg", "occurrence/2"]
    assert _ocorrencias(publico_do_cenario, ausentes) == []
    assert pacotes.conferir_fronteira(publico_do_cenario) == []


def test_registros_retidos_nao_estao_nos_pacotes_nem_nas_tabelas(publico_do_cenario, cenario):
    d = publico_do_cenario
    t = _json(d / "taxa" / f"{cenario.gbif}.json")
    assert sorted(x["id"] for x in t["moleculas"]) == sorted([cenario.molecula, cenario.m_verif])
    assert t["total_moleculas"] == 2 and t["cobertura"]["compostos"] == 2
    assert [i["arquivo"] for i in t["imagens"]] == [f"imagens/{cenario.gbif}/1.jpg"]
    assert (d / "imagens" / str(cenario.gbif) / "1.jpg").exists() and not (d / "imagens" / str(cenario.gbif) / "2.jpg").exists()
    # só as moléculas públicas têm pacote, entrada no índice e linha na tabela
    publicas = sorted([cenario.molecula, cenario.m_verif, cenario.m_farmaco])
    assert sorted(int(p.stem) for p in (d / "moleculas").glob("*.json")) == publicas
    assert sorted(_json(d / "moleculas_indice.json")["dados"]["id"]) == publicas
    assert sorted(int(l["molecula_id"]) for l in _csv(d / "tabelas" / "moleculas.csv")) == publicas
    # afirmações: retida, rejeitada, restrita e a medida da molécula sem registro público ficam de fora de tudo
    fora = {cenario.af_retida, cenario.af_orfa, cenario.af_rej, cenario.af_restr}
    ids_csv = {int(l["afirmacao_id"]) for l in _csv(d / "tabelas" / "afirmacoes.csv")}
    assert ids_csv == {cenario.af_composto, cenario.af_atividade, cenario.af_clinico, cenario.af_verif} and not (ids_csv & fora)
    assert {int(l["afirmacao_id"]) for l in _csv(d / "tabelas" / "prontidao.csv")} == ids_csv
    # obras: só a citável; a retida some também da afirmação pública que a citava
    assert [l["doi"] for l in _csv(d / "tabelas" / "referencias.csv")] == ["10.1000/abc"]
    cafeina = _json(d / "moleculas" / f"{cenario.molecula}.json")
    assert [r["doi"] for r in cafeina["refs"]] == ["10.1000/abc"] and cafeina["ocorre_em"][0]["afirmacao"]["refs"] == [0]
    assert all("retratada" not in r for r in cafeina["refs"])
    # linhagens: só a pública, com a frase da obra citada
    assert [(l["papel"], l["parceiro"]["nome"]) for l in cafeina["linhagens"]] == [("origem", "Farmacotest")]
    assert cafeina["linhagens"][0]["trecho"] == "Caffeine was the lead compound for the test drug." and cafeina["linhagens"][0]["trecho_fonte"] == "resumo_pubmed"
    linhas = _csv(d / "tabelas" / "linhagens_bioinspiradas.csv")
    assert [(l["destino_nome"], l["trecho_fonte"], l["doi"]) for l in linhas] == [("Farmacotest", "resumo_pubmed", "10.1000/abc")]
    assert [l["destino"]["nome"] for l in _json(d / "viz" / "fluxo.json")["linhagens"]] == ["Farmacotest"]
    # as consultas publicadas são as que sustentam registro público
    assert {int(l["id"]) for l in _csv(d / "tabelas" / "consultas.csv")} == {cenario.consulta_gbif, cenario.consulta_lotus, cenario.consulta_chembl}


def test_livro_de_retencoes_fica_na_pasta_interna_e_fora_do_destino(publico_do_cenario, cenario):
    interno = config.SAIDA_DIR / "interno"
    assert not any(p.name == "interno" for p in publico_do_cenario.rglob("*"))
    assert interno.resolve() not in publico_do_cenario.resolve().parents and publico_do_cenario.resolve() not in interno.resolve().parents
    livro = _json(interno / "retencoes.json")
    por_id = {a["id"]: a for a in livro["afirmacoes"]}
    assert set(por_id) == {cenario.af_retida, cenario.af_orfa, cenario.af_rej}
    retida = por_id[cenario.af_retida]
    assert retida["regra"] == "TAX-HOMONIMO" and "Carapa guianensis" in retida["motivo"] and retida["decidida_por"] == "regra"
    assert retida["regras_disparadas"] == ["TAX-HOMONIMO"] and por_id[cenario.af_rej]["estado"] == "rejeitado"
    # a medida da molécula que ficou sem ocorrência pública é retida pela regra derivada: o estado do banco já diz tudo,
    # e a lista defensiva (estado público, molécula sem registro público) fica vazia
    orfa = por_id[cenario.af_orfa]
    assert orfa["regra"] == quarentena.REGRA_DERIVADA and orfa["decidida_por"] == "regra" and "Retidina de teste" in orfa["motivo"]
    assert livro["afirmacoes_de_molecula_sem_registro_publico"] == []
    assert [a["id"] for a in livro["afirmacoes_com_acesso_restrito"]] == [cenario.af_restr]
    assert {r["doi"] or r["pmid"]: r["regra"] for r in livro["referencias"]} == {"10.1000/retida": "REF-DOI-INEXISTENTE", "999001": None}
    assert [(l["destino"], l["regra"]) for l in livro["linhagens"]] == [("Contraditina de teste", "LIN-CONTRADITA")]
    assert [m["motivo"] for m in livro["midia"]] == ["Espécime morto na fotografia (teste)."]
    resumo = _json(interno / "resumo_retencoes.json")
    assert resumo["afirmacoes_por_regra"] == {"TAX-HOMONIMO": 1, quarentena.REGRA_DERIVADA: 1}
    assert resumo["referencias_por_regra"] == {"REF-DOI-INEXISTENTE": 1}
    assert resumo["afirmacoes_por_estado"]["rejeitado"] == 1 and resumo["imagens_retidas"] == 1
    assert "politica_de_exclusao" in _json(interno / "nomes_rejeitados.json")


def test_medida_de_molecula_sem_registro_publico_nao_sai_mesmo_sem_a_regra_derivada(cenario, tmp_path):
    """A fronteira não depende de o banco ter sido rederivado: medida em estado público de molécula sem ocorrência
    pública fica fora do pacote, e o livro interno a lista."""
    con = cenario.con
    # como num banco em que `aplicar_estados` não rodou depois de a ocorrência ser retida
    con.execute("DELETE FROM afirmacao_regra WHERE afirmacao_id=? AND codigo=?", (cenario.af_orfa, quarentena.REGRA_DERIVADA))
    con.execute("UPDATE afirmacao SET estado='candidato', regra_quarentena=NULL, motivo_quarentena=NULL, quarentena_origem=NULL WHERE id=?",
                (cenario.af_orfa,))
    con.commit()
    assert [e["id"] for e in validar.validar(con)["erros"]] == ["Q.publica_de_molecula_sem_organismo"]
    destino = tmp_path / "sem_rederivar"
    with pytest.raises(SystemExit):                              # banco inválido não é exportado sem `forcar`
        pacotes.exportar_tudo(con, destino, log=lambda *_: None)
    m = pacotes.exportar_tudo(con, destino, log=lambda *_: None, forcar=True)
    assert m["contagens"]["afirmacoes_por_tipo"]["atividade_biologica"] == 1
    assert cenario.af_orfa not in {int(l["afirmacao_id"]) for l in _csv(destino / "tabelas" / "afirmacoes.csv")}
    assert _ocorrencias(destino, ["Retidina de teste", "CHEMBL900002"]) == []
    livro = _json(config.SAIDA_DIR / "interno" / "retencoes.json")
    assert [a["id"] for a in livro["afirmacoes_de_molecula_sem_registro_publico"]] == [cenario.af_orfa]
    assert cenario.af_orfa not in {a["id"] for a in livro["afirmacoes"]}


def _vias_de_alvo_publico_e_de_alvo_sem_medida(con, alvo_publico):
    """Uma via do alvo público, compartilhada com um alvo sem medida publicada, e uma via só deste. A linha da via
    compartilhada guarda a consulta feita para o alvo sem medida (o primeiro em que ela apareceu)."""
    reactome = "https://reactome.org/ContentService/data/mapping/UniProt/{}/pathways?species=9606"
    c_pub, c_fora = _consulta(con, "reactome", reactome.format("P30542"), "1"), _consulta(con, "reactome", reactome.format("Q00000"), "2")
    alvo_fora = con.execute("INSERT INTO alvo (nome, chembl_id, uniprot_acc, organismo, tipo_chembl, natureza) VALUES "
                            "('Alvo sem medida publicada', 'CHEMBL900009', 'Q00000', 'Homo sapiens', 'SINGLE PROTEIN', 'proteina_unica')").lastrowid
    via_comum = con.execute("INSERT INTO via_biologica (reactome_id, nome, especie, consulta_id) VALUES "
                            "('R-HSA-111', 'Via compartilhada de teste', 'Homo sapiens', ?)", (c_fora,)).lastrowid
    via_fora = con.execute("INSERT INTO via_biologica (reactome_id, nome, especie, consulta_id) VALUES "
                           "('R-HSA-222', 'Via do alvo sem medida', 'Homo sapiens', ?)", (c_fora,)).lastrowid
    con.execute("INSERT INTO alvo_via (alvo_id, via_id, consulta_id) VALUES (?,?,?), (?,?,?), (?,?,?)",
                (alvo_publico, via_comum, c_pub, alvo_fora, via_comum, c_fora, alvo_fora, via_fora, c_fora))
    con.commit()
    return SimpleNamespace(c_pub=c_pub, c_fora=c_fora, alvo_fora=alvo_fora)


def test_via_e_consulta_de_alvo_sem_medida_publicada_nao_saem(cenario, tmp_path):
    v = _vias_de_alvo_publico_e_de_alvo_sem_medida(cenario.con, cenario.alvo)
    destino = tmp_path / "vias"
    m = pacotes.exportar_tudo(cenario.con, destino, log=lambda *_: None, forcar=True)
    assert _ocorrencias(destino, ["Q00000", "Alvo sem medida publicada", "CHEMBL900009", "Via do alvo sem medida", "R-HSA-222"]) == []
    assert m["contagens"]["vias_reactome"] == 1
    # a via do alvo público cita a busca feita para o próprio alvo, nos pacotes, nas tabelas e no observatório
    cafeina = _json(destino / "moleculas" / f"{cenario.molecula}.json")
    via = cafeina["atividades"][0]["alvo"]["vias_reactome"]
    assert [x["id"] for x in via] == ["R-HSA-111"] and "UniProt/P30542/" in cafeina["consultas"][via[0]["consulta"]]["url"]
    assert [c["url"] for c in _json(destino / "viz" / "fluxo.json")["consultas"] if c["fonte"] == "reactome"] == [
        "https://reactome.org/ContentService/data/mapping/UniProt/P30542/pathways?species=9606"]
    ids = {int(l["id"]) for l in _csv(destino / "tabelas" / "consultas.csv")}
    assert v.c_pub in ids and v.c_fora not in ids


def _sem_o_que_muda_a_cada_execucao(manifesto):
    """O manifesto sem a hora da geração e sem as somas (o .zip do DwC-A guarda a hora de cada membro)."""
    return {k: v for k, v in manifesto.items() if k not in ("gerado_em", "integridade")}


def test_pacote_e_o_mesmo_a_partir_do_banco_de_trabalho_e_da_copia_so_com_o_publicado(cenario, tmp_path):
    """A cópia de distribuição do banco (`banco_publico`) usa a definição de público deste módulo; exportar dela ou do
    banco de trabalho dá os mesmos arquivos, byte a byte."""
    con = cenario.con
    _vias_de_alvo_publico_e_de_alvo_sem_medida(con, cenario.alvo)
    do_trabalho, da_copia = tmp_path / "do_trabalho", tmp_path / "da_copia"
    pacotes.exportar_tudo(con, do_trabalho, log=lambda *_: None, forcar=True)
    banco_publico.gerar(con, tmp_path / "publicado.sqlite", log=lambda *_: None)
    con_pub = db.conectar(tmp_path / "publicado.sqlite")
    try:
        assert validar.validar(con_pub)["erros"] == []
        pacotes.exportar_tudo(con_pub, da_copia, log=lambda *_: None)
    finally:
        con_pub.close()
    arquivos = lambda pasta: sorted(p.relative_to(pasta).as_posix() for p in pasta.rglob("*") if p.is_file())
    assert arquivos(do_trabalho) == arquivos(da_copia)
    for rel in arquivos(do_trabalho):
        a, b = do_trabalho / rel, da_copia / rel
        if rel == "manifesto.json":
            assert _sem_o_que_muda_a_cada_execucao(_json(a)) == _sem_o_que_muda_a_cada_execucao(_json(b))
        elif rel == "SHA256SUMS.txt":
            continue
        elif rel.endswith(".zip"):
            with zipfile.ZipFile(a) as za, zipfile.ZipFile(b) as zb:
                assert za.namelist() == zb.namelist()
                assert all(za.read(n) == zb.read(n) for n in za.namelist()), rel
        else:
            assert a.read_bytes() == b.read_bytes(), rel


def test_destino_dentro_da_saida_interna_e_recusado(mini):
    prontidao.recalcular_todas(mini.con)
    for destino in (config.SAIDA_DIR, config.SAIDA_DIR / "interno", config.SAIDA_DIR / "interno" / "dados"):
        with pytest.raises(SystemExit, match="registros internos"):
            pacotes.exportar_tudo(mini.con, destino, log=lambda *_: None)


def test_arquivos_extintos_somem_do_destino_e_das_somas(mini, tmp_path):
    """Exportar por cima de um pacote antigo não deixa `quarentena.json` para trás nem o lista em SHA256SUMS."""
    prontidao.recalcular_todas(mini.con)
    destino = tmp_path / "antigo"
    destino.mkdir()
    for nome in ("quarentena.json", "benchmark_validacao.json", "nomes_rejeitados.json"):
        (destino / nome).write_text('{"esquema":1}', encoding="utf-8")
    (destino / "manifesto.json").write_text('{"contagens":{"afirmacoes_em_quarentena":9}}', encoding="utf-8")
    pacotes.exportar_tudo(mini.con, destino, log=lambda *_: None)
    somas = (destino / "SHA256SUMS.txt").read_text(encoding="utf-8")
    for nome in ("quarentena.json", "benchmark_validacao.json", "nomes_rejeitados.json"):
        assert not (destino / nome).exists() and nome not in somas
    assert all((destino / l.split("  ", 1)[1]).is_file() for l in somas.strip().splitlines())
    assert "afirmacoes_em_quarentena" not in (destino / "manifesto.json").read_text(encoding="utf-8")


def test_conferencia_de_fronteira_acusa_arquivo_pasta_e_identificador_interno(tmp_path):
    pasta = tmp_path / "site"
    (pasta / "dados" / "interno").mkdir(parents=True)
    (pasta / "api" / "docs").mkdir(parents=True)
    (pasta / "docs").mkdir()
    (pasta / "dados" / "interno" / "retencoes.json").write_text("{}", encoding="utf-8")
    (pasta / "dados" / "quarentena.json").write_text("{}", encoding="utf-8")
    (pasta / "dados" / "banco.sqlite").write_bytes(b"SQLite format 3")
    (pasta / "docs" / "LEIAME.md").write_text("documentação do repositório", encoding="utf-8")
    (pasta / "api" / "docs" / "index.html").write_text("<p>documentação da API pública</p>", encoding="utf-8")
    (pasta / "dados" / "ok.json").write_text('{"evidencia":"base_curada"}', encoding="utf-8")
    (pasta / "dados" / "vazou.json").write_text('{"regra":"BIO-FORA-DA-SELECAO"}', encoding="utf-8")
    (pasta / "dados" / "antigo.csv").write_text("afirmacao_id,nivel_procedencia\r\n1,T3a_endemica_amazonia_br\r\n", encoding="utf-8")
    achados = dict(pacotes.conferir_fronteira(pasta))
    assert set(achados) == {"dados/interno/retencoes.json", "dados/quarentena.json", "dados/banco.sqlite", "docs/LEIAME.md",
                            "dados/vazou.json", "dados/antigo.csv"}
    assert "BIO-FORA-DA-SELECAO" in achados["dados/vazou.json"]


def test_exportacao_que_vazaria_conteudo_interno_para_antes_de_assinar(mini, tmp_path, monkeypatch):
    """Se um exportador passar a emitir um identificador interno, a exportação para e a pasta fica sem manifesto."""
    from bmb.exportar import viz_shards
    original = viz_shards.exportar_viz_tudo

    def com_vazamento(con, ctx, destino, log=print):
        res = original(con, ctx, destino, log)
        (destino / "viz" / "extra.json").write_text('{"regra_quarentena":"REG-344"}', encoding="utf-8")
        return res

    monkeypatch.setattr(viz_shards, "exportar_viz_tudo", com_vazamento)
    prontidao.recalcular_todas(mini.con)
    destino = tmp_path / "v"
    with pytest.raises(SystemExit, match="conteúdo interno"):
        pacotes.exportar_tudo(mini.con, destino, log=lambda *_: None)
    assert not (destino / "manifesto.json").exists() and not (destino / "SHA256SUMS.txt").exists()


# ═══════════════════════════ localidade: só país e UF ═══════════════════════════
def test_leitura_de_curador_sai_estruturada_e_sem_texto_livre(publico_do_cenario, cenario):
    mol = _json(publico_do_cenario / "moleculas" / f"{cenario.m_verif}.json")
    af = mol["ocorre_em"][0]["afirmacao"]
    assert af["estado"] == "verificado" and af["evidencia"] == "curador" and af["procedencia"] == "curador_artigo_amazonia"
    assert af["passagem"] == "Compound seven was isolated from the seed oil of Carapa guianensis." and af["passagem_origem"] == "curador"
    assert mol["refs"][af["passagem_ref"]]["doi"] == "10.1000/abc"
    assert af["organismo_na_fonte"] == "Persoonia guareoides"            # só o nome que difere do aceito
    v = af["verificacao"]
    assert v == {"em": v["em"], "curador": "Curadora Teste", "decisao": "confirmada", "referencia": af["passagem_ref"],
                 "acesso_texto": "texto_completo_aberto", "escopo_geografico_lido": "amazonia_br", "voucher": "INPA 22410"}
    # o que o curador digitou como procedência não sai em lugar nenhum: sai a classe que ele marcou
    assert _ocorrencias(publico_do_cenario, ["Brasil: AM"]) == []
    linha = next(l for l in _csv(publico_do_cenario / "tabelas" / "afirmacoes.csv") if int(l["afirmacao_id"]) == cenario.af_verif)
    assert (linha["evidencia"], linha["procedencia_declarada"], linha["passagem_origem"]) == ("curador", "curador_artigo_amazonia", "curador")
    assert linha["organismo_na_fonte"] == "Carapa guianensis; Persoonia guareoides"
    verifs = _csv(publico_do_cenario / "tabelas" / "verificacoes.csv")
    assert list(verifs[0]) == ["afirmacao_id", "curador", "decisao", "em", "referencia_doi", "referencia_pmid", "acesso_texto",
                               "escopo_geografico_lido", "trecho_conferido", "voucher", "qualidade_experimental"]
    assert [(int(v_["afirmacao_id"]), v_["escopo_geografico_lido"], v_["voucher"]) for v_ in verifs] == [(cenario.af_verif, "amazonia_br", "INPA 22410")]


def test_localidade_mais_fina_que_uf_nao_sai_mesmo_que_esteja_no_banco(cenario, tmp_path):
    """Banco com localidade fina gravada por caminho antigo (o validador acusa): mesmo forçada, a exportação não a leva."""
    con = cenario.con
    con.execute("UPDATE afirmacao SET localidade_declarada='Comunidade Boca do Tupé-Teste, igarapé Açutuba', uf_coleta_declarada='AM, Xiquexique', "
                "pais_coleta_declarado='Brasil', voucher_declarado_base='INPA 1; coletado em Xiquexique, Amazonas', "
                "procedencia_artigo='amazonia_legal', procedencia_artigo_local='BR-AM, Xiquexique' WHERE id=?", (cenario.af_composto,))
    con.execute("UPDATE verificacao SET passagem_conferida='Leaves were collected at Reserva Tucunduba, Xiquexique (3°06′S, 60°01′W).', "
                "procedencia_material='Reserva Tucunduba, Xiquexique', voucher='coletado em Xiquexique por J. Silva 123' WHERE afirmacao_id=?", (cenario.af_verif,))
    con.execute("UPDATE afirmacao SET procedencia_material='Reserva Tucunduba, Xiquexique' WHERE id=?", (cenario.af_verif,))
    con.commit()
    assert any(e["id"].startswith("C.") for e in validar.validar(con)["erros"])
    destino = tmp_path / "loc"
    pacotes.exportar_tudo(con, destino, log=lambda *_: None, forcar=True)
    assert _ocorrencias(destino, ["Tupé", "Açutuba", "Xiquexique", "Tucunduba", "3°06", "J. Silva"]) == []
    af = _json(destino / "moleculas" / f"{cenario.m_verif}.json")["ocorre_em"][0]["afirmacao"]
    assert af["passagem"] is None and af["passagem_origem"] == "curador" and af["verificacao"]["voucher"] is None
    oc = _json(destino / "moleculas" / f"{cenario.molecula}.json")["ocorre_em"][0]["afirmacao"]
    assert "uf_coleta" not in oc and "pais_coleta" not in oc and oc["voucher_base"] == "INPA 1"
    assert oc["procedencia_artigo"] == {"classe": "amazonia_legal"}             # o local fora do formato país-UF não sai


def test_frase_de_artigo_com_local_de_coleta_sai_sem_o_texto(mini, tmp_path):
    """Frase localizada no resumo que cite município, reserva ou coordenada: ficam a origem e a obra, sem o texto."""
    con = mini.con
    con.execute("UPDATE afirmacao SET nivel_evidencia='artigo_trecho', passagem_origem='resumo', passagem_referencia_id=?, passagem_sha256=?, "
                "passagem='Compound 1 was isolated from seeds collected in the municipality of Xiquexique, near Tucunduba Reserve.' WHERE id=?",
                (mini.ref, "a" * 64, mini.af_composto))
    con.commit()
    prontidao.recalcular_todas(con)
    destino = tmp_path / "frase"
    pacotes.exportar_tudo(con, destino, log=lambda *_: None, forcar=True)
    assert _ocorrencias(destino, ["Xiquexique", "Tucunduba"]) == []
    af = _json(destino / "moleculas" / f"{mini.molecula}.json")["ocorre_em"][0]["afirmacao"]
    assert af["passagem"] is None and af["passagem_origem"] == "resumo" and af["passagem_ref"] == 0 and af["evidencia"] == "artigo_trecho"
    # a mesma frase sem o local de coleta sai inteira
    con.execute("UPDATE afirmacao SET passagem='Compound 1 was isolated from the seed oil of Carapa guianensis.' WHERE id=?", (mini.af_composto,))
    con.commit()
    pacotes.exportar_tudo(con, destino, log=lambda *_: None, forcar=True)
    af = _json(destino / "moleculas" / f"{mini.molecula}.json")["ocorre_em"][0]["afirmacao"]
    assert af["passagem"] == "Compound 1 was isolated from the seed oil of Carapa guianensis."


@pytest.mark.parametrize("valor, sai", [
    ("INPA 22410", "INPA 22410"), ("INPA-H 31022", "INPA-H 31022"), ("MZUSP:12345", "MZUSP:12345"), ("geoCA1", "geoCA1"),
    ("MCZ:Herp:A-12345", "MCZ:Herp:A-12345"), ("USNM 123456; KU 221833", "USNM 123456; KU 221833"),
    ("INPA 22410; Reserva Ducke 12", "INPA 22410"),
    # frases curtas, que o filtro da base de origem deixa passar, não são código de coleção
    ("Reserva Ducke 12", None), ("coletado em Xiquexique por J. Silva 123", None), ("Manaus AM 2019", None), ("Rio Negro 7", None),
    ("J. Silva 1234", None), ("Brazil: Amazonas 12", None), ("", None), (None, None)])
def test_testemunho_da_base_so_sai_como_codigo_de_colecao(valor, sai):
    assert pacotes.voucher_publico(valor) == sai


# ═══════════════════════════ validação, integridade e reprodutibilidade ═══════════════════════════
def test_exportacao_recusada_com_erro_de_validacao(mini, tmp_path):
    mini.con.execute("UPDATE afirmacao SET estado='verificado' WHERE id=?", (mini.af_composto,))   # sem verificação humana
    with pytest.raises(SystemExit):
        pacotes.exportar_tudo(mini.con, tmp_path / "x", log=lambda *_: None)
    assert not (tmp_path / "x").exists()


def test_somas_de_verificacao_conferem(publico):
    linhas = (publico / "SHA256SUMS.txt").read_text(encoding="utf-8").strip().splitlines()
    assert linhas
    for l in linhas:
        h, rel = l.split("  ", 1)
        assert hashlib.sha256((publico / rel).read_bytes()).hexdigest() == h, rel
    m = _json(publico / "manifesto.json")
    assert m["integridade"]["n_arquivos"] == len(linhas) and len(m["integridade"]["conjunto"]) == 64
    presentes = {p.relative_to(publico).as_posix() for p in publico.rglob("*") if p.is_file()} - {"manifesto.json", "SHA256SUMS.txt"}
    assert {l.split("  ", 1)[1] for l in linhas} == presentes


def test_exportacao_e_reproduzivel(mini, tmp_path):
    prontidao.recalcular_todas(mini.con)
    a, b = tmp_path / "a", tmp_path / "b"
    pacotes.exportar_tudo(mini.con, a, log=lambda *_: None)
    pacotes.exportar_tudo(mini.con, b, log=lambda *_: None)
    gbif = mini.con.execute("SELECT gbif_key FROM taxon").fetchone()[0]
    for rel in ("indice.json", "indice_mapa.json", "moleculas_indice.json", "sinonimos_indice.json", "territorios.json",
                f"taxa/{gbif}.json", f"moleculas/{mini.molecula}.json", "tabelas/afirmacoes.csv", "tabelas/referencias.csv",
                "tabelas/consultas.csv", "viz/fluxo.json"):
        assert (a / rel).read_bytes() == (b / rel).read_bytes(), rel


# ═══════════════════════════ tabelas e Darwin Core ═══════════════════════════
def test_csv_de_afirmacoes_traz_fonte_licenca_consulta_e_data(publico):
    linhas = _csv(publico / "tabelas" / "afirmacoes.csv")
    assert len(linhas) == 3
    for l in linhas:
        assert l["fonte"] and l["fonte_licenca"] and l["consulta_url"].startswith("https://") and l["consulta_data"] == AGORA[:10]
        assert l["evidencia"] == "base_curada"
    clinico = next(l for l in linhas if l["tipo"] == "efeito_clinico_documentado")
    assert clinico["taxon_id"] == "" and clinico["procedencia_declarada"] == ""       # nunca ligado a organismo
    composto = next(l for l in linhas if l["tipo"] == "composto_em_organismo")
    assert composto["procedencia_declarada"] == "nao_declarada" and composto["organismo_na_fonte"] == "Carapa guianensis"
    atividade = next(l for l in linhas if l["tipo"] == "atividade_biologica")
    assert (atividade["medida_agregacao"], atividade["medida_n"], atividade["medida_n_documentos"], atividade["medida_min"],
            atividade["medida_max"], atividade["natureza_alvo"], atividade["ensaio_tipo"]) == ("unica", "1", "1", "12.0", "12.0", "proteina_unica", "B")


def test_colunas_das_tabelas_seguem_o_contrato(publico):
    cab = lambda nome: list(_csv_cabecalho(publico / "tabelas" / nome))
    afirmacoes = cab("afirmacoes.csv")
    for entra in ("evidencia", "procedencia_declarada", "procedencia_artigo", "procedencia_artigo_local", "organismo_na_fonte",
                  "medida_agregacao", "medida_n", "medida_n_documentos", "medida_min", "medida_max", "natureza_alvo"):
        assert entra in afirmacoes, entra
    for sai in ("nivel_procedencia", "procedencia_material", "localidade_declarada", "ena_accession"):
        assert sai not in afirmacoes, sai
    taxa = cab("taxa.csv")
    assert "distribuicao_br" in taxa and "escopo_biogeografico" not in taxa
    moleculas = cab("moleculas.csv")
    for entra in ("inchikey_conectividade", "massa", "massa_monoisotopica", "massa_media", "estereocentros", "estereocentros_indefinidos"):
        assert entra in moleculas, entra
    assert cab("referencias.csv") == ["referencia_id", "doi", "pmid", "titulo", "autores", "revista", "ano", "tipo_obra", "aviso",
                                     "texto_nivel", "resolvida"]
    assert "rodada_benchmark" not in cab("verificacoes.csv") and "nota" not in cab("verificacoes.csv")
    fontes = {l["id"]: l["descricao"] for l in _csv(publico / "tabelas" / "fontes.csv")}
    assert fontes["curadoria"] == pacotes.DESCRICAO_PUBLICA_DE_FONTE["curadoria"]


def _csv_cabecalho(p):
    with open(p, encoding="utf-8-sig", newline="") as f:
        return next(csv.reader(f))


def test_dwca_sem_dados_do_chembl_e_com_meta_valido(publico):
    with zipfile.ZipFile(publico / "dwca" / "biomapabrasil_dwca.zip") as z:
        nomes = set(z.namelist())
        assert {"meta.xml", "eml.xml", "taxon.txt", "resourcerelationship.txt", "measurementorfact.txt", "reference.txt"} <= nomes
        rel = z.read("resourcerelationship.txt").decode("utf-8")
        assert "CHEMBL" not in rel and "chembl" not in rel.lower()        # licença única: ChEMBL (CC BY-SA) fica de fora
        # cada relação diz o que é, com que evidência e o que se declara da coleta — por rótulo de dado
        assert "composto relatado no organismo" in rel and "Evidência: Transcrito de base curada." in rel
        assert "Local de coleta não declarado pela base de origem." in rel
        meta = z.read("meta.xml").decode("utf-8")
        assert "http://rs.tdwg.org/dwc/terms/Taxon" in meta and 'fieldsTerminatedBy="\\t"' in meta
        assert z.read("taxon.txt").decode("utf-8").splitlines()[0].startswith("taxonID\t")
        assert "10.1000/abc" in z.read("reference.txt").decode("utf-8")


def test_dwca_do_cenario_so_tem_relacoes_e_obras_publicas(publico_do_cenario, cenario):
    with zipfile.ZipFile(publico_do_cenario / "dwca" / "biomapabrasil_dwca.zip") as z:
        rel = z.read("resourcerelationship.txt").decode("utf-8").strip().splitlines()[1:]
        assert sorted(l.split("\t")[1] for l in rel) == ["inchikey:FFFFFFFFFFFFFF-UHFFFAOYSA-N", "inchikey:RYYVLZVUVIJVGH-UHFFFAOYSA-N"]
        assert any("Evidência: Conferido por curador. Coleta na Amazônia conferida no artigo por curador." in l for l in rel)
        assert "10.1000/retida" not in z.read("reference.txt").decode("utf-8")


# ═══════════════════════════ observatórios ═══════════════════════════
def test_observatorios_viz_e_bacias_exportados_com_proveniencia(publico):
    for nome in ("galaxia.json", "fluxo.json", "floresta.json", "filoquimica.json", "materia_escura.json"):
        arq = publico / "viz" / nome
        assert arq.exists(), nome
        d = _json(arq)
        assert d["esquema"] == 1 and "consultas" in d
    me = _json(publico / "viz" / "materia_escura.json")
    assert {"total_especies", "com_quimica_aberta", "sem_quimica_aberta", "pct_sem_quimica", "por_grupo", "familias", "generos_prioritarios"} <= set(me)
    gx = _json(publico / "viz" / "galaxia.json")
    assert gx["colunas"][-1] == "coleta_amazonica_declarada" and "t13" not in gx["colunas"]
    if len(gx["linhas"]) >= 2:
        assert len(gx["arestas"]) > 0, "galaxia.json deve exportar arestas TMAP mesmo sem tmap_arestas.json prévio"
    bacias = _json(publico / "geo" / "bacias.json")
    assert len(bacias["bacias"]) == 9 and bacias["bioma_amazonia_d"].startswith("M")
    assert (publico / "sinonimos_indice.json").exists()
    assert (publico / "tabelas" / "ocorrencias_por_bacia.csv").exists()
    assert (publico / "tabelas" / "linhagens_bioinspiradas.csv").exists()


def test_dicionario_de_traducao_da_semente_e_copiado_como_esta(publico):
    origem = config.SEMENTE_DIR / "i18n"
    for arq in origem.glob("*.json"):
        assert (publico / "i18n" / arq.name).read_bytes() == arq.read_bytes()


# ═══════════════════════════ o conferidor do pacote público (scripts/) ═══════════════════════════
def _conferidor():
    arq = RAIZ / "scripts" / "conferir_pacote_publico.py"
    if not arq.is_file():
        pytest.skip("scripts/conferir_pacote_publico.py não está neste checkout")
    spec = importlib.util.spec_from_file_location("conferir_pacote_publico", arq)
    modulo = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modulo)
    return modulo


def test_pacote_exportado_passa_no_conferidor_do_pacote_publico(publico, publico_do_cenario):
    """Tudo o que a exportação gera passa no conferidor que o CI roda sobre `app/dados`, inclusive o dicionário de
    tradução da semente, copiado como está."""
    conferidor = _conferidor()
    for pasta in (publico, publico_do_cenario):
        assert conferidor.conferir(pasta) == []
