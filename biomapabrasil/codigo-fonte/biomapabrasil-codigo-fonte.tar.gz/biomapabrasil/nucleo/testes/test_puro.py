# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Funções puras: licenças, nomes, DOIs, recorte, formatação e interpretação de respostas das fontes."""
import gzip

import pytest

from bmb import config, prontidao, texto
from bmb.conectores import chembl, gbif, lotus, pubchem, referencias, uniprot
from bmb.http import Cliente
from bmb.util import chave_nome, milhar, numero_legivel

from conftest import resposta


# ───────── licenças (Princípio 3) ─────────
@pytest.mark.parametrize("entrada,esperado", [
    ("http://creativecommons.org/publicdomain/zero/1.0/", "CC0"),
    ("CC0_1_0", "CC0"),
    ("http://creativecommons.org/licenses/by/4.0/", "CC BY"),
    ("CC_BY_4_0", "CC BY"),
    ("http://creativecommons.org/licenses/by-nc/4.0/legalcode", "CC BY-NC"),
    ("http://creativecommons.org/licenses/by-sa/3.0/", "CC BY-SA"),
    ("http://creativecommons.org/licenses/by-nc-nd/4.0/", "CC BY-NC-ND"),
    ("todos os direitos reservados", None),
    ("", None),
    (None, None),
])
def test_normalizar_licenca(entrada, esperado):
    assert config.normalizar_licenca(entrada) == esperado


def test_so_cc0_e_cc_by_sao_imagem_livre():
    assert config.LICENCAS_IMAGEM_OK == {"CC0", "CC BY"}


# ───────── nomes ─────────
@pytest.mark.parametrize("entrada,esperado", [
    ("Bothrops atrox (Common lancehead)", ("Bothrops atrox", "Common lancehead", None)),
    ("Cyriopagopus hainanus (Chinese bird spider) (Haplopelma hainanum)", ("Cyriopagopus hainanus", "Chinese bird spider", "Haplopelma hainanum")),
    ("Conus textile (Cloth-of-gold cone)", ("Conus textile", "Cloth-of-gold cone", None)),
    ("Olivierus martensii (Manchurian scorpion) (Mesobuthus martensii)", ("Olivierus martensii", "Manchurian scorpion", "Mesobuthus martensii")),
    ("Chinese cobra", ("Chinese cobra", None, None)),
    ("Vipera ammodytes ammodytes", ("Vipera ammodytes ammodytes", None, None)),
])
def test_separar_nome_uniprot(entrada, esperado):
    assert uniprot.separar_nome(entrada) == esperado


def test_chave_nome_ignora_acento_caixa_e_pontuacao():
    assert chave_nome("(R)-Naringenin") == chave_nome("r naringenin")
    assert chave_nome("Café") == "cafe"


# ───────── DOI e classes do LOTUS ─────────
def test_doi_do_lotus_troca_marcador_e_normaliza():
    assert lotus.normalizar_doi("10$x$x$1016/S0031-9422(01)00043-7") == "10.1016/s0031-9422(01)00043-7"
    assert lotus.normalizar_doi("https://doi.org/10.1000/ABC") == "10.1000/abc"
    assert lotus.normalizar_doi("nao-e-doi") is None
    assert lotus.normalizar_doi(None) is None


def test_limpar_classe_do_lotus():
    assert lotus.limpar_classe("Alkaloids|Alkaloids › Purine alkaloids|Purine alkaloids") == "Alkaloids › Purine alkaloids"
    assert lotus.limpar_classe("Terpenoids › Limonoids") == "Terpenoids › Limonoids"
    assert lotus.limpar_classe(None) is None


def test_lotus_filtra_so_pares_do_taxon_alvo():
    produto = {"lotus_id": "LTS1", "inchikey": "AAAA-BBBB-N", "smiles": "C", "molecular_formula": "CH4", "molecular_weight": 16.0,
               "traditional_name": "metano", "taxonomyReferenceObjects": {
                   "10$x$x$1/a": {"GBIF": [{"organism_value": "Uncaria tomentosa"}], "NCBI": [{"organism_value": "Uncaria tomentosa (Willd.) DC."}]},
                   "10$x$x$1/b": {"GBIF": [{"organism_value": "Astragalus altaicola"}]}}}
    sem_par = {**produto, "lotus_id": "LTS2", "inchikey": "CCCC-DDDD-N", "taxonomyReferenceObjects": {"10$x$x$1/c": {"GBIF": [{"organism_value": "Outra planta"}]}}}

    class Cli:
        def get(self, *a, **k):
            return resposta({"naturalProducts": [produto, sem_par]})

    lista, _ = lotus.compostos_do_taxon(Cli(), "Uncaria tomentosa", ["Uncaria tomentosa"])
    assert [c["lotus_id"] for c in lista] == ["LTS1"]
    assert set(lista[0]["referencias"]) == {"10.1/a"}          # o DOI do outro organismo não vaza para o táxon
    assert lista[0]["referencias"]["10.1/a"] == ["GBIF", "NCBI"]


# ───────── recorte amazônico (Princípio 2: duas bases) ─────────
def _dist(n_br, n_al, por_uf=None):
    por_uf = por_uf or {}
    com_uf = sum(por_uf.values()) if por_uf else n_al
    return {"n_br": n_br, "n_al": n_al, "com_uf": com_uf, "sem_uf": n_br - com_uf, "por_uf": por_uf, "consulta_id": 1}


def test_recorte_predominante_nas_duas_bases():
    r = gbif.decidir_recorte(_dist(1000, 800, {"PA": 800, "SP": 100}), "2026-11-07")
    assert r["no_recorte"] == 1 and r["predominio_al"] == "predominante"
    assert "não têm UF" in r["motivo_recorte"] and "2026-11-07" in r["motivo_recorte"]   # cita as duas bases e a data


def test_recorte_indeterminado_quando_as_bases_discordam():
    # 879 de 915 com UF (96%), mas só 29% de todos os 3070 registros: depende da base
    r = gbif.decidir_recorte({"n_br": 3070, "n_al": 879, "com_uf": 915, "sem_uf": 2155, "por_uf": {}, "consulta_id": 1}, "2026-11-07")
    assert r["predominio_al"] == "indeterminado" and r["no_recorte"] == 1
    assert "indeterminado" in r["motivo_recorte"]


def test_recorte_marginal_e_fora():
    marg = gbif.decidir_recorte({"n_br": 1301, "n_al": 143, "com_uf": 890, "sem_uf": 411, "por_uf": {}, "consulta_id": 1}, "2026-11-07")
    assert marg["predominio_al"] == "nao_predominante" and marg["no_recorte"] == 1
    fora = gbif.decidir_recorte({"n_br": 26, "n_al": 1, "com_uf": 3, "sem_uf": 23, "por_uf": {}, "consulta_id": 1}, "2026-11-07")
    assert fora["no_recorte"] == 0 and "Fora do recorte" in fora["motivo_recorte"]


def test_recorte_sem_registros_nao_divide_por_zero():
    r = gbif.decidir_recorte({"n_br": 0, "n_al": 0, "com_uf": 0, "sem_uf": 0, "por_uf": {}, "consulta_id": 1}, "2026-11-07")
    assert r["predominio_al"] == "indeterminado" and r["fracao_al_com_uf"] is None


def test_correspondencia_de_nome_rejeita_o_que_nao_e_confiavel():
    ok = {"tipo_correspondencia": "EXACT", "confianca": 99, "reino": "Plantae"}
    assert gbif.correspondencia_aceitavel(ok, "Plantae") == (True, None)
    assert not gbif.correspondencia_aceitavel({**ok, "tipo_correspondencia": "HIGHERRANK"})[0]
    assert not gbif.correspondencia_aceitavel({**ok, "tipo_correspondencia": "FUZZY", "confianca": 80})[0]
    assert not gbif.correspondencia_aceitavel(ok, "Animalia")[0]
    assert not gbif.correspondencia_aceitavel(None)[0]


def test_nome_infraespecifico_sobe_para_a_especie():
    m = gbif.interpretar_match(resposta({"usageKey": 11, "speciesKey": 10, "rank": "SUBSPECIES", "matchType": "EXACT", "confidence": 98,
                                         "kingdom": "Animalia", "scientificName": "Vipera ammodytes ammodytes"}))
    assert m["chave_aceita"] == 10 and m["subiu_para_especie"]


def test_mapeamento_de_ufs_do_gadm_nao_inverte_ms_e_mt():
    assert gbif.UF_GADM["BRA.11_1"] == "MS" and gbif.UF_GADM["BRA.12_1"] == "MT" and len(gbif.UF_GADM) == 27


# ───────── interpretação das fontes ─────────
def test_chembl_molecula_e_fase():
    m = chembl.interpretar_molecula(resposta({"molecules": [{"molecule_chembl_id": "CHEMBL25", "pref_name": "ASPIRIN", "max_phase": "4.0",
                                                             "withdrawn_flag": False}]}))
    assert m["chembl_id"] == "CHEMBL25" and m["max_fase"] == 4.0 and not m["retirado"]
    assert chembl.interpretar_molecula(resposta({"molecules": []})) is None


def test_chembl_atividades_filtra_qualidade_e_repetidas():
    base = {"standard_relation": "=", "standard_type": "IC50", "target_chembl_id": "T1", "standard_value": "10", "pchembl_value": "8.0",
            "activity_id": 1, "document_chembl_id": "D1", "data_validity_comment": None, "potential_duplicate": 0}
    atividades = [base, {**base, "activity_id": 2, "pchembl_value": "7.9"},                       # mesmo alvo e tipo: repetida
                  {**base, "activity_id": 3, "target_chembl_id": "T2", "standard_relation": ">"},  # relação não exata
                  {**base, "activity_id": 4, "target_chembl_id": "T3", "data_validity_comment": "Outside typical range"},
                  {**base, "activity_id": 5, "target_chembl_id": "T4", "potential_duplicate": 1},
                  {**base, "activity_id": 6, "target_chembl_id": "T5", "standard_type": "Potency"},
                  {**base, "activity_id": 7, "target_chembl_id": "T6"}]

    class Cli:
        def get(self, *a, **k):
            return resposta({"activities": atividades})

    saida, _ = chembl.atividades(Cli(), "CHEMBL1", maximo=10)
    assert [a["activity_id"] for a in saida] == [1, 7]


def test_crossref_detecta_retratacao():
    retratada = referencias.interpretar_crossref(resposta({"message": {"title": ["RETRACTED: algo"], "container-title": ["Revista"],
                                                                      "issued": {"date-parts": [[2010]]}, "updated-by": [{"type": "retraction"}]}}))
    assert retratada["retratada"] is True and retratada["ano"] == 2010
    normal = referencias.interpretar_crossref(resposta({"message": {"title": ["Normal"], "updated-by": [{"type": "correction"}]}}))
    assert normal["retratada"] is False
    preocupacao = referencias.interpretar_crossref(resposta({"message": {"title": ["X"], "updated-by": [{"type": "expression_of_concern"}]}}))
    assert preocupacao["aviso"] == "expressao_de_preocupacao" and preocupacao["retratada"] is False
    assert referencias.interpretar_crossref(resposta({}, status=404)) is None


def test_pubchem_interpreta_propriedades():
    p = pubchem.interpretar(resposta({"PropertyTable": {"Properties": [{"CID": 2519, "Title": "Caffeine", "MolecularFormula": "C8H10N4O2",
                                                                         "MolecularWeight": "194.19", "ConnectivitySMILES": "Cn1c"}]}}))
    assert p["cid"] == 2519 and p["massa"] == pytest.approx(194.19) and p["titulo"] == "Caffeine"
    assert pubchem.interpretar(resposta({"Fault": {}}, status=404)) is None


def test_uniprot_normaliza_funcao_evidencia_e_familia():
    entrada = {"primaryAccession": "P1", "proteinDescription": {"recommendedName": {"fullName": {"value": "Batroxobin"}}},
               "organism": {"scientificName": "Bothrops atrox", "taxonId": 8725}, "sequence": {"length": 231},
               "comments": [{"commentType": "FUNCTION", "texts": [{"value": "Cleaves fibrinogen.", "evidences": [
                   {"source": "PubMed", "id": "1011993", "evidenceCode": "ECO:0000269"}]}]},
                   {"commentType": "SIMILARITY", "texts": [{"value": "Belongs to the peptidase S1 family."}]}],
               "uniProtKBCrossReferences": [{"database": "PDB", "id": "1ABC"}],
               "references": [{"citation": {"citationCrossReferences": [{"database": "PubMed", "id": "1011993"}, {"database": "DOI", "id": "10.1/X"}],
                                            "title": "T", "publicationDate": "1976", "authors": ["A"]}}]}
    n = uniprot.normalizar_entrada(entrada)
    assert n["nome"] == "Batroxobin" and n["experimental"] and n["pmids_funcao"] == ["1011993"] and n["familia"] == "peptidase S1 family"
    assert n["pdb"] == ["1ABC"] and n["referencias"]["1011993"]["doi"] == "10.1/x" and n["referencias"]["1011993"]["ano"] == 1976


# ───────── cliente HTTP ─────────
def test_cliente_descomprime_segunda_camada_gzip():
    original = b"Entry\tOrganism\nP1\tBothrops atrox\n"
    assert Cliente._desembrulhar(gzip.compress(original)) == original
    assert Cliente._desembrulhar(gzip.compress(gzip.compress(original))) == original
    assert Cliente._desembrulhar(original) == original


def test_cliente_url_final_ordena_parametros():
    assert Cliente._url_final("https://x.test/a", {"b": 2, "a": 1, "c": None}) == "https://x.test/a?a=1&b=2"


# ───────── enunciados (Princípio 4) e prontidão ─────────
def test_enunciados_nao_afirmam_eficacia_e_dizem_o_que_descrevem():
    a = {"alvo_nome": "Receptor", "alvo_chembl_id": "T", "alvo_organismo": "Homo sapiens", "medida_tipo": "IC50", "relacao": "=",
         "valor": 9460.0, "unidade": "nM"}
    assert "9.460" in texto.enunciado_atividade("X", a) and "não é medida do organismo" in texto.enunciado_atividade("X", a)
    clinico = texto.enunciado_clinico("Cafeína", [{"termo": "apneia"}], [{"texto": "Adenosine receptor antagonist"}])
    assert "não o organismo" in clinico
    assert "relatado em" in texto.enunciado_composto("X", "Y", 3) and "3 publicações" in texto.enunciado_composto("X", "Y", 3)


def test_numero_legivel_e_milhar():
    assert numero_legivel(9460.0) == "9.460" and numero_legivel(4.91) == "4,91" and numero_legivel(None) == "—"
    assert milhar(1234567) == "1.234.567"


def test_indice_de_prontidao_ignora_dimensoes_que_nao_se_aplicam():
    todas = {d: "atende" for d in config.DIMENSOES}
    assert prontidao.indice(todas) == 1.0
    assert prontidao.indice({**todas, "identidade_biologica": "nao_se_aplica", "procedencia": "nao_se_aplica"}) == 1.0
    metade = {d: "parcial" for d in config.DIMENSOES}
    assert prontidao.indice(metade) == 0.5
    zero = {d: "ausente" for d in config.DIMENSOES}
    assert prontidao.indice(zero) == 0.0
    # com duas dimensões fora da conta, uma 'ausente' pesa mais
    assert prontidao.indice({**todas, "identidade_biologica": "nao_se_aplica", "procedencia": "nao_se_aplica", "reutilizacao": "ausente"}) == 0.8


@pytest.mark.parametrize("licenca,esperado", [
    ("CC0 1.0", "livre"), ("CC BY 4.0", "atribuicao"), ("CC BY-SA 3.0", "compartilha_igual"),
    ("CC0 / CC BY / CC BY-NC (por conjunto de dados)", "livre"), ("Proprietária", "desconhecida"),
])
def test_classe_de_licenca_da_fonte(licenca, esperado):
    assert prontidao.classe_licenca(licenca) == esperado


def test_enquadramento_detecta_sujeito_descentrado_e_penaliza_captura_de_tela():
    from PIL import Image, ImageDraw
    from bmb import midia

    # Sujeito nítido à esquerda sobre fundo noturno escuro à direita
    im = Image.new("RGB", (600, 450), (4, 6, 5))
    dr = ImageDraw.Draw(im)
    for r in range(8, 78, 5):
        dr.ellipse((120 - r, 190 - r, 120 + r, 190 + r), outline=(235, 195, 70), width=2)
    enq = midia.analisar_enquadramento(im)
    assert enq["foco_x"] < 36.0 and 30.0 <= enq["foco_y"] <= 55.0
    assert not enq["barra_artificial"]

    # Captura de tela vertical estreita com barras pretas retas no topo e na base
    cap = Image.new("RGB", (220, 480), (0, 0, 0))
    dr2 = ImageDraw.Draw(cap)
    dr2.rectangle((0, 72, 220, 405), fill=(95, 118, 86))
    for y in range(95, 380, 12):
        dr2.line((25, y, 195, y), fill=(180, 210, 155), width=2)
    enq_cap = midia.analisar_enquadramento(cap)
    assert enq_cap["barra_artificial"] is True
    assert enq_cap["nota"] < enq["nota"]


def test_reavaliar_imagens_promove_melhor_foto_a_capa(mini, tmp_path):
    import hashlib
    import io
    from PIL import Image, ImageDraw
    from bmb import midia
    from bmb.exportar import pacotes

    con = mini.con
    gbif_key = con.execute("SELECT gbif_key FROM taxon WHERE id=?", (mini.taxon,)).fetchone()[0]
    pasta_img = tmp_path / "imagens" / str(gbif_key)
    pasta_img.mkdir(parents=True, exist_ok=True)

    # 1.jpg inicial: tira vertical estreita escura; 2.jpg inicial: paisagem 4:3 bem iluminada e nítida
    ruim = Image.new("RGB", (210, 500), (3, 3, 3))
    ImageDraw.Draw(ruim).rectangle((40, 200, 120, 280), outline=(180, 160, 90), width=2)
    boa = Image.new("RGB", (560, 420), (42, 88, 56))
    db = ImageDraw.Draw(boa)
    for k in range(12, 130, 8):
        db.ellipse((340 - k, 180 - k, 340 + k, 180 + k), outline=(245, 220, 95), width=2)

    for idx, (im, autor) in enumerate(((ruim, "Autor Tira"), (boa, "Autor Paisagem")), start=1):
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=80)
        b = buf.getvalue()
        (pasta_img / f"{idx}.jpg").write_bytes(b)
        con.execute(
            "INSERT INTO midia (taxon_id, url, pagina, licenca, autor, arquivo, arquivo_sha256, largura, altura, consulta_id) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            (mini.taxon, f"https://x.test/{idx}.jpg", f"https://gbif.org/occurrence/{idx}", "CC BY", autor,
             f"imagens/{gbif_key}/{idx}.jpg", hashlib.sha256(b).hexdigest(), im.width, im.height, mini.consulta_gbif))
    con.commit()

    res = midia.reavaliar_imagens(con, pasta_imagens=tmp_path / "imagens", log=lambda *_: None)
    assert res == {"taxons": 1, "imagens": 2}

    ctx = pacotes.Contexto(con)
    t_row = con.execute("SELECT * FROM taxon WHERE id=?", (mini.taxon,)).fetchone()
    pk = pacotes.pacote_taxon(ctx, t_row)
    assert pk["imagens"][0]["autor"] == "Autor Paisagem"
    assert pk["imagens"][0]["arquivo"] == f"imagens/{gbif_key}/1.jpg"
    assert pk["imagens"][0]["foco"][0] > 52.0
    ix = pacotes.indice_taxa(ctx)
    assert "foco" in ix["colunas"]
    linha = dict(zip(ix["colunas"], ix["linhas"][0]))
    assert linha["foco"] == 0 or (isinstance(linha["foco"], list) and len(linha["foco"]) == 2)


def test_higiene_de_nomes_quimicos_rejeita_codigos_de_registro_e_impurezas():
    from bmb import quimica

    for invalido in (
        "CID 71312556",
        "SCHEMBL123456",
        "Goiicrovoydkkg-mvdmgqqisa",
        "GOIICROVOYDKKG-MVDMGQQISA-N",
        "Rutoside Trihydrate Impurity 4",
        "58-08-2",
    ):
        assert quimica.nome_quimico_invalido(invalido)
    assert not quimica.nome_quimico_invalido("GOIICROVOYDKKG-MVDMGQQISA-N", permitir_inchikey_canonico=True)
    assert quimica.nome_quimico_invalido("Goiicrovoydkkg-mvdmgqqisa", permitir_inchikey_canonico=True)
    assert not quimica.nome_quimico_invalido("(+)-Quercetina")
    assert quimica.escolher_nome_molecula("nigakilactone a", "CID 71312556", "iupac-fallback", "GOIICROVOYDKKG-MVDMGQQISA-N") == "nigakilactone a"
    assert quimica.escolher_nome_molecula(None, "Goiicrovoydkkg-mvdmgqqisa", "methyl benzoate", "GOIICROVOYDKKG-MVDMGQQISA-N") == "methyl benzoate"
    assert quimica.escolher_nome_molecula("CID 123", "Rutoside Trihydrate Impurity 4", None, "goiicrovoydkkg-mvdmgqqisa-n") == "GOIICROVOYDKKG-MVDMGQQISA-N"

