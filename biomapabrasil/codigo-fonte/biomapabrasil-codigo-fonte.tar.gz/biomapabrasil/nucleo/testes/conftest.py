# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Fixtures: um banco mínimo e coerente, sem rede. Cada teste recebe uma cópia nova."""
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from bmb import db  # noqa: E402

AGORA = "2026-11-07T12:00:00+00:00"


def resposta(dados, status=200, consulta_id=1, url="https://exemplo.test/x"):
    """Resposta falsa no formato de `bmb.http.Resposta`, para testar os interpretadores sem rede."""
    return SimpleNamespace(dados=dados, status=status, consulta_id=consulta_id, url=url, consultado_em=AGORA,
                           versao_fonte=None, do_cache=False, bytes=0, sha256="0" * 64, fonte="gbif")


@pytest.fixture(autouse=True)
def saida_isolada(tmp_path, monkeypatch):
    """Os testes nunca tocam a saída real (miniaturas e estruturas de milhares de arquivos): cada um tem a sua, vazia."""
    from bmb import config
    monkeypatch.setattr(config, "SAIDA_DIR", tmp_path / "saida")


@pytest.fixture
def con(tmp_path):
    c = db.conectar(tmp_path / "t.sqlite")
    yield c
    c.close()


def _consulta(con, fonte="gbif", url="https://api.gbif.org/v1/x", sha="a"):
    con.execute("INSERT OR IGNORE INTO consulta (fonte_id, url, consultado_em, status, bytes, sha256, versao_fonte) VALUES (?,?,?,?,?,?,?)",
                (fonte, url, AGORA, 200, 10, sha * 64 if len(sha) == 1 else sha, None))
    return con.execute("SELECT id FROM consulta WHERE url=? AND sha256=?", (url, sha * 64 if len(sha) == 1 else sha)).fetchone()[0]


def _taxon(con, gbif=100, nome="Carapa guianensis", grupo="planta", recorte=1, consulta_id=None):
    con.execute(
        "INSERT INTO taxon (gbif_key, nome, rank, reino, familia, grupo, n_br, n_al, n_br_com_uf, fracao_al_com_uf, fracao_al_total, "
        "predominio_al, ocorr_consulta_id, no_recorte, motivo_recorte, origem_inclusao, criado_em, gbif_correspondencia, gbif_confianca) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (gbif, nome, "SPECIES", "Plantae", "Meliaceae", grupo, 100, 60, 80, 0.75, 0.6, "predominante", consulta_id, recorte,
         "Dentro do recorte: 60 registros. 20 registros do Brasil não têm UF e ficam fora dessa conta.", "teste", AGORA, "EXACT", 99))
    tid = con.execute("SELECT id FROM taxon WHERE gbif_key=?", (gbif,)).fetchone()[0]
    if consulta_id is not None:      # contagens por UF coerentes com os totais acima (80 com UF, 60 na Amazônia Legal)
        con.execute("INSERT OR REPLACE INTO ocorrencia_uf (taxon_id, uf_sigla, n, consulta_id) VALUES (?,?,?,?), (?,?,?,?)",
                    (tid, "AM", 60, consulta_id, tid, "SP", 20, consulta_id))
    return tid


def _molecula(con, nome="Cafeína", inchikey="RYYVLZVUVIJVGH-UHFFFAOYSA-N", **extra):
    campos = {"tipo": "pequena_molecula", "nome": nome, "inchikey": inchikey,
              "inchikey_conectividade": (inchikey or "")[:14] or None, **extra}
    con.execute(f"INSERT INTO molecula ({', '.join(campos)}) VALUES ({', '.join('?' * len(campos))})", tuple(campos.values()))
    return con.execute("SELECT id FROM molecula WHERE inchikey=?", (inchikey,)).fetchone()[0]


def _afirmacao(con, tipo, molecula_id, consulta_id, taxon_id=None, alvo_id=None, origem="teste:1", fonte="lotus", **extra):
    campos = {"tipo": tipo, "taxon_id": taxon_id, "molecula_id": molecula_id, "alvo_id": alvo_id, "texto": "enunciado de teste",
              "origem": origem, "fonte_id": fonte, "consulta_id": consulta_id, "criado_em": AGORA, "atualizado_em": AGORA, **extra}
    con.execute(f"INSERT INTO afirmacao ({', '.join(campos)}) VALUES ({', '.join('?' * len(campos))})", tuple(campos.values()))
    return con.execute("SELECT last_insert_rowid()").fetchone()[0]


@pytest.fixture
def mini(con):
    """Banco com um táxon, uma molécula, uma referência e uma afirmação de cada tipo permitido."""
    cid = _consulta(con)
    cid2 = _consulta(con, "lotus", "https://lotus.naturalproducts.net/api/search/simple?query=x", "b")
    cid3 = _consulta(con, "chembl", "https://www.ebi.ac.uk/chembl/api/data/activity.json?x=1", "c")
    tid = _taxon(con, consulta_id=cid)
    con.execute("UPDATE taxon SET compostos_fonte=1, compostos_incluidos=1, lotus_consulta_id=? WHERE id=?", (cid2, tid))
    mid = _molecula(con, "Cafeína", pubchem_cid=2519, chembl_id="CHEMBL113", max_fase_clinica=4.0, fase_consulta_id=cid3)
    con.execute("INSERT INTO referencia (doi, titulo, ano, resolvida, consulta_id) VALUES ('10.1000/abc','Artigo de teste',2020,1,?)", (cid2,))
    rid = con.execute("SELECT id FROM referencia").fetchone()[0]
    # o organismo que a fonte nomeia, resolvido no backbone para este táxon (regra da migração 008)
    a1 = _afirmacao(con, "composto_em_organismo", mid, cid2, taxon_id=tid, origem="lotus:1",
                    organismo_na_fonte="Carapa guianensis", procedencia_declarada="nao_declarada")
    con.execute("INSERT INTO organismo_fonte (fonte_id, nome_fonte, id_fonte, via, taxon_id, decisao, resolvido_em) "
                "VALUES ('lotus', 'Carapa guianensis', '100', 'identificador_da_fonte', ?, 'aceito', ?)", (tid, AGORA))
    con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (a1, rid))
    con.execute("INSERT INTO alvo (nome, chembl_id, organismo, tipo_chembl, natureza) "
                "VALUES ('Receptor A1', 'CHEMBL226', 'Homo sapiens', 'SINGLE PROTEIN', 'proteina_unica')")
    alvo = con.execute("SELECT id FROM alvo").fetchone()[0]
    # atividade: um par molécula–alvo agregado (aqui, de uma única medida) com a medida no livro
    a2 = _afirmacao(con, "atividade_biologica", mid, cid3, alvo_id=alvo, origem="chembl:agregado:CHEMBL113:CHEMBL226:IC50",
                    fonte="chembl", medida_tipo="IC50", medida_relacao="=", medida_valor=12.0, medida_unidade="nM",
                    medida_agregacao="unica", medida_n=1, medida_n_documentos=1, medida_min=12.0, medida_max=12.0, ensaio_tipo="B")
    con.execute("INSERT INTO medida_bioatividade (activity_id, afirmacao_id, molecula_id, alvo_chembl_id, tipo, relacao, valor_nm, "
                "pchembl, documento_chembl_id, ensaio_chembl_id, ensaio_tipo, usada, consulta_id) "
                "VALUES (1, ?, ?, 'CHEMBL226', 'IC50', '=', 12.0, 7.92, 'CHEMBL1', 'CHEMBL2', 'B', 1, ?)", (a2, mid, cid3))
    a3 = _afirmacao(con, "efeito_clinico_documentado", mid, cid3, origem="chembl:clinico:CHEMBL113", fonte="chembl",
                    fontes_regulatorias='[{"tipo":"DailyMed","id":"x","url":"https://dailymed.nlm.nih.gov/x"}]')
    con.execute("UPDATE molecula SET inchikey_conectividade=substr(inchikey,1,14) WHERE id=?", (mid,))
    con.commit()
    return SimpleNamespace(con=con, taxon=tid, molecula=mid, ref=rid, alvo=alvo, af_composto=a1, af_atividade=a2, af_clinico=a3,
                           consulta_gbif=cid, consulta_lotus=cid2, consulta_chembl=cid3)
