# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""O banco recusa violações dos princípios por restrição; o validador pega o que a restrição não alcança."""
import json
import sqlite3

import pytest

from bmb import construir, prontidao, validar
from conftest import AGORA, _afirmacao, _consulta, _molecula, _taxon


# ───────── restrições do esquema ─────────
def test_imagem_so_com_cc0_ou_cc_by(mini):
    for licenca in ("CC BY-NC", "CC BY-SA", "CC BY-NC-ND"):
        with pytest.raises(sqlite3.IntegrityError):
            mini.con.execute("INSERT INTO midia (taxon_id, url, pagina, licenca, autor, consulta_id) VALUES (?,?,?,?,?,?)",
                             (mini.taxon, f"https://x/{licenca}", "https://p", licenca, "A", mini.consulta_gbif))
    mini.con.execute("INSERT INTO midia (taxon_id, url, pagina, licenca, autor, consulta_id) VALUES (?,?,?,?,?,?)",
                     (mini.taxon, "https://x/ok", "https://p", "CC BY", "A", mini.consulta_gbif))


def test_composto_exige_organismo(mini):
    with pytest.raises(sqlite3.IntegrityError):
        _afirmacao(mini.con, "composto_em_organismo", mini.molecula, mini.consulta_lotus, taxon_id=None, origem="lotus:sem-taxon")


def test_efeito_clinico_nao_pode_ter_organismo(mini):
    with pytest.raises(sqlite3.IntegrityError):
        _afirmacao(mini.con, "efeito_clinico_documentado", mini.molecula, mini.consulta_chembl, taxon_id=mini.taxon, origem="chembl:x")


def test_atividade_nao_pode_ter_organismo(mini):
    with pytest.raises(sqlite3.IntegrityError):
        _afirmacao(mini.con, "atividade_biologica", mini.molecula, mini.consulta_chembl, taxon_id=mini.taxon, alvo_id=mini.alvo, origem="chembl:y")


def test_quarentena_exige_motivo(mini):
    with pytest.raises(sqlite3.IntegrityError):
        mini.con.execute("UPDATE afirmacao SET estado='quarentena' WHERE id=?", (mini.af_composto,))


def test_contagem_de_ocorrencia_exige_consulta(con):
    with pytest.raises(sqlite3.IntegrityError):
        _taxon(con, consulta_id=None)    # n_br preenchido sem ocorr_consulta_id: zero silencioso proibido


def test_molecula_exige_identidade(con):
    with pytest.raises(sqlite3.IntegrityError):
        con.execute("INSERT INTO molecula (tipo, nome) VALUES ('pequena_molecula', 'sem identidade')")


def test_fase_clinica_exige_consulta(con):
    with pytest.raises(sqlite3.IntegrityError):
        _molecula(con, "X", "XXXXXXXXXXXXXX-UHFFFAOYSA-N", max_fase_clinica=4.0)


def test_afirmacao_unica_pela_origem(mini):
    with pytest.raises(sqlite3.IntegrityError):
        _afirmacao(mini.con, "composto_em_organismo", mini.molecula, mini.consulta_lotus, taxon_id=mini.taxon, origem="lotus:1")


# ───────── upserts do construtor ─────────
def test_reconstruir_atualiza_sem_duplicar_nem_apagar_a_curadoria(mini):
    con = mini.con
    con.execute("UPDATE afirmacao SET estado='em_revisao' WHERE id=?", (mini.af_composto,))
    n0 = con.execute("SELECT COUNT(*) FROM afirmacao").fetchone()[0]
    aid = construir.upsert_afirmacao(con, tipo="composto_em_organismo", molecula_id=mini.molecula, taxon_id=mini.taxon, origem="lotus:1",
                                     fonte_id="lotus", consulta_id=mini.consulta_lotus, texto_="texto novo")
    assert aid == mini.af_composto
    assert con.execute("SELECT COUNT(*) FROM afirmacao").fetchone()[0] == n0
    linha = con.execute("SELECT texto, estado FROM afirmacao WHERE id=?", (aid,)).fetchone()
    assert linha["texto"] == "texto novo" and linha["estado"] == "em_revisao"     # texto atualiza; estado curatorial permanece


def test_referencia_por_doi_e_por_pmid_nao_sao_fundidas_sem_conferencia(con):
    """Quem diz que um DOI e um PMID são a mesma obra é o PubMed, não quem chama. Sem essa conferência, as duas
    linhas ficam separadas: foi a fusão cega que misturou obras diferentes nas linhagens."""
    r_doi = construir.upsert_referencia(con, doi="10.1/x", titulo="Título")
    r_pmid = construir.upsert_referencia(con, pmid="123")
    assert r_doi != r_pmid
    r = construir.upsert_referencia(con, doi="10.1/X", pmid="123", ano=2001)
    assert r == r_doi
    assert con.execute("SELECT COUNT(*) FROM referencia").fetchone()[0] == 2
    assert con.execute("SELECT pmid FROM referencia WHERE id=?", (r_doi,)).fetchone()["pmid"] is None
    # sem linha prévia para o PMID, o par declarado pela fonte é gravado junto e conferido depois
    r2 = construir.upsert_referencia(con, doi="10.1/y", pmid="456")
    assert tuple(con.execute("SELECT doi, pmid FROM referencia WHERE id=?", (r2,)).fetchone()) == ("10.1/y", "456")


def test_molecula_pequena_nao_rebaixa_dado_enriquecido(con):
    c = {"inchikey": "AAAAAAAAAAAAAA-BBBBBBBBBB-N", "nome": "nome longo iupac", "smiles": "C", "formula": "CH4", "massa": 16.0, "lotus_id": "L1", "classe": "A › B"}
    mid = construir.upsert_molecula_pequena(con, c)
    con.execute("UPDATE molecula SET nome='Metano', pubchem_cid=297 WHERE id=?", (mid,))
    assert construir.upsert_molecula_pequena(con, c) == mid
    linha = con.execute("SELECT nome, pubchem_cid FROM molecula WHERE id=?", (mid,)).fetchone()
    assert (linha["nome"], linha["pubchem_cid"]) == ("Metano", 297)


def test_quarentena_por_retratacao_so_quando_todas_as_referencias_foram_retratadas(mini):
    from bmb import bibliografia, quarentena
    con = mini.con
    quarentena.registrar_catalogo(con)
    con.execute("INSERT INTO referencia (doi, retratada, resolvida) VALUES ('10.1/boa', 0, 1)")
    boa = con.execute("SELECT id FROM referencia WHERE doi='10.1/boa'").fetchone()[0]
    con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (mini.af_composto, boa))
    con.execute("UPDATE referencia SET retratada=1 WHERE id=?", (mini.ref,))
    assert bibliografia.declarar_regras_de_afirmacao(con) == {}           # ainda há referência boa
    con.execute("UPDATE referencia SET retratada=1 WHERE id=?", (boa,))
    assert bibliografia.declarar_regras_de_afirmacao(con) == {"REF-RETRATADA": 1}
    quarentena.aplicar_estados(con)
    a = con.execute("SELECT estado, regra_quarentena, motivo_quarentena FROM afirmacao WHERE id=?", (mini.af_composto,)).fetchone()
    assert a["estado"] == "quarentena" and a["regra_quarentena"] == "REF-RETRATADA" and "retratadas" in a["motivo_quarentena"]
    # um evento para a afirmação retratada e um para cada registro da molécula que dependia dela (medida e efeito clínico)
    eventos = [r[0] for r in con.execute("SELECT detalhe FROM evento_proveniencia WHERE atividade='quarentena' ORDER BY id")]
    assert len(eventos) == 3 and eventos[0].startswith("REF-RETRATADA") and all(e.startswith("MOL-SEM-ORGANISMO") for e in eventos[1:])
    # a condição deixa de valer: a afirmação volta a candidato, de forma reprodutível
    con.execute("UPDATE referencia SET retratada=0 WHERE id=?", (boa,))
    bibliografia.declarar_regras_de_afirmacao(con)
    quarentena.aplicar_estados(con)
    assert con.execute("SELECT estado, regra_quarentena FROM afirmacao WHERE id=?", (mini.af_composto,)).fetchone()[:] == ("candidato", None)


# ───────── prontidão no banco ─────────
def test_prontidao_de_candidato_nunca_chega_a_um(mini):
    prontidao.recalcular_todas(mini.con)
    for r in mini.con.execute("SELECT indice FROM prontidao"):
        assert 0 < r["indice"] < 1
    c = mini.con.execute("SELECT * FROM prontidao WHERE afirmacao_id=?", (mini.af_composto,)).fetchone()
    assert c["identidade_quimica"] == "atende" and c["procedencia"] == "nao_avaliado" and c["rastreabilidade"] == "parcial"
    clinico = mini.con.execute("SELECT * FROM prontidao WHERE afirmacao_id=?", (mini.af_clinico,)).fetchone()
    assert clinico["identidade_biologica"] == "nao_se_aplica" and clinico["procedencia"] == "nao_se_aplica"


def test_verificacao_humana_eleva_rastreabilidade_e_sensibilidade(mini):
    con = mini.con
    # a leitura do curador registra a coleta de forma estruturada, até a unidade da federação
    con.execute("INSERT INTO verificacao (afirmacao_id, referencia_id, curador, decisao, passagem_conferida, procedencia_material, sensibilidade, "
                "qualidade_experimental, escopo_geografico_lido, em) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (mini.af_composto, mini.ref, "Curadora X", "confirmada", "Compound isolated from bark collected in Amazonas State.",
                 "Brasil: AM", "sem_restricao", "atende", "amazonia_br", AGORA))
    con.execute("UPDATE afirmacao SET estado='verificado', procedencia_material='Brasil: AM' WHERE id=?", (mini.af_composto,))
    prontidao.recalcular_todas(con)
    p = con.execute("SELECT * FROM prontidao WHERE afirmacao_id=?", (mini.af_composto,)).fetchone()
    assert con.execute("SELECT procedencia_declarada FROM afirmacao WHERE id=?", (mini.af_composto,)).fetchone()[0] == "curador_artigo_amazonia"
    assert p["rastreabilidade"] == "atende" and p["sensibilidade"] == "atende" and p["procedencia"] == "atende"
    assert p["qualidade_experimental"] == "atende" and p["indice"] == 1.0     # as sete dimensões atendidas após leitura humana
    # leitura que não situa a coleta: a procedência fica registrada como ausente, mesmo com texto livre preenchido
    con.execute("UPDATE verificacao SET escopo_geografico_lido='nao_declarado' WHERE afirmacao_id=?", (mini.af_composto,))
    prontidao.recalcular_todas(con)
    assert con.execute("SELECT procedencia FROM prontidao WHERE afirmacao_id=?", (mini.af_composto,)).fetchone()[0] == "ausente"


# ───────── validador ─────────
def test_validador_aceita_banco_coerente(mini):
    prontidao.recalcular_todas(mini.con)
    r = validar.validar(mini.con)
    assert r["erros"] == [], r["erros"]


def test_validador_pega_verificado_sem_verificacao(mini):
    mini.con.execute("UPDATE afirmacao SET estado='verificado' WHERE id=?", (mini.af_composto,))
    ids = {e["id"] for e in validar.validar(mini.con)["erros"]}
    assert "P4.verificado_sem_verificacao" in ids


def test_validador_pega_procedencia_inventada(mini):
    mini.con.execute("UPDATE afirmacao SET procedencia_material='Floresta Nacional de Tapajós' WHERE id=?", (mini.af_composto,))
    assert "P2.procedencia_inventada" in {e["id"] for e in validar.validar(mini.con)["erros"]}


def test_validador_pega_clinico_sem_aprovacao(mini):
    mini.con.execute("UPDATE molecula SET max_fase_clinica=2.0 WHERE id=?", (mini.molecula,))
    assert "P4.clinico_sem_aprovacao" in {e["id"] for e in validar.validar(mini.con)["erros"]}


def test_validador_pega_alegacao_de_eficacia_no_texto(mini):
    mini.con.execute("UPDATE afirmacao SET texto='Esta planta cura o câncer.' WHERE id=?", (mini.af_composto,))
    assert "P4.texto_com_alegacao" in {e["id"] for e in validar.validar(mini.con)["erros"]}


def test_validador_pega_recorte_sem_duas_bases(mini):
    mini.con.execute("UPDATE taxon SET motivo_recorte='Dentro do recorte: 60 registros no Brasil, fim.' WHERE id=?", (mini.taxon,))
    assert "P2.recorte_sem_duas_bases" in {e["id"] for e in validar.validar(mini.con)["erros"]}


def test_validador_pega_referencia_retratada_sustentando(mini):
    mini.con.execute("UPDATE referencia SET retratada=1 WHERE id=?", (mini.ref,))
    assert "P4.retratada_sustentando" in {e["id"] for e in validar.validar(mini.con)["erros"]}


def test_verificacao_exige_passagem_nota_e_curador_identificado(mini):
    ins = ("INSERT INTO verificacao (afirmacao_id, curador, decisao, passagem_conferida, nota, em) VALUES (?,?,?,?,?,?)")
    with pytest.raises(sqlite3.IntegrityError):      # confirmar sem ter lido o trecho
        mini.con.execute(ins, (mini.af_composto, "Curadora X", "confirmada", "curto", None, AGORA))
    with pytest.raises(sqlite3.IntegrityError):      # rejeitar sem dizer por quê
        mini.con.execute(ins, (mini.af_composto, "Curadora X", "rejeitada", None, None, AGORA))
    with pytest.raises(sqlite3.IntegrityError):      # curador anônimo
        mini.con.execute(ins, (mini.af_composto, "  ", "duvida", None, None, AGORA))
    mini.con.execute(ins, (mini.af_composto, "Curadora X", "rejeitada", None, "O artigo não menciona este composto na espécie.", AGORA))
    mini.con.execute(ins, (mini.af_composto, "Curadora X", "duvida", None, None, AGORA))


def test_procedencia_nao_declarada_pelo_artigo_vira_ausencia_registrada(mini):
    con = mini.con
    con.execute("INSERT INTO verificacao (afirmacao_id, referencia_id, curador, decisao, passagem_conferida, sensibilidade, em) VALUES (?,?,?,?,?,?,?)",
                (mini.af_composto, mini.ref, "Curadora X", "confirmada", "Compound isolated from the seed oil of the species.", "sem_restricao", AGORA))
    con.execute("UPDATE afirmacao SET estado='verificado' WHERE id=?", (mini.af_composto,))     # procedencia_material segue NULL
    prontidao.recalcular_todas(con)
    p = con.execute("SELECT procedencia, notas FROM prontidao WHERE afirmacao_id=?", (mini.af_composto,)).fetchone()
    assert p["procedencia"] == "ausente" and "não declara a procedência" in p["notas"]
