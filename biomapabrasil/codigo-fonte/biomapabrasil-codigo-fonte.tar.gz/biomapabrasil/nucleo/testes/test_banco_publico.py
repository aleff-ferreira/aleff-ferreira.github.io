# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Banco de distribuição: a cópia que acompanha a Release só tem registros publicados e exporta os mesmos pacotes."""
from __future__ import annotations

import hashlib
import json
import sqlite3
from pathlib import Path

import pytest

from bmb import db, prontidao, quarentena, validar
from bmb.exportar import banco_publico, pacotes
from conftest import AGORA, _afirmacao, _molecula

MOTIVO_DO_CURADOR = "Dúvida registrada pelo curador sobre a identidade do material."


@pytest.fixture
def cenario(mini):
    """Banco pequeno com um registro publicado de cada tipo e, ao lado, tudo o que não deve acompanhar a cópia."""
    con = mini.con
    # molécula cujo único registro em organismo é retido por regra; a medida dela fica retida por consequência
    ftalato = _molecula(con, "Dibutyl phthalate", "DOIRQSBPFJWKBE-UHFFFAOYSA-N")
    af_retida = _afirmacao(con, "composto_em_organismo", ftalato, mini.consulta_lotus, taxon_id=mini.taxon, origem="lotus:2",
                           organismo_na_fonte="Carapa guianensis", procedencia_declarada="nao_declarada")
    af_dependente = _afirmacao(con, "atividade_biologica", ftalato, mini.consulta_chembl, alvo_id=mini.alvo, fonte="chembl",
                               origem="chembl:agregado:CHEMBL1:CHEMBL226:IC50", medida_tipo="IC50", medida_relacao="=",
                               medida_valor=900.0, medida_unidade="nM", medida_agregacao="unica", medida_n=1,
                               medida_n_documentos=1, medida_min=900.0, medida_max=900.0, ensaio_tipo="B")
    con.execute("INSERT INTO medida_bioatividade (activity_id, afirmacao_id, molecula_id, alvo_chembl_id, tipo, relacao, valor_nm, "
                "pchembl, documento_chembl_id, ensaio_chembl_id, ensaio_tipo, usada, consulta_id) "
                "VALUES (2, ?, ?, 'CHEMBL226', 'IC50', '=', 900.0, 6.05, 'CHEMBL3', 'CHEMBL4', 'B', 1, ?)",
                (af_dependente, ftalato, mini.consulta_chembl))
    quarentena.declarar(con, {"NAT-CONTAMINANTE"},
                        {af_retida: {"NAT-CONTAMINANTE": {"substancia": "Dibutyl phthalate", "taxon": "Carapa guianensis"}}})
    # medida que ficou fora do agregado da afirmação publicada
    con.execute("INSERT INTO medida_bioatividade (activity_id, afirmacao_id, molecula_id, alvo_chembl_id, tipo, relacao, valor_nm, "
                "pchembl, documento_chembl_id, ensaio_chembl_id, ensaio_tipo, usada, motivo_exclusao, consulta_id) "
                "VALUES (3, ?, ?, 'CHEMBL226', 'IC50', '=', 0.001, 12.0, 'CHEMBL5', 'CHEMBL6', 'B', 0, 'inativa_ou_inconclusiva', ?)",
                (mini.af_atividade, mini.molecula, mini.consulta_chembl))
    # segunda referência da afirmação publicada, retida: a afirmação segue pública pela primeira
    con.execute("INSERT INTO referencia (doi, titulo, ano, resolvida, consulta_id) VALUES ('10.9999/nao-existe','Obra não localizada',2019,0,?)",
                (mini.consulta_lotus,))
    ref_retida = con.execute("SELECT id FROM referencia WHERE doi='10.9999/nao-existe'").fetchone()[0]
    con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (mini.af_composto, ref_retida))
    quarentena.reter_referencia(con, ref_retida, "REF-DOI-INEXISTENTE", doi="10.9999/nao-existe", resposta_handle="404")
    # retenção decidida por curador, com motivo em texto livre
    con.execute("INSERT INTO molecula (tipo, nome, uniprot_acc) VALUES ('proteina', 'Toxina de teste', 'P99999')")
    toxina = con.execute("SELECT id FROM molecula WHERE uniprot_acc='P99999'").fetchone()[0]
    af_curador = _afirmacao(con, "funcao_toxina", toxina, mini.consulta_gbif, taxon_id=mini.taxon, origem="uniprot:P99999", fonte="uniprot",
                            procedencia_declarada="nao_declarada", estado="quarentena", quarentena_origem="curador",
                            motivo_quarentena=MOTIVO_DO_CURADOR)
    # registros de trabalho que não descrevem nada publicado
    con.execute("INSERT INTO amostra_benchmark (rodada, afirmacao_id, estrato, semente_aleatoria, amostrado_em) VALUES ('r1', ?, 'lotus', 1, ?)",
                (mini.af_composto, AGORA))
    con.execute("INSERT INTO taxon_sinonimo_legado (taxon_id, nome) VALUES (?, 'Carapa antiga')", (mini.taxon,))
    con.execute("INSERT OR REPLACE INTO etapa (nome, iniciada_em, concluida_em, resumo) VALUES ('atividades', ?, ?, ?)",
                (AGORA, AGORA, json.dumps({"retidos_por_regra": {"BIO-DISCORDANTE": 2}})))
    prontidao.recalcular_todas(con)
    con.commit()
    assert not validar.validar(con)["erros"]
    mini.retidas = {af_retida, af_dependente, af_curador}
    mini.ref_retida, mini.mol_retidas = ref_retida, {ftalato, toxina}
    return mini


def _arquivos(pasta: Path) -> dict[str, str]:
    """SHA-256 de cada arquivo exportado, fora os que dependem do instante da exportação."""
    fora = {"manifesto.json", "SHA256SUMS.txt"}
    return {p.relative_to(pasta).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(pasta.rglob("*")) if p.is_file() and p.name not in fora and p.suffix != ".zip"}


def test_copia_publica_so_tem_registros_publicados(cenario, tmp_path):
    con = cenario.con
    assert {r[0] for r in con.execute("SELECT id FROM afirmacao WHERE estado='quarentena'")} == cenario.retidas
    destino = tmp_path / "publico.sqlite"
    resumo = banco_publico.gerar(con, destino, log=lambda *_: None)
    assert resumo["afirmacao"] == 3 and resumo["molecula"] == 1 and resumo["referencia"] == 1

    pub = sqlite3.connect(destino)
    pub.row_factory = sqlite3.Row
    um = lambda sql: pub.execute(sql).fetchone()[0]
    assert {r[0] for r in pub.execute("SELECT id FROM afirmacao")} == {cenario.af_composto, cenario.af_atividade, cenario.af_clinico}
    assert {r[0] for r in pub.execute("SELECT DISTINCT estado FROM afirmacao")} == {"candidato"}
    assert {r[0] for r in pub.execute("SELECT id FROM molecula")} == {cenario.molecula}
    assert [tuple(r) for r in pub.execute("SELECT afirmacao_id, referencia_id FROM afirmacao_referencia")] == [(cenario.af_composto, cenario.ref)]
    assert um("SELECT COUNT(*) FROM referencia WHERE estado <> 'ativa'") == 0
    for tabela in banco_publico.TABELAS_INTERNAS:
        assert um(f"SELECT COUNT(*) FROM {tabela}") == 0, tabela
    assert um("SELECT COUNT(*) FROM medida_bioatividade") == 1 and um("SELECT COUNT(*) FROM medida_bioatividade WHERE motivo_exclusao IS NOT NULL") == 0
    assert um("SELECT COUNT(*) FROM afirmacao WHERE motivo_quarentena IS NOT NULL OR regra_quarentena IS NOT NULL OR conferencia_literatura IS NOT NULL") == 0
    assert um("SELECT resumo FROM etapa WHERE nome='atividades'") is None
    assert um("SELECT COUNT(*) FROM evento_proveniencia WHERE atividade NOT IN ('extracao','agregacao','reconciliacao','verificacao','publicacao')") == 0
    assert um("SELECT COUNT(*) FROM busca WHERE tipo='molecula' AND CAST(ref_id AS INTEGER) NOT IN (SELECT id FROM molecula)") == 0
    assert pub.execute("PRAGMA foreign_key_check").fetchall() == []
    assert banco_publico.conferir(pub) == []
    pub.close()

    # nem o texto do motivo nem código de regra sobram no arquivo (a cópia é compactada depois da limpeza)
    bruto = destino.read_bytes()
    for trecho in (MOTIVO_DO_CURADOR, "NAT-CONTAMINANTE", "MOL-SEM-ORGANISMO", "REF-DOI-INEXISTENTE", "plastificante", "10.9999/nao-existe",
                   "Dibutyl phthalate", "inativa_ou_inconclusiva", "Carapa antiga"):
        assert trecho.encode("utf-8") not in bruto, trecho
    assert not Path(str(destino) + "-wal").exists()

    # o banco de trabalho continua inteiro: nada é apagado dele
    assert {r[0] for r in con.execute("SELECT id FROM afirmacao WHERE estado='quarentena'")} == cenario.retidas
    assert con.execute("SELECT motivo_quarentena FROM afirmacao WHERE quarentena_origem='curador'").fetchone()[0] == MOTIVO_DO_CURADOR
    assert con.execute("SELECT COUNT(*) FROM taxon_sinonimo_legado").fetchone()[0] == 1


def test_copia_publica_valida_e_exporta_os_mesmos_pacotes(cenario, tmp_path):
    con = cenario.con
    destino = tmp_path / "publico.sqlite"
    banco_publico.gerar(con, destino, log=lambda *_: None)
    pacotes.exportar_tudo(con, tmp_path / "do_banco_de_trabalho", log=lambda *_: None)

    pub = db.conectar(destino)
    try:
        resultado = validar.validar(pub)
        assert resultado["erros"] == [], resultado["erros"]
        pacotes.exportar_tudo(pub, tmp_path / "da_copia", log=lambda *_: None)
    finally:
        pub.close()
    a, b = _arquivos(tmp_path / "do_banco_de_trabalho"), _arquivos(tmp_path / "da_copia")
    assert set(a) == set(b)
    assert {k for k in a if a[k] != b[k]} == set()
    ca = json.loads((tmp_path / "do_banco_de_trabalho" / "manifesto.json").read_text(encoding="utf-8"))["contagens"]
    cb = json.loads((tmp_path / "da_copia" / "manifesto.json").read_text(encoding="utf-8"))["contagens"]
    assert ca == cb and ca["afirmacoes_publicas"] == 3


def test_copia_publica_recusa_conteudo_interno_remanescente(cenario, tmp_path):
    """A conferência final falha, e nada é gravado, se algum texto publicado trouxer um código de regra."""
    con = cenario.con
    con.execute("UPDATE afirmacao SET texto = texto || ' (TAX-HOMONIMO)' WHERE id=?", (cenario.af_composto,))
    con.commit()
    destino = tmp_path / "publico.sqlite"
    with pytest.raises(RuntimeError, match="identificador interno"):
        banco_publico.gerar(con, destino, log=lambda *_: None)
    assert not destino.exists()


def test_copia_publica_nunca_sobrescreve_o_banco_de_trabalho(cenario):
    con = cenario.con
    origem = con.execute("PRAGMA database_list").fetchone()[2]
    with pytest.raises(ValueError, match="próprio banco de trabalho"):
        banco_publico.gerar(con, origem, log=lambda *_: None)
    assert con.execute("SELECT COUNT(*) FROM afirmacao").fetchone()[0] == 6

