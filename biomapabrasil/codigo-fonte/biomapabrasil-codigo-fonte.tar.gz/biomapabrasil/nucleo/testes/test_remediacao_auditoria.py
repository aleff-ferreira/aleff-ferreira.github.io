# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Regressão das correções da migração 008: cada teste reproduz, sem rede, um caso em que o banco já errou.

Identidade taxonômica (sinônimo truncado, homônimo), não constituintes, agregação de bioatividade, procedência
declarada × distribuição, conferência na literatura, integridade das referências, linhagens e limite de localidade.
"""
from __future__ import annotations

import csv
import gzip
import json
import re
import tomllib
from types import SimpleNamespace

import pytest

from bmb import (bibliografia, bioatividade, config, construir, literatura, procedencia, prontidao, quarentena, quimica,
                 taxonomia, validar)
from bmb.conectores import catalogo_nacional_dwca, chembl, ena, linhagem_vias, lotus, npatlas_coconut, nubbe
from bmb.http import ErroDeFonte
from conftest import AGORA, _afirmacao, _consulta, _molecula, _taxon

CAFEINA = ("RYYVLZVUVIJVGH-UHFFFAOYSA-N", "Cn1cnc2c1c(=O)n(C)c(=O)n2C", "Caffeine")
TEOBROMINA = ("YAPQBXQYLJRXSA-UHFFFAOYSA-N", "Cn1cnc2c1c(=O)[nH]c(=O)n2C", "Theobromine")
QUERCETINA = ("REFJWTPEDVJJIY-UHFFFAOYSA-N", "O=c1c(O)c(-c2ccc(O)c(O)c2)oc2cc(O)cc(O)c12", "Quercetin")
LIMONENO = ("XMGQYMWWDOXHJM-UHFFFAOYSA-N", "C=C(C)C1CC=C(C)CC1", "Limonene")


class ClienteFalso:
    """Cliente HTTP de teste: `rotas` é uma lista de (trecho_da_url, função(url, params) -> dados)."""

    def __init__(self, consulta_id, rotas):
        self.consulta_id, self.rotas, self.pedidos = consulta_id, rotas, []

    def get(self, url, params=None, **_):
        self.pedidos.append((url, params))
        for trecho, fn in self.rotas:
            if trecho in url:
                dados = fn(url, params or {})
                if dados is None:
                    return SimpleNamespace(dados={}, status=404, ok=False, consulta_id=self.consulta_id, url=url)
                return SimpleNamespace(dados=dados, status=200, ok=True, consulta_id=self.consulta_id, url=url)
        raise ErroDeFonte(f"sem rota de teste para {url}")

    def get_varios(self, pedidos, **_):
        saida = []
        for url, params in pedidos:
            try:
                saida.append(self.get(url, params))
            except ErroDeFonte:
                saida.append(None)
        return saida


# ═══════════════════════════ identidade taxonômica ═══════════════════════════
def _uso(key, nome, autoria, categoria="SPECIES", status="ACCEPTED", aceito=None, especie=None, reino="Plantae"):
    return {"key": key, "canonicalName": nome, "scientificName": f"{nome} {autoria}", "authorship": autoria, "rank": categoria,
            "taxonomicStatus": status, "acceptedKey": aceito, "speciesKey": especie or key, "kingdom": reino}


def test_decisao_nao_liga_arroz_a_oryza_grandiglumis_nem_graviola_a_annona_montana():
    """«Oryza sativa var. grandiglumis» ser sinônimo de O. grandiglumis não faz do arroz parte dela; «Annona muricata
    Vell.» ser sinônimo de A. montana não faz da graviola de Lineu parte dela."""
    grandiglumis = {"id": 1, "gbif_key": 4110094, "nome": "Oryza grandiglumis", "autoria": "(Döll) Prodoehl"}
    montana = {"id": 2, "gbif_key": 5407100, "nome": "Annona montana", "autoria": "Macfad."}
    por_key = {4110094: grandiglumis, 5407100: montana}
    por_nome = {taxonomia.chave(t["nome"]): t for t in (grandiglumis, montana)}

    sativa = {"key": 2703459, "nome": "Oryza sativa", "autoria": "L.", "categoria": "SPECIES"}
    assert taxonomia.decidir(por_key, por_nome, "Oryza sativa", sativa, sativa) == ("fora_do_escopo", None)
    muricata = {"key": 5407273, "nome": "Annona muricata", "autoria": "L.", "categoria": "SPECIES"}
    assert taxonomia.decidir(por_key, por_nome, "Annona muricata", muricata, muricata) == ("fora_do_escopo", None)
    # o sinônimo verdadeiro, pelo identificador do uso, chega à espécie aceita certa
    var = {"key": 999, "nome": "Oryza sativa var. grandiglumis", "autoria": "Döll", "categoria": "VARIETY"}
    alvo = {"key": 4110094, "nome": "Oryza grandiglumis", "autoria": "(Döll) Prodoehl", "categoria": "SPECIES"}
    assert taxonomia.decidir(por_key, por_nome, "Oryza sativa var. grandiglumis", var, alvo) == ("aceito", 1)


def test_decisao_de_homonimo_e_de_nome_repetido_no_backbone():
    kunth = {"id": 7, "gbif_key": 300, "nome": "Vismia macrophylla", "autoria": "Kunth"}
    por_key, por_nome = {300: kunth}, {taxonomia.chave("Vismia macrophylla"): kunth}
    outro_autor = {"key": 301, "nome": "Vismia macrophylla", "autoria": "Mart.", "categoria": "SPECIES"}
    guianensis = {"key": 302, "nome": "Vismia guianensis", "autoria": "(Aubl.) DC.", "categoria": "SPECIES"}
    # o identificador da fonte leva a um homônimo de outro autor: não se sabe qual o artigo estudou
    assert taxonomia.decidir(por_key, por_nome, "Vismia macrophylla", outro_autor, guianensis) == ("homonimo_nao_resolvido", 7)
    # mesmo quando o homônimo leva a OUTRO táxon do banco, o registro não é transferido para ele
    por_key2 = {300: kunth, 302: {"id": 8, "gbif_key": 302, "nome": "Vismia guianensis", "autoria": "(Aubl.) DC."}}
    assert taxonomia.decidir(por_key2, por_nome, "Vismia macrophylla", outro_autor, guianensis) == ("homonimo_nao_resolvido", 7)
    # mesmo nome e mesma autoria em outra chave do backbone: é a mesma espécie
    duplicado = {"key": 303, "nome": "Vismia macrophylla", "autoria": "Kunth", "categoria": "SPECIES"}
    assert taxonomia.decidir(por_key, por_nome, "Vismia macrophylla", duplicado, None) == ("aceito_mesmo_nome_e_autoria", 7)
    # sem identificador e sem resposta do backbone, só o nome aceito idêntico liga
    assert taxonomia.decidir(por_key, por_nome, "Vismia macrophylla", None, None) == ("aceito", 7)
    assert taxonomia.decidir(por_key, por_nome, "Vismia latifolia", None, None) == ("nao_resolvido", None)


def test_autoria_compara_sobrenomes_e_nao_pontuacao():
    assert taxonomia.mesma_autoria("(Spruce ex Müll.Arg.) Woodson", "(Spruce ex Müll. Arg.) R. E.Woodson")
    assert not taxonomia.mesma_autoria("L.", "Vell.")
    assert not taxonomia.mesma_autoria(None, "L.")
    assert taxonomia.chave("Oryza sativa var. grandiglumis") != taxonomia.chave("Oryza sativa")


def test_nomes_de_organismo_das_fontes_nao_sao_cortados():
    assert nubbe.nome_do_organismo("Cryptocarya", "mandioccana Meissner") == ("Cryptocarya mandioccana", "Meissner")
    assert nubbe.nome_do_organismo("Piper", "nigrum var. album") == ("Piper nigrum var. album", None)
    assert nubbe.nome_do_organismo("Pilocarpus", "affinis pauciflorus") == (None, None)
    assert nubbe.nome_do_organismo("Piper", "sp.") == (None, None)
    assert catalogo_nacional_dwca.nome_do_registro("Oryza", "sativa", "grandiglumis", "VARIEDADE") == (
        "Oryza sativa var. grandiglumis", "VARIETY")
    assert catalogo_nacional_dwca.nome_do_registro("Oryza", "sativa", None, "ESPECIE") == ("Oryza sativa", "SPECIES")
    assert catalogo_nacional_dwca.nome_do_registro("Tachytes", "chrysopyga", "staegeri", "subspecies") == (
        "Tachytes chrysopyga staegeri", "SUBSPECIES")


def test_reconciliacao_com_checklist_exige_autoria_no_sinonimo():
    entrada = {"nome_aceito": "Annona muricata", "autoria": "L.", "reino": "Plantae", "sinonimos_autoria": {}, "forma_vida": None,
               "substrato_habitat": None, "status_origem_br": "cultivada", "dominios_list": [], "endemismo_br": None,
               "fonte": "jbrj_flora_funga", "consulta_id": 1}
    catalogo = {"annona muricata": entrada}
    # sinônimo de texto simples (formato antigo) não reconcilia
    assert catalogo_nacional_dwca.reconciliar_via_dwca_local(catalogo, "Annona montana", "Plantae", ["Annona muricata"]) is None
    # homônimo de outro autor não reconcilia
    vell = [{"nome": "Annona muricata", "autoria": "Vell.", "categoria": "SPECIES"}]
    assert catalogo_nacional_dwca.reconciliar_via_dwca_local(catalogo, "Annona montana", "Plantae", vell) is None
    lineu = [{"nome": "Annona muricata", "autoria": "L.", "categoria": "SPECIES"}]
    assert catalogo_nacional_dwca.reconciliar_via_dwca_local(catalogo, "Annona x", "Plantae", lineu)["origem_estabelecimento"] == "introduzida"


def _dump_lotus(tmp_path, linhas):
    arq = tmp_path / "lotus.csv.gz"
    colunas = ["structure_inchikey", "structure_smiles", "structure_nameTraditional", "structure_exact_mass",
               "structure_molecular_formula", "organism_name", "organism_taxonomy_gbifid", "organism_taxonomy_02kingdom",
               "organism_taxonomy_06family", "organism_taxonomy_09species", "reference_doi", "manual_validation"]
    with gzip.open(arq, "wt", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=colunas)
        w.writeheader()
        for (ik, smi, nome), organismo, gbifid, especie, doi in linhas:
            w.writerow({"structure_inchikey": ik, "structure_smiles": smi, "structure_nameTraditional": nome,
                        "structure_exact_mass": "194.08", "structure_molecular_formula": "NA", "organism_name": organismo,
                        "organism_taxonomy_gbifid": gbifid, "organism_taxonomy_02kingdom": "Archaeplastida",
                        "organism_taxonomy_06family": "Poaceae", "organism_taxonomy_09species": especie, "reference_doi": doi,
                        "manual_validation": "NA"})
    return arq


@pytest.fixture
def cenario_compostos(con, tmp_path, monkeypatch):
    """Banco no estado anterior à correção: O. grandiglumis com compostos do arroz, A. montana com os da graviola."""
    cid = _consulta(con)
    cid_l = _consulta(con, "lotus", "https://zenodo.org/x", "b")
    t_oryza = _taxon(con, gbif=4110094, nome="Oryza grandiglumis", consulta_id=cid)
    t_annona = _taxon(con, gbif=5407100, nome="Annona montana", consulta_id=cid)
    t_vismia = _taxon(con, gbif=300, nome="Vismia macrophylla", consulta_id=cid)
    con.execute("UPDATE taxon SET autoria='(Döll) Prodoehl' WHERE id=?", (t_oryza,))
    con.execute("UPDATE taxon SET autoria='Macfad.' WHERE id=?", (t_annona,))
    con.execute("UPDATE taxon SET autoria='Kunth' WHERE id=?", (t_vismia,))
    for tid, nome in ((t_oryza, "Oryza sativa"), (t_annona, "Annona muricata")):      # sinônimos no formato antigo
        con.execute("INSERT INTO taxon_sinonimo (taxon_id, nome, origem) VALUES (?,?, 'gbif')", (tid, nome))
        con.execute("INSERT INTO taxon_sinonimo_legado (taxon_id, nome) VALUES (?,?)", (tid, nome))
    mols = {ik: _molecula(con, nome, inchikey=ik, smiles=smi) for ik, smi, nome in (CAFEINA, TEOBROMINA, QUERCETINA, LIMONENO)}
    refs = {}
    for doi in ("10.1/arroz", "10.1/grandiglumis", "10.1/compartilhado-certo", "10.1/compartilhado-arroz", "10.1/graviola", "10.1/vismia"):
        con.execute("INSERT INTO referencia (doi, resolvida, consulta_id) VALUES (?, 1, ?)", (doi, cid_l))
        refs[doi] = con.execute("SELECT id FROM referencia WHERE doi=?", (doi,)).fetchone()[0]

    def antiga(taxon, ik, dois):
        aid = _afirmacao(con, "composto_em_organismo", mols[ik], cid_l, taxon_id=taxon, origem=f"lotus:{ik}")
        for d in dois:
            con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (aid, refs[d]))
        return aid

    afs = {"arroz": antiga(t_oryza, CAFEINA[0], ["10.1/arroz"]),
           "mista": antiga(t_oryza, QUERCETINA[0], ["10.1/compartilhado-certo", "10.1/compartilhado-arroz"]),
           "graviola": antiga(t_annona, TEOBROMINA[0], ["10.1/graviola"])}
    arq = _dump_lotus(tmp_path, [
        (CAFEINA, "Oryza sativa", "2703459", "Oryza sativa", "10.1/arroz"),
        (QUERCETINA, "Oryza sativa", "2703459", "Oryza sativa", "10.1/compartilhado-arroz"),
        (QUERCETINA, "Oryza grandiglumis", "4110094", "Oryza grandiglumis", "10.1/compartilhado-certo"),
        (LIMONENO, "Oryza grandiglumis", "4110094", "Oryza grandiglumis", "10.1/grandiglumis"),
        (TEOBROMINA, "Annona muricata", "5407273", "Annona muricata", "10.1/graviola"),
        (LIMONENO, "Vismia macrophylla", "301", "Vismia macrophylla", "10.1/vismia"),
    ])
    monkeypatch.setattr(catalogo_nacional_dwca, "garantir_arquivo_dump", lambda *a, **k: (arq, cid_l))
    usos = {
        4110094: _uso(4110094, "Oryza grandiglumis", "(Döll) Prodoehl"), 2703459: _uso(2703459, "Oryza sativa", "L."),
        5407100: _uso(5407100, "Annona montana", "Macfad."), 5407273: _uso(5407273, "Annona muricata", "L."),
        300: _uso(300, "Vismia macrophylla", "Kunth"),
        301: _uso(301, "Vismia macrophylla", "Mart.", status="SYNONYM", aceito=302, especie=302),
        302: _uso(302, "Vismia guianensis", "(Aubl.) DC."),
    }
    sinonimos = {4110094: [{"canonicalName": "Oryza sativa var. grandiglumis", "scientificName": "Oryza sativa var. grandiglumis Döll",
                            "authorship": "Döll", "rank": "VARIETY", "taxonomicStatus": "SYNONYM", "key": 999}],
                 5407100: [{"canonicalName": "Annona muricata", "scientificName": "Annona muricata Vell.", "authorship": "Vell.",
                            "rank": "SPECIES", "taxonomicStatus": "SYNONYM", "key": 777}], 300: []}

    def rota_sinonimos(url, _):
        return {"results": sinonimos[int(url.split("/species/")[1].split("/")[0])], "endOfRecords": True}

    cli = ClienteFalso(cid, [("/synonyms", rota_sinonimos), ("/species/match", lambda *_: {"matchType": "NONE"}),
                             ("/species/", lambda url, _: usos.get(int(url.rsplit("/", 1)[1])))])
    return SimpleNamespace(con=con, cli=cli, afs=afs, refs=refs, mols=mols, t_oryza=t_oryza, t_annona=t_annona, t_vismia=t_vismia)


def test_etapa_de_compostos_retem_especie_errada_sem_apagar_e_tira_referencia_alheia(cenario_compostos):
    c = cenario_compostos
    con = c.con
    n_antes = con.execute("SELECT COUNT(*) FROM afirmacao").fetchone()[0]
    construir.etapa_compostos(con, c.cli, lambda *_: None)

    def af(aid):
        return con.execute("SELECT estado, regra_quarentena, motivo_quarentena, organismo_na_fonte FROM afirmacao WHERE id=?", (aid,)).fetchone()

    # arroz em O. grandiglumis e graviola em A. montana: retidos, com a espécie certa no motivo
    for chave, especie in (("arroz", "Oryza sativa L."), ("graviola", "Annona muricata L.")):
        a = af(c.afs[chave])
        assert (a["estado"], a["regra_quarentena"]) == ("quarentena", "TAX-ESPECIE-DIVERGENTE")
        assert especie in a["motivo_quarentena"]
    assert con.execute("SELECT COUNT(*) FROM afirmacao").fetchone()[0] >= n_antes                 # nada foi apagado
    # afirmação certa para o táxon, que carregava também uma referência do arroz: continua pública, sem ela
    mista = af(c.afs["mista"])
    assert mista["estado"] == "candidato" and mista["organismo_na_fonte"] == "Oryza grandiglumis"
    dois = [r["doi"] for r in con.execute("SELECT r.doi FROM afirmacao_referencia x JOIN referencia r ON r.id=x.referencia_id "
                                          "WHERE x.afirmacao_id=?", (c.afs["mista"],))]
    assert dois == ["10.1/compartilhado-certo"]
    assert con.execute("SELECT COUNT(*) FROM evento_proveniencia WHERE atividade='desvinculo_referencia'").fetchone()[0] == 1
    assert con.execute("SELECT COUNT(*) FROM referencia WHERE doi='10.1/compartilhado-arroz'").fetchone()[0] == 1
    # composto novo do organismo certo entra; o do homônimo nasce retido
    novo = con.execute("SELECT estado FROM afirmacao WHERE taxon_id=? AND origem=?", (c.t_oryza, f"lotus:{LIMONENO[0]}")).fetchone()
    assert novo["estado"] == "candidato"
    homonimo = con.execute("SELECT estado, regra_quarentena, motivo_quarentena FROM afirmacao WHERE taxon_id=?", (c.t_vismia,)).fetchone()
    assert (homonimo["estado"], homonimo["regra_quarentena"]) == ("quarentena", "TAX-HOMONIMO")
    assert "Mart." in homonimo["motivo_quarentena"] and "Kunth" in homonimo["motivo_quarentena"]
    # nenhum composto do arroz ou da graviola foi parar em outro táxon
    assert con.execute("SELECT COUNT(*) FROM afirmacao WHERE estado='candidato' AND organismo_na_fonte IN ('Oryza sativa','Annona muricata')").fetchone()[0] == 0
    # os sinônimos passam a ter autoria e categoria, inteiros
    s = con.execute("SELECT nome, autoria, categoria, gbif_key FROM taxon_sinonimo WHERE taxon_id=? AND origem='gbif'", (c.t_oryza,)).fetchone()
    assert tuple(s) == ("Oryza sativa var. grandiglumis", "Döll", "VARIETY", 999)
    decisoes = {r["nome_fonte"]: r["decisao"] for r in con.execute("SELECT nome_fonte, decisao FROM organismo_fonte")}
    assert decisoes == {"Oryza sativa": "fora_do_escopo", "Oryza grandiglumis": "aceito", "Annona muricata": "fora_do_escopo",
                        "Vismia macrophylla": "homonimo_nao_resolvido"}


def test_etapa_de_compostos_e_idempotente(cenario_compostos):
    c = cenario_compostos
    construir.etapa_compostos(c.con, c.cli, lambda *_: None)
    foto = [tuple(r) for r in c.con.execute("SELECT id, estado, regra_quarentena, motivo_quarentena FROM afirmacao ORDER BY id")]
    n_ev = c.con.execute("SELECT COUNT(*) FROM evento_proveniencia").fetchone()[0]
    construir.etapa_compostos(c.con, c.cli, lambda *_: None)
    assert [tuple(r) for r in c.con.execute("SELECT id, estado, regra_quarentena, motivo_quarentena FROM afirmacao ORDER BY id")] == foto
    assert c.con.execute("SELECT COUNT(*) FROM evento_proveniencia").fetchone()[0] == n_ev


# ═══════════════════════════ regras de retenção ═══════════════════════════
def test_regras_sao_deterministicas_reversiveis_e_respeitam_curador(mini):
    con = mini.con
    quarentena.registrar_catalogo(con)
    dados = {"substancia": "Calcium", "taxon": "Carapa guianensis"}
    quarentena.declarar(con, ("NAT-ELEMENTO", "NAT-CONTAMINANTE"), {mini.af_composto: {"NAT-ELEMENTO": dados, "NAT-CONTAMINANTE": dados}})
    quarentena.aplicar_estados(con)
    a = con.execute("SELECT estado, regra_quarentena, quarentena_origem FROM afirmacao WHERE id=?", (mini.af_composto,)).fetchone()
    assert tuple(a) == ("quarentena", "NAT-ELEMENTO", "regra")          # precedência fixa
    quarentena.declarar(con, ("NAT-ELEMENTO",), {})                     # uma das condições some
    quarentena.aplicar_estados(con)
    assert con.execute("SELECT regra_quarentena FROM afirmacao WHERE id=?", (mini.af_composto,)).fetchone()[0] == "NAT-CONTAMINANTE"
    quarentena.declarar(con, ("NAT-CONTAMINANTE",), {})
    assert quarentena.aplicar_estados(con)["liberadas"] == 3            # o composto e os dois registros que dependiam dele
    assert {r[0] for r in con.execute("SELECT estado FROM afirmacao")} == {"candidato"}
    assert quarentena.aplicar_estados(con) == {"retidas_agora": 0, "motivo_atualizado": 0, "liberadas": 0, "em_quarentena_por_regra": {}}
    # retenção decidida por curador não é desfeita por regra nenhuma
    con.execute("UPDATE afirmacao SET estado='quarentena', motivo_quarentena='dúvida do curador', quarentena_origem='curador' WHERE id=?",
                (mini.af_atividade,))
    quarentena.aplicar_estados(con)
    assert con.execute("SELECT estado FROM afirmacao WHERE id=?", (mini.af_atividade,)).fetchone()[0] == "quarentena"
    # construção parcial: o que não foi examinado fica como estava
    quarentena.declarar(con, ("NAT-ELEMENTO",), {mini.af_composto: {"NAT-ELEMENTO": dados}})
    quarentena.declarar(con, ("NAT-ELEMENTO",), {}, entre={mini.af_clinico})
    assert con.execute("SELECT COUNT(*) FROM afirmacao_regra WHERE codigo='NAT-ELEMENTO'").fetchone()[0] == 1
    with pytest.raises(ValueError):
        quarentena.declarar(con, ("REF-DOI-INEXISTENTE",), {})          # regra de referência não serve a afirmação


def test_nao_constituintes_controles_contaminantes_e_elementos(mini):
    con = mini.con
    t_piper = _taxon(con, gbif=200, nome="Physalis angulata", consulta_id=mini.consulta_gbif)
    t_papaver = _taxon(con, gbif=201, nome="Papaver somniferum", consulta_id=mini.consulta_gbif)
    con.execute("UPDATE taxon SET genero='Physalis' WHERE id=?", (t_piper,))
    con.execute("UPDATE taxon SET genero='Papaver' WHERE id=?", (t_papaver,))
    casos = {}
    for chave_, nome, ik, formula, taxon in (
            ("dexametasona", "Dexamethasone", "UREBDLICKHMUKA-CXSFZGCWSA-N", "C22H29FO5", t_piper),
            ("morfina_fora", "Morphine", "BQJCRHHNABKAKU-KBQPJGBKSA-N", "C17H19NO3", t_piper),
            ("ftalato", "Dibutyl Phthalate", "DOIRQSBPFJWKBE-UHFFFAOYSA-N", "C16H22O4", t_piper),
            ("calcio", "Calcium", "OYPRJOBELJOOCE-UHFFFAOYSA-N", "Ca", t_piper)):
        mid = _molecula(con, nome, inchikey=ik, formula=formula, smiles="C" if chave_ != "calcio" else None)
        casos[chave_] = _afirmacao(con, "composto_em_organismo", mid, mini.consulta_lotus, taxon_id=taxon, origem=f"lotus:{ik}")
    mid_m = con.execute("SELECT id FROM molecula WHERE nome='Morphine'").fetchone()[0]
    casos["morfina_produtor"] = _afirmacao(con, "composto_em_organismo", mid_m, mini.consulta_lotus, taxon_id=t_papaver, origem="lotus:m2")
    quarentena.registrar_catalogo(con)
    construir.aplicar_regras_de_molecula(con)
    quarentena.aplicar_estados(con)
    regra = {k: con.execute("SELECT regra_quarentena FROM afirmacao WHERE id=?", (v,)).fetchone()[0] for k, v in casos.items()}
    assert regra == {"dexametasona": "NAT-CONTROLE", "morfina_fora": "NAT-CONTROLE", "ftalato": "NAT-CONTAMINANTE",
                     "calcio": "NAT-ELEMENTO", "morfina_produtor": None}
    assert con.execute("SELECT restricao_ocorrencia FROM molecula WHERE nome='Calcium'").fetchone()[0] == "elemento_quimico"


def test_nubbe_semissintese_nao_e_ocorrencia_e_cidade_nao_e_lida():
    linhas = [
        {"gender": "Piper", "species": "aduncum", "smiles": CAFEINA[1], "doi": "10.1/isol", "isolation_type": "Isolated from plant",
         "state": "AM", "city": "Manaus", "compound_automatic_code": 1, "compound_name": "A"},
        {"gender": "Piper", "species": "aduncum", "smiles": CAFEINA[1], "doi": "10.1/semi", "isolation_type": "Semisynthesis",
         "state": "AM", "city": "Manaus", "compound_automatic_code": 1, "compound_name": "A"},
        {"gender": "Piper", "species": "aduncum", "smiles": TEOBROMINA[1], "doi": "10.1/semi", "isolation_type": "Semisynthesis",
         "state": "SP", "city": "Araraquara", "compound_automatic_code": 2, "compound_name": "B"},
    ]
    indice, _ = nubbe.carregar_indice(SimpleNamespace(get=lambda *a, **k: SimpleNamespace(dados=linhas, consulta_id=5)))
    assert "Manaus" not in repr(indice) and "Araraquara" not in repr(indice)
    decisao = taxonomia.Decisao("nubbe", "Piper aduncum", "", "aceito", "nome_estrito", taxon_id=9)
    comps = {c["inchikey"]: c for c in nubbe.compostos_por_taxon(indice, {("Piper aduncum", ""): decisao})[9]}
    isolado, derivado = comps[CAFEINA[0]], comps[TEOBROMINA[0]]
    assert not isolado["nao_constituinte"] and list(isolado["referencias"]) == ["10.1/isol"]      # a citação da semissíntese sai
    assert derivado["nao_constituinte"] and derivado["tipos_nao_constituinte"] == ["semissíntese"]
    assert (isolado["uf_coleta"], derivado["uf_coleta"]) == ("AM", "SP")


def test_ena_nao_deduz_pais_pelas_letras_e_testemunho_nao_carrega_localidade():
    assert ena.interpretar_pais_uf_ena("Costa Rica") == ("CR", None)              # antes: 'CO' (Colômbia, país amazônico)
    assert ena.interpretar_pais_uf_ena("China: Yunnan") == ("CN", None)            # antes: 'CH'
    assert ena.interpretar_pais_uf_ena("Wakanda") == (None, None)
    assert ena.interpretar_pais_uf_ena("Brazil: Para, Santarem") == ("BR", "PA")
    assert ena.voucher_sem_localidade("MZUSP 12345") == "MZUSP 12345"
    assert ena.voucher_sem_localidade("Brazil: Amazonas, Manaus, km 30") is None


# ═══════════════════════════ bioatividade ═══════════════════════════
def _medida(i, valor, p, doc, **extra):
    return {"activity_id": i, "standard_relation": "=", "standard_type": "IC50", "target_chembl_id": "CHEMBL1", "target_pref_name": "Alvo",
            "standard_units": "nM", "standard_value": valor, "pchembl_value": p, "document_chembl_id": doc, "assay_type": "B", **extra}


def test_agregado_usa_mediana_e_nao_o_valor_mais_potente():
    ag = bioatividade.agregar_par([_medida(1, 100, 7.0, "D1"), _medida(2, 200, 6.7, "D2"), _medida(3, 400, 6.4, "D3"),
                                   _medida(4, 0.01, 11.0, "D4")])
    assert ag["agregacao"] == "mediana" and ag["n"] == 3 and ag["n_documentos"] == 3 and ag["regra"] is None
    assert ag["valor_nm"] == pytest.approx(200, rel=0.02) and (ag["min_nm"], ag["max_nm"]) == (100.0, 400.0)
    assert [m for _, m in ag["excluidas"]] == ["discrepante_da_mediana"]


def test_agregado_bloqueia_extremo_isolado_discordancia_e_medidas_que_nao_sao_potencia():
    assert bioatividade.agregar_par([_medida(1, 0.01, 11.0, "D1")])["regra"] == "BIO-EXTREMO-NAO-REPLICADO"
    assert bioatividade.agregar_par([_medida(1, 0.01, 11.0, "D1"), _medida(2, 10000, 5.0, "D2")])["regra"] == "BIO-DISCORDANTE"
    for extra, motivo in (({"activity_comment": "Not Active"}, "inativa_ou_inconclusiva"),
                          ({"assay_description": "Ratio of IC50 for COX1 to COX2"}, "ensaio_de_razao"),
                          ({"assay_variant_mutation": "T790M"}, "alvo_mutante"),
                          ({"data_validity_comment": "Outside typical range"}, "comentario_de_validade"),
                          ({"potential_duplicate": 1}, "duplicata_potencial"), ({"standard_relation": ">"}, "relacao_nao_exata"),
                          ({"target_pref_name": "Unchecked"}, "alvo_nao_atribuido")):
        assert bioatividade.motivo_de_exclusao(_medida(1, 50, 7.3, "D1", **extra)) == motivo
    sem = bioatividade.agregar_par([_medida(1, 50, 7.3, "D1", activity_comment="inconclusive")])
    assert sem["regra"] == "BIO-SEM-MEDIDA-VALIDA" and sem["n"] == 0


def test_selecao_prefere_alvo_molecular_e_publicacoes_a_potencia():
    forte_celula = bioatividade.agregar_par([_medida(1, 1, 9.0, "D1")])
    fraco_proteina = bioatividade.agregar_par([_medida(2, 5000, 5.3, "D2"), _medida(3, 6000, 5.2, "D3")])
    ordem = sorted([("celula", forte_celula, "linhagem_celular"), ("proteina", fraco_proteina, "proteina_unica")],
                   key=lambda x: bioatividade.ordem_de_selecao((x[0], "IC50"), x[1], x[2]))
    assert [x[0] for x in ordem] == ["proteina", "celula"]
    assert chembl.natureza_do_alvo("SINGLE PROTEIN") == "proteina_unica"
    assert chembl.natureza_do_alvo("CELL-LINE") == "linhagem_celular" and chembl.natureza_do_alvo("ORGANISM") == "organismo"
    assert chembl.natureza_do_alvo(None) == "indeterminado"


def test_fase4_nao_classifica_antibiotico_como_metabolito_nem_etanol_como_farmaco_secundario():
    assert quimica.classificar_fase4("AVKUERGKIZMTKX-NJBDSQKTSA-N", "Amino acids and Peptides › Penicillins") == "farmaco_secundario"
    assert quimica.classificar_fase4("LFQSCWFLJHTTHZ-UHFFFAOYSA-N", "Fatty acids › Fatty alcohols") == "metabolito_ou_insumo"   # etanol
    assert quimica.classificar_fase4("PEDCQBHIVMGVHV-UHFFFAOYSA-N") == "metabolito_ou_insumo"                                    # glicerol
    assert quimica.classificar_fase4("QCHFTSOMWOSFHM-WPRPVWTQSA-N", "Alkaloids › Imidazole alkaloids") == "farmaco_secundario"   # pilocarpina


def test_duas_massas_e_estereocentros():
    d = quimica.descritores_de_identidade("C[C@H](N)C(=O)O")
    assert d["massa_monoisotopica"] == pytest.approx(89.0477, abs=1e-3) and d["massa_media"] == pytest.approx(89.094, abs=1e-2)
    assert (d["estereocentros"], d["estereocentros_indefinidos"]) == (1, 0)
    assert quimica.descritores_de_identidade("CC(N)C(=O)O")["estereocentros_indefinidos"] == 1
    assert quimica.descritores_de_identidade(None) is None


# ═══════════════════════════ procedência ═══════════════════════════
def _af(**k):
    base = {"tipo": "composto_em_organismo", "uf_coleta_declarada": None, "pais_coleta_declarado": None}
    return {**base, **k}


def test_distribuicao_da_especie_nunca_vira_procedencia_da_afirmacao():
    endemica = {"origem_estabelecimento": "nativa", "endemismo_br": "endemica", "predominio_al": "predominante", "no_recorte": 1,
                "biomas_json": json.dumps(["Amazônia"])}
    assert procedencia.classificar_distribuicao_taxon(endemica) == "endemica_do_brasil_restrita_ao_dominio_amazonia"
    # espécie endêmica da Amazônia, base sem local de coleta: a afirmação NÃO ganha procedência amazônica
    assert procedencia.classificar_declaracao(_af()) == "nao_declarada"
    assert procedencia.classificar_declaracao(_af(uf_coleta_declarada="AM", pais_coleta_declarado="BR")) == "base_declara_amazonia_legal"
    assert procedencia.classificar_declaracao(_af(uf_coleta_declarada="SP")) == "base_declara_brasil_fora_da_amazonia_legal"
    assert procedencia.classificar_declaracao(_af(pais_coleta_declarado="GF")) == "base_declara_pais_pan_amazonico"   # país não é Amazônia
    assert procedencia.classificar_declaracao(_af(pais_coleta_declarado="CN")) == "base_declara_exterior"
    assert procedencia.classificar_declaracao(_af(tipo="atividade_biologica")) is None
    curador = {"decisao": "confirmada", "escopo_geografico_lido": "amazonia_br"}
    assert procedencia.classificar_declaracao(_af(uf_coleta_declarada="SP"), curador) == "curador_artigo_amazonia"
    assert procedencia.PROCEDENCIA_PRIMARIA_VERIFICADA == ("curador_artigo_amazonia",)
    assert "base_declara_amazonia_legal" not in procedencia.PROCEDENCIA_PRIMARIA_VERIFICADA
    pantropical = {**endemica, "endemismo_br": None, "biomas_json": None}
    assert procedencia.classificar_distribuicao_taxon(pantropical) == "registros_brasileiros_concentrados_na_amazonia_legal"
    assert procedencia.classificar_distribuicao_taxon({**pantropical, "origem_estabelecimento": "cultivada"}) == "introduzida_ou_naturalizada"
    for rotulo in procedencia.ROTULOS_DISTRIBUICAO.values():
        assert "procedência" not in rotulo.lower() and "coleta" not in rotulo.lower()


def test_coleta_fora_da_amazonia_declarada_no_artigo_retem_a_afirmacao(mini):
    con = mini.con
    con.execute("UPDATE afirmacao SET procedencia_artigo='exterior', procedencia_artigo_local='CN' WHERE id=?", (mini.af_composto,))
    res = procedencia.recalcular_procedencia_banco(con)
    quarentena.aplicar_estados(con)
    a = con.execute("SELECT estado, regra_quarentena, motivo_quarentena, nivel_procedencia, procedencia_declarada FROM afirmacao WHERE id=?",
                    (mini.af_composto,)).fetchone()
    assert (a["estado"], a["regra_quarentena"], a["nivel_procedencia"]) == ("quarentena", "PROV-FORA-DA-AMAZONIA", None)
    assert res["coleta_fora_da_amazonia_em_fonte_primaria"] == 1
    assert con.execute("SELECT distribuicao_br, escopo_biogeografico FROM taxon WHERE id=?", (mini.taxon,)).fetchone()[1] is None
    # coleta em país amazônico sem UF não retém nem confirma nada
    con.execute("UPDATE afirmacao SET procedencia_artigo='pais_pan_amazonico', procedencia_artigo_local='PE' WHERE id=?", (mini.af_composto,))
    procedencia.recalcular_procedencia_banco(con)
    quarentena.aplicar_estados(con)
    assert con.execute("SELECT estado FROM afirmacao WHERE id=?", (mini.af_composto,)).fetchone()[0] == "candidato"


def test_localidade_mais_fina_que_uf_nao_entra_no_banco(mini):
    con = mini.con
    aid = construir.upsert_afirmacao(con, tipo="composto_em_organismo", molecula_id=mini.molecula, taxon_id=mini.taxon, origem="nubbe:X:AM",
                                     fonte_id="nubbe", consulta_id=mini.consulta_lotus, texto_="t", uf_coleta_declarada="AM",
                                     pais_coleta_declarado="BR", localidade_declarada="Reserva Ducke, Manaus")
    assert con.execute("SELECT localidade_declarada FROM afirmacao WHERE id=?", (aid,)).fetchone()[0] is None
    con.execute("UPDATE afirmacao SET localidade_declarada='Manaus' WHERE id=?", (aid,))
    assert "C.localidade_mais_fina_que_uf" in {e["id"] for e in validar.validar(con)["erros"]}
    assert literatura.locais_de_coleta("Leaves were collected at Reserva Ducke, Manaus, Amazonas, Brazil (2°57'S)") == {"BR-AM"}
    assert literatura.locais_de_coleta("Plants were collected in Amazonas, Peru") == {"PE"}       # departamento, não a UF brasileira
    assert literatura.classe_dos_locais({"BR-AM", "CN"}) == (None, None)                          # locais divergentes: nada se conclui


# ═══════════════════════════ conferência na literatura ═══════════════════════════
def _obra(i, titulo=None, resumo=None, corpo=None, aberto=False):
    return {"ref_id": i, "titulo": titulo, "resumo": resumo, "corpo": corpo, "aberto": aberto}


def test_leitura_classifica_trecho_citacao_outra_especie_e_ausencia():
    v = literatura.variantes_do_composto(["Dillapiole"])
    trecho = literatura.avaliar_afirmacao(["Piper aduncum"], "Piper", v, [_obra(1, "Oil of Piper aduncum", "Dillapiole was isolated from the leaves of P. aduncum.")])
    assert (trecho["conferencia"], trecho["nivel"], trecho["trecho_ref"]) == ("trecho_localizado", "artigo_trecho", 1)
    citado = literatura.avaliar_afirmacao(["Piper aduncum"], "Piper", v, [_obra(1, "Chemistry of Piper aduncum", "Twenty compounds are described.")])
    assert (citado["conferencia"], citado["nivel"]) == ("organismo_citado", "artigo_cita_organismo")
    outra = literatura.avaliar_afirmacao(["Piper aduncum"], "Piper", v, [_obra(1, "Amides from Piper nigrum fruits")])
    assert (outra["conferencia"], outra["outra_especie"], outra["nivel"]) == ("outra_especie_citada", "Piper nigrum", "base_curada")
    sem = literatura.avaliar_afirmacao(["Piper aduncum"], "Piper", v, [_obra(1, "A survey", "We report compounds from a shrub.")])
    assert sem["conferencia"] == "texto_sem_mencao"
    # obra que não pôde ser lida não condena nada: fica no nível da base, sem retenção
    assert literatura.avaliar_afirmacao(["Piper aduncum"], "Piper", v, [_obra(1)])["conferencia"] == "sem_texto"
    assert literatura.avaliar_afirmacao(["Piper aduncum"], "Piper", v, [_obra(1, "A survey")])["conferencia"] == "so_titulo_sem_organismo"
    misto = literatura.avaliar_afirmacao(["Piper aduncum"], "Piper", v, [_obra(1, "A survey", "We report compounds."), _obra(2)])
    assert misto["conferencia"] == "sem_texto"
    genero = literatura.avaliar_afirmacao(["Piper aduncum"], "Piper", v, [_obra(1, "Notes", "Several Piper species contain dillapiole.")])
    assert genero["conferencia"] == "so_composto_ou_genero_citado"
    # «iso-oenothein C» não é «oenothein C»
    assert literatura.achar_composto("iso-oenothein c was found", ["oenothein c"]) == (None, -1)
    assert literatura.achar_composto("(+)-catechin was found", ["catechin"])[0] == "catechin"


def test_etapa_de_evidencias_grava_nivel_guarda_trecho_so_de_obra_aberta_e_nao_pune_falha_de_rede(mini, monkeypatch):
    con = mini.con
    con.execute("UPDATE molecula SET nome='Caffeine' WHERE id=?", (mini.molecula,))
    con.execute("UPDATE taxon SET genero='Carapa' WHERE id=?", (mini.taxon,))
    resumo = "Caffeine was isolated from the seeds of Carapa guianensis."

    def rota_epmc(aberto):
        return lambda url, params: {"resultList": {"result": [
            {"doi": "10.1000/abc", "pmid": "1", "pmcid": None, "title": "Seeds of Carapa guianensis", "abstractText": resumo,
             "isOpenAccess": "Y" if aberto else "N"}]}}

    res = literatura.conferir(con, ClienteFalso(mini.consulta_lotus, [("europepmc", rota_epmc(False))]), lambda *_: None)
    a = con.execute("SELECT nivel_evidencia, conferencia_literatura, passagem, passagem_origem, passagem_sha256, estado FROM afirmacao WHERE id=?",
                    (mini.af_composto,)).fetchone()
    assert (a["nivel_evidencia"], a["conferencia_literatura"], a["passagem_origem"], a["estado"]) == (
        "artigo_trecho", "trecho_localizado", "resumo", "candidato")
    assert a["passagem"] is None and len(a["passagem_sha256"]) == 64          # obra fechada: fica o hash, não a frase
    assert res["conferencia"] == {"trecho_localizado": 1}
    literatura.conferir(con, ClienteFalso(mini.consulta_lotus, [("europepmc", rota_epmc(True))]), lambda *_: None)
    assert con.execute("SELECT passagem FROM afirmacao WHERE id=?", (mini.af_composto,)).fetchone()[0] == resumo
    assert con.execute("SELECT texto_nivel, texto_fonte FROM referencia WHERE id=?", (mini.ref,)).fetchone()[:] == ("resumo", "europepmc")
    # serviço fora do ar: a afirmação não é reavaliada; nada é retido nem rebaixado
    res = literatura.conferir(con, ClienteFalso(mini.consulta_lotus, []), lambda *_: None)
    quarentena.aplicar_estados(con)
    a = con.execute("SELECT nivel_evidencia, conferencia_literatura, estado, passagem FROM afirmacao WHERE id=?", (mini.af_composto,)).fetchone()
    assert tuple(a) == ("artigo_trecho", "trecho_localizado", "candidato", resumo)
    assert res["conferencia"] == {"nao_conferida_nesta_execucao": 1}
    # o serviço responde e a obra não consta nele: aí sim, só o título registrado é o que se leu
    vazio = ClienteFalso(mini.consulta_lotus, [("europepmc", lambda *_: {"resultList": {"result": []}})])
    literatura.conferir(con, vazio, lambda *_: None)
    quarentena.aplicar_estados(con)
    a = con.execute("SELECT nivel_evidencia, conferencia_literatura, estado FROM afirmacao WHERE id=?", (mini.af_composto,)).fetchone()
    assert tuple(a) == ("base_curada", "so_titulo_sem_organismo", "candidato")
    assert con.execute("SELECT nivel_evidencia, conferencia_literatura FROM afirmacao WHERE id=?", (mini.af_atividade,)).fetchone()[:] == (
        "base_curada", "nao_se_aplica")


# ═══════════════════════════ referências ═══════════════════════════
def _cliente_bibliografia(cid, pubmed=None, crossref=None, handles=None):
    pubmed, crossref, handles = pubmed or {}, crossref or {}, handles or {}

    def rota_pubmed(url, params):
        ids = params["id"].split(",")
        return {"result": {"uids": [i for i in ids if i in pubmed], **{i: pubmed[i] for i in ids if i in pubmed}}}

    def rota_crossref(url, params):
        if "filter" in params:
            dois = [x[4:] for x in params["filter"].split(",")]
            return {"message": {"items": [{"DOI": d, **crossref[d]} for d in dois if d in crossref]}}
        d = url.split("/works/")[1]
        return {"message": {"DOI": d, **crossref[d]}} if d in crossref else None

    return ClienteFalso(cid, [("esummary", rota_pubmed), ("api.crossref.org", rota_crossref),
                              ("doi.org/api/handles", lambda url, _: {"responseCode": handles.get(url.split("/handles/")[1], 1)}),
                              ("api.datacite.org", lambda *_: None), ("europepmc", lambda *_: {"resultList": {"result": []}})])


def test_doi_e_pmid_de_obras_diferentes_retem_a_referencia_e_a_afirmacao(mini):
    con = mini.con
    con.execute("UPDATE referencia SET pmid='191619', doi='10.1126/science.191619' WHERE id=?", (mini.ref,))
    cli = _cliente_bibliografia(mini.consulta_lotus,
                                pubmed={"191619": {"title": "Glyceraldehyde-3-phosphate dehydrogenase in the crystal", "articleids": [
                                    {"idtype": "doi", "value": "10.1016/0022-2836(77)90181-x"}], "pubtype": []}},
                                handles={"10.1126/science.191619": 100})
    res = bibliografia.conferir(con, cli, lambda *_: None)
    quarentena.aplicar_estados(con)
    r = con.execute("SELECT estado, regra_quarentena, doi_pmid_coerente, motivo_quarentena FROM referencia WHERE id=?", (mini.ref,)).fetchone()
    assert (r["estado"], r["regra_quarentena"], r["doi_pmid_coerente"]) == ("quarentena", "REF-DOI-PMID-DIVERGENTES", 0)
    assert "não registrado" in r["motivo_quarentena"] and res["doi_pmid_divergentes"] == 1
    a = con.execute("SELECT estado, regra_quarentena FROM afirmacao WHERE id=?", (mini.af_composto,)).fetchone()
    assert tuple(a) == ("quarentena", "REF-EM-QUARENTENA")
    assert con.execute("SELECT COUNT(*) FROM referencia").fetchone()[0] == 1          # nada apagado


def test_duplicata_suplemento_doi_inexistente_e_falha_de_rede(mini):
    con = mini.con
    crossref = {"10.1000/abc": {"title": ["Artigo de teste"], "type": "journal-article"},
                "10.1021/np0001": {"title": ["Artigo com suplemento"], "type": "journal-article"}}
    con.execute("INSERT INTO referencia (pmid, resolvida) VALUES ('777', 1)")                      # mesma obra, linha só com PMID
    dup = con.execute("SELECT id FROM referencia WHERE pmid='777'").fetchone()[0]
    con.execute("INSERT INTO referencia (doi, resolvida, consulta_id) VALUES ('10.1021/np0001.s001', 1, ?)", (mini.consulta_lotus,))
    sup = con.execute("SELECT id FROM referencia WHERE doi='10.1021/np0001.s001'").fetchone()[0]
    con.execute("INSERT INTO referencia (doi, resolvida, consulta_id) VALUES ('10.1016/nao-existe', 0, ?)", (mini.consulta_lotus,))
    morto = con.execute("SELECT id FROM referencia WHERE doi='10.1016/nao-existe'").fetchone()[0]
    for rid in (dup, sup):
        con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (mini.af_atividade, rid))
    cli = _cliente_bibliografia(mini.consulta_lotus, crossref=crossref, handles={"10.1016/nao-existe": 100},
                                pubmed={"777": {"title": "Artigo de teste", "articleids": [{"idtype": "doi", "value": "10.1000/ABC"}], "pubtype": []}})
    res = bibliografia.conferir(con, cli, lambda *_: None)
    assert (res["duplicatas"], res["suplementos"], res["doi_inexistente"]) == (1, 1, 1)
    assert con.execute("SELECT duplicata_de FROM referencia WHERE id=?", (dup,)).fetchone()[0] == mini.ref
    pai = con.execute("SELECT id, tipo_obra FROM referencia WHERE doi='10.1021/np0001'").fetchone()
    assert con.execute("SELECT duplicata_de, tipo_obra FROM referencia WHERE id=?", (sup,)).fetchone()[:] == (pai["id"], "component")
    vinculos = {r[0] for r in con.execute("SELECT referencia_id FROM afirmacao_referencia WHERE afirmacao_id=?", (mini.af_atividade,))}
    assert vinculos == {mini.ref, pai["id"]}
    assert con.execute("SELECT estado, regra_quarentena FROM referencia WHERE id=?", (morto,)).fetchone()[:] == ("quarentena", "REF-DOI-INEXISTENTE")
    assert validar.validar(con)["erros"] == [] or "R.vinculo_em_duplicata" not in {e["id"] for e in validar.validar(con)["erros"]}
    # falha de rede: nenhuma referência nova é retida
    antes = con.execute("SELECT COUNT(*) FROM referencia WHERE estado='quarentena'").fetchone()[0]
    bibliografia.conferir(con, ClienteFalso(mini.consulta_lotus, []), lambda *_: None)
    assert con.execute("SELECT COUNT(*) FROM referencia WHERE estado='quarentena'").fetchone()[0] == antes


# ═══════════════════════════ linhagens ═══════════════════════════
IDENTIFICADORES_ERRADOS = ("10.1126/science.191619", "191619", "10.1021/jm00049a014", "1433219", "10.1016/s0002-9149(97)00570-5",
                           "9296465", "10.1016/s0022-2275(20)41375-6", "1431580", "10.1038/nrd1061", "12612648", "10.1038/nrd849",
                           "12120259", "10.1017/s003118200005933x", "1866186", "9580373", "10.1038/nrd1468", "15286730",
                           "10.1254/jjp.75.99", "9378717", "10.1161/circulationaha.106.675876", "17576874", "P0C7P7", "P85049")


def test_semente_de_linhagens_esta_integra_e_sem_os_identificadores_errados():
    bruto = (config.SEMENTE_DIR / "linhagens.toml").read_text(encoding="utf-8")
    for errado in IDENTIFICADORES_ERRADOS:
        assert not re.search(rf'"{re.escape(errado)}"', bruto), errado
    entradas = tomllib.loads(bruto)["linhagem"]
    assert len({e["chave"] for e in entradas}) == len(entradas)
    for e in entradas:
        assert e["decisao"] in ("confirmada", "contradita") and (e.get("origem_inchikey") or e.get("origem_uniprot"))
        if e["decisao"] == "confirmada":
            assert e["pmid"] and e["trecho"] and e["termos_origem"] and e["termos_destino"]
            contexto = (e["trecho"] + " " + e.get("contexto_do_trecho", "")).lower()
            assert any(t.lower() in contexto for t in e["termos_origem"]) and any(t.lower() in contexto for t in e["termos_destino"])
            assert not validar.PALAVRAS_EFICACIA.search(e["texto"])
        else:
            assert e["historia_corrigida"] and e["evidencia"]
    por_chave = {e["chave"]: e for e in entradas}
    assert por_chave["acetilcolina-cevimelina"]["decisao"] == "confirmada" and por_chave["pilocarpina-cevimelina"]["decisao"] == "contradita"
    assert "barbourina" in por_chave["batroxostatina-eptifibatida"]["historia_corrigida"]
    assert por_chave["bpp12a-captopril"]["decisao"] == "contradita"


def _cliente_linhagem(cid, resumo, doi_pubmed="10.1016/s0306-3623(96)00314-x"):
    return ClienteFalso(cid, [
        ("esummary", lambda url, params: {"result": {"uids": [params["id"]], params["id"]: {
            "title": "Pharmacological aspects of pentoxifylline", "source": "Gen Pharmacol", "pubdate": "1997",
            "articleids": [{"idtype": "doi", "value": doi_pubmed}], "pubtype": []}}}),
        ("efetch", lambda *_: f"<PubmedArticle><Abstract><AbstractText>{resumo}</AbstractText></Abstract></PubmedArticle>")])


def test_citacao_de_linhagem_e_relida_e_so_passa_com_trecho_no_texto():
    spec = {"pmid": "9251897", "doi": "10.1016/s0306-3623(96)00314-x", "trecho_fonte": "resumo_pubmed",
            "trecho": "Pentoxifylline (PTX), a derivative of the methylxanthine theobromine, has been used for many years",
            "termos_origem": ["theobromine"], "termos_destino": ["pentoxifylline"]}
    resumo = "Pentoxifylline (PTX), a derivative of the methyl- xanthine theobromine, has been used for many years in vascular disease."
    ok, falha, dados = linhagem_vias.conferir_citacao(_cliente_linhagem(1, resumo), spec)
    assert ok and falha is None and dados["fonte"] == "resumo_pubmed" and len(dados["sha256"]) == 64
    assert linhagem_vias.conferir_citacao(_cliente_linhagem(1, "An unrelated abstract about schistosomes."), spec)[:2] == (
        False, "o trecho registrado não está no texto lido")
    ok, falha, _ = linhagem_vias.conferir_citacao(_cliente_linhagem(1, resumo, doi_pubmed="10.9999/outra-obra"), spec)
    assert not ok and "diferente do DOI citado" in falha
    assert linhagem_vias.conferir_citacao(ClienteFalso(1, []), spec)[0] is False            # sem rede: não se publica
    sem_termo = {**spec, "termos_origem": ["caffeine"]}
    assert linhagem_vias.conferir_citacao(_cliente_linhagem(1, resumo), sem_termo)[1] == "o trecho não nomeia a molécula de origem"


def test_linhagens_confirmada_contradita_e_orfa_no_banco(con, tmp_path, monkeypatch):
    cid = _consulta(con, "chembl", "https://www.ebi.ac.uk/chembl/x", "c")
    origem = _molecula(con, "Theobromine", inchikey=TEOBROMINA[0])
    pilo = _molecula(con, "Pilocarpine", inchikey="QCHFTSOMWOSFHM-WPRPVWTQSA-N")
    destino = _molecula(con, "Pentoxifylline", inchikey="BYPFEZZEUUWMEJ-UHFFFAOYSA-N", max_fase_clinica=4.0, fase_consulta_id=cid)
    cevi = _molecula(con, "Cevimeline", inchikey="WUTYZMFRCNBCHQ-UHFFFAOYSA-N", max_fase_clinica=4.0, fase_consulta_id=cid)
    con.execute("INSERT INTO referencia (doi, pmid, resolvida) VALUES ('10.1254/jjp.75.99', '9378717', 1)")
    velha = con.execute("SELECT id FROM referencia").fetchone()[0]
    con.execute("INSERT INTO relacao_molecula (origem_id, destino_id, tipo, texto, referencia_id, consulta_id) VALUES (?,?, 'inspirou', 'x', ?, ?)",
                (pilo, cevi, velha, cid))
    con.execute("INSERT INTO relacao_molecula (origem_id, destino_id, tipo, texto, referencia_id, consulta_id) VALUES (?,?, 'inspirou', 'sem semente', ?, ?)",
                (origem, cevi, velha, cid))
    semente = tmp_path / "linhagens.toml"
    semente.write_text('''
[[linhagem]]
chave = "teobromina-pentoxifilina"
origem_inchikey = "YAPQBXQYLJRXSA-UHFFFAOYSA-N"
destino_chembl_nome = "PENTOXIFYLLINE"
tipo = "derivado_de"
decisao = "confirmada"
texto = "A pentoxifilina é derivado sintético da teobromina."
pmid = "9251897"
doi = "10.1016/s0306-3623(96)00314-x"
trecho_fonte = "resumo_pubmed"
trecho = "Pentoxifylline (PTX), a derivative of the methylxanthine theobromine"
termos_origem = ["theobromine"]
termos_destino = ["pentoxifylline"]

[[linhagem]]
chave = "pilocarpina-cevimelina"
origem_inchikey = "QCHFTSOMWOSFHM-WPRPVWTQSA-N"
destino_chembl_nome = "CEVIMELINE"
tipo = "inspirou"
decisao = "contradita"
historia_corrigida = "a cevimelina foi desenhada como análogo rígido da acetilcolina"
[[linhagem.evidencia]]
pmid = "9869272"
trecho = "a rigid analogue of acetylcholine"
''', encoding="utf-8")
    cli = _cliente_linhagem(cid, "Pentoxifylline (PTX), a derivative of the methylxanthine theobromine, has been used for many years.")
    n = linhagem_vias.registrar_linhagens_farmacologicas(con, cli, construir.upsert_referencia, lambda *_: None, caminho=semente)
    assert n == 1
    rel = {r["chave"] or r["texto"]: r for r in con.execute("SELECT * FROM relacao_molecula")}
    ok = rel["teobromina-pentoxifilina"]
    assert ok["estado"] == "candidato" and ok["trecho_fonte"] == "resumo_pubmed" and ok["regra_quarentena"] is None
    ref = con.execute("SELECT doi, pmid FROM referencia WHERE id=?", (ok["referencia_id"],)).fetchone()
    assert tuple(ref) == ("10.1016/s0306-3623(96)00314-x", "9251897")
    contradita = rel["pilocarpina-cevimelina"]
    assert (contradita["estado"], contradita["regra_quarentena"]) == ("rejeitado", "LIN-CONTRADITA")
    assert "acetilcolina" in contradita["motivo_quarentena"]
    assert contradita["texto"].startswith("Relação não sustentada") and contradita["texto"] != "x"      # a história errada sai do enunciado
    assert con.execute("SELECT COUNT(*) FROM evento_proveniencia WHERE entidade='relacao_molecula' AND detalhe LIKE '%Enunciado anterior: x%'").fetchone()[0] == 1
    orfa = rel["sem semente"]
    assert (orfa["estado"], orfa["regra_quarentena"]) == ("quarentena", "LIN-NAO-CONFIRMADA")
    assert con.execute("SELECT COUNT(*) FROM relacao_molecula").fetchone()[0] == 3                  # nada apagado
    erros = {e["id"] for e in validar.validar(con)["erros"]}
    assert not erros & {"L.linhagem_publica_sem_trecho", "L.linhagem_retida_sem_motivo", "L.linhagem_publica_com_referencia_retida"}


# ═══════════════════════════ validador ═══════════════════════════
def test_validador_acusa_cada_regressao_do_modelo(mini):
    con = mini.con
    prontidao.recalcular_todas(con)
    assert validar.validar(con)["erros"] == []

    def erros_apos(sql, *params):
        con.execute("SAVEPOINT caso")
        con.execute(sql, params)
        ids = {e["id"] for e in validar.validar(con)["erros"]}
        con.execute("ROLLBACK TO caso")
        return ids

    assert "T.composto_sem_organismo_da_fonte" in erros_apos("UPDATE afirmacao SET organismo_na_fonte=NULL WHERE id=?", mini.af_composto)
    assert "T.composto_de_organismo_nao_resolvido_para_o_taxon" in erros_apos(
        "UPDATE afirmacao SET organismo_na_fonte='Oryza sativa' WHERE id=?", mini.af_composto)
    assert "P2.coluna_de_procedencia_antiga" in erros_apos("UPDATE afirmacao SET nivel_procedencia='T3a_endemica_amazonia_br' WHERE id=?", mini.af_composto)
    assert "P2.procedencia_de_curador_sem_verificacao" in erros_apos(
        "UPDATE afirmacao SET procedencia_declarada='curador_artigo_amazonia' WHERE id=?", mini.af_composto)
    assert "V.evidencia_de_curador_sem_verificacao" in erros_apos("UPDATE afirmacao SET nivel_evidencia='curador' WHERE id=?", mini.af_composto)
    assert "B.atividade_publica_sem_agregacao" in erros_apos("UPDATE afirmacao SET origem='chembl:atividade:1' WHERE id=?", mini.af_atividade)
    assert "B.agregado_diverge_das_medidas" in erros_apos("UPDATE afirmacao SET medida_n=5 WHERE id=?", mini.af_atividade)
    assert "N.nao_constituinte_publico" in erros_apos("UPDATE molecula SET restricao_ocorrencia='elemento_quimico' WHERE id=?", mini.molecula)
    assert "Q.publica_com_regra_ativa" in erros_apos(
        "INSERT INTO afirmacao_regra (afirmacao_id, codigo, detectada_em) VALUES (?, 'NAT-ELEMENTO', ?)", mini.af_composto, AGORA)
    assert "G.soma_por_uf" in erros_apos("UPDATE ocorrencia_uf SET n=61 WHERE taxon_id=? AND uf_sigla='AM'", mini.taxon)
    assert "G.soma_amazonia_legal" in erros_apos("UPDATE taxon SET n_al=59 WHERE id=?", mini.taxon)
    assert "M.conectividade_incoerente" in erros_apos("UPDATE molecula SET inchikey_conectividade='XXXXXXXXXXXXXX' WHERE id=?", mini.molecula)
    assert "R.doi_e_pmid_divergentes_ativa" in erros_apos("UPDATE referencia SET doi_pmid_coerente=0 WHERE id=?", mini.ref)


def test_fotografia_repetida_entre_taxons_e_retida(mini):
    con = mini.con
    outro = _taxon(con, gbif=555, nome="Bertholletia excelsa", consulta_id=mini.consulta_gbif)
    for tid, url in ((mini.taxon, "https://x/1.jpg"), (outro, "https://x/2.jpg")):
        con.execute("INSERT INTO midia (taxon_id, url, pagina, licenca, autor, arquivo, arquivo_sha256, largura, altura, consulta_id) "
                    "VALUES (?,?, 'https://x/p', 'CC BY', 'Autora', 'imagens/1.jpg', ?, 400, 300, ?)", (tid, url, "f" * 64, mini.consulta_gbif))
    assert "F.imagem_repetida_entre_taxons" in {e["id"] for e in validar.validar(con)["erros"]}
    assert construir.conferir_midia(con) == 2
    assert con.execute("SELECT COUNT(*) FROM midia WHERE estado='quarentena' AND arquivo IS NULL").fetchone()[0] == 2
    assert "F.imagem_repetida_entre_taxons" not in {e["id"] for e in validar.validar(con)["erros"]}


def test_lotus_indexa_pelo_organismo_inteiro_e_so_passa_referencia_do_organismo_aceito(con, tmp_path, monkeypatch):
    cid = _consulta(con, "lotus", "https://zenodo.org/x", "b")
    arq = _dump_lotus(tmp_path, [
        (CAFEINA, "Capsicum annuum var. glabriusculum", "111", "Capsicum annuum", "10.1/a"),
        (CAFEINA, "Capsicum annuum", "222", "Capsicum annuum", "10.1/b"),
        (CAFEINA, "Capsicum baccatum", "333", "Capsicum baccatum", "10.1/c"),
        (TEOBROMINA, "Capsicum sp.", "444", "NA", "10.1/d"),
    ])
    monkeypatch.setattr(catalogo_nacional_dwca, "garantir_arquivo_dump", lambda *a, **k: (arq, cid))
    por_org, _, _ = lotus.indexar_dump_por_organismo(con, generos={"capsicum"}, log=lambda *_: None)
    assert set(por_org) == {("Capsicum annuum var. glabriusculum", "111"), ("Capsicum annuum", "222"), ("Capsicum baccatum", "333")}
    assert por_org[("Capsicum annuum var. glabriusculum", "111")]["especie_lotus"] == "Capsicum annuum"
    aceito = taxonomia.Decisao("lotus", "Capsicum baccatum", "333", "aceito", "identificador_da_fonte", taxon_id=5)
    fora = taxonomia.Decisao("lotus", "Capsicum annuum", "222", "fora_do_escopo", "identificador_da_fonte")
    por_taxon = lotus.compostos_por_taxon(por_org, {("Capsicum baccatum", "333"): aceito, ("Capsicum annuum", "222"): fora})
    assert list(por_taxon) == [5] and list(por_taxon[5][0]["referencias"]) == ["10.1/c"]
    assert por_taxon[5][0]["organismos"] == ["Capsicum baccatum"]
    assert npatlas_coconut.compostos_do_fungo(SimpleNamespace(_indice_npatlas=({}, 1)), ["Ganoderma lucidum var. x"]) == ([], 1)


def test_todo_codigo_de_regra_usado_no_codigo_existe_no_catalogo():
    """Um código digitado errado só apareceria em produção, na primeira referência retratada."""
    padrao = re.compile(r'"((?:TAX|NAT|LIT|REF|BIO|PROV|LIN|MOL|REG|FONTE|LEGADO)-[A-Z0-9]+(?:-[A-Z0-9]+)*)"')
    usados = {}
    for arq in sorted((config.NUCLEO / "bmb").rglob("*.py")):
        for codigo in padrao.findall(arq.read_text(encoding="utf-8")):
            usados.setdefault(codigo, arq.name)
    desconhecidos = {c: a for c, a in usados.items() if c not in quarentena.REGRAS}
    assert not desconhecidos, desconhecidos
    assert len(quarentena.REGRAS) == len(quarentena.PRECEDENCIA)
    for regra in quarentena.REGRAS.values():
        assert regra.escopo in ("afirmacao", "referencia", "relacao_molecula")
        quarentena.motivo(regra.codigo)            # o modelo formata mesmo sem dados


def test_obra_com_dois_dois_e_fundida_so_com_prova_no_registro(mini):
    con = mini.con
    artigo = {"title": ["Novel triterpenoids from the fungus Ganoderma lucidum."], "type": "journal-article", "volume": "52", "page": "367-372",
              "issued": {"date-parts": [[1988]]}, "author": [{"family": "Nishitoba", "given": "T."}], "container-title": ["Agric Biol Chem"]}
    crossref = {
        "10.1000/abc": {"title": ["Two New Cytotoxic Clerodane Diterpenoids from Casearia membranacea"], "type": "journal-article",
                        "volume": "52", "page": "108", "issued": {"date-parts": [[2004]]}},
        "10.1002/chin.200431143": {"title": ["Two New Cytotoxic Clerodane Diterpenoids from Casearia membranacea"], "type": "journal-article",
                                   "container-title": ["ChemInform"], "issued": {"date-parts": [[2004]]}},
        "10.1271/bbb1961.52.367": artigo, "10.1080/00021369.1988.10868655": artigo,
        # mesmo título e ano, outra página: partes de uma série, não duplicata
        "10.1002/ardp.19803130302": {"title": ["Isolierung und Struktur der Inhaltsstoffe von Cecropia adenopus"], "type": "journal-article",
                                     "volume": "313", "page": "200", "issued": {"date-parts": [[1980]]}},
        "10.1002/ardp.19803130303": {"title": ["Isolierung und Struktur der Inhaltsstoffe von Cecropia adenopus"], "type": "journal-article",
                                     "volume": "313", "page": "210", "issued": {"date-parts": [[1980]]}},
    }
    ids = {}
    for doi in crossref:
        if doi != "10.1000/abc":
            con.execute("INSERT INTO referencia (doi, resolvida, consulta_id) VALUES (?, 1, ?)", (doi, mini.consulta_lotus))
        ids[doi] = con.execute("SELECT id FROM referencia WHERE doi=?", (doi,)).fetchone()[0]
    for doi in ("10.1002/chin.200431143", "10.1080/00021369.1988.10868655", "10.1271/bbb1961.52.367"):
        con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (mini.af_atividade, ids[doi]))
    con.execute("INSERT INTO afirmacao_referencia (afirmacao_id, referencia_id) VALUES (?,?)", (mini.af_clinico, ids["10.1271/bbb1961.52.367"]))
    res = bibliografia.conferir(con, _cliente_bibliografia(mini.consulta_lotus, crossref=crossref), lambda *_: None)
    assert res["duplicatas"] == 2 and res["mesmo_titulo_e_ano_mantidas_separadas"] == 1
    dup = {r["doi"]: r["duplicata_de"] for r in con.execute("SELECT doi, duplicata_de FROM referencia")}
    assert dup["10.1002/chin.200431143"] == ids["10.1000/abc"]                               # o resumo aponta para o artigo
    assert dup["10.1080/00021369.1988.10868655"] == ids["10.1271/bbb1961.52.367"]            # fica a linha com mais vínculos
    assert dup["10.1002/ardp.19803130302"] is None and dup["10.1002/ardp.19803130303"] is None
    vinculos = {r[0] for r in con.execute("SELECT referencia_id FROM afirmacao_referencia WHERE afirmacao_id=?", (mini.af_atividade,))}
    assert vinculos == {ids["10.1000/abc"], ids["10.1271/bbb1961.52.367"]}
    assert "R.vinculo_em_duplicata" not in {e["id"] for e in validar.validar(con)["erros"]}


def test_upsert_de_referencia_devolve_a_linha_canonica_de_uma_duplicata(con):
    r_artigo = construir.upsert_referencia(con, doi="10.1248/cpb.52.108")
    r_resumo = construir.upsert_referencia(con, doi="10.1002/chin.200431143")
    con.execute("UPDATE referencia SET duplicata_de=? WHERE id=?", (r_artigo, r_resumo))
    assert construir.upsert_referencia(con, doi="10.1002/CHIN.200431143") == r_artigo
    assert con.execute("SELECT COUNT(*) FROM referencia").fetchone()[0] == 2


def test_medida_de_molecula_sem_organismo_publicado_fica_retida_e_volta_quando_o_registro_volta(mini):
    """Estado é a única fonte do que é público: medida de molécula que ficou sem registro em organismo é retida por regra."""
    con = mini.con
    quarentena.aplicar_estados(con)
    estado = lambda aid: tuple(con.execute("SELECT estado, regra_quarentena FROM afirmacao WHERE id=?", (aid,)).fetchone())
    assert estado(mini.af_atividade) == ("candidato", None) and estado(mini.af_clinico) == ("candidato", None)

    # o único registro da molécula em organismo passa a disparar uma regra: a medida e o efeito clínico saem junto
    quarentena.declarar(con, {"NAT-CONTROLE"}, {mini.af_composto: {"NAT-CONTROLE": {"substancia": "Cafeína", "taxon": "Carapa guianensis"}}})
    quarentena.aplicar_estados(con)
    assert estado(mini.af_composto) == ("quarentena", "NAT-CONTROLE")
    assert estado(mini.af_atividade) == ("quarentena", "MOL-SEM-ORGANISMO")
    assert estado(mini.af_clinico) == ("quarentena", "MOL-SEM-ORGANISMO")
    assert not [e for e in validar.validar(con)["erros"] if e["id"].startswith("Q.")]

    # a regra do composto deixa de valer: os três voltam, sem intervenção
    quarentena.declarar(con, {"NAT-CONTROLE"}, {})
    quarentena.aplicar_estados(con)
    assert estado(mini.af_composto) == ("candidato", None)
    assert estado(mini.af_atividade) == ("candidato", None) and estado(mini.af_clinico) == ("candidato", None)
    assert con.execute("SELECT COUNT(*) FROM afirmacao_regra").fetchone()[0] == 0


def test_reextracao_nao_apaga_a_passagem_lida_por_curador(mini):
    con = mini.con
    lida = "Compound 1 was isolated from the leaves of Carapa guianensis."
    con.execute("UPDATE afirmacao SET passagem=?, passagem_origem='curador', estado='verificado' WHERE id=?", (lida, mini.af_composto))
    a = con.execute("SELECT tipo, molecula_id, taxon_id, origem, fonte_id, consulta_id FROM afirmacao WHERE id=?", (mini.af_composto,)).fetchone()
    aid = construir.upsert_afirmacao(con, tipo=a["tipo"], molecula_id=a["molecula_id"], taxon_id=a["taxon_id"], origem=a["origem"],
                                     fonte_id=a["fonte_id"], consulta_id=a["consulta_id"], texto_="enunciado regerado", passagem=None)
    assert aid == mini.af_composto
    linha = con.execute("SELECT texto, passagem, passagem_origem, estado FROM afirmacao WHERE id=?", (aid,)).fetchone()
    assert tuple(linha) == ("enunciado regerado", lida, "curador", "verificado")
    # passagem que vem da própria fonte (anotação do UniProt, mecanismo do ChEMBL) continua sendo atualizada pela fonte
    aid3 = construir.upsert_afirmacao(con, tipo="efeito_clinico_documentado", molecula_id=mini.molecula, origem="chembl:clinico:CHEMBL113",
                                      fonte_id="chembl", consulta_id=mini.consulta_chembl, texto_="t", passagem="Adenosine receptor antagonist")
    assert aid3 == mini.af_clinico
    assert con.execute("SELECT passagem FROM afirmacao WHERE id=?", (aid3,)).fetchone()[0] == "Adenosine receptor antagonist"


def test_origem_marinha_declarada_no_artigo_retem_o_registro(mini):
    """«deep-sea-derived fungus»: o material não é amazônico. Vale no título e no resumo; no corpo, só junto de cepa ou isolamento."""
    padroes = [literatura.padrao_do_organismo("Penicillium citrinum")]
    assert literatura.origem_marinha("Citrinin derivatives from the deep-sea-derived fungus Penicillium citrinum", padroes)
    assert literatura.origem_marinha("Penicillium citrinum, isolated from marine sediment, produced two new polyketides.", padroes)
    assert literatura.origem_marinha("New alkaloids from the mangrove endophytic fungus Penicillium citrinum", padroes) is None
    assert literatura.origem_marinha("Penicillium citrinum from the leaves of Carapa guianensis collected in Manaus", padroes) is None
    intro = "Penicillium citrinum occurs in soil and has also been reported from marine sponges worldwide."
    assert literatura.origem_marinha(intro, padroes, exigir_isolamento=True) is None
    r = literatura.avaliar_afirmacao(["Penicillium citrinum"], "Penicillium", ["citrinin"], [
        {"ref_id": 7, "titulo": "Citrinin derivatives from the deep-sea-derived fungus Penicillium citrinum", "resumo": None, "corpo": None, "aberto": False}])
    assert r["marinha_ref"] == 7 and r["conferencia"] == "organismo_citado"
    # no banco: classe própria, sem país, e retenção pela regra de coleta fora da Amazônia
    con = mini.con
    con.execute("UPDATE afirmacao SET procedencia_artigo='ambiente_marinho', procedencia_artigo_referencia_id=? WHERE id=?", (mini.ref, mini.af_composto))
    procedencia.recalcular_procedencia_banco(con)
    quarentena.aplicar_estados(con)
    a = con.execute("SELECT estado, regra_quarentena, motivo_quarentena FROM afirmacao WHERE id=?", (mini.af_composto,)).fetchone()
    assert (a["estado"], a["regra_quarentena"]) == ("quarentena", "PROV-FORA-DA-AMAZONIA") and "ambiente marinho" in a["motivo_quarentena"]
    assert not [e for e in validar.validar(con)["erros"] if e["id"].startswith(("P2.", "C."))]

