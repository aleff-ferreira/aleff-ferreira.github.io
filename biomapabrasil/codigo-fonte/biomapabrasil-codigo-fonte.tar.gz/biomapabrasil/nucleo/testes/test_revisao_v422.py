# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Regressões de revisão científica, higiene química/bibliográfica e paridade do servidor v4.2.2."""
from __future__ import annotations

import gzip
import hashlib
import json
import sys
import threading
import tomllib
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from unittest import mock

import pytest

from bmb import bibliografia, config, curadoria, db, literatura, procedencia, quarentena, quimica, validar


def test_quimica_nomes_vendor_ncgc_ccris_unii_ponto_e_virgula_e_estereo():
    # Códigos internos NCGC/NPC, CCRIS, Angene, Glaxo, UNII e nomes de arquivos suplementares devem ser recusados
    for invalido in (
        "Npc216413",
        "Npc1838",
        "Ccris 7934",
        "Agn-PC-0jram3",
        "GR-133686",
        "acs.jmedchem.1c00409_ST.657",
        "Aek7QS8V99",
        "NCGC00169714-02_C30H48O5_ursolic",
        "Artocarpin (flavonoid); NSC 241010",
        "Ubiquinone Q9;CoQ9;Ubiquinone 9",
    ):
        assert quimica.nome_quimico_invalido(invalido, permitir_inchikey_canonico=True), invalido

    # Locantes IUPAC legítimos com ';' e notação LIPID MAPS permanecem válidos
    assert not quimica.nome_quimico_invalido("3Beta-acetoxy-1,10-epoxy-4-germacrene-12,8;15,6-diolide")
    assert not quimica.nome_quimico_invalido("ST 29:1;O;Hex;FA 16:0")

    # Recuperação de nomes limpos
    assert quimica.escolher_nome_molecula("lapachol", "Npc216413", "4-hydroxy-3-(3-methylbut-2-enyl)naphthalene-1,2-dione", "CWPGNVFCJOPXFB-UHFFFAOYSA-N") == "lapachol"
    assert quimica.escolher_nome_molecula("guaijaverin", "acs.jmedchem.1c00409_ST.657", None, "PZZRDJXEMZMZFD-UHFFFAOYSA-N") == "guaijaverin"
    assert quimica.escolher_nome_molecula(None, "Artocarpin (flavonoid); NSC 241010", "2-(2,4-dihydroxyphenyl)-...", "AAXZLRPBJQFZQA-UHFFFAOYSA-N") == "Artocarpin"
    assert quimica.escolher_nome_molecula(
        "1,2,3-trimethoxy-5-prop-1-enylbenzene",
        "1,2,3-Trimethoxy-5-(1E)-1-propen-1-ylbenzene; (E)-Isoelemicin; 1,2,3-Trimethoxy-5-[(1E)-1-propenyl]benzene",
        "1,2,3-trimethoxy-5-prop-1-enylbenzene",
        "RRXOQHQFJOQLQR-UHFFFAOYSA-N",
    ) == "(E)-Isoelemicin"

    # Contradição estereoquímica entre título depositado (2R) e estrutura/IUPAC real (2S)
    escolhido = quimica.escolher_nome_molecula(
        "9-[(2S)-2-hydroxy-3-methylbut-3-enoxy]furo[3,2-g]chromen-7-one",
        "9-[[(2R)-2-Hydroxy-3-methyl-3-buten-1-yl]oxy]-7H-furo[3,2-g][1]benzopyran-7-one; (+)-Isogospherol",
        "9-[(2S)-2-hydroxy-3-methylbut-3-enoxy]furo[3,2-g]chromen-7-one",
        "RTUPRHIHXSAWDP-GFCCVEGCSA-N",
    )
    assert "(2S)" in escolhido and "Isogospherol" not in escolhido and "(2R)" not in escolhido


def test_validador_detecta_mojibake_em_referencia_e_bibliografia_prefere_utf8(mini):
    con = mini.con
    con.execute("UPDATE referencia SET revista='Zeitschrift f\ufffdr Lebensmittel', autores='[\"Jos\ufffd Maia\"]' WHERE id=?", (mini.ref,))
    erros = {e["id"]: e for e in validar.validar(con)["erros"]}
    assert "E.nome_com_mojibake" in erros

    assert bibliografia._escolher_texto_limpo("Zeitschrift f\ufffdr Lebensmittel", "Zeitschrift für Lebensmittel") == "Zeitschrift für Lebensmittel"
    assert bibliografia._escolher_texto_limpo("Título íntegro", "Outro título") == "Título íntegro"

    con.execute("UPDATE referencia SET revista='Zeitschrift für Lebensmittel', autores='[\"José Maia\"]' WHERE id=?", (mini.ref,))
    erros_limpos = {e["id"] for e in validar.validar(con)["erros"]}
    assert "E.nome_com_mojibake" not in erros_limpos


def test_literatura_alga_derivada_e_coleta_no_titulo_apenas_obra_unica():
    padroes = [literatura.padrao_do_organismo("Penicillium sclerotiorum")]
    assert literatura.origem_marinha(
        "Anti-Inflammatory Azaphilones from the Edible Alga-Derived Fungus Penicillium sclerotiorum.",
        padroes,
    )

    # Obra única cujo título declara coleta na Papua-Nova Guiné -> procedência 'PG' (exterior)
    r_unica = literatura.avaliar_afirmacao(
        ["Piper aduncum"],
        "Piper",
        ["cadin-4-en-10-ol"],
        [{"ref_id": 10, "titulo": "Volatile Chemical Constituents of Piper aduncum L from Papua New Guinea", "resumo": None, "corpo": None, "aberto": False}],
    )
    assert r_unica["locais"] == {"PG"}
    assert literatura.classe_dos_locais(r_unica["locais"]) == ("exterior", "PG")

    # Afirmação sustentada por múltiplas obras (uma da Papua-Nova Guiné e outra sem país no título) NÃO é quarentenada por título isolado
    r_multipla = literatura.avaliar_afirmacao(
        ["Piper aduncum"],
        "Piper",
        ["dillapiol"],
        [
            {"ref_id": 10, "titulo": "Volatile Chemical Constituents of Piper aduncum L from Papua New Guinea", "resumo": None, "corpo": None, "aberto": False},
            {"ref_id": 11, "titulo": "Essential oil composition of Piper aduncum leaves", "resumo": None, "corpo": None, "aberto": False},
        ],
    )
    assert r_multipla["locais"] == set()


def test_semente_curadoria_integridade_quimica_e_espectroscopica():
    arq = config.SEMENTE_DIR / "verificacoes_curador.toml"
    entradas = tomllib.loads(arq.read_text(encoding="utf-8")).get("verificacao", [])
    assert len(entradas) >= 45

    iks_beltrania = {
        e["molecula_inchikey"]
        for e in entradas
        if e.get("taxon_nome") == "Beltrania rhombica" and e.get("pmid") == "15684527"
    }
    assert "XZXBGGYJQALVAW-KYEXWDHISA-N" in iks_beltrania  # (-)-pterocarpol real do artigo
    assert "XZXBGGYJQALVAW-OSFYFWSMSA-N" not in iks_beltrania  # (+)-pterocarpol oposto

    for ent in entradas:
        passagem = ent["passagem_conferida"]
        if ent.get("qualidade_experimental") == "atende" and ent.get("subtipo_decisao") == "isolamento_primario_confirmado":
            assert "gc-ms library search" not in passagem.lower(), f"Busca em biblioteca GC-MS sem RMN marcada como atende: {ent}"
        if ent.get("acesso_texto") == "texto_completo_aberto":
            assert ent.get("procedencia_material"), ent
            assert curadoria.voucher_de_colecao(ent.get("voucher")) is not None, ent


def test_server_unificado_sdf_ensemble_sem_rdkit_e_http_206_range(mini, tmp_path):
    raiz_aw = config.PLATAFORMA.parent
    if not (raiz_aw / "server.py").is_file():
        pytest.skip("server.py institucional fora deste diretório")
    if str(raiz_aw) not in sys.path:
        sys.path.insert(0, str(raiz_aw))
    import server as srv_aw

    # Monta banco temporário a partir da fixture `mini` com estrutura 3D no formato ensemble-sdf-v1 empacotada em ZIP
    arq_db = tmp_path / "bmb_test.sqlite"
    mini.con.execute("VACUUM INTO ?", (str(arq_db),))
    con = db.conectar(arq_db)
    con.execute("INSERT OR IGNORE INTO fonte (id, nome, url, licenca) VALUES ('rdkit_local','RDKit','https://rdkit.org','BSD-3-Clause')")
    cid = con.execute("SELECT id FROM consulta LIMIT 1").fetchone()[0]
    mid = mini.molecula
    ik_mol, smiles_mol = con.execute("SELECT inchikey, smiles FROM molecula WHERE id=?", (mid,)).fetchone()

    sdf_c1 = "Caffeine_c1\n  RDKit          3D\n\n  1  0  0  0  0  0  0  0  0  0999 V2000\n    0.0000    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\nM  END\n$$$$\n"
    sdf_c2 = "Caffeine_c2\n  RDKit          3D\n\n  1  0  0  0  0  0  0  0  0  0999 V2000\n    1.2500    0.0000    0.0000 C   0  0  0  0  0  0  0  0  0  0  0  0\nM  END\n$$$$\n"
    ens_obj = {
        "fmt": "ensemble-sdf-v1",
        "id": mid,
        "ik": ik_mol,
        "smiles_sha256": hashlib.sha256((smiles_mol or "").encode()).hexdigest(),
        "conformeros": [
            {"id": 1, "energia_kcal_mol": 10.0, "peso_boltzmann": 0.75, "sdf": sdf_c1},
            {"id": 2, "energia_kcal_mol": 10.65, "peso_boltzmann": 0.25, "sdf": sdf_c2},
        ],
    }
    ens_bytes = json.dumps(ens_obj, separators=(",", ":")).encode("utf-8")
    ens_sha = hashlib.sha256(ens_bytes).hexdigest()
    nome_ens = f"ens_{mid}_{ens_sha[:16]}.json"

    app_fake = tmp_path / "app"
    ens_dir = app_fake / "dados" / "estruturas3d_ensembles"
    ens_dir.mkdir(parents=True)
    membro_gz = gzip.compress(ens_bytes)
    shard = f"{mid % 256:02x}.zip"
    zip_path = ens_dir / shard
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_STORED) as zf:
        zf.writestr(f"{nome_ens}.gz", membro_gz)

    con.execute(
        "INSERT INTO estrutura_3d (id, molecula_id, natureza, fonte_id, codigo, metodo, energia_kcal_mol, n_atomos_ou_residuos, arquivo_geometria, geometria_sha256, consulta_id) "
        "VALUES (77, ?, 'conformero_calculado', 'rdkit_local', ?, 'ETKDGv3+MMFF94s', 10.0, 20, ?, ?, ?)",
        (mid, f"ETKDGv3-{mid}", f"dados/estruturas3d/{nome_ens}", ens_sha, cid),
    )
    con.commit()
    con.close()

    from bmb import conformeros
    conformeros._conferir_arquivo.cache_clear()
    with (
        mock.patch.object(srv_aw, "BMB_APP", app_fake),
        mock.patch.object(conformeros, "Chem", None),
        mock.patch.dict(sys.modules, {"rdkit": None, "rdkit.Chem": None}),
    ):
        httpd, _ = srv_aw.criar_servidor_http(host="127.0.0.1", porta=0, caminho_db=arq_db, silencioso=True)
        porta = httpd.server_address[1]
        t = threading.Thread(target=httpd.serve_forever, daemon=True)
        t.start()
        try:
            base = f"http://127.0.0.1:{porta}/biomapabrasil"
            with urllib.request.urlopen(f"{base}/api/moleculas/{mid}/estrutura3d.sdf") as r1:
                assert r1.status == 200
                txt1 = r1.read().decode("utf-8")
                assert "Caffeine_c1" in txt1 and "$$$$" in txt1

            with urllib.request.urlopen(f"{base}/api/estruturas3d/77/sdf?conformero=2") as r2:
                assert r2.status == 200
                txt2 = r2.read().decode("utf-8")
                assert "Caffeine_c2" in txt2

            with pytest.raises(urllib.error.HTTPError) as exc99:
                urllib.request.urlopen(f"{base}/api/estruturas3d/77/sdf?conformero=99")
            assert exc99.value.code == 404

            # Verifica suporte a HTTP 206 Partial Content nos arquivos ZIP de ensembles 3D
            req_rng = urllib.request.Request(f"{base}/dados/estruturas3d_ensembles/{shard}", headers={"Range": "bytes=0-15"})
            with urllib.request.urlopen(req_rng) as r206:
                assert r206.status == 206
                fatia = r206.read()
                assert len(fatia) == 16
                assert fatia == zip_path.read_bytes()[:16]
                assert r206.headers.get("Accept-Ranges") == "bytes"
                assert r206.headers.get("Content-Range") == f"bytes 0-15/{zip_path.stat().st_size}"

            req_416 = urllib.request.Request(f"{base}/dados/estruturas3d_ensembles/{shard}", headers={"Range": "bytes=999999-1000000"})
            with pytest.raises(urllib.error.HTTPError) as exc416:
                urllib.request.urlopen(req_416)
            assert exc416.value.code == 416
        finally:
            httpd.shutdown()
            httpd.server_close()


def test_frontend_contratos_abort_filtros_e_escape_3d():
    app_dir = config.APP_DIR
    main_js = (app_dir / "js" / "main.js").read_text(encoding="utf-8")
    paginas_js = (app_dir / "js" / "viz" / "paginas.js").read_text(encoding="utf-8")
    floresta_js = (app_dir / "js" / "viz" / "raiox_floresta.js").read_text(encoding="utf-8")
    est3d_js = (app_dir / "js" / "viz" / "estrutura3d.js").read_text(encoding="utf-8")
    estilos_obs_js = (app_dir / "js" / "viz" / "estilos_obs.js").read_text(encoding="utf-8")
    sw_js = (app_dir / "sw.js").read_text(encoding="utf-8")

    # AbortController propagado até montarMoleculas e montarFloresta
    assert "montarMoleculas(r, { params, dataDados: estado.manifesto.gerado_em, signal: o.signal })" in main_js
    assert "if (signal?.aborted || !raiz.isConnected) return;" in paginas_js
    assert "if (signal?.aborted || !raiz.isConnected) return;" in floresta_js

    # Normalização de bacia (slug/caixa) e UF em montarEspecies
    assert "rawBacia.startsWith('BAC:') ? rawBacia : `BAC:${rawBacia}`" in paginas_js
    assert "const rawUf = (params.get('uf') || '').trim().toUpperCase();" in paginas_js

    # Contenção horizontal em viewports estreitos (360px) nos observatórios
    assert ".obs-grade { grid-template-columns: minmax(0, 1fr); }" in estilos_obs_js

    # Fechamento por Escape no nível de documento quando o visualizador 3D está ampliado
    assert "document.addEventListener('keydown'" in est3d_js
    assert "raizBloco.classList.remove('lab3d-expandido');" in est3d_js

    # Service worker em nova versão de cache
    assert "const VERSAO = 'bmb-v26';" in sw_js


def test_e2e_playwright_especies_bacia_slug_abort_e_escape_3d():
    pw = pytest.importorskip("playwright.sync_api", reason="Playwright opcional")
    if not (config.APP_DIR / "dados" / "indice.json").is_file():
        pytest.skip("Pacotes estáticos em app/dados ausentes")
    raiz_aw = config.PLATAFORMA.parent
    if not (raiz_aw / "server.py").is_file():
        pytest.skip("server.py institucional ausente")
    if str(raiz_aw) not in sys.path:
        sys.path.insert(0, str(raiz_aw))
    import server as srv_aw

    httpd, _ = srv_aw.criar_servidor_http(host="127.0.0.1", porta=0, silencioso=True)
    porta = httpd.server_address[1]
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    erros_js: list[str] = []
    try:
        with pw.sync_playwright() as p:
            try:
                browser = p.chromium.launch(headless=True)
            except Exception as exc:
                pytest.skip(f"Chromium indisponível: {exc}")
            ctx = browser.new_context(viewport={"width": 1280, "height": 800})
            page = ctx.new_page()
            page.on("pageerror", lambda e: erros_js.append(str(e)))

            base = f"http://127.0.0.1:{porta}/biomapabrasil/"
            # 1) Slug/minúsculas em #/especies?bacia=negro&uf=am&g=p
            page.goto(f"{base}#/especies?bacia=negro&uf=am&g=p", wait_until="networkidle")
            page.wait_for_selector("#fe-tabela tbody tr", timeout=10000)
            assert page.locator("#fe-bacia").input_value() == "BAC:NEGRO"
            assert page.locator("#fe-uf").input_value() == "AM"
            assert page.locator("#fe-g").input_value() == "P"
            assert page.locator("#fe-tabela tbody tr").count() > 0

            # 2) Navegação rápida abortada (#/moleculas -> #/floresta -> #/sobre) sem TypeError nem escrita órfã
            page.evaluate("""() => {
                location.hash = '#/moleculas';
                setTimeout(() => { location.hash = '#/floresta'; }, 5);
                setTimeout(() => { location.hash = '#/sobre'; }, 12);
            }""")
            page.wait_for_timeout(600)
            assert "/sobre" in page.url
            assert page.locator("#vista-pagina h1").inner_text().strip() in ("Sobre o BioMapaBrasil", "About BioMapaBrasil")

            # 3) Tecla Escape fecha o modo ampliado do visualizador 3D mesmo com foco no botão Ampliar
            page.goto(f"{base}#/molecula/349", wait_until="networkidle")
            btn_exp = page.locator('[data-3d="expandir"]')
            btn_exp.wait_for(state="visible", timeout=10000)
            btn_exp.click()
            assert page.locator(".lab3d-expandido").count() == 1
            page.keyboard.press("Escape")
            assert page.locator(".lab3d-expandido").count() == 0
            assert btn_exp.get_attribute("aria-pressed") == "false"

            # 4) Viewport 360x640 em inglês sem transbordamento horizontal em #/filoquimica
            ctx_mob = browser.new_context(viewport={"width": 360, "height": 640})
            pg_mob = ctx_mob.new_page()
            pg_mob.goto(f"{base}?lang=en#/filoquimica", wait_until="networkidle")
            pg_mob.wait_for_selector("#fq-svg", timeout=10000)
            ov = pg_mob.evaluate("() => document.documentElement.scrollWidth - window.innerWidth")
            assert ov <= 1, f"Transbordamento horizontal inesperado a 360px: {ov}px"
            ctx_mob.close()

            assert erros_js == []
            browser.close()
    finally:
        httpd.shutdown()
        httpd.server_close()
