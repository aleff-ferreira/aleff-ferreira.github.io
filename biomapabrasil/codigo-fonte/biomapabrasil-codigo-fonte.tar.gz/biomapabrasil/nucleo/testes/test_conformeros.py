"""Integridade do arquivo entregue, seleção de candidatos e retomada no banco."""
import hashlib
import json

import pytest
from rdkit import Chem
from starlette.testclient import TestClient

from bmb import api, conformeros
from bmb.conectores.estruturas3d import gerar_sdf_3d
from conftest import _afirmacao, _consulta, _molecula, _taxon


def tarefa(smi):
    return (1, "Teste", smi, Chem.MolToInchiKey(Chem.MolFromSmiles(smi)), None)


@pytest.mark.parametrize("smi", ["C/C=C/C", "C/C=C\\C", "[13CH3][C@@H](O)C(=O)[O-]", "c1ccccc1CCCO"])
def test_validar_arquivo_e_descritores(smi):
    t = tarefa(smi)
    g, motivo = conformeros.gerar(t)
    assert motivo is None and g == conformeros.gerar(t)[0]
    energias = [c["energia"] for c in g["conformeros"]]
    assert energias == sorted(energias) and 1 <= len(energias) <= conformeros.MAX_CONFORMEROS
    assert gerar_sdf_3d(g) == g["conformeros"][0]["sdf"]
    for c in g["conformeros"]:
        assert conformeros.mesma_identidade(c["sdf"], g["smiles"], t[3])
        assert ">  <NATUREZA_EPISTEMICA>\nconformero_calculado" in c["sdf"]
    if "/" in smi:
        assert [b[4] for b in g["ligacoes"] if b[4]] == ["Z" if "\\" in smi else "E"]
    if "13" in smi:
        assert any(a[4] == 13 for a in g["atomos"])
        assert any(a[1] == -1 for a in g["atomos"])
        assert any(a[3] in ("R", "S") for a in g["atomos"])
    if "c1" in smi:
        assert sum(a[2] for a in g["atomos"]) == sum(b[3] for b in g["ligacoes"]) == 6


@pytest.mark.parametrize("smi, motivo", [("CC=CC", "estereoquimica_indefinida"), ("CC(O)C(=O)O", "estereoquimica_indefinida"),
                                         ("CCO.[Na+]", "multicomponente"), ("C1CCCCCCCCCCC1", "macrociclo")])
def test_fallback_preserva_identidade(smi, motivo):
    assert conformeros.gerar(tarefa(smi)) == (None, motivo)
    assert conformeros.verificar(smi, "AAAAAAAAAAAAAA-BBBBBBBBBB-C")[1] == "identidade_divergente"


def test_ausentes_preserva_existentes_quarentena_e_download(con, tmp_path):
    cid = _consulta(con, "lotus")
    tid = _taxon(con, gbif=7701, nome="Aniba canelilla", consulta_id=cid)
    dest = tmp_path / "app" / "dados"
    (dest / "estruturas3d").mkdir(parents=True)
    for smi, estado in [("COCCCO", "candidato"), ("CCOC", "quarentena"), ("CCCO", "candidato")]:
        mid = _molecula(con, smi, tarefa(smi)[3], smiles=smi)
        _afirmacao(con, "composto_em_organismo", mid, cid, taxon_id=tid, origem="lotus:"+smi, estado=estado,
                   motivo_quarentena="Registro retido" if estado == "quarentena" else None)
        if smi == "CCCO":
            ref = f"estruturas3d/mol_{mid}.json"
            corpo = json.dumps({"a": [["C",0.,0.,0.], ["C",1.51,0.,.02], ["C",2.12,1.38,.24], ["O",3.49,1.43,.36]],
                                "b": [[0,1,1], [1,2,1], [2,3,1]]}).encode()
            (dest / ref).write_bytes(corpo)
            con.execute("INSERT INTO estrutura_3d (molecula_id, natureza, fonte_id, codigo, arquivo_geometria, geometria_sha256, consulta_id) "
                        "VALUES (?, 'experimental', 'cod', 'deposito', ?, ?, ?)", (mid, ref, hashlib.sha256(corpo).hexdigest(), cid))
    con.commit()
    assert conformeros.preencher_ausentes(con, dest, processos=1) == {"gerados": 1}
    assert conformeros.preencher_ausentes(con, dest, processos=1) == {}
    r = con.execute("SELECT * FROM estrutura_3d WHERE fonte_id='rdkit_local'").fetchone()
    arquivo = (dest / r["arquivo_geometria"]).read_bytes()
    assert hashlib.sha256(arquivo).hexdigest() == r["geometria_sha256"]
    db = tmp_path / "test.sqlite"
    con.execute(f"VACUUM INTO '{db}'")
    with TestClient(api.criar_app(caminho_db=db, app_dir=dest.parent)) as cli:
        url = f"/api/estruturas3d/{r['id']}/sdf"
        for i, c in enumerate(json.loads(arquivo)["conformeros"], 1):
            assert cli.get(url, params={"conformero": i}).content == c["sdf"].encode()
        assert cli.get(url, params={"conformero": 500}).status_code == 404
        (dest / r["arquivo_geometria"]).unlink()
        assert cli.get(url).status_code == 404
        exp = con.execute("SELECT id FROM estrutura_3d WHERE codigo='deposito'").fetchone()[0]
        assert cli.get(f"/api/estruturas3d/{exp}/sdf").status_code == 200
        (dest / ref).unlink()
        assert cli.get(f"/api/estruturas3d/{exp}/sdf").status_code == 404


def test_legado_divergente_preservado_mas_fora_da_distribuicao(con, tmp_path):
    from bmb.exportar.pacotes import Contexto
    cid = _consulta(con, "lotus")
    tid = _taxon(con, gbif=7702, consulta_id=cid)
    smi = "CCC"
    mid = _molecula(con, smi, tarefa(smi)[3], smiles=smi)
    _afirmacao(con, "composto_em_organismo", mid, cid, taxon_id=tid, origem="lotus:teste")
    ref = f"estruturas3d/mol_{mid}.json"
    arq = tmp_path / ref
    arq.parent.mkdir()
    corpo = json.dumps({"a": [["C",0.,0.,0.], ["C",1.5,0.,0.], ["O",2.1,1.,.2]], "b": [[0,1,1],[1,2,1]]}).encode()
    arq.write_bytes(corpo)
    con.execute("INSERT INTO estrutura_3d (molecula_id, natureza, fonte_id, codigo, arquivo_geometria, geometria_sha256, consulta_id) "
                "VALUES (?, 'conformero_calculado','rdkit_local','legado',?,?,?)", (mid, ref, hashlib.sha256(corpo).hexdigest(), cid))
    con.commit()
    assert mid not in Contexto(con, tmp_path).estruturas3d
    assert conformeros.preencher_ausentes(con, tmp_path, processos=1) == {"gerados": 1}
    assert len(Contexto(con, tmp_path).estruturas3d[mid]) == 1 and arq.read_bytes() == corpo
    assert con.execute("SELECT count(*) FROM estrutura_3d WHERE molecula_id=?", (mid,)).fetchone()[0] == 2


def test_lote_por_intervalo_e_api_sem_arquivo_avulso(con, tmp_path):
    import gzip
    from bmb.exportar import ensembles, pacotes
    cid = _consulta(con, "lotus")
    tid = _taxon(con, gbif=7703, consulta_id=cid)
    smi = "CCCCl"
    mid = _molecula(con, smi, tarefa(smi)[3], smiles=smi)
    _afirmacao(con, "composto_em_organismo", mid, cid, taxon_id=tid, origem="lotus:lote")
    con.commit()
    dados = tmp_path / "app" / "dados"
    conformeros.preencher_ausentes(con, dados, processos=1)
    e = dict(con.execute("SELECT * FROM estrutura_3d WHERE molecula_id=?", (mid,)).fetchone())
    avulso = dados / e["arquivo_geometria"]
    esperado = avulso.read_bytes()
    assert ensembles.gravar(dados, dados, [e]) == 1
    ref, intervalo = e["arquivo_publico"].split("#")
    inicio, tam, sha = intervalo.split(":")
    with (dados / ref).open("rb") as f:
        f.seek(int(inicio))
        assert gzip.decompress(f.read(int(tam))) == esperado
    avulso.unlink()
    assert hashlib.sha256(esperado).hexdigest().startswith(sha)
    ctx = pacotes.Contexto(con, dados)
    assert ctx.estruturas3d[mid][0]["arquivo_publico"] == e["arquivo_publico"]
    arquivo_db = tmp_path / "somente-lote.sqlite"
    con.execute("VACUUM INTO ?", (str(arquivo_db),))
    with TestClient(api.criar_app(arquivo_db, app_dir=dados.parent)) as cli:
        r = cli.get(f"/api/estruturas3d/{e['id']}/sdf")
        assert r.content == json.loads(esperado)["conformeros"][0]["sdf"].encode()

    from bmb.auditar import auditar_ensembles_publicados
    pac = {"id": mid, "estruturas_3d": [{"id": e["id"], "arquivo": e["arquivo_publico"], "sha256": e["geometria_sha256"]}]}
    pasta_lotes = dados / "moleculas_lotes"
    pasta_lotes.mkdir()
    (pasta_lotes / "01.json").write_text(json.dumps({str(mid): pac}))
    auditoria = auditar_ensembles_publicados(con, dados)
    assert auditoria["erros"] == 0 and auditoria["sdf_revalidados"] == len(json.loads(esperado)["conformeros"])
    (dados / ref).write_bytes(b"corrompido")
    assert auditar_ensembles_publicados(con, dados)["erros"] == 1


def test_validar_arquivo_e_limitacao_funcionam_sem_rdkit_na_stdlib(tmp_path, monkeypatch):
    import hashlib, json
    from bmb import conformeros

    smi = "Cn1c(=O)c2c(ncn2C)n(C)c1=O"
    ik = "RYYVLZVUVIJVGH-UHFFFAOYSA-N"
    geom, motivo = conformeros.gerar((1, "Cafeína", smi, ik, "C8H10N4O2"))
    assert motivo is None
    corpo = json.dumps(geom).encode("utf-8")
    sha = hashlib.sha256(corpo).hexdigest()
    arq = tmp_path / "estruturas3d" / f"ens_1_{sha[:16]}.json"
    arq.parent.mkdir(parents=True)
    arq.write_bytes(corpo)

    conformeros._conferir_arquivo.cache_clear()
    conformeros.limitacao.cache_clear()
    monkeypatch.setattr(conformeros, "Chem", None)

    est = {"molecula_id": 1, "arquivo_geometria": f"estruturas3d/ens_1_{sha[:16]}.json", "geometria_sha256": sha}
    mol = {"tipo": "pequena_molecula", "smiles": smi, "inchikey": ik}
    assert conformeros.validar_arquivo(est, mol, (tmp_path,)) is None
    assert conformeros.limitacao(smi, ik) == "sem_pose_publicada"
    # Corrupção continua recusada por SHA-256 mesmo sem RDKit
    arq.write_bytes(b'{"fmt":"ensemble-sdf-v1"}')
    conformeros._conferir_arquivo.cache_clear()
    assert conformeros.validar_arquivo(est, mol, (tmp_path,)) is False
