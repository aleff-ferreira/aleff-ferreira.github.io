# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Testes de verificação universal 3D: codec binário BM32 (`bm32z`), exportação SDF 3D (`V2000`/`V3000`),
conversão cristalográfica COD CIF, peptídeos de veneno com PTMs, paridade JS<->RDKit, rotas `/sdf` da API,
isolamento de moléculas em quarentena e modo 3D padrão na interface."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys

import pytest
from rdkit import Chem
from starlette.testclient import TestClient

from bmb import api, auditar, config
from bmb.conectores import estruturas3d as e3d
from bmb.exportar import pacotes
from conftest import _afirmacao, _consulta, _molecula, _taxon


APP_DIR = Path(__file__).resolve().parent.parent.parent / "app"


def test_bm32z_float32_experimental_preserva_coordenadas_quiralidade_e_sdf_v2000():
    """Modo experimental (`forc_f32=True`) preserva coordenadas IEEE-754 float32 e InChIKey estereoquímico 27 chars."""
    # Quinina (4 centros estereogênicos definidos)
    smiles_quinina = "COc1ccc2nccc([C@@H](O)[C@H]3C[C@@H]4CCN3C[C@@H]4C=C)c2c1"
    mol, met, energia = e3d.construir_mol_3d_de_smiles(smiles_quinina)
    assert mol is not None and mol.GetNumConformers() == 1
    ik_esperado = Chem.MolToInchiKey(Chem.RemoveHs(mol))

    b64z, n_at, n_bd = e3d.codificar_mol_bm32z(mol, forc_f32=True)
    assert n_at == mol.GetNumAtoms() and n_bd == mol.GetNumBonds()

    dec = e3d.decodificar_bm32z(b64z)
    assert dec["chiral_flag"] == 1
    assert len(dec["atomos"]) == n_at
    assert any(a["cip"] in ("R", "S") for a in dec["atomos"])

    conf = mol.GetConformer(0)
    for idx, a_dec in enumerate(dec["atomos"]):
        p = conf.GetAtomPosition(idx)
        assert abs(a_dec["ox"] - p.x) < 1e-4
        assert abs(a_dec["oy"] - p.y) < 1e-4
        assert abs(a_dec["oz"] - p.z) < 1e-4

    sdf = e3d.gerar_sdf_3d(
        {"fmt": "bm32z", "b64z": b64z, "nat": "experimental", "fonte": "rcsb_pdb", "cod": "QNN (1ABC)", "met": "X-RAY DIFFRACTION"},
        {"nome": "Quinina", "inchikey": ik_esperado, "formula": "C20H24N2O2", "natureza": "experimental", "fonte": "rcsb_pdb", "acesso": "QNN (1ABC)", "resolucao": 1.45},
    )
    assert "V2000" in sdf
    assert ">  <NATUREZA_EPISTEMICA>\nexperimental\n" in sdf
    assert sdf.endswith("$$$$\n")

    mol_rt = Chem.MolFromMolBlock(sdf, sanitize=True, removeHs=False)
    assert mol_rt is not None
    Chem.AssignStereochemistryFrom3D(mol_rt, replaceExistingTags=True)
    assert Chem.MolToInchiKey(Chem.RemoveHs(mol_rt)) == ik_esperado


def test_bm32z_int16_compacto_sais_ions_e_cargas_formais():
    """Modo compacto (`int16`), íons monoatômicos, zwitteríons (`M  CHG`) e sais desconectados sem colisão espacial."""
    # Sal orgânico zwitteriônico + contra-íons desconectados
    smiles_sal = "C[N+](C)(C)CC([O-])=O.[Na+].[Cl-]"
    mol, met, _ = e3d.construir_mol_3d_de_smiles(smiles_sal)
    assert mol is not None and mol.GetNumConformers() == 1

    # Nenhum par de átomos distintos deve colidir na origem (< 0.6 Å)
    conf = mol.GetConformer(0)
    pts = [conf.GetAtomPosition(i) for i in range(mol.GetNumAtoms())]
    for i in range(len(pts)):
        for j in range(i + 1, len(pts)):
            dist = math.dist((pts[i].x, pts[i].y, pts[i].z), (pts[j].x, pts[j].y, pts[j].z))
            assert dist > 0.75, f"Colisão espacial detectada entre átomos {i} e {j}: {dist:.3f} Å"

    b64z, _, _ = e3d.codificar_mol_bm32z(mol, forc_f32=False)
    sdf = e3d.gerar_sdf_3d({"fmt": "bm32z", "b64z": b64z}, {"nome": "Betaína NaCl", "natureza": "conformero_calculado"})
    assert "M  CHG" in sdf
    mol_rt = Chem.MolFromMolBlock(sdf, sanitize=True, removeHs=False)
    assert mol_rt is not None
    cargas_orig = sorted(a.GetFormalCharge() for a in mol.GetAtoms() if a.GetFormalCharge() != 0)
    cargas_rt = sorted(a.GetFormalCharge() for a in mol_rt.GetAtoms() if a.GetFormalCharge() != 0)
    assert cargas_rt == cargas_orig == [-1, -1, 1, 1]

    # Íon monoatômico isolado e entradas inválidas
    m_ion, _, e_ion = e3d.construir_mol_3d_de_smiles("[Ca+2]")
    assert m_ion is not None and m_ion.GetNumAtoms() == 1 and e_ion == 0.0
    assert e3d.construir_mol_3d_de_smiles("") == (None, None, None)
    assert e3d.construir_mol_3d_de_smiles("SMILES_INVALIDO_XYZ") == (None, None, None)


def test_gerar_sdf_3d_v3000_acima_de_999_atomos():
    """Estruturas macromoleculares > 999 átomos usam automaticamente o bloco estendido BIOVIA V3000."""
    # Cadeia alcânica linear C340H682 = 1.022 átomos (> 999 -> obriga V3000)
    mol = Chem.AddHs(Chem.MolFromSmiles("C" * 340))
    conf = Chem.Conformer(mol.GetNumAtoms())
    conf.SetId(0)
    conf.Set3D(True)
    for i in range(mol.GetNumAtoms()):
        conf.SetAtomPosition(i, (i * 0.52, math.sin(i) * 0.8, math.cos(i) * 0.8))
    mol.AddConformer(conf, assignId=False)

    b64z, n_at, _ = e3d.codificar_mol_bm32z(mol, forc_f32=True)
    assert n_at == 1022
    sdf_v3k = e3d.gerar_sdf_3d({"fmt": "bm32z", "b64z": b64z}, {"nome": "Oligomero_1022", "natureza": "experimental"})
    assert "V3000" in sdf_v3k and "M  V30 BEGIN CTAB" in sdf_v3k
    mol_rt = Chem.MolFromMolBlock(sdf_v3k, sanitize=True, removeHs=False)
    assert mol_rt is not None and mol_rt.GetNumAtoms() == 1022


def test_conversao_cif_cristalografico_cod_preserva_geometria_e_valida_inchikey():
    """Converte coordenadas fracionárias em célula triclínica de CIF COD para 3D e rejeita InChIKey divergente."""
    # Etanol cristalográfico sintético em célula oblíqua (a=6, b=7, c=8 Å, alpha=85°, beta=95°, gamma=100°)
    mol_et, _, _ = e3d.construir_mol_3d_de_smiles("CCO")
    ik_et = Chem.MolToInchiKey(Chem.RemoveHs(mol_et))
    conf = mol_et.GetConformer(0)

    # Usa célula ortorrômbica limpa 10x10x10 Å para verificar recuperação exata de coordenadas pesadas e H
    linhas_loop = []
    for i in range(mol_et.GetNumAtoms()):
        at = mol_et.GetAtomWithIdx(i)
        sym = at.GetSymbol()
        p = conf.GetAtomPosition(i)
        linhas_loop.append(f"  {sym}{i+1} {sym} {(p.x + 5.0)/10.0:.6f} {(p.y + 5.0)/10.0:.6f} {(p.z + 5.0)/10.0:.6f}")

    cif_txt = (
        "data_9999999\n"
        "_cell_length_a 10.000(2)\n"
        "_cell_length_b 10.000(2)\n"
        "_cell_length_c 10.000(2)\n"
        "_cell_angle_alpha 90.00\n"
        "_cell_angle_beta 90.00\n"
        "_cell_angle_gamma 90.00\n"
        "_publ_section_title 'Single crystal X-ray diffraction'\n"
        "loop_\n"
        "_atom_site_label\n"
        "_atom_site_type_symbol\n"
        "_atom_site_fract_x\n"
        "_atom_site_fract_y\n"
        "_atom_site_fract_z\n"
        + "\n".join(linhas_loop)
        + "\n"
    )
    mol_cod, bfacs, metodo_cod = e3d._converter_cif_cod_para_mol_3d(cif_txt, "CCO", ik_et)
    assert mol_cod is not None and metodo_cod == "SINGLE-CRYSTAL X-RAY DIFFRACTION"
    assert Chem.MolToInchiKey(Chem.RemoveHs(mol_cod)) == ik_et
    # Deve rejeitar estritamente quando o InChIKey alvo não coincide (ex.: InChIKey da Cafeína != Etanol)
    assert e3d._converter_cif_cod_para_mol_3d(cif_txt, "CCO", "RYYVLZVUVIJVGH-UHFFFAOYSA-N") == (None, None, None)


def test_peptideo_veneno_ptm_3d_pglu_hyp_amida_e_ponte_dissulfeto():
    """Constrói peptídeo curto de veneno com pGlu N-terminal, 4-hidroxiprolina, amidação C-terminal e ponte S–S."""
    doc_uniprot = {
        "sequence": {"value": "MKVLLQCPCPA"},
        "features": [
            {"type": "Peptide", "location": {"start": {"value": 6}, "end": {"value": 11}}},
            {"type": "Modified residue", "description": "Pyrrolidone carboxylic acid", "location": {"start": {"value": 6}, "end": {"value": 6}}},
            {"type": "Modified residue", "description": "4-hydroxyproline", "location": {"start": {"value": 8}, "end": {"value": 8}}},
            {"type": "Modified residue", "description": "Alanine amide", "location": {"start": {"value": 11}, "end": {"value": 11}}},
            {"type": "Disulfide bond", "location": {"start": {"value": 7}, "end": {"value": 9}}},
        ],
    }
    geom, n_ss = e3d._construir_peptideo_ptm_3d(doc_uniprot, 777, "Bradicinina-like PTM", "P0TEST")
    assert geom is not None and n_ss == 1
    assert "pGlu" in geom["met"] and "Hyp" in geom["met"] and "C-NH2" in geom["met"] and "1×S-S" in geom["met"]

    sdf = e3d.gerar_sdf_3d(geom, {"nome": "Bradicinina-like PTM"})
    mol_rt = Chem.MolFromMolBlock(sdf, sanitize=True, removeHs=False)
    assert mol_rt is not None
    # Verifica presença da ligação covalente S–S fechando o macrociclo
    tem_ss = any(
        b.GetBeginAtom().GetAtomicNum() == 16 and b.GetEndAtom().GetAtomicNum() == 16
        for b in mol_rt.GetBonds()
    )
    assert tem_ss, "Ponte dissulfeto S–S deve estar covalentemente fechada no grafo 3D"


def test_paridade_javascript_decodificar_bm32z_e_gerar_sdf_cliente(tmp_path):
    """Executa `decodificarBM32Z` + `gerarSDF3DCliente` do módulo ES real via Node e valida o `.sdf` no RDKit."""
    smiles = "CN1C=NC2=C1C(=O)N(C(=O)N2C)C"  # Cafeína
    mol, _, _ = e3d.construir_mol_3d_de_smiles(smiles)
    ik_esp = Chem.MolToInchiKey(Chem.RemoveHs(mol))
    b64z, _, _ = e3d.codificar_mol_bm32z(mol, forc_f32=True)

    # Prepara espelho ESM isolado em tmp_path (com package.json `"type": "module"` sem poluir `app/`)
    esm_dir = tmp_path / "esm_js"
    (esm_dir / "viz").mkdir(parents=True)
    (esm_dir / "package.json").write_text('{"type": "module"}\n', encoding="utf-8")
    for arq_js in (APP_DIR / "js").glob("*.js"):
        (esm_dir / arq_js.name).write_text(arq_js.read_text(encoding="utf-8"), encoding="utf-8")
    for arq_viz in (APP_DIR / "js" / "viz").glob("*.js"):
        (esm_dir / "viz" / arq_viz.name).write_text(arq_viz.read_text(encoding="utf-8"), encoding="utf-8")

    run_js = esm_dir / "run_check.js"
    run_js.write_text(
        "globalThis.window = { matchMedia: () => ({ matches: false }), addEventListener: () => {} };\n"
        "Object.defineProperty(globalThis, 'navigator', { value: { connection: null }, configurable: true, writable: true });\n"
        "globalThis.document = { documentElement: { dataset: {} }, getElementById: () => null, querySelector: () => null, querySelectorAll: () => [] };\n"
        "const { normalizarModelo3D, gerarSDF3DCliente } = await import('./viz/estrutura3d.js');\n"
        f"const raw = {{ fmt: 'bm32z', b64z: '{b64z}', nat: 'experimental', fonte: 'cod', cod: 'COD-123456', met: 'X-RAY' }};\n"
        "const mod = await normalizarModelo3D(raw);\n"
        f"const sdf = gerarSDF3DCliente(mod, {{ natureza: 'experimental', fonte: 'cod', acesso: 'COD-123456', metodo: 'X-RAY' }}, {{ nome: 'Cafeina', inchikey: '{ik_esp}' }});\n"
        "process.stdout.write(sdf);\n",
        encoding="utf-8",
    )

    sdf_js = None
    erro_node = None
    try:
        p = subprocess.run(
            ["node", str(run_js.resolve())],
            stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=15, encoding="utf-8",
        )
        if p.returncode == 0 and "M  END" in p.stdout:
            sdf_js = p.stdout
        else:
            erro_node = (p.stderr or p.stdout or "")[-1500:]
    except FileNotFoundError:
        if sys.platform != "win32":
            pytest.skip("Node.js indisponível para teste cruzado JS<->RDKit")
    # fora do Windows, node presente e módulo falhando é falha do módulo, não motivo para pular o teste
    assert sdf_js is not None or sys.platform == "win32", f"node não gerou o SDF pelo módulo real:\n{erro_node}"

    if sdf_js is None and sys.platform == "win32":
        # Copia para /tmp nativo ext4 dentro do WSL com `--cd /tmp` (evita bloqueio do mount 9P OneDrive)
        wsl_tmp = Path(r"\\wsl.localhost\Ubuntu\tmp\bmb_esm_test")
        try:
            (wsl_tmp / "viz").mkdir(parents=True, exist_ok=True)
            for arq_src in esm_dir.rglob("*"):
                if arq_src.is_file():
                    rel_f = arq_src.relative_to(esm_dir)
                    (wsl_tmp / rel_f).write_text(arq_src.read_text(encoding="utf-8"), encoding="utf-8")
            p = subprocess.run(
                ["wsl", "--cd", "/tmp", "-d", "Ubuntu", "node", "/tmp/bmb_esm_test/run_check.js"],
                stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=15, encoding="utf-8",
            )
            if p.returncode == 0 and "M  END" in p.stdout:
                sdf_js = p.stdout
        except (FileNotFoundError, OSError):
            pytest.skip("Node.js indisponível para teste cruzado JS<->RDKit")

    assert sdf_js is not None, "Falha ao gerar SDF 3D pelo módulo JavaScript real"
    assert ">  <NATUREZA_EPISTEMICA>\nexperimental\n" in sdf_js
    mol_js = Chem.MolFromMolBlock(sdf_js, sanitize=True, removeHs=False)
    assert mol_js is not None
    assert Chem.MolToInchiKey(Chem.RemoveHs(mol_js)) == ik_esp

    # Testa também no mesmo espelho JS: modo quantizado int16 quiral (Quinina) + V3000 (>999 átomos)
    mol_qn, _, _ = e3d.construir_mol_3d_de_smiles("COc1ccc2nccc([C@@H](O)[C@H]3C[C@@H]4CCN3C[C@@H]4C=C)c2c1")
    ik_qn = Chem.MolToInchiKey(Chem.RemoveHs(mol_qn))
    b64_qn, _, _ = e3d.codificar_mol_bm32z(mol_qn, forc_f32=False)

    mol_big = Chem.AddHs(Chem.MolFromSmiles("C" * 340))
    cf_big = Chem.Conformer(mol_big.GetNumAtoms())
    cf_big.SetId(0); cf_big.Set3D(True)
    for idx_b in range(mol_big.GetNumAtoms()):
        cf_big.SetAtomPosition(idx_b, (idx_b * 0.52, math.sin(idx_b) * 0.8, math.cos(idx_b) * 0.8))
    mol_big.AddConformer(cf_big, assignId=False)
    b64_big, _, _ = e3d.codificar_mol_bm32z(mol_big, forc_f32=True)

    run_js2 = esm_dir / "run_check_v3k.js"
    run_js2.write_text(
        "globalThis.window = { matchMedia: () => ({ matches: false }), addEventListener: () => {} };\n"
        "Object.defineProperty(globalThis, 'navigator', { value: { connection: null }, configurable: true, writable: true });\n"
        "globalThis.document = { documentElement: { dataset: {} }, getElementById: () => null, querySelector: () => null, querySelectorAll: () => [] };\n"
        "const { normalizarModelo3D, gerarSDF3DCliente } = await import('./viz/estrutura3d.js');\n"
        f"const mod1 = await normalizarModelo3D({{ fmt: 'bm32z', b64z: '{b64_qn}', nat: 'conformero_calculado' }});\n"
        f"const mod2 = await normalizarModelo3D({{ fmt: 'bm32z', b64z: '{b64_big}', nat: 'experimental' }});\n"
        "const out = JSON.stringify({ sdf1: gerarSDF3DCliente(mod1), sdf2: gerarSDF3DCliente(mod2) });\n"
        "process.stdout.write(out);\n",
        encoding="utf-8",
    )
    out_js2 = None
    erro_node2 = None
    try:
        p2 = subprocess.run(["node", str(run_js2.resolve())], stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=15, encoding="utf-8")
        if p2.returncode == 0 and p2.stdout.startswith("{"):
            out_js2 = json.loads(p2.stdout)
        else:
            erro_node2 = (p2.stderr or p2.stdout or "")[-1500:]
    except FileNotFoundError:
        if sys.platform != "win32":
            pytest.skip("Node.js indisponível para teste cruzado JS<->RDKit")
    assert out_js2 is not None or sys.platform == "win32", f"node não executou o módulo real:\n{erro_node2}"
    if out_js2 is None:
        wsl_tmp = Path(r"\\wsl.localhost\Ubuntu\tmp\bmb_esm_test")
        (wsl_tmp / "run_check_v3k.js").write_text(run_js2.read_text(encoding="utf-8"), encoding="utf-8")
        p2 = subprocess.run(["wsl", "--cd", "/tmp", "-d", "Ubuntu", "node", "/tmp/bmb_esm_test/run_check_v3k.js"], stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=15, encoding="utf-8")
        assert p2.returncode == 0
        out_js2 = json.loads(p2.stdout)

    m_qn_js = Chem.MolFromMolBlock(out_js2["sdf1"], sanitize=True, removeHs=False)
    assert m_qn_js is not None
    Chem.AssignStereochemistryFrom3D(m_qn_js, replaceExistingTags=True)
    assert Chem.MolToInchiKey(Chem.RemoveHs(m_qn_js)) == ik_qn

    assert "V3000" in out_js2["sdf2"]
    m_big_js = Chem.MolFromMolBlock(out_js2["sdf2"], sanitize=True, removeHs=False)
    assert m_big_js is not None and m_big_js.GetNumAtoms() == 1022


def test_api_sdf_3d_prioriza_experimental_bloqueia_quarentena_e_audita_lotes(con, tmp_path):
    """Testa `/api/estruturas3d/{id}/sdf`, `/api/moleculas/{id}/estrutura3d.sdf`, quarentena e auditoria WS8 em lotes."""
    cid_gbif = _consulta(con, "gbif", "https://api.gbif.org/v1/occ", "1")
    cid_lot = _consulta(con, "lotus", "https://zenodo.org/records/19360665", "2")
    cid_pdb = _consulta(con, "rcsb_pdb", "https://www.ebi.ac.uk/pdbe/static/files/pdbechem_v2/CFF_model.sdf", "3")
    cid_cod = _consulta(con, "cod", "https://www.crystallography.net/cod/1000001.cif", "4")
    cid_af = _consulta(con, "alphafold", "https://alphafold.ebi.ac.uk/files/AF-P01234-F1-model_v6.pdb", "5")

    tid = _taxon(con, gbif=7701, nome="Paullinia cupana", consulta_id=cid_gbif)
    m_pub = _molecula(con, "Cafeína", "RYYVLZVUVIJVGH-UHFFFAOYSA-N", smiles="CN1C=NC2=C1C(=O)N(C(=O)N2C)C", formula="C8H10N4O2")
    m_quar = _molecula(con, "Composto Restrito", "XXXXXXXXXXXXXX-UHFFFAOYSA-N", smiles="CCO", formula="C2H6O")

    _afirmacao(con, "composto_em_organismo", m_pub, cid_lot, taxon_id=tid, origem="lotus:pub1", estado="candidato",
               organismo_na_fonte="Paullinia cupana", procedencia_declarada="nao_declarada")
    a_quar = _afirmacao(con, "composto_em_organismo", m_quar, cid_lot, taxon_id=tid, origem="lotus:quar1", estado="quarentena",
                        motivo_quarentena="Portaria 344", regra_quarentena="REG-344", quarentena_origem="regra",
                        organismo_na_fonte="Paullinia cupana", procedencia_declarada="nao_declarada")
    con.execute("INSERT INTO organismo_fonte (fonte_id, nome_fonte, id_fonte, via, taxon_id, decisao, resolvido_em) "
                "VALUES ('lotus', 'Paullinia cupana', '7701', 'identificador_da_fonte', ?, 'aceito', '2026-01-01T00:00:00Z')", (tid,))
    con.execute("INSERT INTO afirmacao_regra (afirmacao_id, codigo, detectada_em) VALUES (?, 'REG-344', '2026-01-01T00:00:00Z')", (a_quar,))

    con.execute("INSERT INTO alvo (nome, chembl_id, uniprot_acc, organismo, tipo_chembl, natureza) "
                "VALUES ('A1 Receptor', 'CHEMBL226', 'P30542', 'Homo sapiens', 'SINGLE PROTEIN', 'proteina_unica')")
    alvo_id = con.execute("SELECT id FROM alvo WHERE chembl_id='CHEMBL226'").fetchone()[0]
    # a estrutura de um alvo só é pública quando o alvo aparece em alguma atividade pública
    cid_chembl = _consulta(con, "chembl", "https://www.ebi.ac.uk/chembl/api/data/activity.json?x=1", "6")
    a_ativ = _afirmacao(con, "atividade_biologica", m_pub, cid_chembl, alvo_id=alvo_id, fonte="chembl",
                        origem="chembl:agregado:CHEMBL113:CHEMBL226:Ki", medida_tipo="Ki", medida_relacao="=", medida_valor=12.0,
                        medida_unidade="nM", medida_agregacao="unica", medida_n=1, medida_n_documentos=1, medida_min=12.0,
                        medida_max=12.0, ensaio_tipo="B")
    con.execute("INSERT INTO medida_bioatividade (activity_id, afirmacao_id, molecula_id, alvo_chembl_id, tipo, relacao, valor_nm, "
                "pchembl, documento_chembl_id, ensaio_chembl_id, ensaio_tipo, usada, consulta_id) "
                "VALUES (1, ?, ?, 'CHEMBL226', 'Ki', '=', 12.0, 7.92, 'CHEMBL1', 'CHEMBL2', 'B', 1, ?)", (a_ativ, m_pub, cid_chembl))

    # Cria lote fragmentado `estruturas3d_lotes/` contendo estrutura pública experimental, confôrmero, quarentenada e alvo Cα
    mol_caff, _, _ = e3d.construir_mol_3d_de_smiles("CN1C=NC2=C1C(=O)N(C(=O)N2C)C")
    b64_caff, n_caff, _ = e3d.codificar_mol_bm32z(mol_caff, forc_f32=True)

    mol_q, _, _ = e3d.construir_mol_3d_de_smiles("CCO")
    b64_q, n_q, _ = e3d.codificar_mol_bm32z(mol_q, forc_f32=False)

    pasta_lotes = config.SAIDA_DIR / "estruturas3d_lotes"
    pasta_lotes.mkdir(parents=True, exist_ok=True)
    lotes_map: dict[str, dict] = {}

    def _gravar_item(chave: str, geom: dict) -> tuple[str, str]:
        bk = e3d.bucket_chave(chave)
        lotes_map.setdefault(bk, {})[chave] = geom
        sha = hashlib.sha256(e3d.json_canonico_bytes(geom)).hexdigest()
        return f"estruturas3d_lotes/{bk}.json#{chave}", sha

    arq_exp, sha_exp = _gravar_item(f"exp_pdb_{m_pub}", {"fmt": "bm32z", "id": m_pub, "nat": "experimental", "fonte": "rcsb_pdb", "cod": "CFF (2OAX)", "met": "X-RAY DIFFRACTION", "b64z": b64_caff})
    arq_conf, sha_conf = _gravar_item(f"mol_{m_pub}", {"fmt": "bm32z", "id": m_pub, "nat": "conformero_calculado", "fonte": "rdkit_local", "cod": f"ETKDGv3-{m_pub}", "b64z": b64_caff})
    arq_quar, sha_quar = _gravar_item(f"exp_cod_{m_quar}", {"fmt": "bm32z", "id": m_quar, "nat": "experimental", "fonte": "cod", "cod": "COD-1000001", "b64z": b64_q})
    arq_alvo, sha_alvo = _gravar_item(f"alvo_{alvo_id}", {"fmt": "bm32z", "cod": "AF-P30542-F1", "tipo": "cadeia", "nat": "predicao_computacional", "fonte": "alphafold", "ca": [[1, "M", 0, 0, 0, 92.0], [2, "P", 3.8, 0, 0, 94.0], [3, "S", 7.6, 0, 0, 91.0], [4, "I", 11.4, 0, 0, 95.0]], "ss_bonds": []})

    for bk, d_bk in lotes_map.items():
        (pasta_lotes / f"{bk}.json").write_bytes(e3d.json_canonico_bytes(d_bk))

    eid_conf = e3d._upsert_estrutura(con, molecula_id=m_pub, natureza="conformero_calculado", fonte_id="rdkit_local", codigo=f"ETKDGv3-{m_pub}", metodo="RDKit ETKDGv3", n_elem=n_caff, arquivo=arq_conf, sha256=sha_conf, consulta_id=cid_lot, tem_sdf_3d=1)
    eid_exp = e3d._upsert_estrutura(con, molecula_id=m_pub, natureza="experimental", fonte_id="rcsb_pdb", codigo="CFF (2OAX)", metodo="X-RAY DIFFRACTION", resolucao=1.8, n_elem=n_caff, arquivo=arq_exp, sha256=sha_exp, consulta_id=cid_pdb, tem_sdf_3d=1)
    eid_quar = e3d._upsert_estrutura(con, molecula_id=m_quar, natureza="experimental", fonte_id="cod", codigo="COD-1000001", metodo="X-RAY DIFFRACTION", n_elem=n_q, arquivo=arq_quar, sha256=sha_quar, consulta_id=cid_cod, tem_sdf_3d=1)
    eid_alvo = e3d._upsert_estrutura(con, alvo_id=alvo_id, natureza="predicao_computacional", fonte_id="alphafold", codigo="AF-P30542-F1", metodo="AlphaFold", plddt=93.0, n_elem=4, arquivo=arq_alvo, sha256=sha_alvo, consulta_id=cid_af, tem_sdf_3d=0)
    con.commit()

    # Exporta pacotes estáticos para um app_dir temporário e verifica isolamento de quarentena nos lotes
    app_tmp = tmp_path / "app_export"
    (app_tmp / "dados").mkdir(parents=True)
    pacotes.exportar_tudo(con, destino=app_tmp / "dados")

    # Item quarentenado NÃO pode vazar nos lotes exportados para app/dados/estruturas3d_lotes/
    bk_quar = e3d.bucket_chave(f"exp_cod_{m_quar}")
    arq_lote_q = app_tmp / "dados" / "estruturas3d_lotes" / f"{bk_quar}.json"
    if arq_lote_q.exists():
        assert f"exp_cod_{m_quar}" not in json.loads(arq_lote_q.read_text(encoding="utf-8"))

    # Auditoria WS8 verifica integridade SHA-256 item a item dentro dos lotes
    res_ws8 = auditar.auditar_ws8_expansao_e_3d(con, app_tmp / "dados")
    assert res_ws8["ok"] is True
    assert res_ws8["estruturas_3d_experimentais"] == 2  # conta SQLite total, enquanto arquivos públicos batem SHA-256

    # Testa endpoints HTTP da API ASGI
    db_arq = tmp_path / "api_3d.sqlite"
    con_disk = e3d.config  # apenas referência
    con.execute(f"VACUUM INTO '{db_arq.as_posix()}'")
    cli_http = TestClient(api.criar_app(caminho_db=db_arq, app_dir=app_tmp))

    r_lista = cli_http.get("/api/estruturas3d")
    assert r_lista.status_code == 200
    ids_retornados = {it["id"] for it in r_lista.json()["itens"]}
    assert eid_exp in ids_retornados and eid_conf in ids_retornados and eid_alvo in ids_retornados
    assert eid_quar not in ids_retornados, "Estrutura de molécula quarentenada não pode aparecer na listagem pública"

    # `/api/moleculas/{id}/estrutura3d.sdf` prioriza coordenadas experimentais sobre o confôrmero calculado!
    r_sdf_mol = cli_http.get(f"/api/moleculas/{m_pub}/estrutura3d.sdf")
    assert r_sdf_mol.status_code == 200
    assert r_sdf_mol.headers["content-type"].startswith("chemical/x-mdl-sdfile")
    assert "attachment;" in r_sdf_mol.headers["content-disposition"]
    assert ">  <NATUREZA_EPISTEMICA>\nexperimental\n" in r_sdf_mol.text
    assert Chem.MolFromMolBlock(r_sdf_mol.text, sanitize=True, removeHs=False) is not None

    # Download direto por ID da estrutura experimental
    r_sdf_id = cli_http.get(f"/api/estruturas3d/{eid_exp}/sdf")
    assert r_sdf_id.status_code == 200 and "CFF (2OAX)" in r_sdf_id.text

    # Molécula em quarentena e alvo apenas-Cα devem retornar 404 estrito
    assert cli_http.get(f"/api/estruturas3d/{eid_quar}/sdf").status_code == 404
    assert cli_http.get(f"/api/moleculas/{m_quar}/estrutura3d.sdf").status_code == 404
    assert cli_http.get(f"/api/estruturas3d/{eid_alvo}/sdf").status_code == 404


def test_interface_frontend_define_3d_interativo_como_modo_padrao():
    """Garante que `perfis.js`/`detalhe_mol.js` montam o visualizador 3D como modo padrão ativo com alternância para 2D ACS."""
    perfis_js = (
        (APP_DIR / "js" / "perfis.js").read_text(encoding="utf-8")
        + "\n"
        + (APP_DIR / "js" / "viz" / "detalhe_mol.js").read_text(encoding="utf-8")
    )
    assert 'data-modo-est="3d" aria-pressed="true"' in perfis_js
    assert 'data-modo-est="2d" aria-pressed="false"' in perfis_js
    assert 'data-3d-auto="1"' in perfis_js


def test_proveniencia_e_arquivo_dos_modelos_no_banco_producao():
    """Cada geometria publicada possui fonte e arquivo. Um registro sem geometria recebe a vista de contingência."""
    import sqlite3

    db_prod = config.DB_PATH
    if not db_prod.is_file():
        pytest.skip("Banco de produção local não construído neste ambiente de CI")

    con_ro = sqlite3.connect(f"file:{db_prod.as_posix()}?mode=ro", uri=True)
    try:
        rows = con_ro.execute("SELECT fonte_id, natureza, arquivo_geometria, geometria_sha256, consulta_id, tem_sdf_3d "
                              "FROM estrutura_3d").fetchall()
        assert rows
        for fonte, natureza, arquivo, sha, consulta, tem_sdf in rows:
            assert arquivo and len(sha) == 64 and consulta
            if "ens_" in arquivo:
                assert (fonte, natureza, tem_sdf) == ("rdkit_local", "conformero_calculado", 1)

        fontes_exp = {
            r[0] for r in con_ro.execute("SELECT DISTINCT fonte_id FROM estrutura_3d WHERE natureza='experimental'").fetchall()
        }
        assert fontes_exp <= {"rcsb_pdb", "cod"}, f"Fonte não-experimental rotulada como experimental: {fontes_exp}"
    finally:
        con_ro.close()
