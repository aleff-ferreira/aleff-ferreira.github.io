# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Regressões da versão 4.2.3: cobertura 3D universal (100% das moléculas públicas),
contenção tipográfica na abertura do perfil molecular e proporção exata da marca BioMapa BRASIL.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import urllib.request
from pathlib import Path
from unittest import mock

import pytest
from rdkit import Chem
from rdkit.Chem import rdCIPLabeler

from bmb import config, conformeros, db
from bmb.conectores import estruturas3d as e3d
from bmb.exportar.pacotes import Contexto


def _bbox_svg_path(d: str) -> tuple[float, float, float, float]:
    """Calcula a caixa delimitadora exata (xmin, ymin, xmax, ymax) de um caminho SVG com comandos M/L/H/V/C/Q/Z."""
    tokens = re.findall(r"[MLHVCQZmlhvcqz]|[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?", d)
    xs: list[float] = []
    ys: list[float] = []
    cx = cy = sx = sy = 0.0
    cmd = ""
    i = 0

    def _quad_extrema(p0: float, p1: float, p2: float) -> list[float]:
        pts = [p0, p2]
        denom = p0 - 2.0 * p1 + p2
        if abs(denom) > 1e-9:
            t = (p0 - p1) / denom
            if 0.0 < t < 1.0:
                pts.append((1 - t) ** 2 * p0 + 2 * (1 - t) * t * p1 + t ** 2 * p2)
        return pts

    def _cubic_extrema(p0: float, p1: float, p2: float, p3: float) -> list[float]:
        pts = [p0, p3]
        a = -p0 + 3.0 * p1 - 3.0 * p2 + p3
        b = 2.0 * (p0 - 2.0 * p1 + p2)
        c = p1 - p0
        if abs(a) < 1e-9:
            if abs(b) > 1e-9:
                t = -c / b
                if 0.0 < t < 1.0:
                    u = 1.0 - t
                    pts.append(u**3 * p0 + 3 * u**2 * t * p1 + 3 * u * t**2 * p2 + t**3 * p3)
        else:
            disc = b * b - 4.0 * a * c
            if disc >= 0.0:
                sq = disc ** 0.5
                for t in ((-b - sq) / (2.0 * a), (-b + sq) / (2.0 * a)):
                    if 0.0 < t < 1.0:
                        u = 1.0 - t
                        pts.append(u**3 * p0 + 3 * u**2 * t * p1 + 3 * u * t**2 * p2 + t**3 * p3)
        return pts

    while i < len(tokens):
        tk = tokens[i]
        if tk.isalpha():
            cmd = tk
            i += 1
            if cmd in ("Z", "z"):
                cx, cy = sx, sy
            continue
        rel = cmd.islower()
        op = cmd.upper()
        if op == "M":
            nx, ny = float(tokens[i]), float(tokens[i + 1])
            i += 2
            cx = (cx + nx) if rel else nx
            cy = (cy + ny) if rel else ny
            sx, sy = cx, cy
            xs.append(cx)
            ys.append(cy)
            cmd = "l" if rel else "L"
        elif op == "L":
            nx, ny = float(tokens[i]), float(tokens[i + 1])
            i += 2
            cx = (cx + nx) if rel else nx
            cy = (cy + ny) if rel else ny
            xs.append(cx)
            ys.append(cy)
        elif op == "H":
            nx = float(tokens[i])
            i += 1
            cx = (cx + nx) if rel else nx
            xs.append(cx)
        elif op == "V":
            ny = float(tokens[i])
            i += 1
            cy = (cy + ny) if rel else ny
            ys.append(cy)
        elif op == "Q":
            x1, y1, x2, y2 = (float(tokens[i + k]) for k in range(4))
            i += 4
            if rel:
                x1, y1, x2, y2 = cx + x1, cy + y1, cx + x2, cy + y2
            xs.extend(_quad_extrema(cx, x1, x2))
            ys.extend(_quad_extrema(cy, y1, y2))
            cx, cy = x2, y2
        elif op == "C":
            x1, y1, x2, y2, x3, y3 = (float(tokens[i + k]) for k in range(6))
            i += 6
            if rel:
                x1, y1, x2, y2, x3, y3 = cx + x1, cy + y1, cx + x2, cy + y2, cx + x3, cy + y3
            xs.extend(_cubic_extrema(cx, x1, x2, x3))
            ys.extend(_cubic_extrema(cy, y1, y2, y3))
            cx, cy = x3, y3
        else:
            raise AssertionError(f"Comando SVG inesperado: {cmd}")
    return min(xs), min(ys), max(xs), max(ys)


def test_logo_svg_proporcoes_iguais_brasil_e_biomapa():
    """A palavra BRASIL na marca deve ter a mesma largura e altura de caixa-alta que BioMapa."""
    raiz = config.PLATAFORMA
    fontes_svg = [
        raiz / "app" / "index.html",
        raiz / "assets" / "biomapabrasil-logo.svg",
        raiz / "assets" / "social-preview.svg",
    ]
    caminhos_biomapa: set[str] = set()
    caminhos_brasil: set[str] = set()

    for arq in fontes_svg:
        txt = arq.read_text(encoding="utf-8")
        if arq.name in ("biomapabrasil-logo.svg", "social-preview.svg"):
            ds = re.findall(r'\bd="([^"]+)"', txt)
            assert len(ds) >= 4, f"Caminhos insuficientes em {arq.name}"
            d_bio, d_bra = ds[-2], ds[-1]
        else:
            m_bio = re.search(r'class="marca-biomapa"[^>]*\bd="([^"]+)"', txt)
            m_bra = re.search(r'class="marca-brasil"[^>]*\bd="([^"]+)"', txt)
            assert m_bio and m_bra, f"Caminhos da marca ausentes em {arq}"
            d_bio, d_bra = m_bio.group(1), m_bra.group(1)

        caminhos_biomapa.add(d_bio)
        caminhos_brasil.add(d_bra)

        bx0, by0, bx1, by1 = _bbox_svg_path(d_bio)
        rx0, ry0, rx1, ry1 = _bbox_svg_path(d_bra)

        larg_bio = bx1 - bx0
        larg_bra = rx1 - rx0
        # Largura idêntica (diferença < 0,2% das 491 unidades) e alinhamento horizontal exato entre BioMapa e BRASIL
        assert abs(larg_bra - larg_bio) <= 1.0, (arq.name, larg_bio, larg_bra)
        assert abs(rx0 - bx0) <= 1.0 and abs(rx1 - bx1) <= 1.0, (arq.name, (bx0, bx1), (rx0, rx1))

        # Altura de capitais de BRASIL (~87.6–91.7 com overshoot de 'S') igual à altura de capitais de BioMapa (~87.0)
        alt_cap_bio = 99.0 - by0  # linha de base de BioMapa = 99.0 (descendente do 'p' vai até ~126.7)
        alt_bra = ry1 - ry0
        assert 0.96 <= (alt_bra / alt_cap_bio) <= 1.08, (arq.name, alt_cap_bio, alt_bra)

        # Sem colisão vertical entre o descendente de 'p' em BioMapa e o topo de BRASIL, e dentro do viewBox 782x235
        assert ry0 > by1 + 6.0, f"Sobreposição vertical entre BioMapa ({by1}) e BRASIL ({ry0}) em {arq.name}"
        assert bx0 >= 0 and by0 >= 0 and rx1 <= 782.0 and ry1 <= 235.0

    # Todos os três arquivos usam exatamente as mesmas curvas vetoriais
    assert len(caminhos_biomapa) == 1
    assert len(caminhos_brasil) == 1

    css = (raiz / "app" / "css" / "app.css").read_text(encoding="utf-8")
    assert not re.search(r"\.marca-brasil\s*\{[^}]*stroke-width", css)


def test_conformeros_bufaginas_e_bm32z_estereo_indefinido_radical_multicomponente():
    """Bufadienolídeos geram ensembles completos; modelos bm32z cobrem estereo indefinido, radicais, sais e macrociclos."""
    # 1. 11alpha,19-Dihydroxytelocinobufagin (14653) e Telocinobufagin (14656) geram ensembles válidos
    for mid, nome, smi, ik, form in (
        (
            14653,
            "11alpha,19-Dihydroxytelocinobufagin",
            "C[C@]12CC[C@@H](O)C[C@]1(CO)[C@@H]1CC[C@]3(C)[C@@H](c4ccc(=O)oc4)[C@@H](O)C[C@]3(O)[C@@H]1[C@H](O)C2",
            "YREWTUOPCGDZBA-JLSZMDABSA-N",
            "C24H34O7",
        ),
        (
            14656,
            "Telocinobufagin",
            "C[C@]12CC[C@@H](O)C[C@]1(C)CC[C@@H]1[C@@H]2CC[C@]2(C)[C@@H](c3ccc(=O)oc3)CC[C@]12O",
            "SFCUQMBSFZSJHB-JLSZMDABSA-N",
            "C24H34O5",
        ),
    ):
        ik_real = Chem.MolToInchiKey(Chem.MolFromSmiles(smi))
        geom, mot = conformeros.gerar((mid, nome, smi, ik_real, form), tempo_fragmento=0)
        assert mot is None and geom is not None, (nome, mot)
        assert geom["fmt"] == "ensemble-sdf-v1"
        assert len(geom["conformeros"]) >= 1

    # 2. Molécula com estereocentro indefinido preserva '?' (CIP não atribuído) e sinaliza repr_estereo=True
    smi_indef = "CC(O)C(=O)O"
    ik_indef = Chem.MolToInchiKey(Chem.MolFromSmiles(smi_indef))
    mid_i, geom_i, n_at_i, mot_i = e3d._worker_bm32z_pequena_predita((900001, "Ácido láctico racêmico/indefinido", smi_indef, ik_indef, "C3H6O3"))
    assert mot_i is None and geom_i is not None and n_at_i > 0
    assert geom_i.get("repr_estereo") is True
    sdf_i = e3d.gerar_sdf_3d(geom_i)
    mol_i = Chem.MolFromMolBlock(sdf_i, removeHs=False)
    assert mol_i is not None and mol_i.GetConformer().Is3D()
    assert Chem.MolToInchiKey(Chem.RemoveHs(mol_i))[:14] == ik_indef[:14]
    # Verifica que o código CIP codificado em bm32z manteve '?' (código 5), sem fabricar 'R' ou 'S'
    dec = e3d.decodificar_bm32z(geom_i["b64z"])
    cips_decodificados = [a["cip"] for a in dec["atomos"]]
    assert "?" in cips_decodificados
    assert "R" not in cips_decodificados and "S" not in cips_decodificados

    # 3. Radical orgânico preserva M  RAD e InChIKey completo de 27 caracteres no SDF reconstruído
    smi_rad = "[CH2]c1ccccc1"
    ik_rad = Chem.MolToInchiKey(Chem.MolFromSmiles(smi_rad))
    _, geom_r, _, mot_r = e3d._worker_bm32z_pequena_predita((900002, "Radical benzila", smi_rad, ik_rad, "C7H7"))
    assert mot_r is None and geom_r is not None
    assert geom_r.get("rad")
    sdf_r = e3d.gerar_sdf_3d(geom_r)
    assert "M  RAD" in sdf_r
    mol_r = Chem.MolFromMolBlock(sdf_r, removeHs=False)
    assert mol_r is not None
    assert sum(a.GetNumRadicalElectrons() for a in mol_r.GetAtoms()) == 1
    assert Chem.MolToInchiKey(Chem.RemoveHs(mol_r)) == ik_rad

    # 4. Sal multicomponente modela todos os componentes com InChIKey exato de 27 caracteres
    smi_sal = "CCN.Cl"
    ik_sal = Chem.MolToInchiKey(Chem.MolFromSmiles(smi_sal))
    _, geom_s, _, mot_s = e3d._worker_bm32z_pequena_predita((900003, "Cloridrato de etilamina", smi_sal, ik_sal, "C2H8ClN"))
    assert mot_s is None and geom_s is not None
    mol_s = Chem.MolFromMolBlock(e3d.gerar_sdf_3d(geom_s), removeHs=False)
    assert Chem.MolToInchiKey(Chem.RemoveHs(mol_s)) == ik_sal

    # 5. Macrociclo (> 8 membros) gera confôrmero 3D verificado por InChIKey de 27 caracteres
    smi_mac = "O=C1CCCCCCCCCCCCCCC1"
    ik_mac = Chem.MolToInchiKey(Chem.MolFromSmiles(smi_mac))
    _, geom_m, _, mot_m = e3d._worker_bm32z_pequena_predita((900004, "Ciclopentadecanona", smi_mac, ik_mac, "C15H28O"))
    assert mot_m is None and geom_m is not None
    sdf_m = e3d.gerar_sdf_3d(geom_m)
    mol_m = Chem.MolFromMolBlock(sdf_m, removeHs=False)
    assert Chem.MolToInchiKey(Chem.RemoveHs(mol_m)) == ik_mac


def test_server_unificado_sdf_bm32z_radical_sem_rdkit(mini, tmp_path):
    """O servidor institucional reconstrói M  RAD em SDF V2000 a partir de bm32z sem exigir rdkit."""
    raiz_aw = config.PLATAFORMA.parent
    if not (raiz_aw / "server.py").is_file():
        pytest.skip("server.py institucional fora deste diretório")
    if str(raiz_aw) not in sys.path:
        sys.path.insert(0, str(raiz_aw))
    import server as srv_aw

    smi_rad = "[CH2]c1ccccc1"
    ik_rad = Chem.MolToInchiKey(Chem.MolFromSmiles(smi_rad))
    _, geom_r, _, mot_r = e3d._worker_bm32z_pequena_predita((mini.molecula, "Radical benzila", smi_rad, ik_rad, "C7H7"))
    assert mot_r is None and geom_r is not None

    arq_db = tmp_path / "bmb_rad.sqlite"
    mini.con.execute("VACUUM INTO ?", (str(arq_db),))
    con = db.conectar(arq_db)
    con.execute("UPDATE molecula SET nome='Radical benzila', smiles=?, inchikey=?, formula='C7H7' WHERE id=?", (smi_rad, ik_rad, mini.molecula))
    con.execute("INSERT OR IGNORE INTO fonte (id, nome, url, licenca) VALUES ('rdkit_local','RDKit','https://rdkit.org','BSD-3-Clause')")
    cid = con.execute("SELECT id FROM consulta LIMIT 1").fetchone()[0]

    chave = f"mol_{mini.molecula}"
    bk = e3d.bucket_chave(chave)
    app_fake = tmp_path / "app"
    lotes_dir = app_fake / "dados" / "estruturas3d_lotes"
    lotes_dir.mkdir(parents=True)
    corpo_geom = e3d.json_canonico_bytes(geom_r)
    sha_geom = hashlib.sha256(corpo_geom).hexdigest()
    (lotes_dir / f"{bk}.json").write_bytes(e3d.json_canonico_bytes({chave: geom_r}))

    con.execute(
        "INSERT INTO estrutura_3d (id, molecula_id, natureza, fonte_id, codigo, metodo, energia_kcal_mol, n_atomos_ou_residuos, arquivo_geometria, geometria_sha256, tem_sdf_3d, consulta_id) "
        "VALUES (88, ?, 'conformero_calculado', 'rdkit_local', ?, ?, ?, 14, ?, ?, 1, ?)",
        (mini.molecula, geom_r["cod"], geom_r["met"], geom_r["e_kcal"], f"estruturas3d_lotes/{bk}.json#{chave}", sha_geom, cid),
    )
    con.commit()
    con.close()

    conformeros._conferir_arquivo.cache_clear()
    with (
        mock.patch.object(srv_aw, "BMB_APP", app_fake),
        mock.patch.object(conformeros, "Chem", None),
        mock.patch.dict(sys.modules, {"rdkit": None, "rdkit.Chem": None}),
    ):
        httpd, _ = srv_aw.criar_servidor_http(host="127.0.0.1", porta=0, caminho_db=arq_db, silencioso=True)
        porta = httpd.server_address[1]
        t = threading.Thread(target=httpd.serve_forever, daemon=True)
        t.start()
        try:
            url = f"http://127.0.0.1:{porta}/biomapabrasil/api/moleculas/{mini.molecula}/estrutura3d.sdf"
            with urllib.request.urlopen(url) as resp:
                assert resp.status == 200
                sdf_txt = resp.read().decode("utf-8")
                assert "M  RAD  1" in sdf_txt
                assert "$$$$" in sdf_txt
        finally:
            httpd.shutdown()
            httpd.server_close()


def test_layout_hero_molecula_contratos_css_js_i18n():
    """Garante contenção geométrica de .mol-cab-cena, 4 faixas tipográficas e traduções 3D em EN."""
    app_dir = config.APP_DIR
    mol_css = (app_dir / "css" / "molecula.css").read_text(encoding="utf-8")
    det_js = (app_dir / "js" / "viz" / "detalhe_mol.js").read_text(encoding="utf-8")
    est_js = (app_dir / "js" / "viz" / "estrutura3d.js").read_text(encoding="utf-8")
    sw_js = (app_dir / "sw.js").read_text(encoding="utf-8")
    en_json = json.loads((config.SEMENTE_DIR / "i18n" / "en.json").read_text(encoding="utf-8"))

    assert "height:calc(var(--altura-cena) - 7.8rem)" in mol_css
    assert "overflow:hidden" in mol_css
    assert ".mol-cab-cena h2.nome-medio" in mol_css
    assert ".mol-cab-cena h2.nome-longo" in mol_css
    assert ".mol-cab-cena h2.nome-extenso" in mol_css
    assert "max-height:7.3rem" in mol_css
    assert "inset:10.5rem 0 2.9rem" in mol_css

    assert "nome-longo nome-extenso" in det_js
    assert "nome-medio" in det_js
    assert "pack.nome.length > 34" in det_js

    assert "M  RAD" in est_js
    assert "repr_estereo" in est_js
    chave_estereo = "Estereoisômero 3D representativo calculado para a conectividade registrada; centros sem configuração definida na fonte permanecem sem atribuição."
    assert chave_estereo in en_json

    assert "const VERSAO = 'bmb-v26';" in sw_js
    assert "PREFIXO_CACHE" in sw_js


def test_cobertura_3d_universal_pacote_publico():
    """Quando o banco e o manifesto público estão presentes, 100% das moléculas públicas possuem estrutura 3D verificada."""
    arq_manifesto = config.APP_DIR / "dados" / "manifesto.json"
    if not config.DB_PATH.is_file() or not arq_manifesto.is_file():
        pytest.skip("Banco ou pacote público não disponível neste ambiente")

    manifesto = json.loads(arq_manifesto.read_text(encoding="utf-8"))
    cont = manifesto["contagens"]
    assert cont["moleculas"] > 0
    assert cont["moleculas_com_3d"] == cont["moleculas"], (
        f"Esperava 100% de moléculas públicas com 3D, obteve {cont['moleculas_com_3d']} / {cont['moleculas']}"
    )

    con = db.conectar(config.DB_PATH)
    try:
        conformeros._conferir_arquivo.cache_clear()
        ctx = Contexto(con)
        sem_3d = [mid for mid in sorted(ctx.mols_publicas) if not ctx.estruturas3d.get(mid)]
        assert sem_3d == [], f"Moléculas públicas sem estrutura 3D verificada: {sem_3d[:20]}"
        # Verifica especificamente 11alpha,19-Dihydroxytelocinobufagin (14653) e Telocinobufagin (14656)
        for mid_buf in (14653, 14656):
            if mid_buf in ctx.mols_publicas:
                ests = ctx.estruturas3d.get(mid_buf, [])
                assert len(ests) >= 1, f"Bufadienolídeo {mid_buf} sem estrutura 3D"
    finally:
        con.close()


def _encontrar_node_playwright() -> tuple[str, str] | None:
    cands_node = [
        shutil.which("node"),
        "/home/aleff/.nvm/versions/node/v22.23.2/bin/node",
    ]
    node_bin = next((c for c in cands_node if c and Path(c).is_file()), None)
    if not node_bin:
        return None
    cands_pw = [
        os.environ.get("PLAYWRIGHT_MODULE_PATH"),
        "/home/aleff/inct/node_modules/playwright",
    ]
    for pw_mod in cands_pw:
        if pw_mod and Path(pw_mod).is_dir():
            return node_bin, pw_mod
    return None


def test_e2e_chromium_obufagin_layout_3d_2d_e_logo(tmp_path):
    """Verifica no Chromium real que 14653 e 14656 abrem em 3D sem qualquer sobreposição de texto em desktop/mobile e que BRASIL == BioMapa no logo."""
    if not (config.APP_DIR / "dados" / "manifesto.json").is_file():
        pytest.skip("Pacotes estáticos em app/dados ausentes")
    raiz_aw = config.PLATAFORMA.parent
    if not (raiz_aw / "server.py").is_file():
        pytest.skip("server.py institucional ausente")
    node_pw = _encontrar_node_playwright()
    if node_pw is None:
        pytest.skip("Node + Playwright indisponível neste ambiente")
    node_bin, pw_mod = node_pw

    if str(raiz_aw) not in sys.path:
        sys.path.insert(0, str(raiz_aw))
    import server as srv_aw

    httpd, _ = srv_aw.criar_servidor_http(host="127.0.0.1", porta=0, silencioso=True)
    porta = httpd.server_address[1]
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    try:
        script_js = tmp_path / "check_v423.cjs"
        script_js.write_text(
            f"""
const {{ chromium }} = require({json.dumps(pw_mod)});
(async () => {{
  const base = 'http://127.0.0.1:{porta}/biomapabrasil/';
  const browser = await chromium.launch({{ headless: true, args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] }});
  const erros = [];

  function assertNoOverlap(a, b, labelA, labelB) {{
    if (!a || !b || a.width === 0 || b.width === 0) return;
    const overlapX = Math.min(a.right, b.right) - Math.max(a.left, b.left);
    const overlapY = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
    if (overlapX > 1.5 && overlapY > 1.5) {{
      throw new Error(`Colisão geométrica entre ${{labelA}} (${{JSON.stringify(a)}}) e ${{labelB}} (${{JSON.stringify(b)}})`);
    }}
  }}

  // 1) Verifica proporção renderizada do logotipo no cabeçalho
  {{
    const ctx = await browser.newContext({{ viewport: {{ width: 1365, height: 900 }}, reducedMotion: 'reduce' }});
    const pg = await ctx.newPage();
    pg.on('pageerror', e => erros.push(String(e)));
    await pg.goto(base + '?lang=en', {{ waitUntil: 'networkidle' }});
    const dimsLogo = await pg.evaluate(() => {{
      const bio = document.querySelector('.marca-logo .marca-biomapa').getBoundingClientRect();
      const bra = document.querySelector('.marca-logo .marca-brasil').getBoundingClientRect();
      const bbBio = document.querySelector('.marca-logo .marca-biomapa').getBBox();
      const bbBra = document.querySelector('.marca-logo .marca-brasil').getBBox();
      return {{
        bioW: bio.width, braW: bra.width,
        bioBBoxW: bbBio.width, braBBoxW: bbBra.width,
        braBBoxH: bbBra.height,
        gapPx: bra.top - bio.bottom,
      }};
    }});
    if (Math.abs(dimsLogo.bioW - dimsLogo.braW) > 1.2) {{
      throw new Error('Largura renderizada de BRASIL difere de BioMapa: ' + JSON.stringify(dimsLogo));
    }}
    if (dimsLogo.braBBoxH < 84 || dimsLogo.gapPx < 0.5) {{
      throw new Error('Altura ou espaçamento de BRASIL inesperado: ' + JSON.stringify(dimsLogo));
    }}
    await ctx.close();
  }}

  // 2) Verifica abertura molecular em desktop, desktop baixo e mobile para 14653 (obufagin), 14656 (Telocinobufagin) e nome IUPAC extenso (16182)
  for (const vp of [
    {{ width: 1365, height: 900, nome: 'desktop' }},
    {{ width: 1280, height: 600, nome: 'desktop_compacto' }},
    {{ width: 360, height: 640, nome: 'mobile_360' }},
  ]) {{
    const ctx = await browser.newContext({{ viewport: {{ width: vp.width, height: vp.height }}, reducedMotion: 'reduce' }});
    const pg = await ctx.newPage();
    pg.on('pageerror', e => erros.push(String(e)));

    for (const rota of [
      '?lang=en#/especie/5216933/molecula/14653',
      '?lang=en#/especie/5216933/molecula/14656',
      '#/molecula/14653',
    ]) {{
      await pg.goto(base + rota, {{ waitUntil: 'networkidle' }});
      await pg.locator('[data-pronto="1"]').waitFor({{ timeout: 15000 }});
      const geom = await pg.evaluate(() => {{
        const r = (sel) => {{
          const el = document.querySelector(sel);
          if (!el) return null;
          const s = getComputedStyle(el);
          if (s.display === 'none' || s.visibility === 'hidden' || el.hidden) return null;
          const b = el.getBoundingClientRect();
          return {{ left: b.left, top: b.top, right: b.right, bottom: b.bottom, width: b.width, height: b.height }};
        }};
        const cab = document.querySelector('.mol-cab-cena');
        const h2 = document.querySelector('#painel-titulo');
        return {{
          abertura: r('.mol-abertura'),
          barraTopo: r('.mol-barra-topo'),
          cab: r('.mol-cab-cena'),
          h2: r('#painel-titulo'),
          formula: r('.mol-formula'),
          natureza: r('.mol-natureza'),
          elementos: r('.mol-elementos'),
          instrumentos: r('.mol-instrumentos'),
          secId: r('.mol-dossie .sec-titulo'),
          origemTxt: document.querySelector('[data-cena-origem]')?.innerText || '',
          cabOverflow: cab ? cab.scrollHeight - cab.clientHeight : 0,
          docOverflowX: document.documentElement.scrollWidth - window.innerWidth,
        }};
      }});
      if (geom.origemTxt.toLowerCase().includes('unavailable') || geom.origemTxt.toLowerCase().includes('indisponível')) {{
        throw new Error(`Molécula abriu sem 3D em ${{vp.nome}} ${{rota}}: ${{geom.origemTxt}}`);
      }}
      if (geom.cabOverflow > 2) {{
        throw new Error(`Transbordamento vertical em .mol-cab-cena (${{geom.cabOverflow}}px) em ${{vp.nome}} ${{rota}}`);
      }}
      if (geom.docOverflowX > 1) {{
        throw new Error(`Transbordamento horizontal (${{geom.docOverflowX}}px) em ${{vp.nome}} ${{rota}}`);
      }}
      assertNoOverlap(geom.cab, geom.barraTopo, '.mol-cab-cena', '.mol-barra-topo');
      assertNoOverlap(geom.cab, geom.elementos, '.mol-cab-cena', '.mol-elementos');
      assertNoOverlap(geom.cab, geom.instrumentos, '.mol-cab-cena', '.mol-instrumentos');
      assertNoOverlap(geom.cab, geom.secId, '.mol-cab-cena', '.sec-titulo');
      assertNoOverlap(geom.natureza, geom.secId, '.mol-natureza', '.sec-titulo');
    }}

    // 3) Mesmo sob contingência 2D forçada (404 de rede simulando ausência de pacote 3D), zero colisão com [data-fallback]
    await pg.route(/\\/dados\\/estruturas3d/, route => route.fulfill({{ status: 404, body: '' }}));
    await pg.goto(base + '?lang=en#/especie/5216933/molecula/14653', {{ waitUntil: 'networkidle' }});
    await pg.locator('[data-vista="2d"] [data-painel-2d] svg').waitFor({{ timeout: 15000 }});
    const geom2d = await pg.evaluate(() => {{
      const r = (sel) => {{
        const el = document.querySelector(sel);
        if (!el) return null;
        const b = el.getBoundingClientRect();
        return {{ left: b.left, top: b.top, right: b.right, bottom: b.bottom, width: b.width, height: b.height }};
      }};
      return {{
        cab: r('.mol-cab-cena'),
        fallback: r('[data-fallback]'),
        estrutura2d: r('.mol-plana .estrutura'),
        secId: r('.mol-dossie .sec-titulo'),
      }};
    }});
    assertNoOverlap(geom2d.cab, geom2d.fallback, '.mol-cab-cena', '[data-fallback]');
    assertNoOverlap(geom2d.cab, geom2d.estrutura2d, '.mol-cab-cena', '.estrutura 2D');
    assertNoOverlap(geom2d.cab, geom2d.secId, '.mol-cab-cena', '.sec-titulo');
    await ctx.close();
  }}

  await browser.close();
  if (erros.length) {{
    throw new Error('Erros JS na página: ' + erros.join('; '));
  }}
}})().catch(err => {{
  console.error(err);
  process.exit(1);
}});
""",
            encoding="utf-8",
        )
        proc = subprocess.run([node_bin, str(script_js)], capture_output=True, text=True, timeout=90)
        assert proc.returncode == 0, f"Falha E2E Chromium:\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}"
    finally:
        httpd.shutdown()
        httpd.server_close()
