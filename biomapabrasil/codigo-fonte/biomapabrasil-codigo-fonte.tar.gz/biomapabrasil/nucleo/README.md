# Núcleo de dados do BioMapaBrasil

Pacote Python `bmb`. Consulta as fontes e registra a proveniência de cada consulta, monta o banco SQLite, aplica as regras de integridade, exporta os pacotes que o site lê, serve a API de consulta e a curadoria local.

BioMapaBrasil é um produto da Amazonia Works. Licenciado conforme `LICENSE` e `NOTICE.md`, na raiz do repositório.

## Instalar

Python 3.11 ou mais novo.

```bash
cd nucleo
python -m pip install -e ".[api,dev]"
```

O extra `api` traz o servidor (Starlette, uvicorn); o extra `dev` traz o pytest.

## Comandos

| Comando | O que faz |
|---|---|
| `python -m bmb construir` | consulta as fontes e monta o banco, em etapas retomáveis. Opções: `--etapas a,b` (só essas etapas), `--so "Nome científico"` (só esses táxons, para teste), `--semente arquivo.toml` (outra lista editorial), `--offline` (só o cache em disco) |
| `python -m bmb midia` | baixa as miniaturas das fotografias licenciadas e desenha as estruturas. Opções: `--so-estruturas`, `--so-imagens`, `--reavaliar` |
| `python -m bmb validar` | confere as regras do banco; termina com código 1 se houver erro |
| `python -m bmb exportar` | gera os pacotes públicos em `app/dados`: JSON, CSV, geometrias e Darwin Core Archive. Recusa a exportação se o validador achar erro. Opção: `--destino pasta` |
| `python -m bmb banco-publico --destino arquivo.sqlite` | grava a cópia do banco só com os registros publicados, o arquivo SQLite que acompanha a Release. O destino não pode ser o banco de trabalho |
| `python -m bmb auditar` | refaz conferências sobre o banco e os pacotes exportados. Opções: `--json`, `--rapido`, `--destino pasta` |
| `python -m bmb orcamento` | mede a primeira tela e os pacotes do site contra os limites de tamanho |
| `python -m bmb relatorio` | imprime o relatório de construção do banco. Opção: `--md arquivo` |
| `python -m bmb servir` | serve o site em `http://127.0.0.1:8765/` e a API em `/api/docs`. Opções: `--porta`, `--host`, `--curadoria` |
| `python -m bmb --versao` | imprime a versão do pacote |

Etapas de `construir`, na ordem: `territorios`, `universo_checklist`, `taxons`, `checklists`, `hidrografia`, `toxinas`, `compostos`, `enriquecimento`, `atividades`, `estruturas3d`, `referencias`, `evidencias`, `prontidao`, `busca`. Cada etapa lê o que a anterior gravou e pode ser repetida: atualiza os registros em vez de duplicá-los, e as respostas das fontes saem do cache com a data da consulta original.

Sequência completa:

```bash
python -m bmb construir
python -m bmb midia
python -m bmb validar
python -m bmb exportar
python -m bmb banco-publico --destino saida/biomapabrasil-publico.sqlite
python -m bmb auditar
python -m bmb orcamento
python -m bmb servir
```

## Onde ficam as coisas

| O quê | Onde | Variável |
|---|---|---|
| Banco de trabalho (SQLite) | `saida/biomapabrasil.sqlite` | `BMB_DB` |
| Saídas intermediárias (desenhos, miniaturas, geometrias 3D) | `saida/` | `BMB_SAIDA` |
| Registros internos da construção | `saida/interno/` | |
| Cache das respostas das fontes e arquivos completos | `~/.cache/biomapabrasil` | `BMB_CACHE` |
| Pacotes públicos | `../app/dados/` | opção `--destino` de `exportar` |
| Lista editorial de espécies e política de exclusão | `semente/taxa.toml` | |
| Linhagens farmacológicas, com a frase da obra citada | `semente/linhagens.toml` | |
| Substâncias não publicadas como constituinte sem conferência de curador | `semente/nao_constituintes.toml` | |
| Moléculas em fase 4 classificadas como metabólito ubíquo ou insumo | `semente/fase4_metabolitos_e_insumos.toml` | |
| Limiar do recorte, licenças de imagem aceitas, intervalo entre requisições por servidor | `bmb/config.py` | |
| Esquema do banco | `bmb/migracoes/` | |

As pastas `saida/` e `../app/dados/` não são versionadas.

## Onde cada regra é aplicada

| Regra | Módulo |
|---|---|
| Toda contagem e toda afirmação apontam a consulta de origem | `bmb/http.py` registra cada consulta; o esquema exige `consulta_id`; `bmb/validar.py` confere |
| Ausência é declarada: nulo é fonte não consultada, zero é consultada sem resultado | restrições `CHECK` do esquema; `motivo_recorte` obrigatório |
| Organismo da fonte resolvido para a espécie aceita | `bmb/taxonomia.py` |
| Compostos por fonte | `bmb/conectores/lotus.py`, `nubbe.py`, `npatlas_coconut.py` |
| Bioatividade resumida pela mediana | `bmb/bioatividade.py` |
| Nível de evidência | `bmb/literatura.py` |
| Procedência do material e distribuição da espécie | `bmb/procedencia.py` |
| Integridade das referências | `bmb/bibliografia.py` |
| Linhagens farmacológicas e vias do Reactome | `bmb/conectores/linhagem_vias.py` |
| Regras de integridade e estado de publicação | `bmb/quarentena.py` |
| Localidade até país e unidade da federação | `bmb/conectores/nubbe.py`, `ena.py`, `bmb/literatura.py`, `bmb/curadoria.py` |
| Fotografia só com licença CC0 ou CC BY, autor e página de origem | restrição `CHECK` em `midia`; `bmb/conectores/gbif.py` |
| Associação documentada não é eficácia | enunciados de `bmb/texto.py`; restrição `CHECK` impede táxon em bioatividade e efeito clínico; `bmb/validar.py` recusa termo de alegação terapêutica |
| Seleção do que é público | `bmb/exportar/pacotes.py`, usado pelos demais exportadores, pela API e por `bmb/exportar/banco_publico.py` |

Os critérios estão em `../docs/METODOLOGIA.md` e o esquema, em `../docs/MODELO_DE_DADOS.md`.

## Curadoria local

```bash
python -m bmb servir --curadoria
```

O comando imprime o endereço da curadoria com o token da sessão. A curadoria escreve no banco e só roda em endereço local. Só o registro de uma leitura de curador, com nome, trecho lido e data, leva uma afirmação ao estado `verificado`. A sensibilidade marcada na leitura define a classe de acesso; afirmações `restrito` e `comunitario` não são exportadas.

## Testes

```bash
python -m pytest
```

Os testes não usam rede: os conectores são testados com respostas simuladas, o banco com dados de teste e a API com o cliente de teste do Starlette.

## Fontes e licenças

As fontes e suas licenças estão em `bmb/db.py` (`FONTES`) e em `../NOTICE.md`. A compilação é distribuída sob CC BY 4.0; as afirmações derivadas do ChEMBL mantêm CC BY-SA 3.0. O Darwin Core Archive traz só afirmações de LOTUS, NuBBE-DB, NPAtlas e UniProt.
