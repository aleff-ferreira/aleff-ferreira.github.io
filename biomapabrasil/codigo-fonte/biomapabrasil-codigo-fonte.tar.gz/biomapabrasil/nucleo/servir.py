# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Servidor local para plataforma/app (prefere ASGI bmb.api quando disponível; senão HTTP estático).

Diferença para `python -m http.server`:
  * quando o banco SQLite e o ambiente ASGI (uvicorn/starlette) estão presentes, serve a API completa
    (`/api/...`, `/api/docs`, `/api/openapi.json`) em conjunto com `app/`;
  * no modo estático, manda `Cache-Control: no-cache`, declara MIME certos (.webmanifest, .webp, .svg, .sdf)
    e resolve rotas de instantâneo `/api/...` em `_site/` quando disponível.

Uso: python plataforma/nucleo/servir.py [porta]
"""
import functools
import http.server
import os
import sys
from pathlib import Path

NUCLEO = Path(__file__).resolve().parent
PROJETO = NUCLEO.parent
RAIZ = PROJETO / "app"


def _tentar_asgi(porta):
    db_path = Path(os.environ.get("BMB_DB") or (NUCLEO / "saida" / "biomapabrasil.sqlite"))
    if not db_path.is_file():
        return False
    if str(NUCLEO) not in sys.path:
        sys.path.insert(0, str(NUCLEO))
    try:
        import uvicorn
        from bmb import api
    except ImportError:
        return False
    print(f"BioMapaBrasil (ASGI + API) em http://127.0.0.1:{porta}/  (docs em /api/docs)", flush=True)
    app_asgi = api.criar_app(caminho_db=db_path, app_dir=RAIZ)
    try:
        uvicorn.run(app_asgi, host="127.0.0.1", port=porta, log_level="warning")
    except KeyboardInterrupt:
        pass
    return True


class Manipulador(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map,
                      ".webmanifest": "application/manifest+json", ".json": "application/json", ".webp": "image/webp",
                      ".svg": "image/svg+xml", ".js": "text/javascript", ".mjs": "text/javascript", ".csv": "text/csv; charset=utf-8",
                      ".sdf": "chemical/x-mdl-sdfile; charset=utf-8", ".txt": "text/plain; charset=utf-8"}

    def translate_path(self, path):
        limpo = path.split("?", 1)[0].split("#", 1)[0]
        if limpo == "/api" or limpo.startswith("/api/"):
            site_dir = PROJETO / "_site"
            sub = limpo.lstrip("/")
            for cand in (RAIZ / sub, RAIZ / sub / "index.html", RAIZ / sub / "index.json",
                         site_dir / sub, site_dir / sub / "index.html", site_dir / sub / "index.json"):
                if cand.is_file():
                    return str(cand)
        return super().translate_path(path)

    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()

    def log_message(self, formato, *args):  # silencioso: o terminal do dono do projeto não precisa de cada GET
        pass


def main():
    porta = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
    if _tentar_asgi(porta):
        return
    base = RAIZ if (RAIZ / "dados").is_dir() or not (PROJETO / "_site" / "index.html").is_file() else (PROJETO / "_site")
    servidor = http.server.ThreadingHTTPServer(("127.0.0.1", porta), functools.partial(Manipulador, directory=str(base)))
    print(f"BioMapaBrasil (estático) em http://127.0.0.1:{porta}/  (pasta {base})", flush=True)
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
