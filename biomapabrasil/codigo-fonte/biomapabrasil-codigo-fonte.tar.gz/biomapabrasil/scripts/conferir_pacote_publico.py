#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Confere que uma pasta destinada ao público (site, pacotes de dados, instantâneos da API) só traz o que é público.

O contrato está em `docs/dev/CONTRATO_DE_DADOS.md`. Este script falha (código 1) se encontrar, em qualquer arquivo
de texto da pasta:

  * chaves ou colunas internas (retenção, regras, colunas antigas de procedência, validação por amostragem);
  * códigos de regra de retenção ou níveis de procedência extintos (T1…T5);
  * arquivos que não fazem parte do pacote público;
  * no código e nos textos do site, vocabulário de diagnóstico interno.

Títulos de artigos e nomes de substâncias são texto de terceiros e podem conter qualquer palavra: por isso, nos
arquivos de dados, palavras comuns só são procuradas em CHAVES; nos valores procuram-se apenas identificadores
internos inconfundíveis.

Uso:  python scripts/conferir_pacote_publico.py app/dados [_site …]
"""
from __future__ import annotations

import csv
import json
import re
import sys
from pathlib import Path

ARQUIVOS_PROIBIDOS = re.compile(r"(^|/)(quarentena|retencoes|resumo_retencoes|benchmark_validacao)[^/]*\.(json|csv|md)$", re.I)
CHAVE_PROIBIDA = re.compile(
    r"quarentena|quarantine|retid[ao]|retenc|rejeitad|regra_|motivo_exclusao|nivel_procedencia|escopo_biogeografico|"
    r"benchmark|kappa|\bac1\b|pabak|organismo_fonte$|sinonimo_legado|localidade", re.I)
VALOR_PROIBIDO = re.compile(
    r"\b(?:TAX|NAT|LIT|REF|BIO|PROV|LIN|MOL|REG|FONTE|LEGADO)-[A-Z][A-Z0-9]+(?:-[A-Z0-9]+)*\b|"
    r"\bT[1-5][ab]?_[a-z_]+|motivo_quarentena|regra_quarentena|nivel_procedencia|escopo_biogeografico|"
    r"quarentena\.json|benchmark_validacao|amazonica_estrita|procedencia_amazonica_estrita")
# No código e nos textos do site não há texto de terceiros: o vocabulário de diagnóstico interno não aparece.
TEXTO_DO_SITE_PROIBIDO = re.compile(
    r"quarentena|quarantine|benchmark|N\s?=\s?360|\bAC1\b|kappa|κ de Cohen|\bT[1-5][ab]?\b ?[·–-] ?|T1–T[35]|"
    r"retid[ao]s? |rejeitad[ao]s? |contradi[çc][ãa]o|contradiction", re.I)
CODIGOS_DE_REGRA_LEGITIMOS = {"REG-344"}          # nunca deve aparecer; listado para deixar a intenção explícita
EXT_DADOS = {".json", ".geojson", ".csv", ".tsv", ".txt", ".xml"}
EXT_SITE = {".html", ".js", ".mjs", ".css", ".webmanifest", ".md", ".svg"}


def _andar(obj, caminho, achados, arq):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(k, str) and " " in k:
                # chave que é frase (dicionário de tradução): vale o vocabulário de texto do site, não o de nomes de campo
                m = TEXTO_DO_SITE_PROIBIDO.search(k) or VALOR_PROIBIDO.search(k)
                if m:
                    achados.append((arq, f"frase com «{m.group(0)}»: «{k[:80]}»"))
            elif isinstance(k, str) and CHAVE_PROIBIDA.search(k):
                achados.append((arq, f"chave «{k}» em {caminho or '/'}"))
            _andar(v, f"{caminho}/{k}", achados, arq)
    elif isinstance(obj, list):
        for i, v in enumerate(obj[:50000]):
            _andar(v, f"{caminho}[{i}]" if i < 3 else caminho, achados, arq)
    elif isinstance(obj, str):
        m = VALOR_PROIBIDO.search(obj)
        if m:
            achados.append((arq, f"valor «{m.group(0)}» em {caminho}"))


def conferir(pasta: Path) -> list[tuple[str, str]]:
    achados: list[tuple[str, str]] = []
    for arq in sorted(p for p in pasta.rglob("*") if p.is_file()):
        rel = arq.relative_to(pasta).as_posix()
        if ARQUIVOS_PROIBIDOS.search(rel):
            achados.append((rel, "arquivo que não faz parte do pacote público"))
            continue
        ext = arq.suffix.lower()
        if ext not in EXT_DADOS | EXT_SITE:
            continue
        texto = arq.read_text(encoding="utf-8", errors="replace")
        de_dados = ext in EXT_DADOS or "/dados/" in f"/{rel}" or rel.startswith(("dados/", "api/"))
        if ext in (".json", ".geojson"):
            try:
                _andar(json.loads(texto), "", achados, rel)
                continue
            except json.JSONDecodeError:
                pass
        if ext == ".csv":
            cabecalho = next(csv.reader(texto.splitlines()[:1]), [])
            for col in cabecalho:
                if CHAVE_PROIBIDA.search(col):
                    achados.append((rel, f"coluna «{col}»"))
        m = VALOR_PROIBIDO.search(texto)
        if m:
            achados.append((rel, f"identificador interno «{m.group(0)}»"))
        if not de_dados and ext in EXT_SITE:
            for m in list(TEXTO_DO_SITE_PROIBIDO.finditer(texto))[:5]:
                linha = texto.count("\n", 0, m.start()) + 1
                achados.append((rel, f"linha {linha}: «{texto[max(0, m.start() - 30):m.end() + 30].strip()}»"))
    return achados


def main(argv: list[str]) -> int:
    if not argv:
        print(__doc__)
        return 2
    total = 0
    for nome in argv:
        pasta = Path(nome)
        if not pasta.is_dir():
            print(f"✗ {nome}: pasta inexistente")
            total += 1
            continue
        achados = conferir(pasta)
        n_arq = sum(1 for p in pasta.rglob("*") if p.is_file())
        if achados:
            print(f"✗ {nome}: {len(achados)} ocorrência(s) em {len({a for a, _ in achados})} arquivo(s)")
            for arq, o_que in achados[:40]:
                print(f"    {arq}: {o_que}")
            total += len(achados)
        else:
            print(f"✓ {nome}: {n_arq} arquivos, nada interno")
    return 1 if total else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
