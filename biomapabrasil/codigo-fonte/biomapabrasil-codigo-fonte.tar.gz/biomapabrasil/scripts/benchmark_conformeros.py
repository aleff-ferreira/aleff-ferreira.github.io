"""Compara as saídas distribuíveis a coordenadas de raios X do Platinum Dataset 2017-01."""
import argparse
import csv
import hashlib
import json
import statistics
import zipfile
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from io import BytesIO

from rdkit import Chem, rdBase
from rdkit.Chem import rdMolAlign
from rdkit.Chem.Scaffolds import MurckoScaffold
from bmb import conformeros as cf
from bmb.conectores.estruturas3d import construir_mol_3d_de_smiles

SDF_SHA = "715fa18108340f31f09c68f62a9484970b49c78653cbf950dbc411e3ab1b53d8"
POSEBUSTERS_SHA = "495a8f432ee5612c0dfa3cc582829f112bfca3c29dddc2db2c3a8dc7609e721c"
METODOS = ("legado", "etkdg", "etkdg_mmff")


def amostra(arquivo):
    with zipfile.ZipFile(arquivo) as z:
        sdf = z.read("platinum_dataset_2017_01.sdf")
    if hashlib.sha256(sdf).hexdigest() != SDF_SHA:
        raise ValueError("Edição inesperada do Platinum Dataset")
    por_scaffold = {}
    with rdBase.BlockLogs():
        for ref in Chem.ForwardSDMolSupplier(BytesIO(sdf)):
            if ref is None:
                continue
            smi = Chem.MolToSmiles(ref)
            ik = Chem.MolToInchiKey(ref)
            mol, motivo = cf.verificar(smi, ik)
            if motivo:
                continue
            scaffold = MurckoScaffold.MurckoScaffoldSmiles(mol=mol)
            nome = ref.GetProp("_Name")
            ordem = hashlib.sha256(f"BMB-Platinum-v1/{ik}/{nome}".encode()).hexdigest()
            if scaffold not in por_scaffold or ordem < por_scaffold[scaffold][0]:
                por_scaffold[scaffold] = (ordem, nome, smi, ik, Chem.MolToMolBlock(ref))
    return sorted(por_scaffold.values())[:80]


def amostra_posebusters(arquivo, platinum):
    if hashlib.sha256(arquivo.read_bytes()).hexdigest() != POSEBUSTERS_SHA:
        raise ValueError("Edição inesperada de PoseBusters")
    usados = {MurckoScaffold.MurckoScaffoldSmiles(smiles=r[2]) for r in platinum}
    por_scaffold = {}
    with zipfile.ZipFile(arquivo) as z, rdBase.BlockLogs():
        for arq in sorted(z.namelist()):
            if not arq.startswith("posebusters_benchmark_set/") or not arq.endswith("_ligand.sdf"):
                continue
            ref = Chem.MolFromMolBlock(z.read(arq).decode())
            if ref is None:
                continue
            smi, ik = Chem.MolToSmiles(ref), Chem.MolToInchiKey(ref)
            grafo, motivo = cf.verificar(smi, ik)
            if motivo:
                continue
            esqueleto = MurckoScaffold.MurckoScaffoldSmiles(mol=grafo)
            nome = arq.split("/")[1]
            ordem = hashlib.sha256(f"BMB-PoseBusters-v1/{ik}/{nome}".encode()).hexdigest()
            if esqueleto not in usados and (esqueleto not in por_scaffold or ordem < por_scaffold[esqueleto][0]):
                por_scaffold[esqueleto] = (ordem, nome, smi, ik, Chem.MolToMolBlock(ref))
    return sorted(por_scaffold.values())[:32]


def avaliar(item):
    nome, smi, ik, bloco, metodo = item
    ref = Chem.MolFromMolBlock(bloco)
    if metodo == "legado":
        mol, _, _ = construir_mol_3d_de_smiles(smi)
        blocos = [Chem.MolToMolBlock(mol)] if mol else []
    else:
        geom, _ = cf.gerar((0, nome, smi, ik, None), minimizar=metodo == "etkdg_mmff", tempo_fragmento=2 if metodo == "etkdg_2s" else 0)
        blocos = [c["sdf"] for c in geom["conformeros"]] if geom else []
    rms = []
    for bloco in blocos:
        if cf.mesma_identidade(bloco, smi, ik):
            movel = Chem.MolFromMolBlock(bloco)
            try:
                valor = rdMolAlign.GetBestRMS(movel, ref, maxMatches=4096)
            except RuntimeError:
                # Alguns grupos terminais não aceitam a simetrização automática do RDKit.
                # Enumera as isomorfias do grafo químico, mantendo a quiralidade e a mesma cota de permutações.
                matches = ref.GetSubstructMatches(movel, uniquify=False, useChirality=True, maxMatches=4096)
                if not matches:
                    continue
                valor = rdMolAlign.GetBestRMS(movel, ref, map=[list(enumerate(match)) for match in matches])
            rms.append(valor)
    return dict(ligante=nome, inchikey=ik, metodo=metodo, n=len(rms),
                rms_primeiro=round(rms[0], 5) if rms else None,
                rms_melhor=round(min(rms), 5) if rms else None)


def resumo(rows):
    out = {}
    for metodo in dict.fromkeys(r["metodo"] for r in rows):
        itens = [r for r in rows if r["metodo"] == metodo]
        ok = [r for r in itens if r["n"]]
        out[metodo] = {"n": len(itens), "sucessos": len(ok),
                       "mediana_primeiro": statistics.median(r["rms_primeiro"] for r in ok),
                       "mediana_melhor": statistics.median(r["rms_melhor"] for r in ok),
                       "cobertura_1A": sum(r["rms_melhor"] <= 1 for r in ok) / len(itens)}
    return out


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("zip", type=Path)
    p.add_argument("csv", type=Path)
    p.add_argument("--posebusters", type=Path, help="ZIP experimental externo. Grava <csv>.posebusters.csv")
    args = p.parse_args()
    refs = amostra(args.zip)
    if len(refs) != 80:
        raise ValueError("Amostra incompleta")
    fases = defaultdict(list)
    with ProcessPoolExecutor(max_workers=3) as pool:
        for fase, grupo in (("selecao", refs[:32]), ("teste", refs[32:])):
            entrada = [(nome, smi, ik, bloco, metodo) for _, nome, smi, ik, bloco in grupo for metodo in METODOS]
            fases[fase] = [dict(fase=fase, **r) for r in pool.map(avaliar, entrada)]
            stats = resumo(fases[fase])
            print(fase, json.dumps(stats), flush=True)
            if fase == "selecao":
                # Critério fixado antes do teste: cobertura (inclui falhas), depois RMSD de ensemble e do primeiro.
                vencedor = min(stats, key=lambda m: (-stats[m]["cobertura_1A"], stats[m]["mediana_melhor"], stats[m]["mediana_primeiro"]))
                print("Seleção:", vencedor, flush=True)
    with args.csv.open("w") as f:
        writer = csv.DictWriter(f, fieldnames=next(iter(fases["teste"])).keys())
        writer.writeheader()
        for rows in fases.values():
            writer.writerows(rows)

    if args.posebusters:
        grupo = amostra_posebusters(args.posebusters, refs)
        if len(grupo) != 32:
            raise ValueError("Amostra externa incompleta")
        entrada = [(n, s, ik, b, m) for _, n, s, ik, b in grupo for m in (*METODOS, "etkdg_2s")]
        with ProcessPoolExecutor(max_workers=3) as pool:
            rows = [dict(fase="externo", **r) for r in pool.map(avaliar, entrada)]
        print("PoseBusters", json.dumps(resumo(rows)), flush=True)
        with args.csv.with_suffix(".posebusters.csv").open("w") as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)


if __name__ == "__main__":
    main()
