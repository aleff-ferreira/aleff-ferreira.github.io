#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Monta o artefato estático `_site/` para publicação reprodutível no GitHub Pages.

Une o front-end `app/` aos pacotes de dados da Release, confere as invariantes do banco SQLite e o orçamento de
primeira tela, e gera instantâneos estáticos da API pública (`/api/docs/`, `/api/openapi.json`, `/api/saude/`,
`/api/universo/` etc.).

Só o que é público entra em `_site/`: o site, os pacotes de dados e os instantâneos da API pública. A documentação
do repositório (`docs/`), a auditoria externa (`external_audit_2026-11-15/`), o código (`nucleo/`), o banco e os
registros internos da construção (`nucleo/saida/interno/`) nunca são copiados, e o script confere isso antes de
terminar: se algo interno estiver na pasta — inclusive dentro do pacote de dados baixado —, o artefato é recusado.

O banco da Release é descompactado em um arquivo temporário, fora de `_site/`, e apagado no fim. O banco de trabalho
(`nucleo/saida/biomapabrasil.sqlite`) nunca é tocado; `--banco` guarda a cópia descompactada em um arquivo novo.
"""
from __future__ import annotations

import argparse
import gzip
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ / "nucleo"))

# Arquivos e pastas da raiz do repositório que fazem parte do site. Nada além disto e de `app/` é copiado.
ARQUIVOS_DA_RAIZ = (".nojekyll", "LICENSE", "NOTICE.md", "robots.txt", "sitemap.xml")
PASTAS_DA_RAIZ = ("assets",)
# Instantâneos da API pública: só rotas sem parâmetro obrigatório. As rotas internas não existem sem a curadoria.
ROTAS_DA_API = ("saude", "fontes", "universo", "bacias", "lacunas", "linhagens", "vias", "estruturas3d",
                "estruturas3d/experimentais", "taxa", "moleculas", "afirmacoes")


def extrair_seguro(tar_path: Path, destino: Path) -> None:
    destino.mkdir(parents=True, exist_ok=True)
    raiz_dest = destino.resolve()
    with tarfile.open(tar_path, "r:gz") as tf:
        for membro in tf.getmembers():
            alvo = (destino / membro.name).resolve()
            if alvo != raiz_dest and raiz_dest not in alvo.parents:
                raise RuntimeError(f"Caminho fora do destino no tar: {membro.name}")
        if sys.version_info >= (3, 12):
            tf.extractall(destino, filter="data")
        else:
            tf.extractall(destino)


def descompactar_gz(gz_path: Path, destino: Path) -> None:
    destino.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(gz_path, "rb") as f_in, open(destino, "wb") as f_out:
        shutil.copyfileobj(f_in, f_out)


def conferir_saida(site: Path) -> None:
    """Recusa uma pasta de saída que apagaria ou engoliria o repositório, ou que ficaria dentro de pasta interna."""
    site = site.resolve()
    if site == RAIZ or site in RAIZ.parents:
        raise SystemExit(f"--saida {site} contém o repositório; escolha uma pasta própria, como _site.")
    for interna in ("nucleo", "docs", "app", "external_audit_2026-11-15", "scripts", ".git"):
        pasta = (RAIZ / interna).resolve()
        if site == pasta or pasta in site.parents:
            raise SystemExit(f"--saida {site} fica dentro de {interna}/; escolha uma pasta própria, como _site.")


def _gerar_codigo_fonte(site: Path) -> None:
    """Empacota o código-fonte público correspondente (GNU AGPL-3.0), excluindo documentos e auditorias internas."""
    dst = site / "codigo-fonte" / "biomapabrasil-codigo-fonte.tar.gz"
    dst.parent.mkdir(parents=True, exist_ok=True)
    itens_raiz = ("LICENSE", "NOTICE.md", "README.md", "README.en.md", "CITATION.cff")
    pastas_pub = ("app", "assets", "nucleo", "scripts")
    ignorar = {"dados", "saida", ".venv", "__pycache__", ".pytest_cache", ".mypy_cache"}

    if (RAIZ / ".git").exists() and shutil.which("git"):
        ls = subprocess.run(
            ["git", "-C", str(RAIZ), "ls-files", "-z", "--", *itens_raiz, *pastas_pub],
            check=True,
            capture_output=True,
        ).stdout
        arqs = [
            p.decode("utf-8")
            for p in ls.split(b"\0")
            if p
            and not p.decode("utf-8").startswith(("app/dados/", "nucleo/saida/", "docs/", "external_audit"))
            and (RAIZ / p.decode("utf-8")).is_file()
        ]
        if arqs:
            with tarfile.open(dst, "w:gz") as tf:
                for rel in sorted(arqs):
                    tf.add(RAIZ / rel, arcname=f"biomapabrasil/{rel}")
            return

    with tarfile.open(dst, "w:gz") as tf:
        for nome in itens_raiz:
            f = RAIZ / nome
            if f.is_file():
                tf.add(f, arcname=f"biomapabrasil/{nome}")
        for pasta in pastas_pub:
            base = RAIZ / pasta
            if not base.is_dir():
                continue
            for p in sorted(base.rglob("*")):
                rel = p.relative_to(RAIZ)
                if any(part in ignorar for part in rel.parts) or p.suffix in {".pyc", ".sqlite"}:
                    continue
                if p.is_file():
                    tf.add(p, arcname=f"biomapabrasil/{rel.as_posix()}")


def gerar_api_estatica(db_path: Path, site_dir: Path) -> None:
    from starlette.testclient import TestClient
    from bmb import api

    # Aplicação pública: sem curadoria, as rotas internas não existem e o OpenAPI não as lista.
    app_asgi = api.criar_app(caminho_db=db_path, app_dir=site_dir, curadoria_ativa=False)
    api_dir = site_dir / "api"
    api_dir.mkdir(parents=True, exist_ok=True)

    rotas_json = [("/api", api_dir / "index.json"), ("/api/openapi.json", api_dir / "openapi.json"),
                  *((f"/api/{nome}", api_dir / nome / "index.json") for nome in ROTAS_DA_API)]

    try:
        _gravar_instantaneos(TestClient(app_asgi), api_dir, rotas_json)
    finally:
        app_asgi.state.dados.fechar()


def _gravar_instantaneos(cli, api_dir: Path, rotas_json) -> None:
    with cli:
        for url, arq in rotas_json:
            r = cli.get(url)
            assert r.status_code == 200, f"Falha ao pré-renderizar {url}: {r.status_code}"
            arq.parent.mkdir(parents=True, exist_ok=True)
            arq.write_text(r.text, encoding="utf-8")

        bacias = cli.get("/api/bacias").json().get("bacias", [])
        for b in bacias:
            bid = b["id"]
            rb = cli.get(f"/api/bacias/{bid}")
            if rb.status_code == 200:
                p = api_dir / "bacias" / bid / "index.json"
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(rb.text, encoding="utf-8")

        r_docs = cli.get("/api/docs")
        assert r_docs.status_code == 200
        html_docs = r_docs.text
        html_docs = html_docs.replace('href="/css/app.css"', 'href="../../css/app.css"')
        html_docs = html_docs.replace('href="/"', 'href="../../"')
        html_docs = html_docs.replace('href="/api/openapi.json"', 'href="../openapi.json"')
        html_docs = re.sub(rf'href="/api/({"|".join(sorted(ROTAS_DA_API, key=len, reverse=True))})"', r'href="../\1/index.json"', html_docs)
        html_docs = re.sub(r' <a href="/api/busca">testar</a>', "", html_docs)
        aviso_estatico = (
            '<p class="aviso-clinico" style="margin:1rem 0;padding:.75rem 1rem;border-radius:10px;'
            'border:1px solid rgba(110,231,183,.35);background:rgba(16,133,92,.12)">'
            "<strong>Modo estático (GitHub Pages):</strong> os links <code>testar</code> abaixo abrem instantâneos JSON "
            "pré-gerados a partir do banco. Para consultas dinâmicas com filtros (<code>?q=</code>, "
            "<code>?uf=</code>, <code>?bacia=</code>, <code>?evidencia=</code>, paginação), execute localmente "
            "<code>python -m bmb servir</code>.</p>"
        )
        html_docs = html_docs.replace("<h1>API de consulta do BioMapaBrasil</h1>", "<h1>API de consulta do BioMapaBrasil</h1>" + aviso_estatico)
        docs_out = api_dir / "docs" / "index.html"
        docs_out.parent.mkdir(parents=True, exist_ok=True)
        docs_out.write_text(html_docs, encoding="utf-8")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--dados-tar", type=Path, required=True, help="Pacote de dados da Release (biomapabrasil-app-dados-<versão>.tar.gz)")
    ap.add_argument("--sqlite-gz", type=Path, required=True, help="Banco da Release (biomapabrasil-sqlite-<versão>.gz)")
    ap.add_argument("--saida", type=Path, default=RAIZ / "_site", help="Diretório estático de saída (_site)")
    ap.add_argument("--banco", type=Path, help="guarda aqui o banco descompactado (arquivo novo, fora da saída); "
                                               "sem isto, ele fica em arquivo temporário e é apagado no fim")
    ap.add_argument("--forcar", action="store_true", help="monta o artefato mesmo com erros de validação do banco (só para depurar; nunca para publicar)")
    args = ap.parse_args(argv)

    site = args.saida.resolve()
    conferir_saida(site)
    if args.banco is not None:
        banco = args.banco.resolve()
        if banco.exists():
            raise SystemExit(f"--banco {banco} já existe; o banco da Release nunca é gravado por cima de outro arquivo.")
        if banco == site or site in banco.parents:
            raise SystemExit(f"--banco {banco} fica dentro da saída do site; o banco não faz parte do artefato.")
        return _montar(args, site, banco)
    with tempfile.TemporaryDirectory(prefix="bmb_site_") as pasta_tmp:
        return _montar(args, site, Path(pasta_tmp) / "biomapabrasil.sqlite")


def _montar(args, site: Path, db_dest: Path) -> int:
    from bmb import db, orcamento, validar
    from bmb.exportar import pacotes

    if site.exists():
        shutil.rmtree(site)

    print(f"▸ Copiando front-end app/ para {site}...")
    shutil.copytree(RAIZ / "app", site, ignore=shutil.ignore_patterns("dados"))

    print(f"▸ Extraindo pacotes de dados de {args.dados_tar.name}...")
    extrair_seguro(args.dados_tar, site / "dados")

    # O banco fica fora de _site e nunca por cima do banco de trabalho.
    print(f"▸ Descompactando banco {args.sqlite_gz.name} em {db_dest}...")
    descompactar_gz(args.sqlite_gz, db_dest)

    con = db.conectar(db_dest)
    res_v = validar.validar(con)
    con.close()
    if res_v["erros"] and not args.forcar:
        validar.imprimir(res_v, print)
        print("✗ O banco tem erros de validação; o artefato não foi montado.")
        return 1
    print(f"✓ Validador do banco: {len(res_v['ok'])} verificações sem violação, {len(res_v['avisos'])} avisos, {len(res_v['erros'])} erros")

    med = orcamento.medir(site)
    kb_ini = med["total_inicial"] / 1024
    assert kb_ini <= orcamento.ORCAMENTO["inicial"], f"Acima do orçamento inicial: {kb_ini:.1f} KB"
    print(f"✓ Orçamento de primeira tela: {kb_ini:.1f} KB <= {orcamento.ORCAMENTO['inicial']} KB gzip ({med['segundos_primeira_tela']:.1f} s)")

    print("▸ Gerando documentação e instantâneos estáticos da API pública...")
    gerar_api_estatica(db_dest, site)

    for pasta_extra in PASTAS_DA_RAIZ:
        src_extra = RAIZ / pasta_extra
        if src_extra.exists():
            shutil.copytree(src_extra, site / pasta_extra)

    for arq_raiz in ARQUIVOS_DA_RAIZ:
        p = RAIZ / arq_raiz
        if p.exists():
            shutil.copy2(p, site / arq_raiz)

    _gerar_codigo_fonte(site)

    # Fronteira: nada interno em _site, venha de onde vier (pacote de dados antigo, cópia indevida, rota nova).
    internos = pacotes.conferir_fronteira(site)
    if internos:
        for rel, o_que in internos[:40]:
            print(f"✗ {rel}: {o_que}")
        print(f"✗ {len(internos)} arquivo(s) internos em {site}; o artefato não pode ser publicado.")
        return 1

    n_total = sum(1 for p in site.rglob("*") if p.is_file())
    print(f"✓ Artefato GitHub Pages pronto em {site} ({n_total} arquivos, nada interno).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
