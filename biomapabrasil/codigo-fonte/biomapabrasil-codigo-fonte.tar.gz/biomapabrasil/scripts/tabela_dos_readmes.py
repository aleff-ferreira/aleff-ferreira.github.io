#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Tabela de números dos dois README, gerada do manifesto exportado.

Uso:
  python scripts/tabela_dos_readmes.py <manifesto.json> conferir   # compara os README com o manifesto; código 1 se diferirem
  python scripts/tabela_dos_readmes.py <manifesto.json> gravar     # reescreve a tabela nos dois README

Cada linha da tabela vem de uma chave de `contagens` ou de `universo_checklist`. Nada é digitado à mão.
"""
import json
import re
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent

# (grupo pt, item pt, grupo en, item en, caminho no manifesto)
LINHAS = [
    ("Universo de referência", "espécies aceitas com ocorrência amazônica nos catálogos nacionais",
     "Reference universe", "accepted species with Amazonian occurrence in the national checklists",
     "universo_checklist.especies_aceitas_bioma_amazonia"),
    ("", "plantas", "", "plants", "universo_checklist.por_grupo.planta.aceitas"),
    ("", "fungos", "", "fungi", "universo_checklist.por_grupo.fungo.aceitas"),
    ("", "fauna de interesse toxinológico", "", "fauna of toxinological interest", "universo_checklist.por_grupo.animal_peconhento.aceitas"),
    ("", "demais animais", "", "other animals", "universo_checklist.por_grupo.animal_outro.aceitas"),
    ("", "espécies com composto ou toxina em base aberta", "", "species with a compound or toxin in an open database",
     "universo_checklist.com_quimica_aberta"),
    ("", "plantas com registro em base aberta", "", "plants with a record in an open database",
     "universo_checklist.por_grupo.planta.com_quimica"),
    ("", "fungos com registro em base aberta", "", "fungi with a record in an open database",
     "universo_checklist.por_grupo.fungo.com_quimica"),
    ("", "fauna de interesse toxinológico com registro em base aberta", "", "fauna of toxinological interest with a record in an open database",
     "universo_checklist.por_grupo.animal_peconhento.com_quimica"),
    ("", "demais animais com registro em base aberta", "", "other animals with a record in an open database",
     "universo_checklist.por_grupo.animal_outro.com_quimica"),
    ("Táxons do banco", "total", "Taxa in the database", "total", "contagens.taxons"),
    ("", "no recorte amazônico", "", "within the Amazonian scope", "contagens.taxons_no_recorte"),
    ("", "plantas no recorte", "", "plants within the scope", "contagens.plantas"),
    ("", "animais com toxinas no recorte", "", "animals with toxins within the scope", "contagens.animais_com_toxinas"),
    ("", "fungos no recorte", "", "fungi within the scope", "contagens.fungos"),
    ("Distribuição da espécie", "endêmica do Brasil, restrita ao domínio Amazônia",
     "Species distribution", "endemic to Brazil, restricted to the Amazônia domain",
     "contagens.taxons_por_distribuicao.endemica_do_brasil_restrita_ao_dominio_amazonia"),
    ("", "endêmica do Brasil, com ocorrência na Amazônia", "", "endemic to Brazil, occurring in Amazonia",
     "contagens.taxons_por_distribuicao.endemica_do_brasil_com_ocorrencia_na_amazonia"),
    ("", "registros brasileiros concentrados na Amazônia Legal", "", "Brazilian records concentrated in the Legal Amazon",
     "contagens.taxons_por_distribuicao.registros_brasileiros_concentrados_na_amazonia_legal"),
    ("", "registros brasileiros dispersos", "", "Brazilian records dispersed",
     "contagens.taxons_por_distribuicao.registros_brasileiros_dispersos"),
    ("", "introduzida ou naturalizada", "", "introduced or naturalised", "contagens.taxons_por_distribuicao.introduzida_ou_naturalizada"),
    ("", "fora do recorte", "", "outside the scope", "contagens.taxons_por_distribuicao.fora_do_recorte"),
    ("", "indeterminada", "", "undetermined", "contagens.taxons_por_distribuicao.indeterminada"),
    ("Afirmações públicas", "total", "Public claims", "total", "contagens.afirmacoes_publicas"),
    ("", "composto em organismo", "", "compound in organism", "contagens.afirmacoes_por_tipo.composto_em_organismo"),
    ("", "bioatividade (molécula, alvo e tipo de medida)", "", "bioactivity (molecule, target and measurement type)",
     "contagens.afirmacoes_por_tipo.atividade_biologica"),
    ("", "função de toxina", "", "toxin function", "contagens.afirmacoes_por_tipo.funcao_toxina"),
    ("", "efeito clínico de fármaco aprovado", "", "clinical effect of an approved drug",
     "contagens.afirmacoes_por_tipo.efeito_clinico_documentado"),
    ("Nível de evidência", "conferido por curador", "Evidence level", "curator-verified", "contagens.afirmacoes_por_evidencia.curador"),
    ("", "trecho localizado no artigo", "", "passage located in the article", "contagens.afirmacoes_por_evidencia.artigo_trecho"),
    ("", "artigo cita o organismo", "", "article names the organism", "contagens.afirmacoes_por_evidencia.artigo_cita_organismo"),
    ("", "transcrito de base curada", "", "transcribed from a curated database", "contagens.afirmacoes_por_evidencia.base_curada"),
    ("Pares e moléculas", "pares distintos de táxon e molécula", "Pairs and molecules", "distinct taxon-molecule pairs",
     "contagens.pares_taxon_molecula"),
    ("", "pares registrados por mais de uma base", "", "pairs recorded by more than one source database",
     "contagens.pares_taxon_molecula_em_mais_de_uma_base"),
    ("", "moléculas com registro público (pequenas moléculas, peptídeos e proteínas)", "",
     "molecules with a public record (small molecules, peptides and proteins)", "contagens.moleculas"),
    ("", "pequenas moléculas, por estrutura (InChIKey)", "", "small molecules, by structure (InChIKey)", "contagens.moleculas_inchikey"),
    ("", "pequenas moléculas, por conectividade 2D", "", "small molecules, by 2D connectivity", "contagens.conectividades_2d"),
    ("Procedência do material", "coleta na Amazônia conferida no artigo por curador",
     "Provenance of the material", "collection in Amazonia verified in the article by a curator",
     "contagens.procedencia_declarada.curador_artigo_amazonia"),
    ("", "estado da Amazônia Legal, declarado pela base de origem", "", "Legal Amazon state, declared by the source database",
     "contagens.procedencia_declarada.base_declara_amazonia_legal"),
    ("", "estado brasileiro fora da Amazônia Legal, declarado pela base de origem", "",
     "Brazilian state outside the Legal Amazon, declared by the source database",
     "contagens.procedencia_declarada.base_declara_brasil_fora_da_amazonia_legal"),
    ("", "só o país, na Pan-Amazônia, declarado pela base de origem", "", "country only, within Pan-Amazonia, declared by the source database",
     "contagens.procedencia_declarada.base_declara_pais_pan_amazonico"),
    ("", "país fora da Pan-Amazônia, declarado pela base de origem", "", "country outside Pan-Amazonia, declared by the source database",
     "contagens.procedencia_declarada.base_declara_exterior"),
    ("", "não declarada", "", "not declared", "contagens.procedencia_declarada.nao_declarada"),
    ("Alvos e linhagens", "vias do Reactome ligadas a alvos com afirmação pública",
     "Targets and lineages", "Reactome pathways linked to targets with a public claim", "contagens.vias_reactome"),
    ("", "linhagens farmacológicas", "", "pharmacological lineages", "contagens.linhagens_bioinspiradas"),
    ("Referências e mídia", "obras citadas", "References and media", "works cited", "contagens.referencias"),
    ("", "fotografias com licença CC0 ou CC BY", "", "photographs under CC0 or CC BY", "contagens.imagens"),
    ("", "estruturas 3D de moléculas e de alvos", "", "3D structures of molecules and targets", "contagens.estruturas_3d"),
    ("", "estruturas 3D experimentais", "", "experimental 3D structures", "contagens.estruturas_3d_experimentais"),
    ("", "moléculas com estrutura 3D", "", "molecules with a 3D structure", "contagens.moleculas_com_3d"),
    ("Proveniência", "consultas às fontes que sustentam os registros públicos",
     "Provenance of queries", "source queries that support the public records", "contagens.consultas_registradas"),
    ("Território", "sub-bacias hidrográficas amazônicas", "Territory", "Amazonian hydrographic sub-basins", "contagens.bacias_hidrograficas"),
]

ARQUIVOS = {
    "pt": (RAIZ / "README.md", "| Grupo | Item | Registros |", "."),
    "en": (RAIZ / "README.en.md", "| Group | Item | Records |", ","),
}


def valor(manifesto, caminho):
    v = manifesto
    for parte in caminho.split("."):
        v = v[parte]
    if not isinstance(v, int) or isinstance(v, bool):
        raise TypeError(f"{caminho} não é inteiro: {v!r}")
    return v


def numero(n, separador):
    return f"{n:,}".replace(",", separador)


def tabela(manifesto, idioma):
    _, cabecalho, sep = ARQUIVOS[idioma]
    linhas = [cabecalho, "|---|---|---:|"]
    for g_pt, i_pt, g_en, i_en, caminho in LINHAS:
        grupo, item = (g_pt, i_pt) if idioma == "pt" else (g_en, i_en)
        linhas.append(f"| {grupo} | {item} | {numero(valor(manifesto, caminho), sep)} |".replace("|  |", "| |"))
    return "\n".join(linhas)


def trecho_no_arquivo(texto, cabecalho):
    inicio = texto.index(cabecalho)
    fim = inicio
    for linha in texto[inicio:].split("\n"):
        if not linha.startswith("|"):
            break
        fim += len(linha) + 1
    return inicio, fim - 1


def invariantes(manifesto):
    """Somas que a prosa dos README afirma: a evidência cobre todas as afirmações; a procedência, as de organismo."""
    c = manifesto["contagens"]
    problemas = []
    if sum(c["afirmacoes_por_tipo"].values()) != c["afirmacoes_publicas"]:
        problemas.append("afirmacoes_por_tipo não soma afirmacoes_publicas")
    if sum(c["afirmacoes_por_evidencia"].values()) != c["afirmacoes_publicas"]:
        problemas.append("afirmacoes_por_evidencia não soma afirmacoes_publicas")
    de_organismo = c["afirmacoes_por_tipo"]["composto_em_organismo"] + c["afirmacoes_por_tipo"]["funcao_toxina"]
    if sum(c["procedencia_declarada"].values()) != de_organismo:
        problemas.append("procedencia_declarada não soma as afirmações de composto e de toxina")
    if c["procedencia_declarada"].get("curador_artigo_fora_da_amazonia", 0) != 0:
        problemas.append("curador_artigo_fora_da_amazonia > 0: a tabela não tem linha para ele")
    if sum(c["taxons_por_distribuicao"].values()) != c["taxons"]:
        problemas.append("taxons_por_distribuicao não soma taxons")
    if c["plantas"] + c["animais_com_toxinas"] + c["fungos"] != c["taxons_no_recorte"]:
        problemas.append("plantas + animais + fungos não soma taxons_no_recorte")
    u = manifesto["universo_checklist"]
    if sum(g["aceitas"] for g in u["por_grupo"].values()) != u["especies_aceitas_bioma_amazonia"]:
        problemas.append("universo por grupo não soma o total")
    if sum(g["com_quimica"] for g in u["por_grupo"].values()) != u["com_quimica_aberta"]:
        problemas.append("universo com química por grupo não soma o total")
    if set(u["por_grupo"]) != {"planta", "fungo", "animal_peconhento", "animal_outro"}:
        problemas.append(f"grupos do universo inesperados: {sorted(u['por_grupo'])}")
    return problemas


def main(argv):
    if len(argv) != 2 or argv[1] not in ("conferir", "gravar"):
        print(__doc__)
        return 2
    manifesto = json.loads(Path(argv[0]).read_text(encoding="utf-8"))
    problemas = invariantes(manifesto)
    for idioma, (arquivo, cabecalho, _) in ARQUIVOS.items():
        texto = arquivo.read_text(encoding="utf-8")
        nova = tabela(manifesto, idioma)
        inicio, fim = trecho_no_arquivo(texto, cabecalho)
        atual = texto[inicio:fim]
        if atual == nova:
            print(f"{arquivo.name}: {len(LINHAS)} linhas iguais ao manifesto")
            continue
        if argv[1] == "gravar":
            arquivo.write_text(texto[:inicio] + nova + texto[fim:], encoding="utf-8")
            print(f"{arquivo.name}: tabela regravada")
        else:
            for a, n in zip(atual.split("\n"), nova.split("\n")):
                if a != n:
                    problemas.append(f"{arquivo.name}: «{a}» deveria ser «{n}»")
            if len(atual.split("\n")) != len(nova.split("\n")):
                problemas.append(f"{arquivo.name}: número de linhas diferente")
    # nenhuma chave numérica de `contagens` fica sem linha, salvo as três que a tabela não usa
    usadas = {c for *_, c in LINHAS}
    fora = {"contagens.taxons_com_predominio_de_registros_na_amazonia_legal", "contagens.afirmacoes_verificadas",
            "contagens.procedencia_declarada.curador_artigo_fora_da_amazonia"}

    def folhas(d, prefixo):
        for k, v in d.items():
            if isinstance(v, dict):
                yield from folhas(v, f"{prefixo}.{k}")
            elif isinstance(v, int) and not isinstance(v, bool):
                yield f"{prefixo}.{k}"
    todas = set(folhas(manifesto["contagens"], "contagens"))
    sem_linha = todas - usadas - fora
    if sem_linha:
        problemas.append(f"chaves de contagens sem linha na tabela: {sorted(sem_linha)}")
    for p in problemas:
        print("PROBLEMA:", p)
    return 1 if problemas else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
