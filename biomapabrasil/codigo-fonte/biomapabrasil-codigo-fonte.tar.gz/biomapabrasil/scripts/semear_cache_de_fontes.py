#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Semeia o cache do pipeline com arquivos de fonte já baixados, para reconstruir sem rede ou com rede restrita.

O pipeline lê três arquivos grandes de `BMB_CACHE/dumps` (LOTUS, Flora e Funga do Brasil, Catálogo da Fauna) e
dois pelo cache HTTP (NuBBE-DB e NPAtlas). Quem já tem esses arquivos — por exemplo, os mesmos que geraram um
banco publicado — pode colocá-los no cache com este script. Cada arquivo só é aceito se o SHA-256 for igual ao que
o banco de referência registrou em `consulta`; a data gravada é a da consulta ORIGINAL, não a de hoje.

Uso:
    python scripts/semear_cache_de_fontes.py --banco biomapabrasil.sqlite --cache ~/.cache/biomapabrasil \\
        --lotus 260413_frozen_metadata.csv.gz --jbrj jbrj.zip --ctfb ctfb.zip --nubbe output.json --npatlas NPAtlas_download.tsv
"""
import argparse
import hashlib
import json
import shutil
import sqlite3
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ / "nucleo"))

from bmb.conectores import catalogo_nacional_dwca, lotus, npatlas_coconut, nubbe  # noqa: E402
from bmb.http import Cliente  # noqa: E402

DUMPS = {
    "lotus": ("260413_frozen_metadata.csv.gz", lotus.URL_ZENODO_LOTUS_METADATA),
    "jbrj": ("jbrj_flora_funga_dwca.zip", catalogo_nacional_dwca.URL_JBRJ_DWCA),
    "ctfb": ("ctfb_fauna_dwca.zip", catalogo_nacional_dwca.URL_CTFB_DWCA),
}
HTTP = {
    "nubbe": (nubbe.URL_DUMP_NUBBE, "application/json"),
    "npatlas": (npatlas_coconut.URL_DUMP_NPATLAS, "text/tab-separated-values, */*"),
}


def sha256(caminho: Path) -> str:
    h = hashlib.sha256()
    with open(caminho, "rb") as f:
        for bloco in iter(lambda: f.read(1 << 20), b""):
            h.update(bloco)
    return h.hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--banco", required=True, help="banco de referência (somente leitura), de onde saem hash e data de cada consulta")
    ap.add_argument("--cache", required=True, help="pasta do cache do pipeline (BMB_CACHE)")
    for nome in (*DUMPS, *HTTP):
        ap.add_argument(f"--{nome}", help=f"arquivo local da fonte {nome}")
    a = ap.parse_args()

    con = sqlite3.connect(f"file:{a.banco}?mode=ro", uri=True)
    cache = Path(a.cache)
    falhas = 0
    for nome, caminho in ((n, getattr(a, n)) for n in (*DUMPS, *HTTP)):
        if not caminho:
            continue
        origem = Path(caminho)
        url = DUMPS[nome][1] if nome in DUMPS else HTTP[nome][0]
        digest = sha256(origem)
        linha = con.execute("SELECT consultado_em, versao_fonte FROM consulta WHERE url=? AND sha256=? ORDER BY id LIMIT 1",
                            (url, digest)).fetchone()
        if not linha:
            print(f"✗ {nome}: o banco não registra consulta a {url} com SHA-256 {digest[:16]}…; arquivo recusado")
            falhas += 1
            continue
        consultado_em, versao = linha
        if nome in DUMPS:
            pasta = cache / "dumps"
            pasta.mkdir(parents=True, exist_ok=True)
            destino = pasta / DUMPS[nome][0]
            if not destino.exists() or sha256(destino) != digest:
                shutil.copyfile(origem, destino)
            (pasta / f"{destino.name}.sha256").write_text(digest, encoding="utf-8")
            (pasta / f"{destino.name}.meta.json").write_text(json.dumps(
                {"consultado_em": consultado_em, "sha256": digest, "bytes": destino.stat().st_size, "versao": versao},
                ensure_ascii=False), encoding="utf-8")
        else:
            cli = Cliente(con=None, cache_dir=cache, offline=True)
            cli._gravar_cache(url, HTTP[nome][1], {"status": 200, "consultado_em": consultado_em, "versao_fonte": versao,
                                                   "cabecalhos": {}}, origem.read_bytes())
            cli.fechar()
        print(f"✓ {nome}: {origem.name} ({digest[:16]}…), consulta original de {consultado_em}")
    return 1 if falhas else 0


if __name__ == "__main__":
    raise SystemExit(main())
