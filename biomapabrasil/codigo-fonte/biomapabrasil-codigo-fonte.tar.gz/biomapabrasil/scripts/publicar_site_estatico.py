#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# BioMapaBrasil, um produto da Amazonia Works. Licenciado conforme LICENSE e NOTICE.md.
"""Publica apenas o artefato estático `_site/` em um repositório público do GitHub Pages.

Permite manter o repositório principal privado e publicar somente a versão estática compilada do site, sem código-fonte,
banco de trabalho, documentação interna ou registros da auditoria externa.

Uso:
  python scripts/publicar_site_estatico.py --site _site --repo aleff-ferreira/aleff-ferreira.github.io --subpasta biomapabrasil
"""
from __future__ import annotations

import argparse
import html
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from conferir_pacote_publico import conferir  # noqa: E402

EXTENSOES_PROIBIDAS = {".py", ".sqlite", ".sqlite3", ".sql", ".toml", ".enc"}
PASTAS_PROIBIDAS = {"docs", "nucleo", "external_audit_2026-11-15", "scripts", ".git"}
AUTOR_NOME = "Aleff Ferreira Francisco"
AUTOR_EMAIL = "aleff-ferreira@users.noreply.github.com"


def validar_site_estatico(site: Path) -> None:
    """Garante que `_site` existe, traz o site completo e não contém código nem dados internos."""
    if not site.is_dir():
        raise SystemExit(f"✗ Pasta do site não encontrada: {site}")
    if not (site / "index.html").is_file() or not (site / "dados" / "manifesto.json").is_file():
        raise SystemExit(f"✗ Pasta {site} não parece um artefato montado por scripts/preparar_pages.py.")

    achados = conferir(site)
    if achados:
        for rel, o_que in achados[:20]:
            print(f"✗ {rel}: {o_que}")
        raise SystemExit(f"✗ Conferência pública falhou ({len(achados)} ocorrência(s)); publicação cancelada.")

    bloqueados: list[str] = []
    for item in sorted(site.rglob("*")):
        partes = item.relative_to(site).parts
        if partes[0] in PASTAS_PROIBIDAS or ".git" in partes:
            bloqueados.append(f"{item.relative_to(site).as_posix()} (pasta interna/código)")
        elif item.is_file() and item.suffix.lower() in EXTENSOES_PROIBIDAS:
            bloqueados.append(f"{item.relative_to(site).as_posix()} (extensão {item.suffix})")
    if bloqueados:
        for b in bloqueados[:20]:
            print(f"✗ Bloqueado: {b}")
        raise SystemExit(f"✗ {len(bloqueados)} item(ns) proibido(s) encontrados em {site}; publicação cancelada.")


def _url_remota(repo: str, token: str | None) -> str:
    if token:
        return f"https://x-access-token:{token}@github.com/{repo}.git"
    return f"git@github.com:{repo}.git"


def _git(cmd: list[str], cwd: Path | None = None, token: str | None = None, check: bool = True) -> subprocess.CompletedProcess:
    env = {**os.environ, "GIT_TERMINAL_PROMPT": "0"}
    res = subprocess.run(["git", *cmd], cwd=cwd, text=True, capture_output=True, env=env)
    if check and res.returncode != 0:
        err = res.stderr or res.stdout
        if token:
            err = err.replace(token, "***")
        raise SystemExit(f"✗ Erro ao executar git {' '.join(cmd[:3])}: {err.strip()}")
    return res


def _html_redirecionamento(subpasta: str) -> str:
    destino = f"{subpasta.strip('/')}/"
    esc = html.escape(destino, quote=True)
    return (
        "<!doctype html>\n"
        '<html lang="pt-BR">\n'
        "<head>\n"
        '  <meta charset="utf-8">\n'
        '  <meta name="viewport" content="width=device-width, initial-scale=1">\n'
        "  <title>Amazonia Works · BioMapaBrasil</title>\n"
        f'  <meta http-equiv="refresh" content="0; url={esc}">\n'
        "</head>\n"
        "<body>\n"
        f'  <p>Redirecionando para <a href="{esc}">BioMapaBrasil</a>…</p>\n'
        "</body>\n"
        "</html>\n"
    )


def publicar(site: Path, repo: str, subpasta: str, mensagem: str, ramo: str = "main") -> bool:
    """Clona `repo`, atualiza `<subpasta>/` com `site` validado e envia para `origin <ramo>`."""
    validar_site_estatico(site)
    sub_limpa = subpasta.strip("/").strip()
    if not sub_limpa or ".." in Path(sub_limpa).parts:
        raise SystemExit(f"✗ Subpasta inválida: {subpasta!r}")

    token = os.environ.get("GH_TOKEN") or os.environ.get("PAGES_DEPLOY_TOKEN") or None
    url = _url_remota(repo, token)

    with tempfile.TemporaryDirectory(prefix="bmb_pages_pub_") as tmp:
        clone_dir = Path(tmp) / "pages_repo"
        print(f"▸ Clonando {repo} para preparação do deploy estático...")
        _git(["clone", "--depth", "1", url, str(clone_dir)], token=token)

        # Se o repositório recém-criado estiver vazio, inicializa o ramo alvo; caso contrário, garante o ramo atual.
        tem_head = _git(["rev-parse", "--verify", "HEAD"], cwd=clone_dir, check=False).returncode == 0
        if tem_head:
            _git(["checkout", "-B", ramo], cwd=clone_dir, token=token)
        else:
            _git(["checkout", "-b", ramo], cwd=clone_dir, token=token)

        nojekyll = clone_dir / ".nojekyll"
        if not nojekyll.exists():
            nojekyll.write_text("", encoding="utf-8")

        idx_raiz = clone_dir / "index.html"
        if not idx_raiz.exists():
            idx_raiz.write_text(_html_redirecionamento(sub_limpa), encoding="utf-8")

        destino = clone_dir / sub_limpa
        if destino.exists():
            shutil.rmtree(destino)
        destino.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(site, destino)

        _git(["config", "user.name", AUTOR_NOME], cwd=clone_dir)
        _git(["config", "user.email", AUTOR_EMAIL], cwd=clone_dir)
        _git(["add", "-A"], cwd=clone_dir)

        status = _git(["status", "--porcelain"], cwd=clone_dir).stdout.strip()
        if not status:
            print("✓ Nenhuma alteração no site estático para publicar.")
            return False

        _git(["commit", "-m", mensagem], cwd=clone_dir)
        print(f"▸ Enviando artefato estático para {repo} ({ramo})...")
        _git(["-c", "http.postBuffer=524288000", "push", "-u", "origin", ramo], cwd=clone_dir, token=token)
        print(f"✓ Site estático publicado em {repo}/{sub_limpa}/.")
        return True


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--site", type=Path, default=Path("_site"), help="Pasta montada por preparar_pages.py (_site)")
    ap.add_argument("--repo", required=True, help="Repositório público de destino (ex.: aleff-ferreira/aleff-ferreira.github.io)")
    ap.add_argument("--subpasta", default="biomapabrasil", help="Subpasta dentro do repositório Pages (padrão: biomapabrasil)")
    ap.add_argument("--mensagem", default="Publica site estático BioMapaBrasil v4.2.4", help="Mensagem do commit")
    ap.add_argument("--ramo", default="main", help="Ramo de destino no repositório Pages (padrão: main)")
    args = ap.parse_args(argv)
    publicar(args.site.resolve(), args.repo, args.subpasta, args.mensagem, ramo=args.ramo)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
