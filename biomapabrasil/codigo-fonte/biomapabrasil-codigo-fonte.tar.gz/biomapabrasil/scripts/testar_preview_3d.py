"""Valida e perfila o perfil molecular no site construído, usando Chromium com Playwright."""
import argparse
import hashlib
import json
import math
import re
import shutil
import statistics
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

INSTRUMENTAR = """
window.amostra3d = { frames: [], draws: 0, view: null, proj: null };
const glp = WebGL2RenderingContext.prototype;
const canvasDraw = CanvasRenderingContext2D.prototype.drawImage;
CanvasRenderingContext2D.prototype.drawImage = function(...args){
  if (this.canvas.classList.contains('lab3d-hud')) amostra3d.draws++;
  return canvasDraw.apply(this,args);
};
const locs = new WeakMap();
const localizar = glp.getUniformLocation, definir = glp.uniformMatrix4fv, draw = glp.drawArraysInstanced;
glp.getUniformLocation = function(p, n) {
  const l = localizar.call(this, p,n); if (l) locs.set(l,n); return l;
};
glp.uniformMatrix4fv = function(l,t,v) {
  const k = locs.get(l);
  if (k === 'u_view') amostra3d.view = Array.from(v);
  if (k === 'u_proj') amostra3d.proj = Array.from(v);
  return definir.call(this,l,t,v);
};
glp.drawArraysInstanced = function(...a) { amostra3d.draws++; return draw.apply(this,a); };
"""

ALVOS = """async () => {
 const {normalizarModelo3D} = await import('./js/viz/estrutura3d.js');
 const {estrutura3d} = await import('./js/dados.js');
 const info = JSON.parse(document.querySelector('[data-3d-json]').dataset['3dJson'])[0];
 const m = await normalizarModelo3D(await estrutura3d(info.arquivo));
 const rect = document.querySelector('.lab3d-hud').getBoundingClientRect();
 const mult = (a,p) => [0,1,2,3].map(i=>a[i]*p[0]+a[i+4]*p[1]+a[i+8]*p[2]+a[i+12]*p[3]);
 const pts = m.atomos.map(a=>{
   const v = mult(amostra3d.view,[a.x,a.y,a.z,1]);
   const n = mult(amostra3d.proj,v);
   return {x:rect.left+(n[0]/n[3]+1)*rect.width/2,y:rect.top+(1-n[1]/n[3])*rect.height/2,z:v[2],i:a.idx};
 });
 const atom = pts.reduce((a,b)=> a.z>b.z?a:b);
 const bonds = m.ligacoes.map((b,i)=>{
   const a=pts[b.a],c=pts[b.b];
   return {x:(a.x+c.x)/2,y:(a.y+c.y)/2,len:Math.hypot(a.x-c.x,a.y-c.y),i};
 }).sort((a,b)=>b.len-a.len);
 return {atom,bonds};
}"""

PERFIL = """async () => {
 const cv = document.querySelector('.lab3d-hud'), b = cv.getBoundingClientRect();
 const x=b.x+b.width*.55,y=b.y+b.height*.54;
 const envia=(type,ox,oy)=>cv.dispatchEvent(new PointerEvent(type,{bubbles:true,pointerId:1,clientX:x+ox,clientY:y+oy}));
 envia('pointerdown',0,0);
 const fim = performance.now()+4200, gaps=[], js=[], inicio=performance.now();
 let ult=null, draws=amostra3d.draws, nDraw=0;
 await new Promise(resolve=>{
   function tick(t) {
     if (ult!==null && t-inicio>450) {gaps.push(t-ult); if(amostra3d.draws>draws)nDraw++;}
     draws=amostra3d.draws; ult=t;
     const s=performance.now(); envia('pointermove',Math.sin(t*.003)*72,Math.cos(t*.002)*38); js.push(performance.now()-s);
     if(t<fim)requestAnimationFrame(tick); else {envia('pointerup',0,0);resolve();}
   }
   requestAnimationFrame(tick);
 });
 const gl=document.querySelector('.lab3d-gl').getContext('webgl2'), ext=gl.getExtension('WEBGL_debug_renderer_info');
 return {gaps,js,desenhados:nDraw,renderizador:ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),
   dpr_final:cv.width/b.width};
}"""


def percentil(valores, p):
    dados = sorted(valores)
    return round(dados[min(len(dados)-1, int(p*len(dados)))], 2)


def esperar(pg, condicao, argumento=None):
    fim = time.monotonic() + 15
    while not pg.evaluate(condicao, argumento):
        if time.monotonic() >= fim:
            raise AssertionError(condicao)
        pg.wait_for_timeout(30)


def diedro_sdf(sdf, ids):
    linhas = sdf.splitlines()
    p = [[float(linhas[4+i][x:x+10]) for x in (0,10,20)] for i in ids]
    sub = lambda a,b: [x-y for x,y in zip(a,b)]
    dot = lambda a,b: sum(x*y for x,y in zip(a,b))
    a, eixo, b = sub(p[0],p[1]), sub(p[2],p[1]), sub(p[3],p[2])
    eixo = [x/math.hypot(*eixo) for x in eixo]
    v = sub(a,[dot(a,eixo)*x for x in eixo])
    w = sub(b,[dot(b,eixo)*x for x in eixo])
    cruz = [eixo[(i+1)%3]*v[(i+2)%3]-eixo[(i+2)%3]*v[(i+1)%3] for i in range(3)]
    return math.degrees(math.atan2(dot(cruz,w),dot(v,w)))


def rodar(browser, args, mobile):
    nome = "mobile" if mobile else "desktop"
    ctx = browser.new_context(viewport={"width": 390 if mobile else 1365, "height": 844 if mobile else 900},
                              device_scale_factor=2.75 if mobile else 1, has_touch=mobile, is_mobile=mobile,
                              reduced_motion="reduce", service_workers="block", accept_downloads=True)
    ctx.add_init_script(INSTRUMENTAR)
    pg = ctx.new_page()
    cdp = ctx.new_cdp_session(pg)
    cdp.send("Emulation.setCPUThrottlingRate", {"rate": 4 if mobile else 1})
    erros = []
    pg.on("pageerror", lambda e: erros.append(str(e)))
    pg.goto(f"{args.url}/#/molecula/{args.id}", wait_until="domcontentloaded")
    pronto = pg.locator('[data-pronto="1"]')
    pronto.wait_for(timeout=45000)
    esperar(pg, "()=>amostra3d.draws>0")
    primeiro = round(pg.evaluate("performance.now()"))
    pg.wait_for_timeout(200)
    cont = pg.evaluate("amostra3d.draws")
    pg.wait_for_timeout(250)
    assert pg.evaluate("amostra3d.draws") == cont, "Movimento automático com redução ativa"
    assert pg.locator(".mapa-coluna").is_hidden() and pg.locator(".mol-abertura").evaluate("e=>e === e.parentElement.firstElementChild")
    assert pg.locator(".mol-abertura").bounding_box()["width"] >= pg.viewport_size["width"]-2
    assert pg.evaluate("document.documentElement.scrollWidth<=innerWidth+1")
    pg.screenshot(path=args.destino/f"{nome}.png")
    alvos = pg.evaluate(ALVOS)
    item = pg.locator("[data-item]")
    apontar = pg.touchscreen.tap if mobile else pg.mouse.move
    a = alvos["atom"]
    apontar(a["x"],a["y"])
    assert item.input_value() == f"at:{a['i']}"
    for b in alvos["bonds"][:12]:
        apontar(b["x"], b["y"])
        if item.input_value() == f"bd:{b['i']}":
            break
    else:
        raise AssertionError("Ligação inacessível no palco")
    assert "Å" in pg.locator("[data-propriedades]").inner_text()
    pg.locator("[data-fixar]").click()
    assert pg.locator(".mol-fixado").count() == 1
    hud = pg.locator(".lab3d-hud")
    hud.focus()
    antes = item.input_value()
    hud.press("]")
    assert item.input_value() != antes
    hud.press("Enter")
    assert pg.locator(".mol-fixado").count() == 2
    pg.locator("[data-comparacao] summary").click()
    rows = pg.locator("[data-angulos] tbody tr")
    assert rows.count() >= 2
    quartet = [int(x) for x in pg.locator("[data-torcao]").input_value().split(",")]
    info = json.loads(pronto.get_attribute("data-3d-json"))[0]
    for j in range(rows.count()):
        sdf_ref = pg.request.get(f"{args.url}/api/estruturas3d/{info['id']}/sdf?conformero={j+1}")
        assert sdf_ref.status == 200
        mostrado = float(rows.nth(j).locator("td").first.inner_text().replace("°","").replace(",","."))
        assert abs(diedro_sdf(sdf_ref.text(),quartet) - mostrado) <= .0051
    pg.locator("[data-conf]").select_option("1")
    assert pg.locator(".mol-fixado").count() == 2
    with pg.expect_download() as dl:
        pg.locator("[data-3d-sdf]").click()
    sob = Path(dl.value.path()).read_bytes()
    with pg.expect_download() as dl:
        pg.locator("[data-xyz]").click()
    xyz = Path(dl.value.path()).read_text().splitlines()
    sdf = sob.decode().splitlines()
    n = int(sdf[3][:3])
    assert n == int(xyz[0])
    for a, b in zip(sdf[4:4+n], xyz[2:], strict=True):
        assert a[31:34].strip() == b.split()[0]
        assert [float(a[i:i+10]) for i in (0,10,20)] == [float(v) for v in b.split()[1:]]
    api = pg.request.get(f"{args.url}/api/estruturas3d/{info['id']}/sdf?conformero=2")
    assert api.status == 200 and api.body() == sob
    assert pg.request.get(f"{args.url}/api/estruturas3d/{info['id']}/sdf?conformero=99").status == 404
    pg.locator('[data-modo-est="2d"]').click()
    pg.locator('[data-painel-2d] svg').wait_for()
    pg.locator('[data-modo-est="3d"]').click()
    # Escala óptica, inclusive zoom com dois dedos.
    hud.scroll_into_view_if_needed()
    escala = lambda: pg.locator('[data-escala]').evaluate("e=>parseFloat(e.style.width)")
    v = escala()
    if mobile:
        box = hud.bounding_box()
        x,y = box["x"]+box["width"]/2, box["y"]+box["height"]/2
        for kind, dx in [("touchStart",22),("touchMove",45),("touchEnd",0)]:
            pontos = [{"x":x-dx,"y":y,"id":2},{"x":x+dx,"y":y,"id":3}] if dx else []
            cdp.send("Input.dispatchTouchEvent",{"type":kind,"touchPoints":pontos})
    else:
        hud.hover(); pg.mouse.wheel(0,-250)
    esperar(pg, "(v)=>parseFloat(document.querySelector('[data-escala]').style.width)>v*1.05", v)
    hud.press("0")
    perfil = pg.evaluate(PERFIL)
    assert perfil["desenhados"] >= len(perfil["gaps"])*.90, "A cena não acompanhou o arrasto"
    pg.evaluate("document.querySelector('.lab3d-gl').getContext('webgl2').getExtension('WEBGL_lose_context').loseContext()")
    pg.locator("[data-render-status]").wait_for()
    assert "WebGL" in pg.locator("[data-render-status]").inner_text()
    # A troca pode exigir mais de um quadro para compor a nova camada. Depois deve ficar ociosa.
    pg.wait_for_function("document.querySelector('[data-lab3d-palco]').dataset.motor==='atlas'")
    pg.wait_for_timeout(1000)
    simples_parado = pg.evaluate("amostra3d.draws")
    pg.wait_for_timeout(650)
    assert pg.evaluate("amostra3d.draws") == simples_parado, "Repintura ociosa com WebGL indisponível"
    # Segunda cena no limite superior de tamanho, com a abertura animada e teste de repouso ao final.
    pg.emulate_media(reduced_motion="no-preference")
    pg.goto(f"{args.url}/#/molecula/{args.complexa}")
    pg.reload(wait_until="domcontentloaded")
    pronto.wait_for()
    esperar(pg, "()=>amostra3d.draws>0")
    pg.wait_for_timeout(1650)
    parado = pg.evaluate("amostra3d.draws")
    pg.wait_for_timeout(300)
    assert pg.evaluate("amostra3d.draws") == parado, "A abertura não entrou em repouso"
    denso = pg.evaluate(PERFIL)
    assert denso["desenhados"] >= len(denso["gaps"])*.90
    # O catálogo disponibiliza os dois caminhos e o erro de pacote exibe o desenho de contingência.
    pg.goto(f"{args.url}/#/especie/{args.gbif}/molecula/{args.id}")
    pronto.wait_for()
    pg.route(re.compile(r"/dados/estruturas3d(?:/ens_|_ensembles/)"), lambda route: route.fulfill(status=404,body=""))
    pg.reload()
    pg.locator('[data-vista="2d"] [data-painel-2d] svg').wait_for()
    assert "3D indisponível" in pg.locator("[data-cena-origem]").inner_text()
    pg.goto(f"{args.url}/#/molecula/{args.ausente}")
    pg.get_by_text("Sem coordenadas 3D verificadas",exact=False).wait_for()
    assert not erros, erros
    ctx.close()
    return {"viewport": "390×844" if mobile else "1365×900", "dpr": 2.75 if mobile else 1, "cpu_throttle": 4 if mobile else 1,
            "renderizador": perfil["renderizador"], "dpr_final":round(perfil["dpr_final"],2),"primeiro_quadro_ms":primeiro,
            "quadros":len(perfil["gaps"]), "p50_ms":round(statistics.median(perfil["gaps"]),2), "p95_ms":percentil(perfil["gaps"],.95),
            "evento_p95_ms":percentil(perfil["js"],.95),
            "molecula_complexa":args.complexa, "complexa_p50_ms":round(statistics.median(denso["gaps"]),2),
            "complexa_p95_ms":percentil(denso["gaps"],.95),"sdf_selecionado_sha256":hashlib.sha256(sob).hexdigest()}


def conferir_atribuicoes(browser, args):
    with browser.new_context(reduced_motion="reduce", service_workers="block") as ctx:
        pg = ctx.new_page()
        for mid, item, esperado in [(226,"bd:2","Aromatic"), (233,"at:18","R"),
                                    (563,"bd:1","Z"), (1437,"at:21","+1 e")]:
            pg.goto(f"{args.url}/?lang=en#/molecula/{mid}")
            pg.locator('.mol-registro').filter(has_text=f'{mid:05d}').wait_for()
            pg.locator('[data-pronto="1"]').wait_for()
            pg.locator('[data-item]').select_option(item)
            assert esperado in pg.locator('[data-propriedades] dd').all_text_contents()


def conferir_offline(browser, args):
    with browser.new_context(reduced_motion="reduce") as ctx:
        pg = ctx.new_page()
        pg.goto(f"{args.url}/?sw=1#/molecula/{args.id}")
        pg.evaluate("navigator.serviceWorker.ready")
        pg.wait_for_function("!!navigator.serviceWorker.controller")
        pg.reload()
        pg.locator('[data-pronto="1"]').wait_for()
        esperar(pg, """async()=> {
            const k = (await caches.keys()).find(k => k.endsWith('-membros3d'));
            return k && (await (await caches.open(k)).keys()).length>0;
        }""")
        ctx.set_offline(True)
        pg.reload()
        pg.locator('[data-pronto="1"]').wait_for()
        assert pg.locator('[data-conf] option').count() > 1


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url",default="http://127.0.0.1:8765")
    parser.add_argument("--id",type=int,default=349)
    parser.add_argument("--gbif",type=int,default=4181679)
    parser.add_argument("--complexa",type=int,default=1021)
    parser.add_argument("--ausente",type=int,default=256)
    parser.add_argument("--chromium",default=shutil.which("chromium"))
    parser.add_argument("--swiftshader",action="store_true")
    parser.add_argument("--destino",type=Path,required=True)
    args=parser.parse_args()
    args.destino.mkdir(parents=True,exist_ok=True)
    with sync_playwright() as p:
        flags=["--use-gl=angle","--use-angle=swiftshader","--enable-unsafe-swiftshader"] if args.swiftshader else []
        browser=p.chromium.launch(executable_path=args.chromium,args=flags)
        results={name:rodar(browser,args,name=="mobile") for name in ["desktop","mobile"]}
        conferir_atribuicoes(browser, args)
        conferir_offline(browser, args)
        results["offline"]=True
        results["chromium"]=browser.version
        browser.close()
    (args.destino/"perfil.json").write_text(json.dumps(results,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(results,ensure_ascii=False), flush=True)
    for nome in ("desktop", "mobile"):
        if max(results[nome]["p95_ms"], results[nome]["complexa_p95_ms"]) > 33.5:
            raise SystemExit(f"{nome}: p95 acima de 33,5 ms")


if __name__=="__main__":
    main()
