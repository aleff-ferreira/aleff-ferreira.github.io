# BioMapaBrasil

Scientific data on species of the Brazilian Legal Amazon: the natural products and toxins reported from each species, the measured bioactivity of those molecules, and the approved drugs related to them. Every record carries its source, licence, query date and evidence level.

Version 4.2.0 · [Site](https://aleff-ferreira.github.io/biomapabrasil/) · [API](https://aleff-ferreira.github.io/biomapabrasil/api/docs/) · [Português](README.md) · [Methods](docs/METODOLOGIA.md) · [Data model](docs/MODELO_DE_DADOS.md) · [Governance](docs/GOVERNANCE_SISGEN_NAGOYA_CARE.md) · [Release notes](docs/NOTAS_DA_VERSAO.md)

The project language is Brazilian Portuguese. Field names and controlled vocabularies are in Portuguese, as are the linked documents.

A documented association is not efficacy. A compound reported from an organism is a record of chemical occurrence. A bioactivity measurement describes the isolated molecule in an assay. A clinical effect describes the approved drug. No record describes an effect of the organism, of an extract or of a plant.

## What it is

The Python package `bmb` queries open scientific databases, stores each response with its provenance in an SQLite database, and exports the records that meet the integrity rules. The static site in `app/` reads the exported packages. The same selection of records is published as CSV tables, as a Darwin Core Archive and through a read-only API.

On the site a user can:

- search by species, molecule and state;
- see on the map of Brazil the taxa in the database recorded in each state;
- open the profile of a species or a molecule, with its claims, the works cited and the source queries;
- filter the tables of species and of molecules;
- explore chemical space, flows and lineages, forest strata, chemotaxonomy and sampling gaps;
- download the data.

The interface is available in Portuguese and English.

## What the data contain

The database holds four types of claim (`afirmacao`). Compound in organism comes from LOTUS, NuBBE-DB and NPAtlas. Toxin function comes from UniProtKB/Swiss-Prot (Tox-Prot). Bioactivity and clinical effect of an approved drug come from ChEMBL. GBIF provides the reference taxonomy and the occurrence counts. Flora e Funga do Brasil and the Catálogo Taxonômico da Fauna do Brasil provide the species universe and the data on origin and endemism.

Public records in version 4.2.0:

| Group | Item | Records |
|---|---|---:|
| Reference universe | accepted species with Amazonian occurrence in the national checklists | 47,118 |
| | plants | 15,066 |
| | fungi | 1,833 |
| | fauna of toxinological interest | 4,633 |
| | other animals | 25,586 |
| | species with a compound or toxin in an open database | 1,987 |
| | plants with a record in an open database | 1,750 |
| | fungi with a record in an open database | 118 |
| | fauna of toxinological interest with a record in an open database | 79 |
| | other animals with a record in an open database | 40 |
| Taxa in the database | total | 1,287 |
| | within the Amazonian scope | 1,230 |
| | plants within the scope | 1,131 |
| | animals with toxins within the scope | 70 |
| | fungi within the scope | 29 |
| Species distribution | endemic to Brazil, restricted to the Amazônia domain | 38 |
| | endemic to Brazil, occurring in Amazonia | 31 |
| | Brazilian records concentrated in the Legal Amazon | 162 |
| | Brazilian records dispersed | 578 |
| | introduced or naturalised | 4 |
| | outside the scope | 57 |
| | undetermined | 417 |
| Public claims | total | 24,114 |
| | compound in organism | 19,190 |
| | bioactivity (molecule, target and measurement type) | 4,654 |
| | toxin function | 225 |
| | clinical effect of an approved drug | 45 |
| Evidence level | curator-verified | 37 |
| | passage located in the article | 885 |
| | article names the organism | 14,891 |
| | transcribed from a curated database | 8,301 |
| Pairs and molecules | distinct taxon-molecule pairs | 18,019 |
| | pairs recorded by more than one source database | 1,141 |
| | molecules with a public record (small molecules, peptides and proteins) | 12,170 |
| | small molecules, by structure (InChIKey) | 11,945 |
| | small molecules, by 2D connectivity | 8,570 |
| Provenance of the material | collection in Amazonia verified in the article by a curator | 2 |
| | Legal Amazon state, declared by the source database | 546 |
| | Brazilian state outside the Legal Amazon, declared by the source database | 642 |
| | country only, within Pan-Amazonia, declared by the source database | 9 |
| | country outside Pan-Amazonia, declared by the source database | 15 |
| | not declared | 18,201 |
| Targets and lineages | Reactome pathways linked to targets with a public claim | 1,137 |
| | pharmacological lineages | 16 |
| References and media | works cited | 6,464 |
| | photographs under CC0 or CC BY | 1,035 |
| | 3D structures of molecules and targets | 5,741 |
| | experimental 3D structures | 30 |
| | molecules with a 3D structure | 5,690 |
| Provenance of queries | source queries that support the public records | 27,716 |
| Territory | Amazonian hydrographic sub-basins | 9 |

Evidence level covers all claims. Provenance of the material covers compound and toxin claims.

## How each record is qualified

The full description is in [docs/METODOLOGIA.md](docs/METODOLOGIA.md).

### Evidence level

The field `evidencia` states what supports the claim.

| Code | Meaning |
|---|---|
| `curador` | a curator read the passage in the publication and confirmed it |
| `artigo_trecho` | a sentence in the abstract or open full text names the organism and the compound, with a verb of isolation |
| `artigo_cita_organismo` | the title, abstract or open full text of a cited work names the organism |
| `base_curada` | the source database records the datum; the text of the work was not read |

Only `curador` means verified against the primary source. `artigo_trecho` and `artigo_cita_organismo` result from text search in the cited works. Curator verification is the next stage of the project; the table above shows how many claims have it.

### Provenance of the material and species distribution

The field `procedencia` records what is declared about where the studied material was collected, and who declares it: a curator who read the article, or the source database (NuBBE-DB, ENA). A declaration by the source database has not been checked against the article. The field `procedencia_artigo` records what a collection sentence, located in the open full text of the article, declares.

The field `distribuicao_br` describes where the species occurs, according to the national checklist and the GBIF counts. Species distribution is not provenance of the studied material and never fills the field `procedencia`.

No field carries a locality finer than country and Brazilian state. Occurrences enter as aggregate counts.

### Organism

A compound record is linked to a species only when the organism named by the source resolves, in the GBIF backbone, to the same accepted species: through the taxonomic identifier supplied by the source, or through an exact match of the full name. A match with the text of a synonym alone links nothing.

### Bioactivity

Each bioactivity claim summarises all valid ChEMBL measurements for one combination of molecule, target and measurement type. The central value is the median, and the record gives the number of measurements, the number of publications and the observed range. The nature of the target is stated in the record: single protein, protein complex, cell line, whole organism or another category of the vocabulary. Only a single protein is an individual molecular target.

### Publication

Records that do not meet the integrity rules are not published. The rules are in section 14 of the methods document; the mechanism is in [docs/MODELO_DE_DADOS.md](docs/MODELO_DE_DADOS.md).

## Access to the data

- Site: <https://aleff-ferreira.github.io/biomapabrasil/>.
- Read-only API: documentation at `/api/docs`, OpenAPI specification at `/api/openapi.json`. The taxon, molecule and claim lists accept the filters `evidencia`, `procedencia` and `coleta_amazonica_declarada`; the taxon list also accepts `distribuicao_br`. The published site serves snapshots of the parameterless routes; filters work on the local server.
- Files of [Release v4.2.0](https://github.com/aleff-ferreira/biomapabrasil/releases/tag/v4.2.0):

| File | Content |
|---|---|
| `biomapabrasil-app-dados-v4.2.0.tar.gz` | content of `app/dados/`: JSON packages, images, geometries, CSV tables and Darwin Core Archive |
| `biomapabrasil-tabelas-csv-v4.2.0.zip` | CSV tables |
| `biomapabrasil_dwca_v4.2.0.zip` | Darwin Core Archive |
| `biomapabrasil-sqlite-v4.2.0.gz` | SQLite database with the published records |
| `biomapabrasil-codigo-fonte-v4.2.0.tar.gz` | corresponding public source code (GNU AGPL-3.0) |
| `SHA256SUMS-v4.2.0.txt` | SHA-256 checksums of the files above |

## Running locally

Python 3.11 or later is required. The site and the API read the data packages and the database from the Release. Instead of `gh release download`, the three files can be downloaded from the Release page.

```bash
git clone https://github.com/aleff-ferreira/biomapabrasil.git
cd biomapabrasil

gh release download v4.2.0 \
  --pattern "biomapabrasil-app-dados-v4.2.0.tar.gz" \
  --pattern "biomapabrasil-sqlite-v4.2.0.gz" \
  --pattern "SHA256SUMS-v4.2.0.txt"
sha256sum --ignore-missing -c SHA256SUMS-v4.2.0.txt
mkdir -p app/dados nucleo/saida
tar -xzf biomapabrasil-app-dados-v4.2.0.tar.gz -C app/dados
gunzip -c biomapabrasil-sqlite-v4.2.0.gz > nucleo/saida/biomapabrasil.sqlite

python -m pip install -e "nucleo[api]"
python -m bmb servir          # site at http://127.0.0.1:8765/ and API at http://127.0.0.1:8765/api/docs
```

Alternatives, with the same data extracted:

```bash
python nucleo/servir.py       # static site only; needs nothing beyond Python
docker compose up --build     # site and API in a container, on port 8765
```

## Rebuilding from the sources

```bash
cd nucleo
python -m pip install -e ".[api,dev]"

python -m bmb construir       # queries the sources and builds the database; stages can be resumed
python -m bmb midia           # photograph thumbnails and structure drawings
python -m bmb validar         # integrity rules; an error blocks the export
python -m bmb exportar        # JSON packages, CSV, geometries and Darwin Core Archive into app/dados
python -m bmb banco-publico --destino saida/biomapabrasil-publico.sqlite   # SQLite database with the published records
python -m bmb auditar         # checks on the database and the exported packages
python -m bmb orcamento       # size of the first screen and of the site packages
python -m pytest              # tests; no network access
```

`python -m bmb construir --etapas evidencias` repeats one stage. The stages, in order: `territorios`, `universo_checklist`, `taxons`, `checklists`, `hidrografia`, `toxinas`, `compostos`, `enriquecimento`, `atividades`, `estruturas3d`, `referencias`, `evidencias`, `prontidao`, `busca`. The variables `BMB_DB`, `BMB_SAIDA` and `BMB_CACHE` set the location of the database, of the outputs and of the cache of source responses.

## Repository layout

```text
app/                 static site (HTML, CSS, JavaScript modules); reads the packages in app/dados/
nucleo/bmb/          Python package: connectors, build, validation, export, API, curation
nucleo/bmb/migracoes/  database schema, as numbered SQL migrations
nucleo/semente/      editorial species list, lineages, curated lists, base geometries, translation
nucleo/testes/       pytest suite
docs/                methods, data model, governance, release notes
scripts/             assembly of the published site, check of the public packages, source-cache seeding
.github/workflows/   tests, data build with Release publication, site publication
```

## Licences, governance and citation

- Code: GNU AGPL-3.0, with a commercial licence available from Amazonia Works ([LICENSE](LICENSE)).
- Data: the compilation is distributed under CC BY 4.0. Claims derived from ChEMBL (bioactivity and clinical effect) remain under CC BY-SA 3.0, and the deforestation-pressure and protected-area indicators per cell remain under CC BY-SA 4.0. Each claim carries the licence of its source. The Darwin Core Archive contains no ChEMBL data.
- Attribution: the sources and their licences are listed in [NOTICE.md](NOTICE.md). Each photograph carries its author, licence and source page.
- Trademark: the names Amazonia Works and BioMapaBrasil are reserved and are not covered by the code licence.
- Governance: the project collects no biological material and records no associated traditional knowledge. Species of ritual or sacred use by Indigenous peoples, and plants of controlled use, are kept out of the platform. Use of the data in research or development involving Brazilian genetic heritage is subject to Brazilian Law No. 13,123/2015 and Decree No. 8,772/2016 (registration in SisGen, <https://sisgen.gov.br/>). See [docs/GOVERNANCE_SISGEN_NAGOYA_CARE.md](docs/GOVERNANCE_SISGEN_NAGOYA_CARE.md).
- Citation: use the metadata in [CITATION.cff](CITATION.cff).

Developed and maintained by Aleff Ferreira Francisco, Amazonia Works.
