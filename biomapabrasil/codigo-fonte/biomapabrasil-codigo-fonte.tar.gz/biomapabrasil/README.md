# BioMapaBrasil

Dados científicos sobre espécies da Amazônia Legal: os produtos naturais e as toxinas relatados em cada espécie, a bioatividade medida dessas moléculas e os fármacos aprovados a elas relacionados. Cada registro traz a fonte, a licença, a data da consulta e o nível de evidência.

Versão 4.2.4 · [Site](https://aleff-ferreira.github.io/biomapabrasil/) · [API](https://aleff-ferreira.github.io/biomapabrasil/api/docs/) · [English](README.en.md) · [Metodologia](docs/METODOLOGIA.md) · [Modelo de dados](docs/MODELO_DE_DADOS.md) · [Governança](docs/GOVERNANCE_SISGEN_NAGOYA_CARE.md) · [Notas da versão](docs/NOTAS_DA_VERSAO.md)

Associação documentada não é eficácia. Um composto relatado em um organismo é um registro de ocorrência química. Uma medida de bioatividade descreve a molécula isolada em um ensaio. Um efeito clínico descreve o fármaco aprovado. Nenhum registro descreve efeito do organismo, de extrato ou de planta.

## O que é

O pacote Python `bmb` consulta bases científicas abertas, grava cada resposta com proveniência em um banco SQLite e exporta os registros que cumprem as regras de integridade. O site estático em `app/` lê os pacotes exportados. A mesma seleção de registros sai em tabelas CSV, em um Darwin Core Archive e em uma API de consulta.

No site é possível:

- buscar por espécie, molécula e estado;
- ver no mapa do Brasil os táxons do banco com registro em cada estado;
- abrir o perfil de uma espécie ou de uma molécula, com as afirmações, as obras citadas e as consultas de origem;
- filtrar as tabelas de espécies e de moléculas;
- explorar o espaço químico, os fluxos e as linhagens, os estratos florestais, a quimiotaxonomia e as lacunas de amostragem;
- baixar os dados.

A interface tem versões em português e em inglês.

## O que os dados contêm

O banco tem quatro tipos de afirmação. Composto em organismo vem do LOTUS, do NuBBE-DB e do NPAtlas. Função de toxina vem do UniProtKB/Swiss-Prot (Tox-Prot). Bioatividade e efeito clínico de fármaco aprovado vêm do ChEMBL. O GBIF fornece a taxonomia de referência e as contagens de ocorrência; a Flora e Funga do Brasil e o Catálogo Taxonômico da Fauna do Brasil fornecem o universo de espécies e os dados de origem e endemismo.

Registros públicos da versão 4.2.4:

| Grupo | Item | Registros |
|---|---|---:|
| Universo de referência | espécies aceitas com ocorrência amazônica nos catálogos nacionais | 47.118 |
| | plantas | 15.066 |
| | fungos | 1.833 |
| | fauna de interesse toxinológico | 4.633 |
| | demais animais | 25.586 |
| | espécies com composto ou toxina em base aberta | 1.987 |
| | plantas com registro em base aberta | 1.750 |
| | fungos com registro em base aberta | 118 |
| | fauna de interesse toxinológico com registro em base aberta | 79 |
| | demais animais com registro em base aberta | 40 |
| Táxons do banco | total | 1.287 |
| | no recorte amazônico | 1.230 |
| | plantas no recorte | 1.131 |
| | animais com toxinas no recorte | 70 |
| | fungos no recorte | 29 |
| Distribuição da espécie | endêmica do Brasil, restrita ao domínio Amazônia | 38 |
| | endêmica do Brasil, com ocorrência na Amazônia | 31 |
| | registros brasileiros concentrados na Amazônia Legal | 162 |
| | registros brasileiros dispersos | 578 |
| | introduzida ou naturalizada | 4 |
| | fora do recorte | 57 |
| | indeterminada | 417 |
| Afirmações públicas | total | 23.913 |
| | composto em organismo | 18.991 |
| | bioatividade (molécula, alvo e tipo de medida) | 4.652 |
| | função de toxina | 225 |
| | efeito clínico de fármaco aprovado | 45 |
| Nível de evidência | conferido por curador | 45 |
| | trecho localizado no artigo | 889 |
| | artigo cita o organismo | 14.788 |
| | transcrito de base curada | 8.191 |
| Pares e moléculas | pares distintos de táxon e molécula | 17.822 |
| | pares registrados por mais de uma base | 1.139 |
| | moléculas com registro público (pequenas moléculas, peptídeos e proteínas) | 12.133 |
| | pequenas moléculas, por estrutura (InChIKey) | 11.908 |
| | pequenas moléculas, por conectividade 2D | 8.554 |
| Procedência do material | coleta na Amazônia conferida no artigo por curador | 6 |
| | estado da Amazônia Legal, declarado pela base de origem | 546 |
| | estado brasileiro fora da Amazônia Legal, declarado pela base de origem | 642 |
| | só o país, na Pan-Amazônia, declarado pela base de origem | 9 |
| | país fora da Pan-Amazônia, declarado pela base de origem | 15 |
| | não declarada | 17.998 |
| Alvos e linhagens | vias do Reactome ligadas a alvos com afirmação pública | 1.137 |
| | linhagens farmacológicas | 16 |
| Referências e mídia | obras citadas | 6.455 |
| | fotografias com licença CC0 ou CC BY | 1.035 |
| | estruturas 3D de moléculas e de alvos | 12.184 |
| | estruturas 3D experimentais | 30 |
| | moléculas com estrutura 3D | 12.133 |
| Proveniência | consultas às fontes que sustentam os registros públicos | 34.106 |
| Território | sub-bacias hidrográficas amazônicas | 9 |

O nível de evidência cobre todas as afirmações. A procedência do material cobre as afirmações de composto e de toxina.

## Como cada registro é qualificado

A descrição completa está em [docs/METODOLOGIA.md](docs/METODOLOGIA.md).

### Nível de evidência

O campo `evidencia` diz o que sustenta a afirmação.

| Código | Significado |
|---|---|
| `curador` | um curador leu a passagem na publicação e a confirmou |
| `artigo_trecho` | uma frase do resumo ou do texto aberto cita o organismo e o composto, com verbo de isolamento |
| `artigo_cita_organismo` | o título, o resumo ou o texto aberto de uma obra citada nomeia o organismo |
| `base_curada` | a base de origem registra o dado; o texto da obra não foi lido |

Verificado em fonte primária é só o nível `curador`. Os níveis `artigo_trecho` e `artigo_cita_organismo` vêm de busca de texto nas obras citadas. A conferência por curador é a etapa seguinte do projeto; a tabela acima mostra quantas afirmações já a têm.

### Procedência do material e distribuição da espécie

O campo `procedencia` registra o que se declara sobre o local de coleta do material estudado, e quem declara: um curador que leu o artigo, ou a base de origem (NuBBE-DB, ENA). O que a base declara não foi conferido no artigo. O campo `procedencia_artigo` registra o que uma frase de coleta, localizada no texto aberto do artigo, declara.

O campo `distribuicao_br` descreve onde a espécie ocorre, segundo o catálogo nacional e as contagens do GBIF. Distribuição da espécie não é procedência do material estudado, e nunca preenche o campo `procedencia`.

Nenhum campo traz localidade mais fina que país e unidade da federação. As ocorrências entram como contagens agregadas.

### Organismo

Um registro de composto só é ligado a uma espécie quando o organismo nomeado pela fonte resolve, no backbone do GBIF, para a mesma espécie aceita: pelo identificador taxonômico que a fonte fornece ou pela correspondência exata do nome inteiro. A coincidência com o texto de um sinônimo não liga registro algum.

### Bioatividade

Cada afirmação de bioatividade resume todas as medidas válidas do ChEMBL para uma combinação de molécula, alvo e tipo de medida. O valor central é a mediana, e o registro traz o número de medidas, o número de publicações e a faixa observada. A natureza do alvo acompanha o registro: proteína única, complexo proteico, linhagem celular, organismo inteiro ou outra categoria do vocabulário. Só proteína única é alvo molecular individual.

### Publicação

Registros que não cumprem as regras de integridade não são publicados. As regras estão na seção 14 da metodologia e o mecanismo, em [docs/MODELO_DE_DADOS.md](docs/MODELO_DE_DADOS.md).

## Acesso aos dados

- Site: <https://aleff-ferreira.github.io/biomapabrasil/>.
- API de consulta, somente leitura: documentação em `/api/docs` e especificação OpenAPI em `/api/openapi.json`. As listas de táxons, de moléculas e de afirmações aceitam os filtros `evidencia`, `procedencia` e `coleta_amazonica_declarada`; a de táxons aceita também `distribuicao_br`. No site publicado ficam instantâneos das rotas sem parâmetro; os filtros funcionam no servidor local.
- Arquivos da [Release v4.2.4](https://github.com/aleff-ferreira/biomapabrasil/releases/tag/v4.2.4):

| Arquivo | Conteúdo |
|---|---|
| `biomapabrasil-app-dados-v4.2.4.tar.gz` | conteúdo de `app/dados/`: pacotes JSON, imagens, geometrias, tabelas CSV e Darwin Core Archive |
| `biomapabrasil-tabelas-csv-v4.2.4.zip` | tabelas CSV |
| `biomapabrasil_dwca_v4.2.4.zip` | Darwin Core Archive |
| `biomapabrasil-sqlite-v4.2.4.gz` | banco SQLite com os registros publicados |
| `biomapabrasil-codigo-fonte-v4.2.4.tar.gz` | código-fonte público correspondente (GNU AGPL-3.0) |
| `SHA256SUMS-v4.2.4.txt` | somas SHA-256 dos arquivos acima |

## Rodar localmente

Requer Python 3.11 ou mais novo. O site e a API leem os pacotes de dados e o banco da Release. O comando `gh release download` pode ser trocado pelo download dos três arquivos na página da Release.

```bash
git clone https://github.com/aleff-ferreira/biomapabrasil.git
cd biomapabrasil

gh release download v4.2.4 \
  --pattern "biomapabrasil-app-dados-v4.2.4.tar.gz" \
  --pattern "biomapabrasil-sqlite-v4.2.4.gz" \
  --pattern "SHA256SUMS-v4.2.4.txt"
sha256sum --ignore-missing -c SHA256SUMS-v4.2.4.txt
mkdir -p app/dados nucleo/saida
tar -xzf biomapabrasil-app-dados-v4.2.4.tar.gz -C app/dados
gunzip -c biomapabrasil-sqlite-v4.2.4.gz > nucleo/saida/biomapabrasil.sqlite

python -m pip install -e "nucleo[api]"
python -m bmb servir          # site em http://127.0.0.1:8765/ e API em http://127.0.0.1:8765/api/docs
```

Alternativas, com os mesmos dados extraídos:

```bash
python nucleo/servir.py       # só o site estático, sem dependências além do Python
docker compose up --build     # site e API em contêiner, na porta 8765
```

## Reconstruir a partir das fontes

```bash
cd nucleo
python -m pip install -e ".[api,dev]"

python -m bmb construir       # consulta as fontes e monta o banco; etapas retomáveis
python -m bmb midia           # miniaturas das fotografias e desenhos das estruturas
python -m bmb validar         # regras de integridade; erro bloqueia a exportação
python -m bmb exportar        # pacotes JSON, CSV, geometrias e Darwin Core Archive em app/dados
python -m bmb banco-publico --destino saida/biomapabrasil-publico.sqlite   # banco SQLite com os registros publicados
python -m bmb auditar         # conferências sobre o banco e os pacotes exportados
python -m bmb orcamento       # tamanho da primeira tela e dos pacotes do site
python -m pytest              # testes, sem rede
```

`python -m bmb construir --etapas evidencias` repete uma etapa. As etapas, na ordem: `territorios`, `universo_checklist`, `taxons`, `checklists`, `hidrografia`, `toxinas`, `compostos`, `enriquecimento`, `atividades`, `estruturas3d`, `referencias`, `evidencias`, `prontidao`, `busca`. As variáveis `BMB_DB`, `BMB_SAIDA` e `BMB_CACHE` mudam o local do banco, das saídas e do cache das respostas das fontes.

## Estrutura do repositório

```text
app/                 site estático (HTML, CSS, módulos JavaScript); lê os pacotes de app/dados/
nucleo/bmb/          pacote Python: conectores, construção, validação, exportação, API, curadoria
nucleo/bmb/migracoes/  esquema do banco, em migrações SQL numeradas
nucleo/semente/      lista editorial de espécies, linhagens, listas curadas, geometrias de base, tradução
nucleo/testes/       suíte pytest
docs/                metodologia, modelo de dados, governança, notas da versão
scripts/             montagem do site publicado, conferência dos pacotes públicos, preparo do cache de fontes
.github/workflows/   testes, construção dos dados com publicação da Release, publicação do site
```

## Licenças, governança e citação

- Código: GNU AGPL-3.0, com licença comercial disponível junto à Amazonia Works ([LICENSE](LICENSE)).
- Dados: a compilação é distribuída sob CC BY 4.0. As afirmações derivadas do ChEMBL (bioatividade e efeito clínico) mantêm CC BY-SA 3.0, e os indicadores de pressão de desmatamento e de área protegida por célula mantêm CC BY-SA 4.0. Cada afirmação traz a licença da sua fonte. O Darwin Core Archive não inclui dados do ChEMBL.
- Atribuição: as fontes e suas licenças estão em [NOTICE.md](NOTICE.md). Cada fotografia traz autor, licença e página de origem.
- Marca: os nomes Amazonia Works e BioMapaBrasil são reservados e não fazem parte da licença do código.
- Governança: o projeto não coleta material biológico nem registra conhecimento tradicional associado. Espécies de uso ritual ou sagrado de povos indígenas e plantas de uso controlado ficam fora da plataforma. O uso dos dados em pesquisa ou desenvolvimento com patrimônio genético brasileiro está sujeito à Lei nº 13.123/2015 e ao Decreto nº 8.772/2016 (cadastro no SisGen, <https://sisgen.gov.br/>). Ver [docs/GOVERNANCE_SISGEN_NAGOYA_CARE.md](docs/GOVERNANCE_SISGEN_NAGOYA_CARE.md).
- Citação: use os metadados de [CITATION.cff](CITATION.cff).

Desenvolvido e mantido por Aleff Ferreira Francisco, Amazonia Works.
